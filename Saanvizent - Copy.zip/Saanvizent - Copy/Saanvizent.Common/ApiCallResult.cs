﻿using Saanvizent.Common.Constants;
using Saanvizent.Common.Exceptions;

namespace Saanvizent.Common
{
   public class ApiCallResult<T>
    {
        private T value;

        /// <summary>
        /// Gets or sets a value indicating whether true if the call succeeded; false if failed
        /// </summary>
        public bool Succeeded { get; set; }

        /// <summary>
        /// Gets or sets a generic return value from a Web API call if the call succeeded
        /// </summary>
        public T Value
        {
            get
            {
                if (this.Succeeded)
                {
                    return this.value;
                }
                else if (this.ErrorResult != null)
                {
                    BusinessException exception = new BusinessException(this.ErrorResult.ErrorCode, this.ErrorResult.Message);
                    exception.Data[KeyConstants.ErrorLogID] = this.ErrorResult.ErrorLogID;
                    throw exception;
                }
                else
                {
                    throw new BusinessException(ErrorCodeConstants.UnknownException, "Unknown error");
                }
            }

            set
            {
                this.value = value;
            }
        }

        /// <summary>
        /// Gets or sets the error info from a Web API call if the call raised an exception
        /// </summary>
        public ErrorResult ErrorResult { get; set; }

    }
}
