﻿
namespace Saanvizent.Common.Enum
{
    public enum SortDirectionEnum
    {
        ASC,
        DESC
    }
}
