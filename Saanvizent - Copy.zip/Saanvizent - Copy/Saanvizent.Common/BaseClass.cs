﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common
{
    public class BaseClass: IDisposable
    {
        // Flag: Has Dispose already been called?
        private bool disposed = false;

        ~BaseClass()
        {
            this.Dispose(false);
        }

        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (this.disposed)
            {
                return;
            }

            if (disposing)
            {
                // Free any other managed objects here.
            }

            // Free any unmanaged objects here.
            this.disposed = true;
        }

    }
}
