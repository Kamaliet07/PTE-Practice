﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Constants
{
    public static class KeyConstants
    {
        public const string ErrorLogID = "ErrorLogID";
        public const string ErrorCode = "ErrorCode";
        public const string ModelState = "ModelState";
        public const string ExceptionType = "ExceptionType";
        public const string UserModelKey = "UserModel";
    }
}
