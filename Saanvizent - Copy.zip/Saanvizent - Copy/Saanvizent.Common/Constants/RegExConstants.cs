﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Constants
{
    public class RegExConstants
    {
        public const string MGANameRegEx = "^[a-zA-Z0-9_ ]*$";
        public const string PasswordRegEx = "^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[^a-zA-Z]).*$";

    }
}
