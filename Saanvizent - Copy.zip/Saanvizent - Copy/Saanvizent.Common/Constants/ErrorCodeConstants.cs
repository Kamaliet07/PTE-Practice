﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Constants
{
   public class ErrorCodeConstants
    {
        public const int UnknownException = 1000;
        public const int ApiException = 1001;
    }
}
