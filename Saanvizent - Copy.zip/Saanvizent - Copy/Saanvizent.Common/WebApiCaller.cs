﻿using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using Saanvizent.Common.Constants;
using Saanvizent.Common.Exceptions;
using Saanvizent.Common.HelperClass;
using Saanvizent.Resource;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Elmah;

namespace Saanvizent.Common
{
    public class WebApiCaller: BaseClass
    {
        private const string JSONCONTENTTYPE = "application/json";
        private const string FORMURLENCODEDCONTENTTYPE = "application/x-www-form-urlencoded";
        private string baseAddress = ConfigurationManager.AppSettings["BaseAddress"].ToString();
        private ElmahException.IElmahEventLogErrorLog errorLog = null;

        // Flag: Has Dispose already been called?
        private bool disposed = false;

        // Instantiate a SafeHandle instance.
        private SafeHandle handle = new SafeFileHandle(IntPtr.Zero, true);

        public Task<ApiCallResult<T>> GetAsJsonAsync<T>(object mGAGetNotificationTypeUrl)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Send a GET request to the specified Uri as an asynchronous operation.
        /// </summary>
        /// <typeparam name="TReturnValue">T Type Return</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <returns>Returns System.Threading.Tasks.Task<TReturnValue />.The task object representing
        /// the asynchronous operation.</returns>
        public async Task<ApiCallResult<TReturnValue>> GetAsJsonAsync<TReturnValue>(Uri url)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();
            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = await response.Content.ReadAsAsync<TReturnValue>();
                    }
                    else
                    {
                        result.ErrorResult = await this.GetErrorResult(response);
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }       

        /// <summary>
        /// Send a GET request to the specified Uri as an asynchronous operation with the given model converted as query string.
        /// </summary>
        /// <typeparam name="TParameter">T Type Return</typeparam>
        /// <typeparam name="TReturnValue">The task object representing the asynchronous operation.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <param name="model">Object that is sent along with the request.</param>
        /// <returns>Returns System.Threading.Tasks.Task</returns>
        public async Task<ApiCallResult<TReturnValue>> GetAsJsonAsync<TParameter, TReturnValue>(Uri url, TParameter model)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();

            string urlWithQueryString = url + "?" + HttpHelper.ToQueryString<TParameter>(model);

            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(urlWithQueryString);
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = await response.Content.ReadAsAsync<TReturnValue>();
                    }
                    else
                    {
                        result.ErrorResult = await this.GetErrorResult(response);
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Send a GET request to the specified Uri as an asynchronous operation.
        /// </summary>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <returns>Async Task</returns>
        public async Task GetAsync(Uri url)
        {
            using (var client = this.CreateHttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
            }
        }

        /// <summary>
        /// Sends a POST request as an asynchronous operation to the specified Uri with
        /// the given model serialized as JSON.
        /// </summary>
        /// <typeparam name="TParameter">Type of the model.</typeparam>
        /// <typeparam name="TReturnValue">Type of the return value.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <param name="model">The model that will be placed in the request's entity body.</param>
        /// <returns> A task object representing the asynchronous operation.</returns>
        public async Task<ApiCallResult<TReturnValue>> PostAsJsonAsync<TParameter, TReturnValue>(Uri url, TParameter model)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();
            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.PostAsJsonAsync(url, model);
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = await response.Content.ReadAsAsync<TReturnValue>();
                    }
                    else
                    {
                        result.ErrorResult = await this.GetErrorResult(response);
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Sends a POST request as an asynchronous operation to the specified Uri with
        /// the given model serialized as JSON.
        /// </summary>
        /// <typeparam name="TParameter">Type of the model.</typeparam>
        /// <typeparam name="TReturnValue">Type of the return value.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <param name="model">The model that will be placed in the request's entity body.</param>
        /// <param name="jsonConverter">The converter that is used to serialize the model as JSON.</param>
        /// <returns>A task object representing the asynchronous operation.</returns>
        public async Task<ApiCallResult<TReturnValue>> PostAsFormUrlEncodedAsync<TParameter, TReturnValue>(Uri url, TParameter model, JsonConverter jsonConverter = null)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();
            string parameters = model.ToQueryString();
            using (var client = this.CreateHttpClient(contentType: FORMURLENCODEDCONTENTTYPE))
            {
                try
                {
                    StringContent content = new StringContent(parameters, Encoding.UTF8, FORMURLENCODEDCONTENTTYPE);
                    HttpResponseMessage response = await client.PostAsync(url, content);
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        if (jsonConverter == null)
                        {
                            result.Value = await response.Content.ReadAsAsync<TReturnValue>();
                        }
                        else
                        {
                            result.Value = await response.Content.ReadAsAsync<TReturnValue>(new[]
                                          {
                                                new JsonMediaTypeFormatter
                                                {
                                                    SerializerSettings =
                                            new JsonSerializerSettings
                                            {
                                                Converters =
                                            new List<JsonConverter> { jsonConverter }
                                            }
                                        }
                                            });
                        }
                    }
                    else
                    {
                        result.ErrorResult = await this.GetErrorResult(response);
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Send a GET request to the specified Uri as synchronous operation.
        /// </summary>
        /// <typeparam name="TReturnValue">Type of the return value.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <returns>Json Result</returns>
        public ApiCallResult<TReturnValue> GetAsJson<TReturnValue>(Uri url)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();
            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.GetAsync(url).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = response.Content.ReadAsAsync<TReturnValue>().Result;
                    }
                    else
                    {
                        result.ErrorResult = this.GetErrorResult(response).Result;
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Send a GET request to the specified Uri as synchronous operation with model converted as
        /// querystring.
        /// </summary>
        /// <typeparam name="TParameter">Type of the model.</typeparam>
        /// <typeparam name="TReturnValue">Type of the return value.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <param name="model">The model that wil lbe converted into querystring.</param>
        /// <returns>Type of return value.</returns>
        public ApiCallResult<TReturnValue> GetAsJson<TParameter, TReturnValue>(Uri url, TParameter model)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();

            string urlWithQueryString = url + "?" + HttpHelper.ToQueryString<TParameter>(model);

            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.GetAsync(urlWithQueryString).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = response.Content.ReadAsAsync<TReturnValue>().Result;
                    }
                    else
                    {
                        result.ErrorResult = this.GetErrorResult(response).Result;
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Sends a POST request as a synchronous operation to the specified Uri with
        /// the given model serialized as JSON.
        /// </summary>
        /// <typeparam name="TParameter">Type of the model.</typeparam>
        /// <typeparam name="TReturnValue">Type of the return value.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <param name="model">The model that will be placed in the request's entity body.</param>
        /// <returns>Type Of Return</returns>
        public ApiCallResult<TReturnValue> PostAsJson<TParameter, TReturnValue>(Uri url, TParameter model)
        {
            ApiCallResult<TReturnValue> result = new ApiCallResult<TReturnValue>();
            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.PostAsJsonAsync(url, model).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = response.Content.ReadAsAsync<TReturnValue>().Result;
                    }
                    else
                    {
                        result.ErrorResult = this.GetErrorResult(response).Result;
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Send a GET request to the specified Uri as synchronous operation.
        /// </summary>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <returns>String Value</returns>
        public ApiCallResult<string> GetAsString(Uri url)
        {
            ApiCallResult<string> result = new ApiCallResult<string>();
            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.GetAsync(url).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        result.ErrorResult = this.GetErrorResult(response).Result;
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Send a GET request to the specified Uri as a synchronous operation
        /// with model converted as querystring.
        /// </summary>
        /// <typeparam name="TParameter">Type of the model.</typeparam>
        /// <param name="url">The Uri the request is sent to.</param>
        /// <param name="model">The model that will be converted into querystring.</param>
        /// <returns>String Return</returns>
        public ApiCallResult<string> GetAsString<TParameter>(Uri url, TParameter model)
        {
            ApiCallResult<string> result = new ApiCallResult<string>();

            string urlWithQueryString = url + "?" + HttpHelper.ToQueryString<TParameter>(model);

            using (var client = this.CreateHttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.GetAsync(urlWithQueryString).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result.Succeeded = true;
                        result.Value = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        result.ErrorResult = this.GetErrorResult(response).Result;
                    }
                }
                catch (Exception ex)
                {
                    // log original exception to Windows event log if service is down
                    if (this.errorLog != null)
                    {
                        string errorLogID = this.errorLog.Log(new Error(ex));
                    }

                    // return user friendly error
                    result.ErrorResult = new ErrorResult(null, ErrorCodeConstants.ApiException, CommonResource.ServiceIsUnavailable);
                }
            }

            return result;
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing">bool Value</param>
        protected override void Dispose(bool disposing)
        {
            if (this.disposed)
            {
                return;
            }

            if (disposing)
            {
                this.handle.Dispose();
            }

            // Free any unmanaged objects here.
            this.disposed = true;

            // Call base class implementation.
            base.Dispose(disposing);
        }

        /// <summary>
        /// Creates a new instance of <see cref="System.Net.Http.HttpClient"/>
        /// that can be used to sned HTTP requests and receive HTTP responses
        /// from the resource identified by Uri.
        /// </summary>
        /// <param name="contentType">Type of the content that will be sent to Uri.</param>
        /// <returns>Instance of <see cref="System.Net.Http.HttpClient"/></returns>
        private HttpClient CreateHttpClient(string contentType = JSONCONTENTTYPE)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(this.baseAddress);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(contentType));
            client.DefaultRequestHeaders.Add("Accept-Language", Thread.CurrentThread.CurrentCulture.Name);
            string webApiToken = string.Empty;
            if (!string.IsNullOrEmpty(webApiToken))
            {
                client.DefaultRequestHeaders.Add("Authorization", string.Format(CultureInfo.InvariantCulture, "Bearer {0}", webApiToken));
            }

            // if run locally, ignore Certificate validation failures (aka untrusted certificate + certificate chains)
            if (this.baseAddress.Contains("localhost"))
            {
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            }

            return client;
        }

        /// <summary>
        /// Reads the error from the response that is received from a resource.
        /// </summary>
        /// <param name="response">The response that is recieved from a resource.</param>
        /// <returns>New instance of <see cref="BMO.Common.Models.ErrorResult"/> that contains the error
        /// message received from the resource.</returns>
        private async Task<ErrorResult> GetErrorResult(HttpResponseMessage response)
        {
            ErrorResult retVal = null;
            HttpContent httpContent = response.Content;
            HttpStatusCode httpStatusCode = response.StatusCode;
            string content = await httpContent.ReadAsStringAsync();

            // log original exception to Windows event log if service is down
            if (this.errorLog != null)
            {
                this.errorLog.Log(new Error(new Exception(content)));
            }

            if (content.Contains(KeyConstants.ErrorCode))
            {
                retVal = await httpContent.ReadAsAsync<ErrorResult>();
            }
            else if (content.Contains(KeyConstants.ModelState))
            {
                retVal = await httpContent.ReadAsAsync<ModelStateErrorResult>();
            }
            else if (content.Contains(KeyConstants.ExceptionType))
            {
                retVal = await httpContent.ReadAsAsync<ExceptionErrorResult>();
                switch (httpStatusCode)
                {
                    case HttpStatusCode.NotFound:
                        retVal.Message = CommonResource.NotFound;
                        break;
                    case HttpStatusCode.Unauthorized:
                        retVal.Message = CommonResource.UnauthorizedMessage;
                        break;
                    default:
                        retVal.Message = CommonResource.ErrorOccurred;
                        break;
                }
            }
            else
            {
                retVal = await httpContent.ReadAsAsync<ErrorResult>();
                retVal.ErrorCode = ErrorCodeConstants.UnknownException;
                retVal.Message = CommonResource.ErrorOccurred;
            }

            // log original exception to Windows event log if service is down
            if (this.errorLog != null)
            {
                this.errorLog.Log(new Error(new Exception(retVal.Message)));
            }

            return retVal;
        }
    }
}

