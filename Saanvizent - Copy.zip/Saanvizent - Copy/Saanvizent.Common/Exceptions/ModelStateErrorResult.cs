﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Exceptions
{
    public class ModelStateErrorResult: ErrorResult
    {
        // public ModelStateDictionary ModelState { get; set; }
        public Dictionary<string, List<string>> ModelState { get; set; }

    }
}
