﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Exceptions
{
    public class ErrorResult
    {
        public ErrorResult()
        {
        }

        public ErrorResult(string errorLogID, int errorCode, string message)
        {
            this.ErrorLogID = errorLogID;
            this.ErrorCode = errorCode;
            this.Message = message;
        }

        /// <summary>
        /// Gets or sets the primary key value of the error stored in table ELMAH_Error
        /// </summary>
        public string ErrorLogID { get; set; }

        /// <summary>
        /// Gets or sets a unique error identifier for BMOI
        /// </summary>
        public int ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets user-friendly message that is returned to the UI for display to the user.
        /// </summary>
        public string Message { get; set; }

    }
}
