﻿using Saanvizent.Common.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Exceptions
{
    [Serializable]
    public class BusinessException: Exception
    {
        public BusinessException()
    : base()
        {
        }

        public BusinessException(string message)
            : base(message)
        {
        }

        public BusinessException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public BusinessException(int errorCode, string message)
            : base(message)
        {
            this.ErrorCode = errorCode;
        }

        public BusinessException(int errorCode, string message, Exception innerException)
            : base(message, innerException)
        {
            this.ErrorCode = errorCode;
        }

        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        protected BusinessException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this.ErrorCode = info.GetInt32(KeyConstants.ErrorCode);
        }

        public int ErrorCode { get; set; }

        /// <summary>
        /// Override that stored the error code
        /// </summary>
        /// <param name="info">Info</param>
        /// <param name="context">Context</param>
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }

            info.AddValue(KeyConstants.ErrorCode, this.ErrorCode);

            // MUST call through to the base class to let it save its own state
            base.GetObjectData(info, context);
        }

    }
}
