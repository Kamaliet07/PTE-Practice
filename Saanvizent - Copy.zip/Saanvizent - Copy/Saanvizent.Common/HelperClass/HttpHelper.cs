﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Saanvizent.Common.HelperClass
{
    public static class HttpHelper
    {
        /// <summary>
        /// Constructs the query string from the non-null public properties of the model.
        /// </summary>
        /// <typeparam name="T">Type of the model.</typeparam>
        /// <param name="model">The model from which querystring should be constructed.</param>
        /// <returns>A string representing the querystring.-or- An empty string,
        /// if the model does not have non-null public properties.</returns>
        public static string ToQueryString<T>(T model)
        {
            string result = string.Empty;

            if (model == null)
            {
                throw new ArgumentNullException("model");
            }

            // Get the non-null properties of the model.
            var properties = model.GetType().GetProperties().Where(m => m.GetValue(model) != null);

            // Result will be
            // "Prop1=Value1&Prop2=Value2&..."
            result = string.Join("&", properties.Select(m =>
                string.Format("{0}={1}", HttpUtility.UrlEncode(m.Name), HttpUtility.UrlEncode(m.GetValue(model).ToString()))));

            return result;
        }

    }
}
