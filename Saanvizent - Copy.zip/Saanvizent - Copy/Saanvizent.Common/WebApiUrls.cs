﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common
{
    public static class WebApiUrls
    {
        public static string GetExtractAlreadyExistUrl { get; set; }
        public static string GetExtractDetailByMGAUrl { get; set; }
        public static string GetIfExtractAlreadyAddedUrl { get; set; }
        public static string GetMGAGroupList { get; set; }
        public static string GetNotificationForEditDeleteUrl { get; set; }
        public static string GetSalesGroupDetailByMGAUrl { get; set; }
        public static string InsertNewMGACodeUrl { get; set; }
        public static string InsertNewSalesGroupUrl { get; set; }
        public static string MGADisableMGAExtractUrl { get; set; }

        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract
        /// </summary>
        public static Uri MGAExtractUrl
        {
            get { return new Uri(ConfigurationManager.AppSettings["MGAExtractyUrl"], UriKind.Relative); }
        }

        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract
        /// </summary>
        public static Uri MGAGetExtractStatusUrl
        {
            get { return new Uri(ConfigurationManager.AppSettings["MGAExtractyUrl"], UriKind.Relative); }
        }

        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri MGAGetExtractTypeUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }

        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri MGAGetNotificationTypeUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }

        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri DeleteMGA
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }
        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri DeleteSalesgroupUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }
        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri UpdateSalesgroupUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }
        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri UpdateMGA
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }
        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri MGAUpdateExtractUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }
        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri MGASubmitParentUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }
        /// <summary>
        /// Gets app Config Value For Service call To Fetch Extract Type
        /// </summary>
        public static Uri MGASaveExtractFromEditUrl
        {
            get
            {
                return new Uri(ConfigurationManager.AppSettings["MGAGetExtractTypeUrl"], UriKind.Relative);
            }

        }      
    
    }
}
