﻿using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using Saanvizent.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.JsonModelFormatting
{
    public class SubscriptionNotificationFormattingModel: BaseClass
    {
        // Flag: Has Dispose already been called?
        private bool disposed = false;
        private Definition definition;

        // Instantiate a SafeHandle instance.
        private SafeHandle handle = new SafeFileHandle(IntPtr.Zero, true);

        public SubscriptionNotificationFormattingModel(List<SubscriptionNotificationModel> subscriptionVal)
        {
            List<Definition> objdef = new List<Definition>();

            // Foreach Item in List collection _value
            foreach (var item in subscriptionVal)
            {
                CitsNotificationSubscriptionModel objres = new CitsNotificationSubscriptionModel();
                this.definition = new Definition()
                {
                    Defn = objres.CitsNotificationSubscription(item)
                };
                objdef.Add(this.definition);
            }

            this.Definitions = objdef;
        }

        [JsonProperty("definitions")]
        public object Definitions { get; set; }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing">bool Value</param>
        protected override void Dispose(bool disposing)
        {
            if (this.disposed)
            {
                return;
            }

            if (disposing)
            {
                this.handle.Dispose();
            }

            // Free any unmanaged objects here.
            this.disposed = true;

            // Call base class implementation.
            base.Dispose(disposing);
        }
    }

    /// <summary>
    /// Model to Design Definition
    /// </summary>
    public class Definition
    {
        [JsonProperty("definition")]
        public object Defn { get; set; }
    }

}

