﻿using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using Saanvizent.Common.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.JsonModelFormatting
{
    public class CitsNotificationSubscriptionModel : BaseClass
    {
        private Delivery delivery;
        private CITSfeedsColl citsfeed;
        private DefinitionLoad defload;

        // Flag: Has Dispose already been called?
        private bool disposed = false;

        // Instantiate a SafeHandle instance.
        private SafeHandle handle = new SafeFileHandle(IntPtr.Zero, true);

        [JsonProperty("definition")]
        public object Definition { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CitsNotificationSubscriptionModel"/> class.
        /// Method To Get Subscription Response based on MGACode
        /// </summary>
        /// <param name="item">List of Data </param>
        /// <returns>Definition</returns>
        public DefinitionLoad CitsNotificationSubscription(SubscriptionNotificationModel item)
        {
            string feedType = this.ReadAppSetting("FeedType");
            this.delivery = new Delivery()
            {
                Mode = item.DeliveryMode,
                Emailaddress = item.EmailAddress,
            };

            this.citsfeed = new CITSfeedsColl()
            {
                FeedType = feedType,
                Delivery = this.delivery
            };

            this.defload = new DefinitionLoad()
            {
                Action = item.NotificationAction,
                Accorddistributorcode = item.AccorddistributorCode,
                CITSfeeds = new List<CITSfeedsColl>() { this.citsfeed },
                Mgacode = string.IsNullOrEmpty(item.MgaCode) ? string.Empty : item.MgaCode.ToString(),
                Emailaddress = item.EmailAddress,
                Mganame = string.IsNullOrEmpty(item.MgaName) ? string.Empty : item.MgaName.ToString(),
                Mgashortname = string.IsNullOrEmpty(item.MgaShortName) ? string.Empty : item.MgaShortName.ToString(),
            };

            return this.defload;
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing">bool Value</param>
        protected override void Dispose(bool disposing)
        {
            if (this.disposed)
            {
                return;
            }

            if (disposing)
            {
                this.handle.Dispose();
            }

            // Free any unmanaged objects here.
            this.disposed = true;

            // Call base class implementation.
            base.Dispose(disposing);
        }

        /// <summary>
        /// Read Appsetting From Web.Config File
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>Key value </returns>
        private string ReadAppSetting(string key)
        {
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                string result = appSettings[key] ?? "Not Found";
                return result;
            }
            catch (ConfigurationErrorsException)
            {
                return "Error reading app settings";
            }
        }
    }

    /// <summary>
    /// Class Model for Delivery
    /// </summary>
    public class Delivery
    {
        [JsonProperty("mode")]
        public string Mode { get; set; }

        [JsonProperty("emailaddress")]
        public string Emailaddress { get; set; }
    }

    /// <summary>
    /// Model Design for CITS Feed
    /// </summary>
    public class CITSfeedsColl
    {
        [JsonProperty("FeedType")]
        public string FeedType { get; set; }

        [JsonProperty("delivery", NullValueHandling = NullValueHandling.Ignore)]
        public object Delivery { get; set; }
    }

    /// <summary>
    /// Model Design for Definition Load
    /// </summary>
    public class DefinitionLoad
    {
        [JsonProperty("action")]
        public string Action { get; set; }

        [JsonProperty("accorddistributorcode")]
        public string Accorddistributorcode { get; set; }

        [JsonProperty("CITSfeeds")]
        public List<CITSfeedsColl> CITSfeeds { get; set; }

        [JsonProperty("mgacode")]
        public string Mgacode { get; set; }

        [JsonProperty("emailaddress")]
        public string Emailaddress { get; set; }

        [JsonProperty("mganame")]
        public string Mganame { get; set; }

        [JsonProperty("mgashortname")]
        public string Mgashortname { get; set; }

    }
}
