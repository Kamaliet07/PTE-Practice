﻿using Elmah;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.ElmahException
{
    public interface IElmahErrorLog
    {
        ErrorLogEntry GetError(string id);

        int GetErrors(int pageIndex, int pageSize, IList errorEntryList);

        string Log(Error error);

    }
}
