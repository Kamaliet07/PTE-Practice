﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.ElmahException
{
    public interface IElmahEventLogErrorLog: IElmahErrorLog
    {
        string EventLogName { get; set; }

        string EventSourceName { get; set; }

        string Name { get; }

    }
}
