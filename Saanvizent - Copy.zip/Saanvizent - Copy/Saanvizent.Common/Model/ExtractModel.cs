﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Model
{
    public class ExtractTypeModel
    {
        public int ExtractID { get; set; }
        public string ExtractType { get; set; }
    }

    public class NotificationModel
    {
        public int NotificationID { get; set; }
        public string NotificationType { get; set; }
    }

    public class ExtractStatusModel
    {
        public int StatusID { get; set; }
        public string ExtractStatus { get; set; }
    }

    public class MGASalesGroups
    {
        public int SalesGrpID { get; set; }
        public string SalesGroup { get; set; }
    }

    public class MGAGroups
    {
        public int MGAID { get; set; }
        public string MGACode { get; set; }
    }

    public class MGAExtractModel
    {
        public int MGAID { get; set; }
        public string MGACode { get; set; }
    }
}
