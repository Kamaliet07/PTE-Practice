﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Common.Model
{
   public class SubscriptionNotificationModel
    {
        public string DeliveryMode { get; set; }
        public string EmailAddress { get; set; }
        public string NotificationAction { get; set; }
        public string AccorddistributorCode { get; set; }
        public string MgaCode { get; set; }
        public string MgaName { get; set; }
        public string MgaShortName { get; set; }
     
    }
}
