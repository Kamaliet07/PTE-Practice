﻿using Saanvizent.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Saanvizent.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        //[HttpGet]
        //public async Task<PartialViewResult> SearchMGA(string searchMGAName, string searchMGACode, int page = 1, string sort = "MGAName", SortDirectionEnum sortDir = SortDirectionEnum.ASC)
        //{
        //    // Create Object OF MGASearchItemModel
        //    MGASearchItemModel mgaListCollection = new MGASearchItemModel();

        //    // Get Page Sixe From Configuration File
        //    int pageSize = int.Parse(ConfigurationManager.AppSettings["MGASearchListPageSize"]);
        //    int totalRecords;

        //    // Set Null For Empty Value
        //    if (string.IsNullOrEmpty(searchMGAName))
        //    {
        //        searchMGAName = null;
        //    }

        //    if (string.IsNullOrEmpty(searchMGACode))
        //    {
        //        searchMGACode = null;
        //    }

        //    using (ExtractService mgaBAl = new ExtractService())
        //    {
        //        // Method to Get totalCount Based on the search criteria
        //        ApiCallResult<string> resultCount = await mgaBAl.GetTotalCount(searchMGAName, searchMGACode);

        //        // If Count Exist Then search filter criteria
        //        if (resultCount.Succeeded)
        //        {
        //            string value = resultCount.Value;
        //            if (!string.IsNullOrEmpty(value))
        //            {
        //                if (Convert.ToInt16(value) > 0)
        //                {
        //                    totalRecords = Convert.ToInt16(value);

        //                    // Get the sorted List of Searched MGA
        //                    ApiCallResult<List<MGASearchModel>> result = await mgaBAl.GetSearchedMGAListSorted(searchMGAName, searchMGACode, page, sort, pageSize, sortDir);
        //                    if (result.Succeeded)
        //                    {
        //                        // userListCollection = result.Value;
        //                        if (result.Value != null && result.Value.Count > 0)
        //                        {
        //                            // Set Model With Value To Bind In WebGrid
        //                            mgaListCollection.MgaSearchModel = result.Value;
        //                            mgaListCollection.PageSize = pageSize;
        //                            mgaListCollection.PageNumber = page;
        //                            mgaListCollection.TotalRows = totalRecords;
        //                        }
        //                        else
        //                        {
        //                            // Set Empty Modelue If record Not Found
        //                            MGASearchItemModel mgaSearchModel = new MGASearchItemModel();
        //                            List<MGASearchModel> mgaModel = new List<MGASearchModel>();
        //                            mgaSearchModel.MgaSearchModel = mgaModel;
        //                            mgaSearchModel.PageSize = int.Parse(ConfigurationManager.AppSettings["MGASearchListPageSize"]);
        //                            mgaSearchModel.PageNumber = 1;
        //                            mgaSearchModel.TotalRows = 0;
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    // Set Empty Modelue If record Not Found
        //                    MGASearchItemModel mgaSearchModel1 = new MGASearchItemModel();
        //                    List<MGASearchModel> mgaModel1 = new List<MGASearchModel>();
        //                    mgaSearchModel1.MgaSearchModel = mgaModel1;
        //                    mgaSearchModel1.PageSize = int.Parse(ConfigurationManager.AppSettings["MGASearchListPageSize"]);
        //                    mgaSearchModel1.PageNumber = 1;
        //                    mgaSearchModel1.TotalRows = 0;
        //                }
        //            }
        //        }
        //    }

        //    return this.PartialView("GridPartialView", mgaListCollection);
        //}

    }
}