﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Saanvizent.Controllers
{
    public class UserExtractController : Controller
    {
        // GET: UserExtract
        public ActionResult UserExtract()
        {
            return View();
        }
    }
}