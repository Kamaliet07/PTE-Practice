﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.WebPages;

namespace Saanvizent.Extensions
{
    public static class WebGridExtensions
    {
        /// <summary>
        /// Method For Pager List
        /// </summary>
        /// <param name="webGrid">Web Grid</param>
        /// <param name="mode">Mode</param>
        /// <param name="firstText">First Text</param>
        /// <param name="previousText">Previous Text</param>
        /// <param name="nextText">Next Text</param>
        /// <param name="lastText">Last Text</param>
        /// <param name="numericLinksCount">Numeric Link</param>
        /// <returns>Pager List</returns>
        public static HelperResult PagerList(
           this WebGrid webGrid,
           WebGridPagerModes mode = WebGridPagerModes.NextPrevious | WebGridPagerModes.Numeric,
           string firstText = null,
           string previousText = null,
           string nextText = null,
           string lastText = null,
           int numericLinksCount = 7)
        {
            return PagerList(webGrid, mode, firstText, previousText, nextText, lastText, numericLinksCount, explicitlyCalled: true);
        }

        /// <summary>
        /// Private Method For Pager List
        /// </summary>
        /// <param name="webGrid">Web Grid</param>
        /// <param name="mode">Mode</param>
        /// <param name="firstText">First Text</param>
        /// <param name="previousText">Previous text</param>
        /// <param name="nextText">Next Text</param>
        /// <param name="lastText">Last Text</param>
        /// <param name="numericLinksCount">Numeric Link</param>
        /// <param name="explicitlyCalled">Explicitly</param>
        /// <returns>Helper Result</returns>
        private static HelperResult PagerList(
            WebGrid webGrid,
            WebGridPagerModes mode,
            string firstText,
            string previousText,
            string nextText,
            string lastText,
            int numericLinksCount,
            bool explicitlyCalled)
        {
            int currentPage = webGrid.PageIndex;
            int totalPages = webGrid.PageCount;
            int lastPage = totalPages - 1;

            var ul = new TagBuilder("ul");
            var li = new List<TagBuilder>();

            if (webGrid.TotalRowCount < webGrid.RowsPerPage)
            {
                return new HelperResult(writer =>
                {
                    writer.Write(string.Empty);
                });
            }

            if (ModeEnabled(mode, WebGridPagerModes.NextPrevious))
            {
                if (string.IsNullOrEmpty(previousText))
                {
                    previousText = "<";
                }

                int page = currentPage == 0 ? 0 : currentPage - 1;

                var part = new TagBuilder("li")
                {
                    InnerHtml = GridLink(webGrid, webGrid.GetPageUrl(page), previousText, currentPage != 0)
                };

                if (currentPage == 0)
                {
                    part.MergeAttribute("class", "disabled");
                }

                li.Add(part);
            }

            if (ModeEnabled(mode, WebGridPagerModes.FirstLast))
            {
                if (string.IsNullOrEmpty(firstText))
                {
                    firstText = "1";
                }

                var part = new TagBuilder("li")
                {
                    InnerHtml = GridLink(webGrid, webGrid.GetPageUrl(0), firstText, currentPage != 0)
                };

                if (currentPage == 0)
                {
                    part.MergeAttribute("class", "active");
                }

                li.Add(part);
            }

            if (ModeEnabled(mode, WebGridPagerModes.Numeric) && (totalPages > 1))
            {
                int last = currentPage + (numericLinksCount / 2);
                int first = last - numericLinksCount + 1;
                if (last > lastPage)
                {
                    first -= last - lastPage;
                    last = lastPage;
                }

                if (first < 0)
                {
                    last = Math.Min(last + (0 - first), lastPage);
                    first = 0;
                }

                if ((currentPage > numericLinksCount / 2) && (totalPages > numericLinksCount))
                {
                    li.Add(new TagBuilder("li") { InnerHtml = "<a>...</a>" });
                }

                for (int i = first + 1; i <= last - 1; i++)
                {
                    var pageText = (i + 1).ToString(CultureInfo.InvariantCulture);
                    var part = new TagBuilder("li")
                    {
                        InnerHtml = GridLink(webGrid, webGrid.GetPageUrl(i), pageText, currentPage != i)
                    };

                    if (currentPage == i)
                    {
                        part.MergeAttribute("class", "active");
                    }

                    li.Add(part);
                }

                if ((currentPage < totalPages - (numericLinksCount / 2) - 1) && (totalPages > numericLinksCount))
                {
                    li.Add(new TagBuilder("li") { InnerHtml = "<a>...</a>" });
                }
            }

            if (ModeEnabled(mode, WebGridPagerModes.FirstLast))
            {
                if (string.IsNullOrEmpty(lastText))
                {
                    lastText = totalPages.ToString();
                }

                var part = new TagBuilder("li")
                {
                    InnerHtml = GridLink(webGrid, webGrid.GetPageUrl(lastPage), lastText, currentPage != lastPage)
                };

                if (currentPage == lastPage)
                {
                    part.MergeAttribute("class", "active");
                }

                li.Add(part);
            }

            if (ModeEnabled(mode, WebGridPagerModes.NextPrevious))
            {
                if (string.IsNullOrEmpty(nextText))
                {
                    nextText = ">";
                }

                int page = currentPage == lastPage ? lastPage : currentPage + 1;

                var part = new TagBuilder("li")
                {
                    InnerHtml = GridLink(webGrid, webGrid.GetPageUrl(page), nextText, currentPage != lastPage)
                };

                if (currentPage == lastPage)
                {
                    part.MergeAttribute("class", "disabled");
                }

                li.Add(part);
            }

            ul.InnerHtml = string.Join(string.Empty, li);
            var html = string.Empty;
            if (explicitlyCalled && webGrid.IsAjaxEnabled)
            {
                var span = new TagBuilder("span");
                span.MergeAttribute("data-swhgajax", "true");
                span.MergeAttribute("data-swhgcontainer", webGrid.AjaxUpdateContainerId);
                span.MergeAttribute("data-swhgcallback", webGrid.AjaxUpdateCallback);

                span.InnerHtml = ul.ToString();
                html = span.ToString();
            }
            else
            {
                html = ul.ToString();
            }

            return new HelperResult(writer =>
            {
                writer.Write(html);
            });
        }

        /// <summary>
        /// Method For Grid Link
        /// </summary>
        /// <param name="webGrid">Web Grid</param>
        /// <param name="url">Url</param>
        /// <param name="text">Text</param>
        /// <param name="isAvtive">Active</param>
        /// <returns>String Value</returns>
        private static string GridLink(WebGrid webGrid, string url, string text, bool isAvtive = true)
        {
            TagBuilder builder = new TagBuilder("a");
            builder.SetInnerText(text);
            if (isAvtive)
            {
                builder.MergeAttribute("href", url);
                if (webGrid.IsAjaxEnabled)
                {
                    builder.MergeAttribute("data-swhglnk", "true");
                }
            }

            return builder.ToString(TagRenderMode.Normal);
        }

        /// <summary>
        /// Method For Mode Enable
        /// </summary>
        /// <param name="mode">Mode</param>
        /// <param name="modeCheck">Mode Check</param>
        /// <returns>Mode enable</returns>
        private static bool ModeEnabled(WebGridPagerModes mode, WebGridPagerModes modeCheck)
        {
            return (mode & modeCheck) == modeCheck;
        }
    }
}
