﻿using Microsoft.Win32.SafeHandles;
using Saanvizent.Common;
using Saanvizent.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Saanvizent.Services
{
    public class ExtractEditService: BaseClass
    {
        // Flag: Has Dispose already been called?
        private bool disposed = false;

        // Instantiate a SafeHandle instance.
        private SafeHandle handle = new SafeFileHandle(IntPtr.Zero, true);

        /// <summary>
        /// Method To Get extract Type
        /// </summary>
        /// <returns>List OF Extract Type</returns>
        public async Task<ApiCallResult<List<ExtractTypeModel>>> GetExtractType()
        {
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<List<ExtractTypeModel>>(WebApiUrls.MGAGetExtractTypeUrl);
            }
        }

        /// <summary>
        ///  Method To Get Notification Type
        /// </summary>
        /// <returns>List Of Notification</returns>
        public async Task<ApiCallResult<List<NotificationModel>>> GetNotificationType()
        {
            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<List<NotificationModel>>(WebApiUrls.MGAGetNotificationTypeUrl);
            }
        }

        /// <summary>
        /// Method To Get Extract Status
        /// </summary>
        /// <returns>List Of Status</returns>
        public async Task<ApiCallResult<List<ExtractStatusModel>>> GetExtractStatus()
        {
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<List<ExtractStatusModel>>(WebApiUrls.MGAGetExtractStatusUrl);
            }
        }

        /// <summary>
        /// Method To Get Sales Group List For MGA
        /// </summary>
        /// <param name="mgaCode">Mga Code</param>
        /// <returns>List Of Sales Group</returns>
        public async Task<ApiCallResult<List<MGASalesGroups>>> GetSalesGroupByMGA(string mgaCode)
        {
            var url = new Uri(WebApiUrls.GetSalesGroupDetailByMGAUrl + string.Format("?searchMGACode={0}", mgaCode), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<List<MGASalesGroups>>(url);
            }
        }

        /// <summary>
        /// Method To Get Extract Detail By MGA Code
        /// </summary>
        /// <param name="mgaCode">MGA Code</param>
        /// <param name="mgaName">MGA Name</param>
        /// <returns>Return List Of Extract</returns>
        public async Task<ApiCallResult<List<MGAExtractModel>>> GetExtractDetailByMGA(string mgaCode, string mgaName)
        {
            var url = new Uri(WebApiUrls.GetExtractDetailByMGAUrl + string.Format("?mgaCode={0}&mgaName={1}", mgaCode, mgaName), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<List<MGAExtractModel>>(url);
            }
        }

        /// <summary>
        /// Method To Soft Delete Selected Extract
        /// </summary>
        /// <param name="iD">Extract ID</param>
        /// <param name="mGACode">Mga Code</param>
        /// <param name="mGAName">Mga Name</param>
        /// <returns>Return Disable Status</returns>
        public async Task<ApiCallResult<string>> DisableMGAExtractInfo(int iD, string mGACode, string mGAName)
        {
            var url = new Uri(WebApiUrls.MGADisableMGAExtractUrl + string.Format("?extractID={0}&mgaCode={1}&mgaName={2}", iD, mGACode, mGAName), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Save New MGA Extract
        /// </summary>
        /// <param name="mgaName">MGA Name</param>
        /// <param name="mgaCode">MGA Code</param>
        /// <param name="mgaAccordCode">Acord Code</param>
        /// <param name="mgaShortName">Short Name</param>
        /// <param name="mgaNotificationEmail">Notification Email</param>
        /// <param name="salesgroupList">Sales Group List</param>
        /// <param name="extractTypeID">Extract Type ID</param>
        /// <param name="notificatiTypeID">Notification ID</param>
        /// <param name="dropDownLocation">Drop Box Location</param>
        /// <param name="dropDownFolder">Drop Box Folder</param>
        /// <param name="fileName">File Name</param>
        /// <param name="winzipFile">WinZip File</param>
        /// <param name="statusID">Status ID</param>
        /// <returns>Return Save Staus</returns>
        public async Task<ApiCallResult<string>> SaveMGAExtractFromEdit(string mgaName, string mgaCode, string mgaAccordCode, string mgaShortName, string mgaNotificationEmail, string salesgroupList, int extractTypeID, int notificatiTypeID, string dropDownLocation, string dropDownFolder, string fileName, string winzipFile, int statusID)
        {
            var url = new Uri(
                WebApiUrls.MGASaveExtractFromEditUrl +
                string.Format(
                    "?mgaCode={0}&mgaName={1}&mgaAccordCode={2}&mgaShortName={3}&mgaNotificationEmail={4}&salesGroups={5}&extractTypeID={6}&notificatiTypeID={7}&dropDownLocation={8}&dropDownFolder={9}&fileName={10}&winzipFile={11}&statusID={12}", mgaCode, mgaName, mgaAccordCode, mgaShortName, mgaNotificationEmail, salesgroupList, extractTypeID, notificatiTypeID, dropDownLocation, dropDownFolder, fileName, winzipFile, statusID), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Update MGA Extract
        /// </summary>
        /// <param name="extrInfoID">Extract Info ID</param>
        /// <param name="extractTypeID">Extract Type ID</param>
        /// <param name="notificatiTypeID">Notificati Type ID</param>
        /// <param name="dropDownLocation">Drop Box Location</param>
        /// <param name="dropDownFolder">Drop Box Folder</param>
        /// <param name="fileName">file Name</param>
        /// <param name="winzipFile">win zip File</param>
        /// <param name="statusID">status ID</param>
        /// <returns>Update Status</returns>
        public async Task<ApiCallResult<string>> UpdateExtractInfo(int extrInfoID, int extractTypeID, int notificatiTypeID, string dropDownLocation, string dropDownFolder, string fileName, string winzipFile, int statusID)
        {
            var url = new Uri(WebApiUrls.MGAUpdateExtractUrl + string.Format("?extrInfoID={0}&extractTypeID={1}&notificatiTypeID={2}&dropDownLocation={3}&dropDownFolder={4}&fileName={5}&winzipFile={6}&statusID={7}", extrInfoID, extractTypeID, notificatiTypeID, dropDownLocation, dropDownFolder, fileName, winzipFile, statusID), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Update Sales Group
        /// </summary>
        /// <param name="salesID">Sales Group ID</param>
        /// <param name="salesText">Sales Group Name</param>
        /// <returns>Update Status</returns>
        public async Task<ApiCallResult<string>> UpdateSalesGroup(int salesID, string salesText)
        {
            var url = new Uri(WebApiUrls.UpdateSalesgroupUrl + string.Format("?salesID={0}&salesText={1}", salesID, salesText), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Delete Sales Group
        /// </summary>
        /// <param name="salesGroupID">Sales Group ID</param>
        /// <param name="salesText">Sales Group Name</param>
        /// <returns>Delete Status</returns>
        public async Task<ApiCallResult<string>> DeleteSalesGroup(int salesGroupID, string salesText)
        {
            var url = new Uri(WebApiUrls.DeleteSalesgroupUrl + string.Format("?salesID={0}&salesText={1}", salesGroupID, salesText), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Submit Parent Data
        /// </summary>
        /// <param name="mgaName">Mga Name</param>
        /// <param name="accordCode">Accord Code</param>
        /// <param name="mgaCode">Mga Code</param>
        /// <param name="shortName">Short Name</param>
        /// <param name="emailNotification">Notification Email</param>
        /// <returns>Submit Status</returns>
        public async Task<ApiCallResult<string>> SubmitParentData(string mgaName, string accordCode, string mgaCode, string shortName, string emailNotification)
        {
            var url = new Uri(WebApiUrls.MGASubmitParentUrl + string.Format("?magName={0}&mgaCode={1}&mgaAccordCode={2}&mgaShortName={3}&notificationEmail={4}", mgaName, mgaCode, accordCode, shortName, emailNotification), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Update MGA
        /// </summary>
        /// <param name="mgaCodeID">Mga Code ID</param>
        /// <param name="mgaText">Mga Code</param>
        /// <returns>Update Status</returns>
        public async Task<ApiCallResult<string>> UpdateMga(int mgaCodeID, string mgaText)
        {
            var url = new Uri(WebApiUrls.UpdateMGA + string.Format("?mgaCodeID={0}&mgaText={1}", mgaCodeID, mgaText), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Delete MGA
        /// </summary>
        /// <param name="mgaCodeID">Mga Code ID</param>
        /// <param name="mgaText">Mga Code</param>
        /// <returns>Delete Status</returns>
        public async Task<ApiCallResult<string>> DeleteMga(int mgaCodeID, string mgaText)
        {
            var url = new Uri(WebApiUrls.DeleteMGA + string.Format("?mgaCodeID={0}&mgaText={1}", mgaCodeID, mgaText), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Get MGA List
        /// </summary>
        /// <param name="mgaCode">Mga Code</param>
        /// <param name="mgaShortName">Mga Short Name</param>
        /// <returns>List of MGA</returns>
        public async Task<ApiCallResult<List<MGAGroups>>> GetMgaList(string mgaCode, string mgaShortName)
        {
            var url = new Uri(WebApiUrls.GetMGAGroupList + string.Format("?searchMGACode={0}&mgaShortName={1}", mgaCode, mgaShortName), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<List<MGAGroups>>(url);
            }
        }

        /// <summary>
        ///  Method To Check If Extract Already Added In Database
        /// </summary>
        /// <param name="extrInfoID">Extract Info ID</param>
        /// <param name="extractTypeID">Extract TypeI D</param>
        /// <param name="notificatiTypeID">Notification Type ID</param>
        /// <param name="shortName">Short Name</param>
        /// <returns>Status If Already Added</returns>
        public async Task<ApiCallResult<string>> GetExtractAlreadyExist(int extrInfoID, int extractTypeID, int notificatiTypeID, string shortName)
        {
            var url = new Uri(WebApiUrls.GetExtractAlreadyExistUrl + string.Format("?extrInfoID={0}&extractTypeID={1}&notificatiTypeID={2}&shortName={3}", extrInfoID, extractTypeID, notificatiTypeID, shortName), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        ///  Method To Check If Extract Already Added In Database
        /// </summary>
        /// <param name="extractTypeID">Extract TypeI D</param>
        /// <param name="notificatiTypeID">Notification Type ID</param>
        /// <param name="shortName">Short Name</param>
        /// <returns>Status If Already Added</returns>
        public async Task<ApiCallResult<string>> GetIfExtractAlreadyAdded(int extractTypeID, int notificatiTypeID, string shortName)
        {
            var url = new Uri(WebApiUrls.GetIfExtractAlreadyAddedUrl + string.Format("?extractTypeID={0}&notificatiTypeID={1}&shortName={2}", extractTypeID, notificatiTypeID, shortName), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Insert Sales Group
        /// </summary>
        /// <param name="shortName">Short Name</param>
        /// <param name="salesGroup">Sales Group</param>
        /// <returns>Insert Status</returns>
        public async Task<ApiCallResult<string>> InsertSalesGroup(string shortName, string salesGroup)
        {
            var url = new Uri(WebApiUrls.InsertNewSalesGroupUrl + string.Format("?mgaShortName={0}&salesGroups={1}", shortName, salesGroup), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Method To Insert Mga Code
        /// </summary>
        /// <param name="shortName">Short Name</param>
        /// <param name="mgaCode">Mga Code</param>
        /// <returns>Insert Status</returns>
        public async Task<ApiCallResult<string>> InsertMgaCode(string shortName, string mgaCode)
        {
            var url = new Uri(WebApiUrls.InsertNewMGACodeUrl + string.Format("?mgaShortName={0}&mgaCode={1}", shortName, mgaCode), UriKind.Relative);

            // Creating object of MGAExtractEntities
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return await objapiCaller.GetAsJsonAsync<string>(url);
            }
        }

        /// <summary>
        /// Receive Notification Detail For Edit And Delete Operation
        /// </summary>
        /// <param name="extrInfoID">Extract Infor ID</param>
        /// <returns>Notification Model</returns>
        public ApiCallResult<List<SubscriptionNotificationModel>> ReceiveCitsNotificationForEditDelete(int extrInfoID)
        {
            var url = new Uri(WebApiUrls.GetNotificationForEditDeleteUrl + string.Format("?extractID={0}", extrInfoID), UriKind.Relative);
            using (WebApiCaller objapiCaller = new WebApiCaller())
            {
                return objapiCaller.GetAsJson<List<SubscriptionNotificationModel>>(url);
            }
        }

        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing">bool Value</param>
        protected override void Dispose(bool disposing)
        {
            if (this.disposed)
            {
                return;
            }

            if (disposing)
            {
                this.handle.Dispose();
            }

            // Free any unmanaged objects here.
            this.disposed = true;

            // Call base class implementation.
            base.Dispose(disposing);
        }

    }
}
