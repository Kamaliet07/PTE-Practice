﻿using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Net.Mail;
using System.Threading.Tasks;

namespace TDRP.Utility
{
    public class EmailSender : IEmailSender
    {
        private readonly IConfiguration _config;
        private readonly ILogger<EmailSender> _logger;

        public EmailSender(IConfiguration iConfig, ILogger<EmailSender> logger)
        {
            _config = iConfig;
            _logger = logger;
        }

        public Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            return Execute(subject, htmlMessage, email);
        }

        private Task Execute(string subject, string htmlMessage, string email)
        {
            try
            {
                string SenderEmail = _config.GetSection("SmtpOptions").GetSection("SenderEmail").Value;
                string SenderName = _config.GetSection("SmtpOptions").GetSection("SenderName").Value;
                // Log Message to configure SMTP Client
                _logger.LogError("Configure SMTP Client");
                var smtpClient = new SmtpClient
                {
                    Host =  _config.GetSection("SmtpOptions").GetSection("MailServer").Value,
                    Port = 25, // Port 
                    //EnableSsl = true,
                };

                var message = new MailMessage(SenderEmail, email)
                {
                    From = new MailAddress(SenderEmail, SenderName),
                    Subject = subject,
                    IsBodyHtml = true,
                    Body = htmlMessage,
                };

                return smtpClient.SendMailAsync(message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.InnerException.ToString());
                throw ex;
            }
        }
    }
}
