﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace TDRP.Utility
{
    public class AppConstant
    {
        #region Temp Message Values

        public const string StatusSubmitted = "Submitted";
        public const string StatusApproved = "Approved";
        public const string StatusRejected = "Rejected";

        #endregion

        #region User Roles

        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string Employee = "Employee";

        #endregion

        #region Stored Procedures

        public const string usp_GetEmployees = "usp_GetEmployees";
        public const string usp_GetAllProjects = "usp_GetAllProjects";
        public const string usp_GetTeams = "usp_GetTeams";
        public const string usp_ViewEmployeeList = "usp_ViewEmployeeList";

        // Added for editing project info on the project details view. - SD
        public const string usp_GetProjectDetail = "usp_GetProjectDetail";

        // Added to filter out previously Assigned Employees from the assignment
        // table in AssignEmployeeProject.cshtml. - SD
        public const string usp_GetAssignedEmployees = "usp_GetAssignedEmployees";
        public const string usp_GetUnassignedEmployees = "usp_GetUnassignedEmployees";
        public const string usp_GetAssignedWorkDetails = "usp_GetAssignedWorkDetails";

        // Added to find all active members for the team employees partial view. - SD
        public const string usp_GetActiveTeamMembers = "usp_GetActiveTeamMembers";

        // Added procedure details for get the list of assigned project to resource. - KB       
        public const string usp_GetTotalTimeAllocated = "usp_GetTotalTimeAllocated";

        // Added procedure Details for Project Allocation Module - KB
        public const string usp_GetAllocatedDays = "usp_GetAllocatedDays";
        public const string usp_GetAssignedProjects = "usp_GetAssignedProjects";
        public const string usp_GetEmployeeDetails = "usp_GetEmployeeDetails";
        public const string usp_SaveProjectAllocation = "usp_SaveProjectAllocation";
        public const string usp_GetMonthlyAllocation = "usp_GetMonthlyAllocation";
        public const string usp_GetRemainingDaysInMonth = "usp_GetRemainingDaysInMonth";
        public const string usp_GetProjectsAllocationSixMonth = "usp_GetProjectsAllocationSixMonth";
        public const string usp_GetAllocationDetails = "usp_GetAllocationDetails";
        public const string usp_GetTeamProjects = "usp_GetTeamProjects";

        // Added procedure for ProjectList View Model. - SD
        public const string usp_ProjectList = "usp_ProjectList";

        // Added for Dashboard Chart data integration. - SD
        public const string usp_PieChartProjectAllocationDays = "usp_PieChartProjectAllocationDays";
        public const string usp_PieChartCategoryAllocationDays = "usp_PieChartCategoryAllocationDays";
        public const string usp_AreaChartDataAllocation = "usp_AreaChartDataAllocation";
        public const string usp_GetAllocatedEmployeesMonth = "usp_GetAllocatedEmployeesMonth";

        // Added for User Profile Partials Views - SD
        public const string usp_GetUserWork = "usp_GetUserWork";

        // Added for Unnamed Resource Assignments - SD
        public const string usp_GetWorkingDaysInMonth = "usp_GetWorkingDaysInMonth";
        public const string usp_SaveUnnamedAssignment = "usp_SaveUnnamedAssignment";

        #endregion
    }
}
