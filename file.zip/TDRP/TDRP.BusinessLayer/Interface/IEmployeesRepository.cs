﻿using System;
using System.Collections.Generic;
using System.Text;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IEmployeesRepository : IRepository<Employees>
    {
        IEnumerable<Employees> GetAllEmployees();

        void Update(Employees employees);
    }
}
