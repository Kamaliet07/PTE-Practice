﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface IAssignedWorkRepository : IRepository<AssignedWork>
    {
        IEnumerable<SelectListItem> GetProjectsForDropDown();

        void Update(AssignedWork assignedWork);
    }
}
