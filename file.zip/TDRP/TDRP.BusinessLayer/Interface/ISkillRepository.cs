﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Interface
{
    public interface ISkillRepository : IRepository<Skills>
    {
        IEnumerable<SelectListItem> GetSkillsListItems();

        void Update(Skills skills);
    }
}
