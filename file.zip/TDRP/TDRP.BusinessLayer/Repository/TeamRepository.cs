﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class TeamRepository : Repository<Teams>, ITeamRepository
    {
        private readonly ApplicationDbContext _db;

        public TeamRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetTeamListForDropDown()
        {
            return _db.Teams.Select(i => new SelectListItem()
            {
                Text = i.TeamName,
                Value = i.TeamId.ToString(),
            });
        }

        public IEnumerable<Teams> GetAllTeamDetails()
        {
            List<Teams> teamDetails = new List<Teams>();
            teamDetails = _db.Teams.AsList();
            return teamDetails;
        }

        public void Update(Teams teams)
        {
            var objFromDb = _db.Teams.FirstOrDefault(s => s.TeamId == teams.TeamId);

            objFromDb.TeamName = teams.TeamName;
            objFromDb.UpdateId = teams.UpdateId;
            objFromDb.UpdatedDate = DateTime.Now;
            objFromDb.TeamDetails = teams.TeamDetails;
            objFromDb.Active = teams.Active;

            _db.SaveChanges();
        }
    }
}
