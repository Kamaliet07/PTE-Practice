﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ProjectRepository : Repository<Projects>, IProjectRepository
    {
        private readonly ApplicationDbContext _db;

        public ProjectRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetProjectListForDropDown()
        {
            return _db.Projects.Select(i => new SelectListItem()
            {
                Text = i.ProjectName,
                Value = i.ProjectId.ToString(),
            });
        }

        public IEnumerable<Projects> GetAllProjectDetails()
        {
            List<Projects> projectDetails = new List<Projects>();
            projectDetails = _db.Projects.AsList();
            return projectDetails;
        }

        public void Update(Projects projects)
        {
            var objFromDb = _db.Projects.FirstOrDefault(s => s.ProjectId == projects.ProjectId);
            objFromDb.ProjectName = projects.ProjectName;
            objFromDb.EstimatedBudget = projects.EstimatedBudget;
            objFromDb.TotalExpenditure = projects.TotalExpenditure;
            objFromDb.Category = projects.Category;
            objFromDb.TeamId = projects.TeamId;
            objFromDb.StartDate = projects.StartDate;
            objFromDb.EndDate = projects.EndDate;
            objFromDb.ProjectDescription = projects.ProjectDescription;
            objFromDb.UpdatedDate = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
