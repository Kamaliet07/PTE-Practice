﻿using System.Collections.Generic;
using TDRP.DataModel;

namespace TDRP.ViewModel
{
    public class ProfileViewModel
    {
        public UserProfileDetails UserProfileDetails { get; set; }
        public IList<UserSkills> UserSkills { get; set; }

        public IList<AssignedWork> AssignedWork { get; set; }
        public Teams Teams { get; set; }
    }
}
