﻿using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.Utility;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.ViewModel;

namespace TDRP.Areas.Employee.Controllers
{
    [Area("Employee")]
    public class EmployeesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        /// Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="userService"></param>
        public EmployeesController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        public IActionResult EmployeeList()
        {
            List<ViewEmployeeList> objEmpList = _unitOfWork.SpCall
                .ReturnList<ViewEmployeeList>(AppConstant.usp_ViewEmployeeList).Result.ToList();
            return View(objEmpList);
        }

        // Add Employee Methods have been moved to the User Area under the Teams Controller since the
        // user now adds employees through the team details screen.

        #region Delete Employee Methods

        [HttpDelete]
        [Authorize(Roles = "Manager, Admin")]
        public async Task<IActionResult> DeleteEmployee(string id)
        {
            ApplicationUser objFromDb = await _userService.FindByIdAsync(id);
            if (objFromDb == null)
            {
                return Json(new
                {
                    success = false,
                    message = "Error While Deleting."
                });
            }

            await _userService.DeleteAsync(objFromDb);
            _unitOfWork.Save();

            return Json(new
            {
                success = true,
                message = "Delete Successful."
            });
        }

        #endregion

        #region Edit Employee Methods

        /// <summary>
        ///     Using the Employees number, return a view form that will allow the user to amend their details.
        /// </summary>
        /// <param name="empNum"></param>
        /// <returns></returns>
        [HttpGet]
        [ActionName("EditEmployee")]
        public IActionResult EditEmployeeGet(int empNum)
        {
            Employees employee = _unitOfWork.EmployeesRepository.GetFirstOrDefault(x => x.EmployeeNumber.Equals(empNum));
            Teams teams = _unitOfWork.teamRepository.GetById(employee.TeamId);

            EditEmployeeForm editEmployeeForm = new EditEmployeeForm
            {
                EmpSysId = employee.EmpSysId,
                EmployeeNumber = employee.EmployeeNumber,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                FTE = employee.FTE,
                StartDate = employee.StartDate,
                CreateDate = employee.CreateDate,
                CreateId = employee.CreateId,
                UpdateId = employee.UpdateId,
                UpdateDate = employee.UpdateDate,
                TeamId = employee.TeamId,
                SupervisorNumber =  employee.SupervisorNumber,
                Active = employee.Active,
                EmploymentType = employee.EmploymentType,
                TeamName = _unitOfWork.teamRepository.GetTeamListForDropDown().ToList()
            };

            return View(editEmployeeForm);
        }

        /// <summary>
        ///     Post changes to the employee record back to the database.
        /// </summary>
        /// <param name="editEmployeeForm"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionName("EditEmployee")]
        public IActionResult EditEmployeePost(EditEmployeeForm editEmployeeForm)
        {
            var userDetails = _userService.GetUserAsync(User).Result;
            Employees employee = new Employees
            {
                EmpSysId = editEmployeeForm.EmpSysId,
                EmployeeNumber = editEmployeeForm.EmployeeNumber,
                FirstName = editEmployeeForm.FirstName,
                LastName = editEmployeeForm.LastName,
                FTE = editEmployeeForm.FTE,
                StartDate = editEmployeeForm.StartDate,
                CreateDate = editEmployeeForm.CreateDate,
                CreateId = editEmployeeForm.CreateId,
                TeamId = editEmployeeForm.TeamId,
                SupervisorNumber = editEmployeeForm.SupervisorNumber,
                Active = editEmployeeForm.Active,
                EmploymentType = editEmployeeForm.EmploymentType,
                UpdateId = userDetails.EmployeeNumber,
                UpdateDate = DateTime.Now
            };

            if (ModelState.IsValid)
            {
                _unitOfWork.EmployeesRepository.Update(employee);

                return RedirectToAction("ViewTeamDetails", "Teams", new { area = "User", id = employee.TeamId });
            }
            return View(editEmployeeForm);
        }

        #endregion
    }
}