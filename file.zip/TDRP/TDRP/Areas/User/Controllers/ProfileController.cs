﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Dapper;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Areas.User.Controllers
{
    [Authorize]
    [Area("User")]
    public class ProfileController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        public ProfileController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        public async Task<IActionResult> UserProfile(string uid)
        {
            ApplicationUser user = await _userService.FindByIdAsync(uid);
            ViewBag.EmployeeNumber = user.EmployeeNumber;
            ViewBag.TeamId = user.TeamId;
            return View(user);
        }

        /// <summary>
        ///     Calls the stored procedure to retrieve all assigned projects to the specified employee number.
        /// </summary>
        /// <param name="employeeNumber"></param>
        /// <returns></returns>
        public JsonResult GetUserWork(int employeeNumber)
        {
            DynamicParameters empNumber = new DynamicParameters();
            empNumber.Add("@EmployeeNumber", employeeNumber, DbType.Int32, ParameterDirection.Input);

            List<UserAssignedProjects> assignedWork = _unitOfWork.SpCall.ReturnList<UserAssignedProjects>(AppConstant.usp_GetUserWork, empNumber).Result.ToList();

            return Json(new { data = assignedWork });
        }

        #region User Project Assignment

        /// <summary>
        ///     POST Method that can only be completed by an Admin or Manager to save the
        ///     assigned projects to the user.
        /// </summary>
        /// <param name="projects"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Manager, Admin")]
        public PartialViewResult SaveUserWork(string projects)
        {
            // If the JSON string is not null then parse the string to an array for further use.
            if (!string.IsNullOrEmpty(projects))
            {
                // Create a integer variable we can use for the array.
                int projectId = 0;

                JArray jArray = JArray.Parse(projects);

                // Loops through each data item found in the array.
                for (var i = 0; i < jArray.Count; i++)
                {
                    projectId = Convert.ToInt32(jArray[i]);
                    if (ProjectPreviouslyAssigned(projectId) == false)
                    {
                        AssignProjectToUser(projectId);
                    }
                }
            }
            return PartialView("UserWork");
        }

        /// <summary>
        ///     Returns a true or false depending if the User has been assigned
        ///     to project and the end date is null.
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        private bool ProjectPreviouslyAssigned(int projectId)
        {
            // Find the user ID and get the list of projects that have been assigned to the user.
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            var userProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));

            List<AssignedWork> assignedProjects = _unitOfWork.AssignedWorkRepository.GetAll().Where(x => x.ProjectId.Equals(projectId)).ToList();

            // If the project has a null end date then return true and
            // do not proceed to assign to user the project again.
            if (assignedProjects.Exists(x => x.EmployeeNumber.Equals(userProfile.EmployeeNumber) && x.EndDate.Equals(null)))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// </summary>
        /// <param name="projectId"></param>
        private void AssignProjectToUser(int projectId)
        {
            // Get the user ID so we can assign the project ID to a record in AssignedWork.
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            var userProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));

            AssignedWork assignedWork = new AssignedWork
            {
                // Assign values to the AssignedWork model to post back to the database.
                ProjectId = projectId,
                EmployeeNumber = userProfile.EmployeeNumber,
                TeamId = userProfile.TeamId,
                UnnamedResource = false,
                CreatedDate = DateTime.Now,
                CreateId = userProfile.EmployeeNumber
            };
            _unitOfWork.AssignedWorkRepository.Add(assignedWork);
            _unitOfWork.Save();
        } 

        #endregion
    }
}