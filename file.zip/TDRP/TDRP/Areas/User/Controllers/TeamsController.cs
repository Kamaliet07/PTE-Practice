﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Areas.User.Controllers
{
    [Authorize]
    [Area("User")]
    public class TeamsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        [BindProperty]
        public TeamProjects _teamProjects { get; set; }

        /// <summary>
        ///     Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        public TeamsController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        public void TempDataMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }
        }

        public IActionResult ViewTeams()
        {
            List<Teams> objTeamList = _unitOfWork.teamRepository.GetAllTeamDetails().ToList();
            return View(objTeamList);
        }

        [HttpGet]
        public IActionResult GetAllTeams()
        {
            return Json(new { data = _unitOfWork.SpCall.ReturnList<Teams>(AppConstant.usp_GetTeams).Result });
        }

        /// <summary>
        ///     GET Method to retrieve team details using the TeamId.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public IActionResult ViewTeamDetails(int id)
        {
            // Gets the user ID of the person creating the employee so we can retrieve their team ID.
            var userDetails = _userService.GetUserAsync(User).Result;

            DynamicParameters teamProj = new DynamicParameters();
            teamProj.Add("@TeamId", id, DbType.Int32, ParameterDirection.Input);

            _teamProjects = new TeamProjects()
            {
                Teams = _unitOfWork.teamRepository.GetById(id),
                Teamproject = _unitOfWork.SpCall.ReturnList<TeamProject>(AppConstant.usp_GetTeamProjects, teamProj).Result.ToList()
            };

            ViewBag.TeamId = id;
            ViewBag.EmployeeNumber = userDetails.EmployeeNumber;

            return View(_teamProjects);
        }

        /// <summary>
        ///     GET Method used to retrieve the team's active projects which will be displayed in a data table.
        /// </summary>
        /// <param name="teamId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult LoadActiveProjects(int teamId)
        {
            List<Projects> teamProjects = _unitOfWork.projectRepository.GetAllProjectDetails()
                .Where(x => x.TeamId.Equals(teamId)).ToList();

            return Json(new { data = teamProjects });
        }

        /// <summary>
        ///     Partial view to display team members and their assigned projects.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult ViewTeamEmployees(int id)
        {
            DynamicParameters teamId = new DynamicParameters();
            teamId.Add("@TeamId", id, DbType.Int32, ParameterDirection.Input);

            List<Employees> employees = _unitOfWork.SpCall.ReturnList<Employees>(AppConstant.usp_GetActiveTeamMembers, teamId).Result.ToList();

            return Json(new { data = employees });
        }

        /// <summary>
        ///     Get the Six Month Allocation Details of Employee
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetSixMonthsAllocation(int empId)
        {
            DynamicParameters dallo = new DynamicParameters();
            dallo.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            List<MonthsAllocated> monthAlloca = _unitOfWork.SpCall.ReturnList<MonthsAllocated>(AppConstant.usp_GetProjectsAllocationSixMonth, dallo).Result.ToList();
            return Json(new { data = monthAlloca });
        }

        #region Add Team Methods

        /// <summary>
        ///     GET Method for adding new teams to the application.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Manager, Admin")]
        public IActionResult AddTeam()
        {
            Teams team = new Teams();

            return View(team);
        }

        /// <summary>
        ///     POST Method for adding teams to the application.
        /// </summary>
        /// <param name="team"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("AddTeam")]
        public IActionResult AddTeamPost(Teams team)
        {
            // If the model state is valid then submit the record to the database
            // and save the changes.
            if (ModelState.IsValid)
            {
                _unitOfWork.teamRepository.Add(team);
                _unitOfWork.Save();

                return RedirectToAction(nameof(ViewTeams));
            }

            return View(team);
        }
        #endregion

        #region Edit Team Methods

        /// <summary>
        ///     GET Method to retrieve data for the team that will be amended.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Manager, Admin")]
        public IActionResult EditTeam(int id)
        {
            Teams team = new Teams();
            team = _unitOfWork.teamRepository.GetById(id);

            if (team == null)
            {
                return NotFound();
            }
            return View(team);
        }

        /// <summary>
        ///     POST Method to update the team details.
        /// </summary>
        /// <param name="team"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize]
        [ActionName("EditTeam")]
        [ValidateAntiForgeryToken]
        public IActionResult EditTeamPost(Teams team)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Get the user ID so we can assign it to records when making updates.
                    var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
                    var userProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));

                    // Change the update ID to the employee number of the user.
                    team.UpdateId = userProfile.EmployeeNumber;

                    _unitOfWork.teamRepository.Update(team);

                    TempDataMessage(TDRPResource.msg, TDRPResource.titleSuccess, TDRPResource.changeSuccess);

                    return RedirectToAction("ViewTeamDetails", new { id = team.TeamId });
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex);
            }
            return View(team);
        }

        #endregion

        #region Delete Team Methods

        /// <summary>
        ///     Delete the selected team.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [Authorize(Roles = "Manager, AdminS")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteTeam(int id)
        {
            Teams objFromDb = _unitOfWork.teamRepository.GetById(id);
            if (objFromDb == null)
            {
                return Json(new
                {
                    success = false,
                    message = "Error While Deleting."
                });
            }

            _unitOfWork.teamRepository.Remove(objFromDb);
            _unitOfWork.Save();

            return Json(new
            {
                success = true,
                message = "Delete Successful."
            });
        }

        #endregion

        #region Add Employee Method

        /// <summary>
        ///     POST Method to add the newly created employee to the database if the duplication check returns true.
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ActionName("AddEmployee")]
        public IActionResult AddEmployeePost(Employees employee)
        {
            if (ModelState.IsValid)
            {
                if (employee.EmpSysId == 0 && DuplicateEmployeeExists(employee.EmployeeNumber).Equals(false))
                {
                    _unitOfWork.EmployeesRepository.Add(employee);
                    _unitOfWork.Save();

                    return RedirectToAction("ViewTeamDetails", new { id = employee.TeamId });
                }
            }
            return RedirectToAction("ViewTeamDetails", new { id = employee.TeamId });
        }

        /// <summary>
        ///     Bool Method checks the details of the employee to see if they already exist on the database before allowing
        ///     the AddEmployeePost method to save the details to the database.
        /// </summary>
        /// <param name="employeeNumber"></param>
        /// <returns></returns>
        public bool DuplicateEmployeeExists(int employeeNumber)
        {
            try
            {
                // Search the employees table with the employee number and return a result.
                Employees employeeFound = _unitOfWork.EmployeesRepository.GetFirstOrDefault(x => x.EmployeeNumber.Equals(employeeNumber));

                // If a record is found then return true.
                if (employeeFound != null)
                {
                    return true;
                }
                return false;
            }
            // If an error occurs, return true to prevent the details being posted.
            catch
            {
                return true;
            }
        }

        #endregion Methods

        #region Delete Employee Methods

        /// <summary>
        ///     When the user clicks the delete icon it will insert an end date into the employee record.
        /// </summary>
        /// <param name="employeeNumber"></param>
        /// <returns></returns>
        public JsonResult DeleteEmployee(int employeeNumber)
        {
            //Find the ID of the current user.
            var id = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            var userProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(id));

            // Find the record of the employee.
            Employees employee = _unitOfWork.EmployeesRepository.GetFirstOrDefault(x => x.EmployeeNumber.Equals(employeeNumber));

            // If a record has been found update it with an end date and the update ID of the user.
            if (employee != null)
            {
                employee.Active = false;
                employee.EndDate = DateTime.Now;

                _unitOfWork.EmployeesRepository.Update(employee);

                return Json(new { success = true });
            }
            return Json(new { success = false });
        }

        #endregion Delete Employee Methods
    }
}