﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Areas.User.Controllers
{
    [Authorize]
    [Area("User")]
    public class ProjectAllocationController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<ProjectAllocationController> _logger;

        [BindProperty]
        public ProjectsAllocation ProjAllocation { get; set; }

        public ProjectAllocationController(IUnitOfWork unitOfWork, ILogger<ProjectAllocationController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }
       
        /// <summary>
        /// Index method to load user and assigned projects detail
        /// </summary>
        /// <param name="empid"></param>
        /// <param name="projectid"></param>
        /// <returns></returns>
        public IActionResult ProjectAllocation(int empid, int projectid)
        {
            DynamicParameters empdetailsParam = new DynamicParameters();
            empdetailsParam.Add("@EmployeeNo", empid, DbType.Int32, ParameterDirection.Input);
            empdetailsParam.Add("@ProjectId", projectid, DbType.Int32, ParameterDirection.Input);

            List<EmployeeDetails> employeeDetails = _unitOfWork.SpCall.ReturnList<EmployeeDetails>(AppConstant.usp_GetEmployeeDetails, empdetailsParam).Result.ToList();

            ProjAllocation = new ProjectsAllocation()
            {
                EmployeeDetails = employeeDetails[0],
                Project = _unitOfWork.projectRepository.GetById(projectid),                
            };       

            return View(ProjAllocation);
        }        

        /// <summary>
        /// Method to get total FTE allocated to employee
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetMonthlyAllocation(int empId, string currmonth)
        {
            DynamicParameters fteall = new DynamicParameters();
            fteall.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            fteall.Add("@Month", currmonth, DbType.String, ParameterDirection.Input);
            List<DaysAllocated> total = _unitOfWork.SpCall.ReturnList<DaysAllocated>(AppConstant.usp_GetMonthlyAllocation, fteall).Result.ToList();

            return Json(new { data = total[0] });
        }

        /// <summary>
        /// Method To Get The Remaining Days In Month
        /// </summary>
        /// <param name="empId">employee number</param>
        /// <param name="currmonth">Month Selected</param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetRemainingDaysInMonth(int empId, string currmonth)
        {
            DynamicParameters rdays = new DynamicParameters();
            rdays.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            rdays.Add("@Month", currmonth, DbType.String, ParameterDirection.Input);
            List<int> total = _unitOfWork.SpCall.ReturnList<int>(AppConstant.usp_GetRemainingDaysInMonth, rdays).Result.ToList();
            return Json(new { data = total[0] });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetSixMonthsAllocation(int empId)
        {
            DynamicParameters dallo = new DynamicParameters();
            dallo.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);            
            List<MonthsAllocated> monthAlloca = _unitOfWork.SpCall.ReturnList<MonthsAllocated>(AppConstant.usp_GetProjectsAllocationSixMonth, dallo).Result.ToList();

            return Json(new { data = monthAlloca });
        }

        /// <summary>
        /// Get the Allocation Details for Selected Month
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetAllocationDetails(int empId, string currmonth, int projectid)
        {
            DynamicParameters allodetails = new DynamicParameters();
            allodetails.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
            allodetails.Add("@ProjectId", projectid, DbType.Int32, ParameterDirection.Input);
            allodetails.Add("@Month", currmonth, DbType.String, ParameterDirection.Input);
            List<AllocationDetails> lstAlloca = _unitOfWork.SpCall.ReturnList<AllocationDetails>(AppConstant.usp_GetAllocationDetails, allodetails).Result.ToList();

            return Json(new { data = lstAlloca });
        }

        /// <summary>
        /// Method to Load The Allocation Run Time When Tab Selected
        /// </summary>
        /// <param name="empNo"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult LoadProjectAllocationPartial(int empNo, string selectedmonth)
        {
            DynamicParameters allocat = new DynamicParameters();
            allocat.Add("@EmployeeNo", empNo, DbType.Int32, ParameterDirection.Input);
            allocat.Add("@Month", selectedmonth, DbType.String, ParameterDirection.Input);
            List<ProjectsAssigned> lstAllocapartial = _unitOfWork.SpCall.ReturnList<ProjectsAssigned>(AppConstant.usp_GetAssignedProjects, allocat).Result.ToList();
            return Json(new { data = lstAllocapartial });            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="projId"></param>
        /// <param name="hoursPerday"></param>
        /// <param name="month"></param>
        /// <param name="totalHr"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult SaveProjectAllocation(int empId, int projId, int allocatedday, string month, int workingdays, DateTime startdate, DateTime endDate, int teamID)
        {
            try
            {
                DynamicParameters fteall = new DynamicParameters();
                fteall.Add("@EmployeeNo", empId, DbType.Int32, ParameterDirection.Input);
                fteall.Add("@ProjectId", projId, DbType.Int32, ParameterDirection.Input);
                fteall.Add("@TeamId", teamID, DbType.Int32, ParameterDirection.Input);
                fteall.Add("@AllocatedDay", allocatedday, DbType.Int32, ParameterDirection.Input);
                fteall.Add("@Month", month, DbType.String, ParameterDirection.Input);                
                fteall.Add("@Workingdays", workingdays, DbType.Int32, ParameterDirection.Input);
                fteall.Add("@StartDate", startdate, DbType.Date, ParameterDirection.Input);
                fteall.Add("@EndDate", endDate, DbType.Date, ParameterDirection.Input);                

                _unitOfWork.SpCall.ExecuteWithoutReturn(AppConstant.usp_SaveProjectAllocation, fteall);                
            }
            catch(Exception ex)
            {
                string msg = "Project Allocation - Unable to save changes. " + ex.Message;
                _logger.LogError(msg);
                TempDataMessage(TDRPResource.msg, TDRPResource.msgError, msg);
            }

            return RedirectToAction("ProjectAllocation", "ProjectAllocation", new
            {
                empid = empId,
                projectid = projId
            });
        }

        /// <summary>
        /// Method to handle Error Message
        /// </summary>
        /// <param name="key"></param>
        /// <param name="alert"></param>
        /// <param name="value"></param>
        public void TempDataMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }
        }
    }
}