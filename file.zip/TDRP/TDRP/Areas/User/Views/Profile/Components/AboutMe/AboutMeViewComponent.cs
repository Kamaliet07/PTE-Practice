﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.ViewModel;

namespace TDRP.Areas.User.Views.Profile.Components.AboutMe
{
    public class AboutMeViewComponent : ViewComponent
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        public AboutMeViewComponent(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        public async Task<IViewComponentResult> InvokeAsync(ProfileViewModel profileModel)
        {
            return await Task.FromResult((IViewComponentResult)View("Default", profileModel));
        }
    }
}
