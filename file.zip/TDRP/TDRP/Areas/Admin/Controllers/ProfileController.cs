﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.UI.V3.Pages.Internal.Account.Manage;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ProfileController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        ///     Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        public ProfileController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        /// <summary>
        ///     Index method To Load profile
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public async Task<IActionResult> MyProfile()
        {
            ApplicationUser user = await _userService.GetUserAsync(HttpContext.User);
            return View(user);
        }

        /// <summary>
        ///     Method to update about me details
        /// </summary>
        /// <param name="profileId">profile id</param>
        /// <param name="headlines">profile headlines</param>
        /// <param name="profDetails">brief details</param>
        /// <param name="workLocation">Work Location</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<PartialViewResult> UpdateAboutMe(int profileId, string headlines, string profDetails, string workLocation)
        {
            ApplicationUser user = await _userService.GetUserAsync(User);
            UserProfileDetails objUserProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(user.Id));
            if (objUserProfile == null)
            {
                objUserProfile = new UserProfileDetails();
            }
            objUserProfile.UserId = user.Id;

            if (ModelState.IsValid)
            {
                if (profileId == 0)
                {
                    _unitOfWork.userprofile.Add(objUserProfile);
                }
                else
                {
                    _unitOfWork.userprofile.Update(objUserProfile);
                }
                user.TeamId = objUserProfile.TeamId;
                _unitOfWork.Save();
            }
            return PartialView("AboutMe", objUserProfile);
        }

        #region User Project Assignment
        /// <summary>
        ///     Method to get employee experience
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Authorize]
        public JsonResult GetAssignedWork()
        {
            //Find the ID of the current user.
            var id = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            var userProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(id));
            ViewBag.TeamId = userProfile.TeamId;

            // Create a Dynamic parameter for a Dapper to execute a stored procedure.
            DynamicParameters userId = new DynamicParameters();
            userId.Add("@UserId", id, DbType.String, ParameterDirection.Input);

            // Store the results in a list and post as a json object to be dealt with by the Data table.
            List<AssignedWorkDetails> assignedWork = _unitOfWork.SpCall
                .ReturnList<AssignedWorkDetails>(AppConstant.usp_GetAssignedWorkDetails, userId).Result.ToList();

            return Json(new { data = assignedWork });
        }

        /// <summary>
        ///     POST Method that can only be completed by an Admin or Manager to save the
        ///     assigned projects to the user.
        /// </summary>
        /// <param name="projects"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Manager, Admin")]
        public PartialViewResult SaveAssignedWork(string projects)
        {
            // Find the user ID and get the list of projects that have been assigned to the user.
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            UserProfileDetails userProfileDetails =
                _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));

            // If the JSON string is not null then parse the string to an array for further use.
            if (!string.IsNullOrEmpty(projects))
            {
                // Create a integer variable we can use for the array.

                JArray jArray = JArray.Parse(projects);

                // Loops through each data item found in the array.
                foreach (var i in jArray)
                {
                    var projectId = Convert.ToInt32(i);
                    if (ProjectPreviouslyAssigned(projectId, userProfileDetails.EmployeeNumber) == false)
                    {
                        AssignProjectToUser(projectId);
                    }
                }
            }
            return PartialView("AssignedWork");
        }

        /// <summary>
        ///     Returns a true or false depending if the User has been assigned
        ///     to project and the end date is null.
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private bool ProjectPreviouslyAssigned(int projectId, int? employeeNumber)
        {
            List<AssignedWork> assignedProjects = _unitOfWork.AssignedWorkRepository.GetAll().Where(x => x.ProjectId.Equals(projectId)).ToList();

            // If the project has a null end date then return true and
            // do not proceed to assign to user the project again.
            if (assignedProjects.Exists(x => x.EmployeeNumber.Equals(employeeNumber) && x.ProjectId.Equals(projectId) && x.EndDate.Equals(null)))
            {
                return true;
            }
            return false;
        }

        private void AssignProjectToUser(int projectId)
        {
            // Get the user ID so we can assign the project ID to a record in AssignedWork.
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            var userProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));

            AssignedWork assignedWork = new AssignedWork
            {
                // Assign values to the AssignedWork model to post back to the database.
                ProjectId = projectId,
                EmployeeNumber = userProfile.EmployeeNumber,
                TeamId = userProfile.TeamId,
                UnnamedResource = false,
                CreatedDate = DateTime.Now,
                CreateId = userProfile.EmployeeNumber
            };

            // Add the records to the repository and post to the database.
            _unitOfWork.AssignedWorkRepository.Add(assignedWork);
            _unitOfWork.Save();
        }

        #endregion

        /// <summary>
        ///     Method to Get the team list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetTeamList()
        {
            var teams = _unitOfWork.teamRepository.GetAll();
            return Json(teams);
        }

        /// <summary>
        ///     Method to get Autocomplete Job Roles
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetJobRoles(string search)
        {
            List<JobRoles> allsearch = _unitOfWork.jobRolesRepository.GetAll(x => x.JobRole.Contains(search)).Select(
                x => new JobRoles
                {
                    JobRoleId = x.JobRoleId,
                    JobRole = x.JobRole
                }).ToList();

            return Json(allsearch);
        }

        #region User Skills

        /// <summary>
        ///     Methods to get Autocomplete Skills
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetSkills(string search)
        {
            List<Skills> allsearch = _unitOfWork.skillRepository.GetAll(x => x.Skill.Contains(search)).Select(
                x => new Skills
                {
                    SkillId = x.SkillId,
                    Skill = x.Skill
                }).ToList();

            return Json(allsearch);
        }

        /// <summary>
        ///     Method to get employee Skills
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetEmployeeSkills()
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            return Json(new { data = _unitOfWork.userSkillsRepository.GetAll(x => x.UserId.Equals(userId)) });
        }

        /// <summary>
        ///     Method to save Experience details
        /// </summary>
        /// <param name="expDetails"></param>
        /// <returns></returns>
        [HttpPost]
        public PartialViewResult SaveEmployeeSkills(string values)
        {
            UserSkills userSkill = null;
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            if (!string.IsNullOrEmpty(values))
            {
                // Parse and deserialize the JSON object
                JArray array = JArray.Parse(values);
                foreach (JToken jToken in array)
                {
                    userSkill = new UserSkills();
                    JToken[] innerArray = jToken.ToArray();
                    userSkill.Skill = innerArray[0].First.ToString();
                    userSkill.UserId = userId;
                    userSkill.CreatedDate = DateTime.Now;
                    userSkill.Active = true;
                    _unitOfWork.userSkillsRepository.Add(userSkill);
                    _unitOfWork.Save();
                }
            }
            return PartialView("EmployeeSkills");
        }

        /// <summary>
        ///     Method to delete the Employee Skills
        /// </summary>
        /// <param name="id">User Skill Id</param>
        /// <returns></returns>
        [HttpDelete]
        public IActionResult DeleteEmployeeSkill(int id)
        {
            var objFromDb = _unitOfWork.userSkillsRepository.GetFirstOrDefault(x => x.SysId.Equals(id));
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting." });
            }

            _unitOfWork.userSkillsRepository.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful." });
        } 

        #endregion

        /// <summary>
        ///     Method to update basic details
        /// </summary>
        /// <param name="profileId">Profile Id</param>
        /// <param name="fistName">User Firs Name</param>
        /// <param name="lastName">User Last Name</param>
        /// <param name="phoneNumber">phone Number</param>
        /// <param name="hireDate">Hire Date</param>
        /// <param name="teamId">Team Assigned</param>
        /// <param name="jobRolesId">Job Role Assigned</param>
        /// <param name="gender">Gender</param>
        /// <param name="dob">Date Of Birth</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult UpdateBasicDetails(int profileId, string fistName, string lastName, int teamId, int jobRolesId)
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            UserProfileDetails objUserProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));
            if (objUserProfile == null)
            {
                objUserProfile = new UserProfileDetails();
            }
            objUserProfile.FirstName = fistName;
            objUserProfile.LastName = lastName;
            objUserProfile.TeamId = teamId;
            objUserProfile.JobRoleId = jobRolesId;
            objUserProfile.UserId = userId;

            if (profileId == 0)
            {
                _unitOfWork.userprofile.Add(objUserProfile);
            }
            else
            {
                _unitOfWork.userprofile.Update(objUserProfile);
            }
            _unitOfWork.Save();

            return PartialView("BasicDetails", objUserProfile);
        }

        public ActionResult GetWorkDetails()
        {
            // to do : Update to include the data for the view
            return PartialView("EmployeeWorkDetail");
        }
    }
}