﻿using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;
using TDRP.ViewModel;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ProjectsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        public ProjectsController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }
        public void TempDataMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }
        }

        public IActionResult ViewProjects()
        {
            return View();
        }

        /// <summary>
        ///     Returns a view showing a table of the projects that are currently on
        ///     the Resource Planner application.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult ProjectList()
        {
            List<ProjectList> projectList = _unitOfWork.SpCall.ReturnList<ProjectList>(AppConstant.usp_ProjectList).Result.ToList();

            return Json(new { data = projectList });
        }

        /// <summary>
        ///     Called when the user clicks on a project in the projects overview table.   
        /// </summary>
        /// <param name="id"></param>
        /// <returns>
        ///     Returns a screen showing project details using the project ID.
        /// </returns>
        public IActionResult ProjectDetails(int id)
        {
            // Create a dynamic parameter that will be used in the stored procedure to retrieve
            // the project details.
            DynamicParameters projectId = new DynamicParameters();
            projectId.Add("@ProjectId", id, DbType.Int32, ParameterDirection.Input);

            // Create a ViewBag for the project ID that will be used to fetch the data for
            // the assigned employees table.
            ViewBag.ProjectId = id;

            List<ProjectDetail> project = _unitOfWork.SpCall.ReturnList<ProjectDetail>(AppConstant.usp_GetProjectDetail, projectId).Result.ToList();

            return View(project);
        }

        /// <summary>
        ///     Used by the Partial view data table to display a list of employees who are currently assigned to the project.
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult ViewAssignedEmployees(int projectId)
        {
            // Create a new dynamic parameter to be used in the Dapper Stored Procedure Query
            DynamicParameters projId = new DynamicParameters();
            projId.Add("@ProjectId", projectId, DbType.Int32, ParameterDirection.Input);

            // Get a list of all employees that work in the manager's team.
            List<ViewEmployeeList> assignedEmployees = _unitOfWork.SpCall
                .ReturnList<ViewEmployeeList>(AppConstant.usp_GetAssignedEmployees, projId).Result.ToList();

            return Json(new { data = assignedEmployees });
        }

        #region Add Project Methods

        /// <summary>
        ///     GET Method that will retrieve information for the AddProject Page.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ActionName("AddProject")]
        [Authorize(Roles = "Manager, Admin")]
        public IActionResult AddProjectGet(int id)
        {
            AddProject project = new AddProject();
            List<SelectListItem> projectCat = _unitOfWork.projectCategoriesRepository.GetCategoriesDropDown().ToList();

            // Add the select list to the ViewBag so it can be used in the view.
            ViewBag.ProjectCat = projectCat;
            project.TeamId = id;
            project.TeamName = _unitOfWork.teamRepository.GetFirstOrDefault(x => x.TeamId.Equals(id)).TeamName;

            return View(project);
        }

        /// <summary>
        ///     POST Method that will check the model state and insert a new record into the Projects
        ///     table if the user has completed the form correctly.
        /// </summary>
        /// <param name="project"></param>
        /// <returns>
        ///     Unit of Work posts data to the Projects table.
        /// </returns>
        [HttpPost]
        [Authorize(Roles = "Admin, Manager")]
        [ActionName("AddProject")]
        public IActionResult AddProjectPost(AddProject project)
        {
            // Get the user ID so we can assign it to records when making updates.
            var userProfile = _userService.GetUserAsync(User).Result;

            if (ModelState.IsValid)
            {
                Projects newProject = new Projects
                {
                    TeamId = project.TeamId,
                    ProjectName = project.ProjectName,
                    ProjectDescription = project.ProjectDescription,
                    StartDate = project.StartDate,
                    EndDate = project.EndDate,
                    EstimatedBudget = project.EstimatedBudget,
                    Category = project.Category,
                    CreateId = userProfile.EmployeeNumber,
                    CreatedDate = DateTime.Now
                };

                _unitOfWork.projectRepository.Add(newProject);
                _unitOfWork.Save();

                // Redirect the user back to the Team Details page of the Team they created the Project for.
                return RedirectToAction("ViewTeamDetails", "Teams", new { id = project.TeamId, Area = "User" });
            }

            List<SelectListItem> projectCat = _unitOfWork.projectCategoriesRepository.GetCategoriesDropDown().ToList();
            // Add the select list to the ViewBag so it can be used in the view.
            ViewBag.ProjectCat = projectCat;
            return View(project);
        }

        #endregion

        #region Edit Poject Methods

        /// <summary>
        ///     GET Method to allow the user to edit the project details.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Manager, Admin")]
        public IActionResult EditProjectDetails(int id)
        {
            // Create a new instance of the ProjectDetails class and use the id to find the data.
            Projects project = _unitOfWork.projectRepository.GetById(id);

            if (project == null)
            {
                return NotFound();
            }

            List<SelectListItem> projectCat = _unitOfWork.projectCategoriesRepository.GetCategoriesDropDown().ToList();

            ViewBag.ProjectCat = projectCat;

            return View(project);
        }

        /// <summary>
        ///     POST Method when the user submits the form it will validate the data
        ///     and post the changes to the database.
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionName("EditProjectDetails")]
        public IActionResult EditProjectDetailsPost(Projects project)
        {
            try
            {
                // Get the user ID so we can assign it to records when making updates.
                var userProfile = _userService.GetUserAsync(User).Result;
                project.UpdateId = userProfile.EmployeeNumber;
                project.UpdatedDate = DateTime.Now;

                // Validate the data before attempting to insert it into the database table.
                if (ModelState.IsValid)
                {
                    _unitOfWork.projectRepository.Update(project);

                    return RedirectToAction("ProjectDetails", new { id = project.ProjectId });
                }
            }
            catch (Exception ex)
            {
                // info.
                Console.Write(ex);
            }
            return View(project);
        }

        #endregion

        #region Employee Assignment Methods

        /// <summary>
        ///     When the manager/admin is in the Project Details view they will be able to open up a new table
        ///     to assign employees to the project that have not yet been assigned to the project.
        /// </summary>
        /// <param name="projId"></param>
        /// <returns>
        ///     View showing the employees that have not yet been assigned to the project.
        /// </returns>
        [HttpGet]
        [Authorize(Roles = "Manager, Admin")]
        public IActionResult AssignEmployeeProject(int projId)
        {
            // Create a ViewBag so the user can return to the project details screen.
            ViewBag.ProjectId = projId;

            return View();
        }

        /// <summary>
        ///     Takes the project ID and returns a list of Employees who are not assigned to the project.
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public JsonResult AssignEmployeeResult(int projectId)
        {
            // Create a new dynamic parameter to be used in the Dapper Stored Procedure Query
            DynamicParameters projId = new DynamicParameters();
            projId.Add("@ProjectId", projectId, DbType.Int32, ParameterDirection.Input);

            // Get a list of all employees that work in the manager's team.
            List<ViewEmployeeList> objEmpList = _unitOfWork.SpCall
                .ReturnList<ViewEmployeeList>(AppConstant.usp_GetUnassignedEmployees, projId).Result.ToList();

            return Json(new { data = objEmpList });
        }

        /// <summary>
        ///     POST Method that can only be completed by an Admin or Manager to save the
        ///     assigned projects to the user.
        /// </summary>
        /// <param name="employeeId"></param>
        /// <param name="projectId"></param>
        /// <returns>
        ///     View of the Assignable Employees after the data has been posted.
        /// </returns>
        [HttpPost]
        [Authorize(Roles = "Manager, Admin")]
        [ActionName("AssignEmployeeProject")]
        public JsonResult AssignEmployeeProjectPost(int employeeId, int projectId)
        {
            Projects project = _unitOfWork.projectRepository.GetById(projectId);

            // If the user tries to assign an employee to a project that has already ended return an expired alert message.
            if (project.EndDate > DateTime.Now)
            {
                if (EmployeePreviouslyAssigned(employeeId, projectId) == false)
                {
                    AssignEmployeeToProject(employeeId, projectId);

                    // Pass JSON result back to the JQuery function so it can display the success message alert.
                    return Json(new { success = true });
                }
                return Json(new { error = true });
            }
            return Json(new { expired = true });
        }

        /// <summary>
        ///     Returns a true or false depending if the User/Employee has been assigned
        ///     to project and the end date is null.
        /// </summary>
        /// <param name="employeeId"></param>
        /// <param name="projectId"></param>
        /// <returns>
        ///     FALSE if the user is not currently assigned to the project.
        ///     TRUE if the user is currently assigned.
        /// </returns>
        private bool EmployeePreviouslyAssigned(int? employeeId, int projectId)
        {
            List<AssignedWork> assignedProjects = _unitOfWork.AssignedWorkRepository.GetAll().Where(x => x.ProjectId.Equals(projectId)).ToList();

            // If the project has a null end date then return true and
            // do not proceed to assign to user the project again.
            if (assignedProjects.Exists(x => x.EmployeeNumber.Equals(employeeId) && x.ProjectId.Equals(projectId) && x.EndDate.Equals(null)))
            {
                return true;
            }
            // else
            return false;
        }

        /// <summary>
        ///     Takes the Employee Number and Project ID to insert a new record into the AssignedWork table.
        /// </summary>
        /// <param name="employeeId"></param>
        /// <param name="projectId"></param>
        private void AssignEmployeeToProject(int employeeId, int projectId)
        {
            // Get the user ID so we can assign the project ID to a record in AssignedWork.
            var userProfile = _userService.GetUserAsync(User).Result;
            // Get the details for the employee that is being assigned to the project.
            var employee = _unitOfWork.EmployeesRepository.GetFirstOrDefault(x => x.EmployeeNumber.Equals(employeeId));

            AssignedWork assignedWork = new AssignedWork
            {
                // Assign values to the AssignedWork model to post back to the database.
                ProjectId = projectId,
                EmployeeNumber = employeeId,
                TeamId = employee.TeamId,
                CreatedDate = DateTime.Now,
                CreateId = userProfile.EmployeeNumber,
                UnnamedResource = false
            };
            // Add the records to the repository and post to the database.
            _unitOfWork.AssignedWorkRepository.Add(assignedWork);
            _unitOfWork.Save();
        }

        /// <summary>
        ///    Validates the user before inserting an end date and update ID into the
        ///    record containing the assignedWorkId. 
        /// </summary>
        /// <param name="assignedWorkId"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Admin, Manager")]
        public IActionResult RemoveEmployeeFromProject(int assignedWorkId)
        {
            // Get the current user ID and their employee number for the update ID column.
            var userProfile = _userService.GetUserAsync(User).Result;

            // Retrieve the open record from the database table.
            AssignedWork assignedWork = _unitOfWork.AssignedWorkRepository.GetById(assignedWorkId);

            if (assignedWork.EndDate == null)
            {
                // Insert update details and an end date.
                assignedWork.UpdateId = userProfile.EmployeeNumber;
                assignedWork.UpdatedDate = DateTime.Now;
                assignedWork.EndDate = DateTime.Now;

                // Update the record on database and save the changes.
                _unitOfWork.AssignedWorkRepository.Update(assignedWork);
                _unitOfWork.Save();

                return Json(new { success = true });
            }
            return Json(new { error = true });
        }

        #endregion

        #region Unallocated Resource Assignment Methods

        /// <summary>
        ///     Returns the team's available remaining capacity for the selected month.
        /// </summary>
        /// <param name="teamId"></param>
        /// <param name="monthId"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetTeamCapacityInMonth(int teamId, int monthId, int year)
        {
            try
            {
                DynamicParameters chartParameters = new DynamicParameters();
                chartParameters.Add("@TeamId", teamId, DbType.Int32, ParameterDirection.Input);
                chartParameters.Add("@MonthId", monthId, DbType.Int32, ParameterDirection.Input);
                chartParameters.Add("@Year", year, DbType.Int32, ParameterDirection.Input);

                List<AreaAllocationChart> areaAllocationChart = _unitOfWork.SpCall.ReturnList<AreaAllocationChart>(
                    AppConstant.usp_GetWorkingDaysInMonth,
                    chartParameters).Result.ToList();

                return Json(new { success = true, areaChart = areaAllocationChart });
            }
            catch
            {
                string errorMessage =
                    "Stored Procedure call failed.  Please contact site admin for further assistance.";
                return Json(new { error = true, errorMessage = errorMessage });
            }
        }

        /// <summary>
        ///     Posts unnamed resource assignment to the UnnamedAssignments table.  It will query the table first to see if a
        ///     record already exists for the Team, Month, Year and Project.  If so, update the record else insert a new one.
        /// </summary>
        /// <param name="teamId"></param>
        /// <param name="projectId"></param>
        /// <param name="assignedDays"></param>
        /// <param name="daysInMonth"></param>
        /// <param name="monthId"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult AssignUnnamedResource(int teamId, int projectId, int assignedDays, int daysInMonth, int monthId, int year)
        {
            Projects project = _unitOfWork.projectRepository.GetFirstOrDefault(x => x.ProjectId.Equals(projectId));
            // Check the end date of the project.  Display error if the project has ended and do not post assignment.
            if (project.EndDate < DateTime.Now)
            {
                return Json(new { projectEnded = true });
            }
            // Check if the record exists.  If not, insert a new record.
            if (UnnamedResourceExists(teamId, projectId) == false)
            {
                try
                {
                    // Get the user ID so we can assign the project ID to a record in AssignedWork.
                    var userProfile = _userService.GetUserAsync(User).Result;

                    AssignedWork assignedWork = new AssignedWork
                    {
                        // Assign values to the AssignedWork model to post back to the database.
                        ProjectId = projectId,
                        TeamId = teamId,
                        CreatedDate = DateTime.Now,
                        CreateId = userProfile.EmployeeNumber,
                        UnnamedResource = true
                    };
                    // Add the records to the repository and post to the database.
                    _unitOfWork.AssignedWorkRepository.Add(assignedWork);
                    _unitOfWork.Save();

                    return Json(new { success = true });
                }
                catch
                {
                    // Return error data to the js function and display a sweet alert message to inform the user an error has occurred.
                    return Json(new { error = true });
                }
            }
            return Json(new { existingRecord = true });
        }

        private bool UnnamedResourceExists(int? teamId, int projectId)
        {
            List<AssignedWork> assignedProjects = _unitOfWork.AssignedWorkRepository.GetAll().Where(x => x.ProjectId.Equals(projectId)).ToList();

            // If the project has a null end date then return true and
            // do not proceed to assign to user the project again.
            if (assignedProjects.Exists(x => x.TeamId.Equals(teamId) && x.EmployeeNumber.Equals(null) && x.ProjectId.Equals(projectId) && x.EndDate.Equals(null) && x.UnnamedResource.Equals(true)))
            {
                return true;
            }
            // else
            return false;
        }

        /// <summary>
        ///     Uses the Team's AssignedWorkId to retrieve details for the unnamed resource assignment view.
        /// </summary>
        /// <param name="assignedWorkId"></param>
        /// <returns></returns>
        public IActionResult UnnamedAssignment(int assignedWorkId)
        {
            AssignedWork assignedWork = _unitOfWork.AssignedWorkRepository.GetFirstOrDefault(x => x.AssignedWorkId.Equals(assignedWorkId));

            ViewData["TeamName"] = _unitOfWork.teamRepository
                .GetFirstOrDefault(x => x.TeamId.Equals(assignedWork.TeamId)).TeamName;

            return View(assignedWork);
        }

        /// <summary>
        ///     Take the unnamed resource and insert a record into ProjectAllocations
        ///     once the data has passed all of the checks in the method.
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="teamId"></param>
        /// <param name="allocatedDays"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <param name="workingDays"></param>
        /// <returns></returns>
        public JsonResult AssignDaysToTeam(int projectId, int teamId, int allocatedDays, string month, int year, int workingDays)
        {
            // Retrieve the project details so we can use the end date to check if the user is being allocated
            // time past the end of the project.
            Projects project = _unitOfWork.projectRepository.GetById(projectId);

            // Get the month number and create a new date to check the project end date is not greater than the month
            // and year specified.
            int monthNumber = Convert.ToDateTime("01-" + month + "-" + year).Month;
            DateTime dateCheck = new DateTime(year, monthNumber, 1);

            try
            {
                // Check if the project end date is greater than the date the user is trying to assign to the resource.
                if (project.EndDate > dateCheck)
                {
                    // Create new dynamic parameter and assign the variables to the properties before posting to the database.
                    DynamicParameters unnamedResource = new DynamicParameters();
                    unnamedResource.Add("@EmployeeNo", 0, DbType.Int32, ParameterDirection.Input);
                    unnamedResource.Add("@ProjectId", projectId, DbType.Int32, ParameterDirection.Input);
                    unnamedResource.Add("@TeamId", teamId, DbType.Int32, ParameterDirection.Input);
                    unnamedResource.Add("@AllocatedDay", allocatedDays, DbType.Int32, ParameterDirection.Input);
                    unnamedResource.Add("@Month", month, DbType.String, ParameterDirection.Input);
                    unnamedResource.Add("@Year", year, DbType.Int32, ParameterDirection.Input);
                    unnamedResource.Add("@Workingdays", workingDays, DbType.Int32, ParameterDirection.Input);

                    // Add the new record to the database and commit the change.
                    _unitOfWork.SpCall.ExecuteWithoutReturn(AppConstant.usp_SaveProjectAllocation, unnamedResource);
                    return Json(new { success = true });
                }
                return Json(new { error = true });
            }
            catch
            {
                // Return an error message to the user if the method has failed.
                return Json(new { error = true });
            }
        }

        #endregion

        #region Methods and Functionality for Project Calender

        public IActionResult ProjectsCalender()
        {
            return View();
        }

        /// <summary>
        /// Method to Load the Projects and Start Date and End Date
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetProjectsCalendarData()
        {
            // Loading Projects Details.
            List<CalenderProjects> objProjectList = await LoadProjectsDetails();

            // Processing.
            return Json(new { data = objProjectList });
        }

        /// <summary>
        /// Load Project Details
        /// </summary>
        /// <returns></returns>
        private async Task<List<CalenderProjects>> LoadProjectsDetails()
        {
            // Initialization.
            List<CalenderProjects> lst = new List<CalenderProjects>();

            try
            {
                // Get the list of Projects with all details from the table
                List<Projects> objProjectList = _unitOfWork.projectRepository.GetAllProjectDetails().ToList();

                foreach (var item in objProjectList)
                {
                    CalenderProjects cld = new CalenderProjects()
                    {
                        ProjId = item.ProjectId,
                        ProjectName = item.ProjectName,
                        ProjectDescription = item.ProjectDescription,
                        StartDate = item.StartDate,
                        EndDate = item.EndDate
                    };

                    lst.Add(cld);
                }
            }
            catch (Exception ex)
            {
                // info.
                Console.Write(ex);
            }

            return await Task.Run(() => lst);
        }

        #endregion
    }
}