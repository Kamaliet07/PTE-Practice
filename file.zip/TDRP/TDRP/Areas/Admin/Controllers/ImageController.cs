﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ImageController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IUserRepository _userService;
        private readonly ILogger<ImageController> _logger;
        public const int ImageMinimumBytes = 524288;

        public ImageController(ApplicationDbContext dbContext, IUserRepository userService, ILogger<ImageController> logger)
        {
            _dbContext = dbContext;
            _userService = userService;
            _logger = logger;
        }
        public IActionResult ProfileImage(int? id)
        {
            UserProfileImage imageObj = new UserProfileImage();
            if (id == null)
            {

            }
            else
            {
                imageObj = _dbContext.UserProfileImage.SingleOrDefault(m => m.SysId == id);
                if (imageObj == null)
                {
                    return NotFound();
                }
            }
            return View(imageObj);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileImage(int id, UserProfileImage imageObj)
        {
            ApplicationUser user = await _userService.GetUserAsync(User);

            if (ModelState.IsValid)
            {
                imageObj.UserId = user.Id;
                imageObj.Active = false;
                var files = HttpContext.Request.Form.Files;

                if (files.Count > 0)
                {
                    byte[] fileBytes = null;
                    using (var fs1 = files[0].OpenReadStream())
                    {
                        using (var ms1 = new MemoryStream())
                        {
                            fs1.CopyTo(ms1);
                            fileBytes = ms1.ToArray();
                        }
                    }

                    // Check if file size is not more tham 0.5 MB
                    if (fileBytes.Length < ImageMinimumBytes)
                    {
                        if (ImageHelper.GetImageFormat(fileBytes) != ImageHelper.ImageFormat.unknown)
                        {
                            imageObj.Picture = fileBytes;

                            if (imageObj.SysId == 0)
                            {
                                _dbContext.UserProfileImage.Add(imageObj);
                            }
                            else
                            {
                                var imageFromDb = _dbContext.UserProfileImage.FirstOrDefault(c => c.SysId == imageObj.SysId);

                                imageFromDb.Name = imageObj.Name;
                                if (files.Count > 0)
                                {
                                    imageFromDb.Picture = imageObj.Picture;
                                }
                            }
                            _dbContext.SaveChanges();
                            // Fetch module from database.
                            imageObj = _dbContext.UserProfileImage.SingleOrDefault(m => m.UserId == user.Id);
                            TempDataMessage(TDRPResource.msg, TDRPResource.msgInfo, TDRPResource.profileImg);
                        }
                        else
                        {
                            _logger.LogError(TDRPResource.incorectFile);
                            TempDataMessage(TDRPResource.msg, TDRPResource.msgError, TDRPResource.incorectFile);
                        }
                    }
                    else
                    {
                        _logger.LogError(TDRPResource.fileSize);
                        TempDataMessage(TDRPResource.msg, TDRPResource.msgError, TDRPResource.fileSize);
                    }
                }
                else
                {
                    TempDataMessage(TDRPResource.msg, TDRPResource.msgError, TDRPResource.imgNotFound);
                }
            }
            else
            {
                _logger.LogError(TDRPResource.nameReq);
                TempDataMessage(TDRPResource.msg, TDRPResource.msgError, TDRPResource.nameReq);
            }
            return View(imageObj);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _dbContext.UserProfileImage.ToList() });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _dbContext.UserProfileImage.Find(id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = TDRPResource.deleteError });
            }

            _dbContext.UserProfileImage.Remove(objFromDb);
            _dbContext.SaveChanges();
            return Json(new { success = true, message = TDRPResource.deleteSuccess });

        }

        public void TempDataMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }
        }
    }
}