﻿// Variables for dashboard.js
var teamId = $("#teamId").val();

var categoryChart;
var pieChart;
var pieChartCanvas;
var pieData;
var pieOptions;

// Variables used for the Project Names Pie Chart
var doughnutMonth;
var doughnutTeam;
var doughnutLabels = [];
var doughnutDays = [];

// Variables used for the Project Categories Pie Chart
var pieLabels = [];
var pieDays = [];

// Variables used for the Capacity Bar Chart
var barMonth = [];
var barCapacityUsed = [];
var barCapacitySpare = [];

// Used to get the current month.
var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
var date = new Date();
var getMonth = date.getMonth();
var getYear = date.getFullYear();
var currentMonth = monthNames[getMonth];

// Ajax request will call the method in the Home Controller to get the Allocation Days for the Pie Charts.
// It passes the teamId that is found on the Index.cshtml view.
function retrieveChartAllocationData(teamData, monthData, yearData) {
    $.ajax({
        async: false,
        url: "/User/Home/GetAllocationData",
        data: { teamId: teamData, monthId: monthData, year: yearData },
        type: "GET",
        success: function (result) {
            if (result.data && result.data2 && result.data3) {
                separateResultsForAreaChart(result.data3);
                splitResultIntoArray(result.data, result.data2);
            }
        }
    });
}

// Split the results from the Ajax call into arrays and variables for use on the chart.
function splitResultIntoArray(data, data2) {
    if (data.length > 0) {
        doughnutMonth = data[0].monthId - 1;
        doughnutTeam = data[0].teamId;
        for (var i = 0; i < data.length; i++) {
            doughnutLabels.push(data[i].projectName);
            doughnutDays.push(data[i].allocatedDays);
        }
    }
    if (data2.length > 0) {
        for (var x = 0; x < data2.length; x++) {
            pieLabels.push(data2[x].category);
            pieDays.push(data2[x].allocatedDays);
        }
    }
}

// Split the results from the Ajax call into arrays and variables for use on the Area chart.
function separateResultsForAreaChart(data) {
    if (data.length > 0) {
        doughnutTeam = data[0].teamId;
        for (var i = 0; i < data.length; i++) {
            barMonth.push(data[i].monthName);
            barCapacityUsed.push(data[i].allocatedDays);
            barCapacitySpare.push(data[i].workingDays - data[i].allocatedDays);
        }
    }
}

$(function () {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */
    retrieveChartAllocationData(teamId, getMonth, getYear);
    // Pre-select the dropdown list values with the current month.
    $("#dropDownListProjects").val(getMonth);
    $("#dropDownListYears").val(getYear);

    var pieCategoryData = {
        labels: pieLabels,
        datasets: [
            {
                data: pieDays,
                backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de', '#8D6A9F', '#584B53', '#F18F01', '#083D77', '#D1B490']
            }
        ]
    }

    var donutData = {
        labels: doughnutLabels,
        datasets: [
            {
                data: doughnutDays,
                backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de', '#8D6A9F', '#584B53', '#F18F01', '#083D77', '#D1B490']
            }
        ]
    }

    //-------------
    //- Pie Chart -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
    var pieData = donutData;
    var pieOptions = {
        maintainAspectRatio: false,
        responsive: true,
        title: {
            display: true,
            text: "Current Month: " + currentMonth
        }
    }
    //Create pie chart    
    pieChart = new Chart(pieChartCanvas,
        {
            type: 'pie',
            data: pieData,
            options: pieOptions
        });
    // Populate chart data from the GET method in the HomeController.cs
    var pieCategoryCanvas = $("#categoryChart").get(0).getContext("2d");
    var categoryData = pieCategoryData;
    var pieCategoryOptions = {
        maintainAspectRatio: false,
        responsive: true,
        title: {
            display: true,
            text: "Current Month: " + currentMonth
        }
    }
    // Create the Pie Chart for Project Categories - SD
    categoryChart = new Chart(pieCategoryCanvas,
        {
            type: "pie",
            data: categoryData,
            options: pieCategoryOptions
        });

    //--------------
    //- Area Chart -
    //--------------
    var areaChartData = {
        labels: barMonth,
        datasets: [
            {
                label: 'Capacity Spare',
                backgroundColor: 'rgba(210, 214, 222, 1)',
                borderColor: 'rgba(210, 214, 222, 1)',
                pointRadius: false,
                pointColor: 'rgba(210, 214, 222, 1)',
                pointStrokeColor: '#c1c7d1',
                pointHighlightFill: '#fff',
                pointHighlightStroke: 'rgba(220,220,220,1)',
                data: barCapacitySpare
            },
            {
                label: 'Capacity In Use',
                backgroundColor: 'rgba(60,141,188,0.9)',
                borderColor: 'rgba(60,141,188,0.8)',
                pointRadius: false,
                pointColor: '#3b8bba',
                pointStrokeColor: 'rgba(60,141,188,1)',
                pointHighlightFill: '#fff',
                pointHighlightStroke: 'rgba(60,141,188,1)',
                data: barCapacityUsed
            }
        ]
    }

    var areaChartOptions = {
        maintainAspectRatio: false,
        responsive: true,
        legend: {
            display: false
        },
        scales: {
            xAxes: [
                {
                    gridLines: {
                        display: false
                    }
                }
            ],
            yAxes: [
                {
                    gridLines: {
                        display: false
                    }
                }
            ]
        }
    }

    var barChartData = areaChartData;
    var temp0 = areaChartData.datasets[0];
    var temp1 = areaChartData.datasets[1];
    barChartData.datasets[0] = temp1;
    barChartData.datasets[1] = temp0;

    //---------------------
    //- Stacked Bar Chart -
    //---------------------
    var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d');
    var stackedBarChartData = barChartData;

    var stackedBarChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        title: {
            display: true,
            text: barMonth[0].trim() + " - " + barMonth[barMonth.length - 1].trim()
        },
        scales: {
            xAxes: [
                {
                    stacked: true
                }
            ],
            yAxes: [
                {
                    stacked: true
                }
            ]
        }
    }

    var stackedBarChart = new Chart(stackedBarChartCanvas,
        {
            type: 'bar',
            data: stackedBarChartData,
            options: stackedBarChartOptions
        });
});

// Dropdown list for the Projects Pie Chart will clear the relevant arrays and reload new ones for the selected month.
$("#dropDownListProjects").change(function () {
    getMonth = parseInt(jQuery(this).val());
    getYear = parseInt(jQuery("#dropDownListYears").val());

    doughnutDays = [];
    doughnutLabels = [];
    pieDays = [];
    pieLabels = [];

    retrieveChartAllocationData(teamId, getMonth, getYear);

    pieChart.data.datasets[0].data = doughnutDays;
    pieChart.data.labels = doughnutLabels;
    pieChart.options.title.text = "Selected Month: " + monthNames[getMonth];
    categoryChart.data.datasets[0].data = pieDays;
    categoryChart.data.labels = pieLabels;
    categoryChart.options.title.text = "Selected Month: " + monthNames[getMonth];

    return pieChart.update(), categoryChart.update();
});

// Dropdown list for the Category Pie Chart will clear the relevant arrays and reload new ones for the selected month.
$("#dropDownListYears").change(function () {
    getMonth = parseInt(jQuery("#dropDownListProjects").val());
    getYear = parseInt(jQuery(this).val());

    doughnutDays = [];
    doughnutLabels = [];
    pieDays = [];
    pieLabels = [];

    retrieveChartAllocationData(teamId, getMonth, getYear);

    pieChart.data.datasets[0].data = doughnutDays;
    pieChart.data.labels = doughnutLabels;
    pieChart.options.title.text = "Selected Month: " + monthNames[getMonth];
    categoryChart.data.datasets[0].data = pieDays;
    categoryChart.data.labels = pieLabels;
    categoryChart.options.title.text = "Selected Month: " + monthNames[getMonth];

    return pieChart.update(), categoryChart.update();
});

var canvas = document.getElementById("pieChart");

// Test functionality for interactive chart where the user can click on a segment and it will direct them to a new view
// which will display all of employees who are assigned to the project and for how many days in the selected month.
canvas.onclick = function (evt) {
    var points = pieChart.getElementAtEvent(evt);
    if (points.length > 0) {
        var clickedDatasetIndex = points[0]._datasetIndex;
        var clickedElementIndex = points[0]._index;

        var label = pieChart.data.labels[clickedElementIndex];
        var value = pieChart.data.datasets[clickedDatasetIndex].data[clickedElementIndex];
        var title = monthNames[getMonth];

        // Redirect the user to the new view.
        return window.location.href = "/User/Home/ViewMonthAssignment/?projectName=" + label + "&month=" + title + "&year=" + getYear;
    }
    // If the user clicks outside a segment, do nothing.
    return false;
};