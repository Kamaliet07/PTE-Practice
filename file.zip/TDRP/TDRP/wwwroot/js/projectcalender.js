﻿$(document).ready(function () {
    $('#calendar').fullCalendar({
        header:
        {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        buttonText: {
            today: 'today',
            month: 'month',
            week: 'week',
            day: 'day'
        },

        events: function (start, end, timezone, callback) {
            $.ajax({
                url: '/Admin/Projects/GetProjectsCalendarData',
                type: "GET",
                dataType: "JSON",

                success: function (result) {
                    var events = [];
                    var colorArray = ["#FF9966", "#669933", "#03d3fc", "#3399FF", "#a103fc", "#fc03c2"];
                    for (var i = 0; i < result.data.length; i++) {
                        events.push(
                            {
                                title: result.data[i].projectName,
                                description: result.data[i].projectDescription,
                                start: result.data[i].startDate.substring(10, 0),
                                end: result.data[i].endDate.substring(10, 0),
                                backgroundColor: colorArray[i]
                                //borderColor: "#fc0101"
                            });
                    };

                    callback(events);
                }
            });
        },
        eventMouseover: function (calEvent, jsEvent) {
            var tooltip = '<div class="tooltipevent" style="width:250px;height:100px;background:#aed0ea;position:absolute;z-index:10001;"> Title: ' + calEvent.description + '</div>'; var $tool = $(tooltip).appendTo('body');
            $(this).mouseover(function (e) {
                $(this).css('z-index', 10000);
                $tool.fadeIn('500');
                $tool.fadeTo('10', 1.9);
            }).mousemove(function (e) {
                $tool.css('top', e.pageY + 10);
                $tool.css('left', e.pageX + 20);
            });
        },
        eventMouseout: function (calEvent, jsEvent) {
            $(this).css('z-index', 8);
            $('.tooltipevent').remove();
        },
        //eventRender: function (event, element) {
        //    element.qtip(
        //        {
        //            content: event.description + '<br />' + event.start,
        //            position: {                          
        //                corner: {
        //                    target: 'center',
        //                    tooltip: 'bottomMiddle'                            
        //                }
        //            }
        //        });
        //},

        editable: false
    });
});