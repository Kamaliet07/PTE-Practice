﻿var dataTableAssignedEmp;
var projectId = $("#projectId").val();

// Variables used for the Assigned Employees Pie Chart.
var pieMonth;
var pieLabels = [];
var pieDays = [];
var pieChart;
var pieChartCanvas;
var pieData;
var pieOptions;

// Dates.
var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
var date = new Date();
var getMonth = date.getMonth();
var getYear = date.getFullYear();
var selectedMonth = $("#selectedMonth").val() - 2;
var currentMonth = monthNames[selectedMonth];

$(document).ready(function () {
    // Subtract 2 from the month value since the select list item starts at 0 and the table month ID starts at 2.
    $("#dropDownListMonths").val(selectedMonth);
    loadAssignedEmployeeMonth(projectId, currentMonth, getYear);
    retrieveChartAllocationData(projectId, currentMonth, getYear);
});

function loadAssignedEmployeeMonth(projectId, month, year) {
    dataTableAssignedEmp = $("#assignedEmployeeTbl").DataTable({
        "ajax": {
            "url": "/User/Home/FindAssignedEmployees/",
            "dataType": "json",
            "type": "GET",
            "data": { "projectId": projectId, "month": month, "year": year }
        },
        "columns": [
            { "data": "employeeNumber", "title": "Employee Number" },
            { "data": "employeeName", "title": "Employee Name" },
            { "data": "teamName", "title": "Team" },
            { "data": "teamId", "title": " " },
            { "data": "allocatedDays", "title": "Allocated Days" }
        ],
        "columnDefs": [
            { "visible": false, "targets": [3] }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

// Dropdown list for the Projects Pie Chart will clear the relevant arrays and reload new ones for the selected month.
$("#dropDownListMonths").change(function () {
    // Update currentMonth and getYear values with the selected dropdown values.
    currentMonth = monthNames[parseInt(jQuery(this).val())];
    getYear = parseInt(jQuery("#dropDownListYears").val());

    pieChart.destroy();

    // Reset arrays for Pie Chart data.
    pieDays = [];
    pieLabels = [];

    retrieveChartAllocationData(projectId, currentMonth, getYear);

    pieChart.data.datasets[0].data = pieDays;
    pieChart.data.labels = pieLabels;
    pieChart.options.title.text = "Selected Month: " + currentMonth;

    // Destroy current table and reload with the new parameters.
    dataTableAssignedEmp.destroy();
    loadAssignedEmployeeMonth(projectId, currentMonth, getYear);

    return pieChart.update();
});

// Ajax request will call the method in the Home Controller to get the Allocation Days for the Pie Charts.
// It passes the teamId that is found on the Index.cshtml view.
function retrieveChartAllocationData(projectId, monthData, yearData) {
    $.ajax({
        async: false,
        url: "/User/Home/FindAssignedEmployees/",
        data: { projectId: projectId, month: monthData, year: yearData },
        type: "GET",
        success: function (result) {
            if (result.data) {
                splitResultIntoArray(result.data);
                loadPieChart();
            }
        }
    });
}

// Split the results from the Ajax call into arrays and variables for use on the chart.
function splitResultIntoArray(data) {
    if (data.length > 0) {
        pieMonth = data[0].monthId - 1;
        for (var i = 0; i < data.length; i++) {
            pieLabels.push(data[i].employeeName);
            pieDays.push(data[i].allocatedDays);
        }
    }
}

function loadPieChart() {
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
    pieChartCanvas.clearRect(0, 0, pieChartCanvas.width, pieChartCanvas.height);

    var pieData = {
        labels: pieLabels,
        datasets: [
            {
                data: pieDays,
                backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de', '#8D6A9F', '#584B53', '#F18F01', '#083D77', '#D1B490']
            }
        ]
    }


    var pieOptions = {
        maintainAspectRatio: false,
        responsive: true,
        title: {
            display: true,
            text: "Current Month: " + currentMonth
        }
    }

    //Create pie chart    
    pieChart = new Chart(pieChartCanvas,
        {
            type: 'pie',
            data: pieData,
            options: pieOptions
        });
}