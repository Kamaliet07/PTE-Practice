﻿// Variables to be used in the script.
var availableCapacity;
var projectId = $("#projectId").val();
var teamId = $("#dropDownListTeamName").val();

// DateTime variables.
var date = new Date();
var getMonth = date.getMonth();
var getYear = date.getFullYear();
var monthId = getMonth + 2;

// Used to get the current month.
var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];

// To be used when parsing the list passed by the team capacity method.
var capacityObject = {
    monthName: null,
    capacityUsed: null
}

$(document).ready(function () {
    $("#dropDownListMonths").val(monthId);
    $("#dropDownListYears").val(getYear);
    retrieveTeamCapacity(teamId, monthId, getYear);
});

// Retrieve the spare capacity for the selected team for the selected month and year.
function retrieveTeamCapacity(teamId, monthId, year) {
    $.ajax({
        url: "/Admin/Projects/GetTeamCapacityInMonth/",
        type: "GET",
        dataType: "json",
        data: { teamId: teamId, monthId: monthId, year: year },
        traditional: false,
        success: function (data) {
            if (data.success) {
                //parseDataToArray(data.areaChart);
                updateCapacityInputs(data.areaChart);
            }
            if (data.error) {
                swal({
                    title: "Request failed! Try again.",
                    text: data.errorMessage,
                    type: "warning"
                });
            }
        },
        error: function () {
            swal({
                title: "Request Failed!",
                text: "Data could not be found! Try again.",
                type: "warning"
            });
        }
    });
}

// Parse the data retrieved in the ajax call to add it into an array for further use in the view.
function parseDataToArray(data) {
    capacityObject.monthName = data[0].monthName;
    capacityObject.capacityUsed = data[0].allocatedDays;
}

// Update the working days and available capacity input fields with the data for the selected team, month and year.
function updateCapacityInputs(data) {
    $("#txtMonthDays").val(data[0].daysInMonth);
    $("#txtWorkDays").val(data[0].daysInMonth - data[0].allocatedDays);
}

$("#dropDownListTeamName").change(function () {
    teamId = $("#dropDownListTeamName").val();
    //monthId = $("#dropDownListMonths").val();
    //getYear = $("#dropDownListYears").val();
    //retrieveTeamCapacity(teamId, monthId, getYear);
});

// When the user selects a different month, update the variable values and working days input field in the view.
$("#dropDownListMonths").change(function () {
    monthId = $("#dropDownListMonths").val();
    getYear = $("#dropDownListYears").val();
    availableCapacity = $("#txtWorkDays").val();
    retrieveTeamCapacity(teamId, monthId, getYear);
});

// When the user selects a different year, update the variable values and working days input field in the view.
$("#dropDownListYears").change(function () {
    monthId = $("#dropDownListMonths").val();
    getYear = $("#dropDownListYears").val();
    availableCapacity = $("#txtWorkDays").val();
    retrieveTeamCapacity(teamId, monthId, getYear);
});

//// Ajax call to retrieve the team ID which will be used in the main call the get the team capacity data.
//function retrieveTeamId(teamName) {
//    $.ajax({
//        url: "/Admin/Projects/RetrieveTeamId/",
//        type: "GET",
//        dataType: "json",
//        data: { teamName: teamName },
//        traditional: false,
//        success: function (data) {
//            return teamId = data;
//        }
//    });
//}

// When the users clicks on the submit button, call an ajax POST method and submit the details to the AssignedWork table.
function submitUnnamedAssignment() {
    // Ajax call to server-side method to post details back to the database.
    $.ajax({
        url: "/Admin/Projects/AssignUnnamedResource/",
        type: "POST",
        dataType: "json",
        data: {
            teamId: teamId,
            projectId: projectId
        },
        traditional: false,
        success: function (data) {
            if (data.success) {
                swal({
                    title: "Resource Assigned",
                    text: "The assignment was posted successfully!",
                    type: "success"
                });
                return true;
            } else if (data.existingRecord) {
                swal({
                    title: "Team already Assigned",
                    text: "Resource was not assigned as it a record already exists for it.",
                    type: "warning"
                });
                return false;
            } else if (data.projectEnded) {
                swal({
                    title: "Project has ended",
                    text: "Resource was not assigned as the project end date has passed.",
                    type: "warning"
                });
                return false;
            } else {
                swal({
                    title: "Resource not Assigned",
                    text: "Something went wrong and the resource was not assigned.",
                    type: "warning"
                });
                return false;
            }
        },
        error: function () {
            swal({
                title: "Request Failed!",
                text: "Data could not be found! Try again.",
                type: "warning"
            });
            return false;
        }
    });
};

// Function will be called when the user selects assign days.  It will call a server-side function in ProjectsController.cs
// to check the data and post to the database on success.  Messages will be displayed if there are any errors with further info
// for the user.
function assignDaysToTeam() {
    var allocatedDays = parseInt($("#daysToAssign").val());
    if (allocatedDays < 1 || isNaN(allocatedDays)) {
        swal({
            title: "No value in Assigned Days field",
            text: "You must select a number of days to assign to the resource.  Try again.",
            type: "warning"
        });
        return false;
    }
    $.ajax({
        url: "/Admin/Projects/AssignDaysToTeam/",
        type: "POST",
        dataType: "json",
        data: {
            projectId: projectId,
            teamId: teamId,
            allocatedDays: allocatedDays,
            month: monthNames[getMonth],
            year: getYear,
            workingDays: $('#txtMonthDays').val()
        },
        traditional: false,
        success: function (data) {
            if (data.success) {
                swal({
                    title: "Days Assigned to Resource Successfully",
                    type: "success"
                });
                return true;
            }
            else if (data.error) {
                swal({
                    title: "Error occured on the server side functionality",
                    text: "Please contact the site administrator for further assistance.",
                    type: "warning"
                });
                return false;
            }
            else
                return false;
        },
        error: function (data) {
            swal({
                title: "Error occured on the client side functionality.",
                text: "Please contact the site administrator for further assistance.",
                type: "warning"
            });
            return false;
        }
    });
}