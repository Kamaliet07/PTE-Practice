﻿var dataTableWrk;
var dataTableSkills;
var employeeNumber = $("#empNumber").val();

$(document).ready(function () {
    loadUserWork();
    loadTeams();
    loadEmployeeSkills();
    loadAssignedWork();
});

function loadAssignedWork() {

    dataTableWrk = $('#tblData').DataTable({
        "ajax": {
            "url": "/admin/profile/GetAssignedWork",
            "type": "GET",
            "dataType": "json"
        },
        "columns": [
            { "data": "projectId", "width": "10%" },
            { "data": "projectName", "width": "10%" },
            { "data": "projectDescription", "width": "15%" },
            { "data": "startDate", "width": "10%" },
            { "defaultContent": " ", "width": "5%" }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function loadEmployeeSkills() {

    dataTableSkills = $('#tblskills').DataTable({
        "searching": false,
        "info": false,
        "sDom": '<"row view-filter"<"col-sm-12"<"pull-left"l><"pull-right"f><"clearfix">>>t<"row view-pager"<"col-sm-12"<"text-center"ip>>>',
        pageLength: 5,
        lengthMenu: [[5, 10, 20], [5, 10, 20]],
        "pagingType": "numbers",
        "ajax": {
            "url": "/admin/profile/GetEmployeeSkills",
            "type": "GET",
            "datatype": "json"
        },
        "columns": [
            { "data": "skill", "width": "90%" },
            {
                "data": "sysId",
                "render": function (data) {
                    return `<div class="text-center">                               
                                <a onclick= DeleteSkills("/Admin/profile/DeleteEmployeeSkill/${data}") class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='glyphicon glyphicon-trash fa_customDelete'></i> </a>	
                            </div>
                            `;
                }, "width": "10%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function loadTeams() {

    var ddlTeam = $("#team");
    ddlTeam.empty().append('<option selected="selected" value="0" disabled = "disabled">Loading.....</option>');

    $.ajax({
        url: '/Admin/Profile/GetTeamList',
        dataType: "json",
        type: "GET",
        success: function (data) {
            ddlTeam.empty().append('<option selected="selected" value="0">Please select ....</option>');
            $.each(data, function () {
                ddlTeam.append($("<option></option>").val(this['teamId']).html(this["teamName"]));
            });
        },
        failure: function (data) {
            alert(data.responseText);
        },
        error: function (data) {
            alert(data.responseText);
        }
    });
}

//Button Events including Show and Hide and Save 

$("#btnEditAboutMe").click(function () {
    $("#AboutPanel").hide();
    $("#UpdateAboutPanel").show();
});

$("#btnCancelAbout").click(function () {
    $("#AboutPanel").show();
    $("#UpdateAboutPanel").hide();
});

$("#btnBasicDetails").click(function () {
    $("#BasicDetails").hide();
    $("#UpdateBasicPanel").show();
    var teamId = $("#teamId").val();
    var sel = document.getElementById("team");
    for (i = 0; i < sel.length; i++) {
        if (sel[i].value == teamId) {
            break;
        }
    }
    sel.options.selectedIndex = i;
});

$("#btnCancelBasic").click(function () {
    $("#BasicDetails").show();
    $("#UpdateBasicPanel").hide();
});

$("#UpdateWrk").click(function () {
    $("#wrkPanel").hide();
    $("#UpdateWrkPanel").show();
});

$("#btnCancelWrk").click(function () {
    $("#wrkPanel").show();
    $("#UpdateWrkPanel").hide();
});

$("#AddSkills").click(function () {
    $("#skillPanel").hide();
    $("#AddSkillsPanel").show();
});

$("#btnCancelSkill").click(function () {
    $("#skillPanel").show();
    $("#AddSkillsPanel").hide();
});

$("#btnUpdateAbout").click(function () {
    SaveAboutMe();
});

$("#btnUpdBasicDetails").click(function () {
    SaveEmployeeBasicDetails();
});

function SaveAboutMe() {
    var profId = $("#profileId").val();
    var profHeadlines = $("#profHeadlines").val();
    var profDetails = $("#profDetails").val();
    var profworkLocation = $("#profworkLocation").val();
    $.ajax({
        async: false,
        url: '/Admin/Profile/UpdateAboutMe',
        data: { profileId: profId, headlines: profHeadlines, proffDetails: profDetails, workLocation: profworkLocation },
        type: "POST",
        success: function (data) {
            $(".partialAbout").ajax.load(data);
        }
    });
}

function SaveEmployeeBasicDetails() {
    var profId = $("#profileId").val();
    var fistName = $("#fistName").val();
    var lastName = $("#lastName").val();
    var phoneNumber = $("#phoneNumber").val();
    var hireDate = $("#hireDate").val();
    var team = document.getElementById("team");
    var teamId = team.options[team.selectedIndex].value;
    var jobRolesId = $("#jobroleId").val();
    var gender = $("#gender").val();
    var dob = $("#dob").val();
    $.ajax({
        async: false,
        url: '/Admin/Profile/UpdateBasicDetails',
        data: {
            profileId: profId, fistName: fistName, lastName: lastName, phoneNumber: phoneNumber, hireDate: hireDate,
            teamId: teamId, jobRolesId: jobRolesId, gender: gender, dob: dob,
        },
        type: "POST",
        success: function (data) {
            $(".partialBasic").ajax.load(data);
        }
    });
}

// Stuck the array outside of the checkbox function so it does not refresh every time a checkbox fires an event.
var workArray = [];
// Used to check the value of a check box.  Also determines whether the checkbox has been checked or not.
$('input[type=checkbox]').click(function () {
    // Used to see if the checkbox value already exists in the work array.
    var spliceCheck = $.inArray($(this).val(), workArray);
    if ($(this).prop('checked') == true) {
        workArray.push($(this).val());
        // If the checkbox has been un-checked then remove the project ID from the array.
    } else if ($(this).prop('checked') == false) {
        workArray.splice(spliceCheck, 1);
    }
});

// When the user clicks the Assign Work button execute the following code:
$('#btnSaveWrk').click(function () {
    // Don't post anything if there are no ID's in the array.
    if (workArray.length == 0) {
        swal("WorkArray does not contain any arrays!");
        return false;
    } else {
        $.ajax({
            url: '/Admin/Profile/SaveAssignedWork',
            data: { projects: JSON.stringify(workArray) },
            type: "POST",
            traditional: true,
            success: function (data) {
                $(".partialWrkform").ajax.load(data);
            }
        });
        // Refreshes the table so it will show the newly assigned projects.
        $.ajax.reload();
    }
});

$("#btnSaveSkill").click(function () {
    var skillsArray = [];
    skillsArray = getSelectedSkillsList();
    if (skillsArray.length == 0) {
        swal("No skill added into list!");
        return false;
    } else {
        $.ajax({
            url: '/Admin/Profile/SaveEmployeeSkills',
            data: { values: JSON.stringify(skillsArray) },
            type: "POST",
            traditional: true,
            success: function (data) {
                $(".partialSkills").ajax.load(data);
            }
        });
    }
});

function getSelectedSkillsList() {
    var select = document.getElementById("lstValue");
    var selectedSkillsArray = [];
    for (var i = 0; i < select.length; i++) {
        selectedSkillsArray.push({ Name: select.options[i].text });
    }
    return selectedSkillsArray;
}

//Auto Complete Methods

$("#jobRoles").autocomplete({
    source: function (request, response) {
        $.ajax({
            url: '/Admin/Profile/GetJobRoles',
            type: "GET",
            dataType: "json",
            data: { search: $("#jobRoles").val() },
            success: function (data) {
                response(data.map(function (item) {
                    return { label: item.jobRole, value: item.jobRole, id: item.jobRoleId };
                }));
            },
            error: function (data) {
                alert(data.responseText);
            }
        });
    },
    select: function (event, ui) {
        $('#jobroleId').val(ui.item.id);
    },
    change: function (event, ui) {
        $('#jobroleId').val(ui.item.id);
    }
});

$("#empSkills").autocomplete({
    source: function (request, response) {
        $.ajax({
            url: '/Admin/Profile/GetSkills',
            type: "GET",
            dataType: "json",
            data: { search: $("#empSkills").val() },
            success: function (data) {
                response(data.map(function (item) {
                    return { label: item.skill, value: item.skill };
                }));
            },
            error: function (data) {
                swal(data.responseText);
            }
        });
    },
    select: function (event, ui) {
        if (LogSkills(ui.item.value)) {
            $("#empSkills").clearQueue();
        }
    }
});

function LogSkills(value) {
    var select = document.getElementById("lstValue");
    var contains = false;
    for (var i = 0, ceiling = select.options.length; i < ceiling; i++) {
        if (select.options[i].value == value) {
            contains = true;
            break;
        }
    }
    if (!contains) {
        var option = document.createElement("option");
        option.value = value;
        option.text = value;
        select.options.add(option);
    }

    return true;
}

$("#lstValue").keydown(function (event) {
    if (event.which != 46) {
        return; // not delete key
    } else {
        var select = document.getElementById("lstValue");
        var sel = $(this);
        var val = sel.val();
        if (val != "") {
            for (var i = 0; i < select.length; i++) {
                if (select.options[i].value == val) {
                    select.remove(i);
                }
            }
        }
    }
});

function DeleteWork(url) {
    swal({
        title: "Are you sure you want to remove this project?",
        text: "This action cannot be recovered!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        closeOnconfirm: true
    }, function () {
        $.ajax({
            type: 'DELETE',
            url: url,
            success: function (data) {
                if (data.success) {
                    dataTableExp.ajax.reload();
                }
                else {
                    toastr.error(data.message);
                }
            }
        });
    });
}

function DeleteSkills(url) {
    swal({
        title: "Are you sure you want to delete this skill?",
        text: "This action cannot be recovered!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        closeOnconfirm: true
    }, function () {
        $.ajax({
            type: 'DELETE',
            url: url,
            success: function (data) {
                if (data.success) {
                    dataTableSkills.ajax.reload();
                }
                else {
                    toastr.error(data.message);
                }
            }
        });
    });
}

$("#Chart1").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");

});

$("#Chart2").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");

});

$("#Chart3").click(function () {

    $(".active").removeClass("active");
    $(this).addClass("active");

});

function Logout() {
    swal({
        title: "Are you sure you want to logout?",
        text: "You will be returned to the login screen!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, logout!",
        closeOnConfirm: true
    },
        function () {
            swal("Request Complete!", "You have been logged out successfully.", "success");
        });
}

//#region UserProfile Functionality (potentially use for Employee Profiles)

function loadUserWork() {
    dataTableWrk = $('#tblUserWrk').DataTable({
        "ajax": {
            "url": "/user/profile/GetUserWork",
            "data": {"employeeNumber": employeeNumber},
            "type": "GET",
            "dataType": "json"
        },
        "columns": [
            { "data": "projectId", "title": "Project ID", "width": "10%" },
            {
                "data": "projectName", "title": "Project Name", "width": "20%",
                "render": function (data, type, row) {
                    return `<a href="../../Admin/Projects/ProjectDetails/${row.projectId}">${data}</a>`;
                }
            },
            { "data": "projectDescription", "title": "Project Description", "width": "15%" },
            { "defaultContent": " ", "width": "5%" }
        ],
        "columnDefs": [
            { "visible": false, "targets": [0] }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%",
        "pageLength": 3
    });
}

//#endregion