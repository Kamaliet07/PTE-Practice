﻿namespace TDRP.ViewModel
{
    public class ProjectAllocationChart
    {
        public string ProjectName { get; set; }
        public string Category { get; set; }
        public int MonthId { get; set; }
        public int AllocatedDays { get; set; }
        public int? TeamId { get; set; }
    }

    public class AreaAllocationChart
    {
        public string MonthName { get; set; }
        public int AllocatedDays { get; set; }
        public decimal WorkingDays { get; set; }
        public int Year { get; set; }
    }

    public class MonthAssignedEmployees
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int MonthId { get; set; }
        public int Year { get; set; }
        public int EmployeeNumber { get; set; }
        public string EmployeeName { get; set; }
        public string TeamName { get; set; }
        public int TeamId { get; set; }
        public int AllocatedDays { get; set; }
    }
}
