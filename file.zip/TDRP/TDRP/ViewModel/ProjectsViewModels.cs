﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace TDRP.ViewModel
{
    public class UnnamedResources
    {
        public int AssignedWorkId { get; set; }
        public int TeamId { get; set; }
        public IEnumerable<SelectListItem> TeamName { get; set; }
        public int ProjectId { get; set; }
        public decimal AvailableCapacity { get; set; }
        public decimal AssignedCapacity { get; set; }
        public int MonthId { get; set; }
        public int Year { get; set; }
        public int CreateId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? UpdateId { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
