﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    public class ContractTypes
    {
        [Key]
        public int ContractId { get; set; }

        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string ContractType { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class JobRoles
    {
        [Key]
        public int JobRoleId { get; set; }

        [Display(Name = "Job Role")]
        [StringLength(150, ErrorMessage = "Character length cannot exceed 150.")]
        public string JobRole { get; set; }

        [Display(Name = "Job Role Description")]
        [StringLength(450, ErrorMessage = "Character length cannot exceed 450.")]
        public string JobRoleDescription { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class Skills
    {
        [Key]
        public int SkillId { get; set; }

        [Required]
        [StringLength(150, ErrorMessage = "Character length cannot exceed 150.")]
        public string Skill { get; set; }

        [StringLength(250, ErrorMessage = "Character length cannot exceed 250.")]
        public string SkillDescription { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }

    [Table("Teams")]
    public class Teams
    {
        [Key]
        public int TeamId { get; set; }

        [Required]
        [Display(Name = "Team Name")]
        [StringLength(50, ErrorMessage = "Character length cannot exceed 50.")]
        public string TeamName { get; set; }

        [Display(Name = "Team Details")]
        [StringLength(250, ErrorMessage = "Character length cannot exceed 250.")]
        public string TeamDetails { get; set; }

        [Required]
        [Display(Name = "Supervisor Name")]
        [StringLength(450)]
        public string SupervisorName { get; set; }
      
        public bool Active { get; set; }

        [Display(Name = "Creator ID")]
        public int? CreateId { get; set; }

        [Display(Name = "Creation Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Update ID")]
        public int? UpdateId { get; set; }

        [Display(Name = "Update Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class Projects
    {
        [Key]
        [Display(Name = "Project ID")]
        public int ProjectId { get; set; }

        public int? TeamId { get; set; }

        [Required]
        [Display(Name = "Project Name")]
        [StringLength(100, ErrorMessage = "Name length cannot exceed 100 characters.")]
        public string ProjectName { get; set; }

        [Display(Name = "Project Description")]
        [StringLength(2000, ErrorMessage = "Project Description cannot exceed 2000 characters.")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Start Date")]
        public DateTime? StartDate { get; set; }

        [Display(Name = "End Date")]
        public DateTime? EndDate { get; set; }

        [StringLength(50, ErrorMessage = "Category length cannot exceed 50 characters.")]
        public string Category { get; set; }

        [Display(Name = "Estimated Budget")]
        public decimal? EstimatedBudget { get; set; }

        [Display(Name = "Total Expenditure")]
        public decimal? TotalExpenditure { get; set; }

        [Display(Name = "Created Date")]
        public DateTime? CreatedDate { get; set; }

        [Display(Name = "Creator ID")]
        public int CreateId { get; set; }

        [Display(Name = "Updated Date")]
        public DateTime? UpdatedDate { get; set; }
        public int? UpdateId { get; set; }
        public ProjectDetails ProjectDetails { get; set; }
        public Teams Teams { get; set; }
    }

    public class ProjectCategories
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public int CreateId { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime CreatedDate { get; set; }
        
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }

        public int? UpdateId { get; set; }
    }

    // Added for Project Details View to enable users to add notes to projects.
    public class ProjectDetails
    {
        [Key]
        public int Id { get; set; }

        public int ProjectId { get; set; }

        [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters.")]
        public string Notes { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        public int CreateId { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }

        public int? UpdateId { get; set; }
        
        public Projects Projects { get; set; }
    }
}
