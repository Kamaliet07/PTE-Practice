﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace TDRP.DataModel
{
    public class EmployeesList
    {
        public string UserId { get; set; }

        [Display(Name = "Name")]
        public string Name { get; set; }
        public string Email { get; set; }

        public bool EmailConfirmed { get; set; }
        public byte[] Picture { get; set; }
        public string Team { get; set; }

        [Display(Name = "Supervisor Name")]
        public string SupervisorName { get; set; }

        [Display(Name = "Job Role")]
        public string JobRole { get; set; }
        public bool Active { get; set; }
    }

    public class ProjectDetail
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }
        public decimal EstimatedBudget { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime EndDate { get; set; }
        public decimal TotalExpenditure { get; set; }
        public string ProjectLead { get; set; }
        public int TeamId { get; set; }
    }

    public class AssignedWorkDetails
    {
        [Display(Name = "Project ID")]
        public string ProjectId { get; set; }

        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }

        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }

        [Display(Name = "Start Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }
    }
}
