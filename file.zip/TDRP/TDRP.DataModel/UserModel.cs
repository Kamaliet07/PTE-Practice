﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace TDRP.DataModel
{
    public class UserProfileDetails
    {
        [Key]
        public int ProfileId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        // Added so managers can use 'U' numbers to assign, filter and search for people.
        [Display(Name = "Employee Number")]
        public int EmployeeNumber { get; set; }

        [Display(Name = "First Name")]
        [StringLength(20, ErrorMessage = "Length cannot be more than 20 characters.")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [StringLength(25, ErrorMessage = "Length cannot be more than 25 characters.")]
        public string LastName { get; set; }

        // Added for time management purposes.
        public decimal? FTE { get; set; }

        public int? TeamId { get; set; }

        [ForeignKey("TeamId")]
        public Teams Teams { get; set; }

        public int? JobRoleId { get; set; }

        [ForeignKey("JobRoleId")]
        public JobRoles JobRoles { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class UserProfileImage
    {
        [Key]
        public int SysId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        [Required]
        [StringLength(15, ErrorMessage = "length can't be more than 15.")]
        public string Name { get; set; }

        public byte[] Picture { get; set; }

        public bool Active { get; set; }
    }

    public class UserSkills
    {
        [Key]
        public int SysId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        public string Skill { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class MySkills
    {
        public List<string> Values { get; set; }

    }

    public class Supervisor
    {
        [Key]
        public string SupervisorId { get; set; }
        public string SupervisorName { get; set; }
        public string SupervisorEmail { get; set; }
    }

    public class ProjectAllocation
    {
        [Key]
        public int ProjAllocationId { get; set; }
        public int EmployeeNumber { get; set; }
        public int ProjectId { get; set; }
        public int MonthId { get; set; }
        public int Year { get; set; }
        public int AllocatedDays { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int WorkingDays { get; set; }
        public int TeamId { get; set; }
    }
}
