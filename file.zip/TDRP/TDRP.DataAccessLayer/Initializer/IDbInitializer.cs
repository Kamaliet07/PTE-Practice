﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TDRP.DataAccessLayer.Initializer
{
   public interface IDbInitializer
    {
        void Initialize();
    }
}
