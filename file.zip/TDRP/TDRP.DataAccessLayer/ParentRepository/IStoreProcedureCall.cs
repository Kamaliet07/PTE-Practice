﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace TDRP.DataAccessLayer.ParentRepository
{
    public interface IStoreProcedureCall : IDisposable
    {
        Task<IEnumerable<T>> ReturnList<T>(string storeprocedure, DynamicParameters parm = null);

        void ExecuteWithoutReturn(string storeprocedure, DynamicParameters parm = null);

        Task<T> ExecuteReturnScaler<T>(string storeprocedure, DynamicParameters parm = null);

        Task<T> QueryFirstOrDefault<T>(string storeprocedure, DynamicParameters parm = null);
    }
}
