﻿namespace SideMenu
{
    public enum AdornerPlacement
    {
        Inside,
        Outside
    }
}
