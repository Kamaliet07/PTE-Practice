﻿using System;
using System.Windows;
using PTEPractice.View;

namespace PTEPractice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void WindowRLLoaded(object sender, System.Windows.RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTESpeakingReadLoud();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }

        }

        private void ClickableMenuItemRLClick(object sender, System.Windows.RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTESummariseText();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void ClickableMenuItemRLClickRL3(object sender, System.Windows.RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEReadingFillinBlanks();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }

        }

        private void readAloudRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTESpeakingReadLoud();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void desImageRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEDescribeImage();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void repeatSentRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTERepeatSentence();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void wfdRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEWriteFromDictation();

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }
       

        private void RdrbtnRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEReorderParagraph();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void sstBtnRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTESummarizeSpocText();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void readtxtRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTERetellLecture();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void LFIBtxtRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEAsqListFib();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void essaytxtRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEEssayWriting();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }
    }
}
