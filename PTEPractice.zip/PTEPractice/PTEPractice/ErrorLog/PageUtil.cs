﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PTEPractice.ErrorLog
{
   public class PageUtil
    {
        /// <summary>
        /// Email validation function
        /// </summary>
        /// <param name="inputEmail"></param>
        /// <returns></returns>
        public static bool IsValidEmail(string inputEmail)
        {
            string pattern = @"^[a-z][a-z|0-9|]*([RL][a-z|0-9]+)*([.][a-z|" +
                             @"0-9]+([RL][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z]" +
                             @"[a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$";

            Match match =
                Regex.Match(inputEmail, pattern, RegexOptions.IgnoreCase);

            if (match.Success)
                return (true);
            else
                return (false);
        }

        /// <summary>
        /// This code will send the Email
        /// </summary>
        /// <param name="fromMailID"></param>
        /// <param name="toMailID"></param>
        /// <param name="CCmailID"></param>
        /// <param name="BCCmailID"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="mailServer"></param>
        /// <returns></returns>
        public bool SendEmail(string fromMailID, ArrayList toMailID, ArrayList CCmailID, ArrayList BCCmailID, string subject, string body, string mailServer)
        {
            bool isMailSent = true;
            try
            {
                System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();

                if (!string.IsNullOrEmpty(fromMailID))
                {
                    mail.From = new MailAddress(fromMailID);
                }

                if (toMailID != null)
                {
                    if (toMailID.Count > 0)
                    {
                        foreach (string toMail in toMailID)
                        {
                            mail.To.Add(new MailAddress(toMail));

                        }
                    }
                }

                if (CCmailID != null)
                {
                    if (CCmailID.Count > 0)
                    {
                        foreach (string ccMail in CCmailID)
                        {
                            mail.CC.Add(new MailAddress(ccMail));
                        }
                    }
                }

                if (BCCmailID != null)
                {
                    if (BCCmailID.Count > 0)
                    {
                        foreach (string bccMail in BCCmailID)
                        {
                            mail.Bcc.Add(new MailAddress(bccMail));
                        }
                    }
                }

                if (!string.IsNullOrEmpty(subject))
                {
                    mail.Subject = subject;
                }

                if (!string.IsNullOrEmpty(body))
                {
                    mail.Body = body;
                }

                // Set the priority of the mail message to normal
                mail.Priority = System.Net.Mail.MailPriority.Normal;

                // Instantiate a new instance of SmtpClient
                SmtpClient mSmtpClient = new SmtpClient(mailServer);
                // Send the mail message
                mSmtpClient.Send(mail);

            }
            catch (Exception)
            {
                isMailSent = false;
            }
            return isMailSent;
        }

        /// <summary>
        /// One of the ways to validate if the entered phone number is correct
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public Boolean ValidatePhone(String phoneNumber, ref string number)
        {
            String telePhoneNumber = string.Empty;
            Boolean returnValue = new Boolean();

            try
            {
                if (phoneNumber != "RLRLRL-RLRLRL-RLRLRLRL")
                {
                    telePhoneNumber = phoneNumber.Replace("RL", "");
                    telePhoneNumber = telePhoneNumber.Replace("-", "");

                    if (telePhoneNumber.Length < 10)
                    {
                        returnValue = false;
                    }
                    else
                    {
                        returnValue = true;
                        number = telePhoneNumber;
                    }
                }
                else
                {
                    returnValue = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnValue;
        }

        public static String FormattedPhoneNumber(string phoneNumber)
        {
            String returnPhoneNumber = String.Empty;
            try
            {
                if (!string.IsNullOrEmpty(phoneNumber))
                {
                    if (phoneNumber.Length == 10)
                        returnPhoneNumber = String.Format("{0:###-###-####}", Convert.ToInt64(phoneNumber));
                    else
                        returnPhoneNumber = phoneNumber;
                }
            }
            catch (Exception ex)
            {
                    throw ex;
            }
            return returnPhoneNumber;
        }
    }
}
