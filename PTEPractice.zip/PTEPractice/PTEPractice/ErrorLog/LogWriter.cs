﻿using System.Configuration;
using System.IO;

namespace PTEPractice.ErrorLog
{
    public class LogWriter
    {
        /// <summary>
        /// Method To Log High Level Progress into Log File
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="sbMessage"></param>
        public static void LogToReviseAgainWFD(string sbMessage)
        {
            if (!string.IsNullOrEmpty(sbMessage))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["WFDFile"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(sbMessage);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(sbMessage);
                    }
                }
            }
        }

        /// <summary>
        /// Method To Log High Level Progress into Log File
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="sbMessage"></param>
        public static void LogToReviseAgainRS(string sbMessage)
        {
            if (!string.IsNullOrEmpty(sbMessage))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["RSFile"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(sbMessage);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(sbMessage);
                    }
                }
            }
        }

        public static void LogToReviseAgainRO(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ROFile"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(str);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(str);
                    }
                }
            }
        }

        internal static void LogToSaveAgainASQ(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ASQFile"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(str);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(str);
                    }
                }
            }
        }

        internal static void LogToSaveListFIB(string text)
        {
            if (!string.IsNullOrEmpty(text))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ListFIBFile"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(text);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(text);
                    }
                }
            }
        }

        internal static void LogToReviseAgainSpell(string textspell)
        {
            if (!string.IsNullOrEmpty(textspell))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ReviceSpell"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(textspell);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(textspell);
                    }
                }
            }
        }

        internal static void LogToReviseRFIB(string rcounter)
        {
            if (!string.IsNullOrEmpty(rcounter))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ReviceRFIB"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(rcounter);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(rcounter);
                    }
                }
            }
        }

        internal static void LogToReviseRWFIB(string rwcounter)
        {
            if (!string.IsNullOrEmpty(rwcounter))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ReviceRWFIB"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(rwcounter);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(rwcounter);
                    }
                }
            }
        }

        internal static void LogToReviseRL(string rwcounter)
        {
            if (!string.IsNullOrEmpty(rwcounter))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir, ConfigurationManager.AppSettings["ReviceRL"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(rwcounter);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(rwcounter);
                    }
                }
            }
        }
    }
}
