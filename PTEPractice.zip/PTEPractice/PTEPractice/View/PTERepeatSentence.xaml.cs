﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using PTEPractice.ErrorLog;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTERepeatSentence.xaml
    /// </summary>
    public partial class PTERepeatSentence : UserControl
    {
        //speech synthesizer
        private SpeechSynthesizer synthesizer;
        private string selectedSpeakData;
        private Hashtable RLhasContent;
        private int counter = 0;
        private bool firstTimeRun = true;
        int totalCount = 0;

        public PTERepeatSentence()
        {
            InitializeComponent();
        }

        private void UserControlRLLoaded(object sender, RoutedEventArgs e)
        {
            synthesizer = new SpeechSynthesizer();

            #region synthesizer eventes			
            synthesizer.SpeakProgress += new EventHandler<SpeakProgressEventArgs>(synthesizerRLSpeakProgress);
            synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizerRLSpeakCompleted);
            #endregion

            LoadInstalledVoices();
        }
        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
        }

        #region Synthesizer events
        private void synthesizerRLSpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            //reset when complete 			
            labelProgress.Content = "";
            txtRS.Text = selectedSpeakData;
        }

        private void synthesizerRLSpeakProgress(object sender, SpeakProgressEventArgs e)
        {
            //show the synthesizer's current progress 
            labelProgress.Content = e.Text;
        }
        #endregion

        private void OpenTextFileButtonRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == true)
                {
                    LoadTextDocument(openFileDialog.FileName);
                    txtFileName.Text = openFileDialog.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void LoadTextDocument(string fileName)
        {
            if (File.Exists(fileName))
            {
                RLhasContent = new Hashtable();
                string[] lines = File.ReadAllLines(fileName);
                if (lines.Length > 0)
                {
                    bool rearranged = RearrangeTextNumbers(lines);
                    if (rearranged)
                    {
                        LoadRepeatSentenceContent(1);
                        //int number = Convert.ToInt32(Regex.Replace(newstring, "[^0-9]", ""));
                    }
                }
            }
        }

        private bool RearrangeTextNumbers(string[] lines)
        {
            bool status = false;
            int hashCounter = 0;
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                if (!string.IsNullOrEmpty(newstring))
                {
                    string content = newstring.Replace(Regex.Replace(newstring, "[^0-9]", ""), "").Replace(".", "").Replace("\t", "").Trim();
                    hashCounter = hashCounter + 1;
                    RLhasContent.Add(hashCounter, content);
                }
            }

            totalCount = RLhasContent.Count;

            if (totalCount > 0)
            {
                status = true;
            }

            return status;
        }

        //private void LoadRichTextBox(string fileName)
        //{
        //    TextRange range;
        //    if (System.IO.File.Exists(fileName))
        //    {
        //        range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
        //        using (FileStream fStream = new FileStream(fileName, System.IO.FileMode.OpenOrCreate))
        //        {
        //            range.Load(fStream, System.Windows.DataFormats.Text);
        //        }
        //    }
        //}

        private void btnSpeakRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    if (firstTimeRun)
                    {
                        Thread.Sleep(2000);
                        synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                        comboVoice.IsEnabled = false;
                        switch (synthesizer.State)
                        {
                            //if synthesizer is ready
                            case SynthesizerState.Ready:
                                synthesizer.SpeakAsync(selectedSpeakData);
                                break;
                            //if synthesizer is paused
                            case SynthesizerState.Paused:
                                synthesizer.Resume();
                                break;
                            //if synthesizer is speaking
                            case SynthesizerState.Speaking:
                                synthesizer.Pause();
                                break;
                        }

                        firstTimeRun = false;

                    }

                    else
                    {
                        synthesizer.SpeakAsync(selectedSpeakData);
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }

        }

        private void LoadRepeatSentenceContent(int value)
        {
            if (value > 0)
            {
                string contentvalue = RLhasContent[value].ToString();

                if (!string.IsNullOrEmpty(contentvalue))
                {
                    selectedSpeakData = contentvalue;
                    labelCount.Content = value.ToString() + '/' + totalCount.ToString();
                }

                counter = value;
            }
        }

        private void btnNextQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtRS.Clear();
                LoadRepeatSentenceContent(counter + 1);
                Thread.Sleep(2000);
                if (!string.IsNullOrEmpty(selectedSpeakData))
                {
                    synthesizer.SpeakAsync(selectedSpeakData);
                }
                else
                {
                    MessageBox.Show("No more RS available.", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnPrevQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtRS.Clear();
                LoadRepeatSentenceContent(counter - 1);
                Thread.Sleep(2000);
                synthesizer.SpeakAsync(selectedSpeakData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnRestoreRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                foreach (string value in RLhasContent.Values)
                {
                    LogWriter.LogToReviseAgainRS(value);
                }

                MessageBox.Show("File Generated Successfully", "Message");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }

        }

        private void btnSaveRLClick(object sender, RoutedEventArgs e)
        {
            LogWriter.LogToReviseAgainRS(selectedSpeakData);
        }

        private void comboskipRLSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (RLhasContent != null)
                {
                    ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
                    int skipcount = Convert.ToInt32(cbi.Content.ToString());
                    if (RLhasContent.Count >= skipcount)
                    {
                        LoadRepeatSentenceContent(skipcount);
                    }
                    else
                    {
                        MessageBox.Show("File does not contain this count of data to skip", "Message");
                    }
                }
                else
                {
                    comboskip.SelectedIndex = -1;
                    MessageBox.Show("Please browse the file", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }
    }
}
