﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using PTEPractice.ErrorLog;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTEAsqListFib.xaml
    /// </summary>
    public partial class PTEAsqListFib : UserControl
    {
        //speech synthesizer
        private SpeechSynthesizer synthesizer;
        private string selectedSpeakData;
        private int counter = 0;
        bool firstTimeRun = true;
        private Hashtable RLhasContent;

        public PTEAsqListFib()
        {
            InitializeComponent();
            btnValidate.Click += new RoutedEventHandler(BtnValidateRLClick);
        }

        private void UserControlRLLoaded(object sender, RoutedEventArgs e)
        {
            synthesizer = new SpeechSynthesizer();
            synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizerRLSpeakCompleted);
            LoadInstalledVoices();
        }

        #region Synthesizer events
        private void synthesizerRLSpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {

        }
        #endregion

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
        }

        private void BtnBrowseRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == true)
                {
                    LoadTextDocument(openFileDialog.FileName);
                    txtFileName.Text = openFileDialog.FileName;
                    LoadWFDContent(1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void LoadTextDocument(string fileName)
        {
            if (File.Exists(fileName))
            {
                RLhasContent = new Hashtable();
                string[] lines = File.ReadAllLines(fileName);
                if (lines.Length > 0)
                {
                    bool rearranged = RearrangeTextNumbers(lines);
                    if (rearranged)
                    {
                        LoadWFDContent(1);
                        //int number = Convert.ToInt32(Regex.Replace(newstring, "[^0-9]", ""));
                    }
                }
            }
        }

        private bool RearrangeTextNumbers(string[] lines)
        {
            bool status = false;
            int hashCounter = 0;
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                if (!string.IsNullOrEmpty(newstring))
                {
                    hashCounter = hashCounter + 1;
                    RLhasContent.Add(hashCounter, newstring);
                }
            }

            if (RLhasContent.Count > 0)
            {
                status = true;
            }

            return status;
        }

        private void LoadWFDContent(int value)
        {
            string contentvalue = RLhasContent[value].ToString();

            if (!string.IsNullOrEmpty(contentvalue))
            {
                selectedSpeakData = contentvalue;
            }

            counter = value;
            lblCont.Content = value.ToString();
        }

        private void BtnStartRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    if (firstTimeRun)
                    {
                        gbASW.IsEnabled = false;
                    }
                    txtText.Clear();
                    txtText.Focus();
                    txtText.Background = new SolidColorBrush(Colors.White);
                    txtCorrect.Clear();
                    synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                    comboVoice.IsEnabled = false;
                    synthesizer.SpeakAsync(selectedSpeakData);
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnNextQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtText.Clear();
                txtText.Focus();
                txtText.Background = new SolidColorBrush(Colors.White);
                txtCorrect.Clear();
                LoadWFDContent(counter + 1);
                if (!string.IsNullOrEmpty(selectedSpeakData))
                {
                    synthesizer.SpeakAsync(selectedSpeakData);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnPrevQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtText.Clear();
                txtText.Focus();
                txtText.Background = new SolidColorBrush(Colors.White);
                txtCorrect.Clear();
                LoadWFDContent(counter - 1);
                synthesizer.SpeakAsync(selectedSpeakData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnRepeatRLClick(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedSpeakData))
            {
                txtText.Clear();
                txtText.Focus();
                synthesizer.SpeakAsync(selectedSpeakData);
            }
        }

        private void BtnValidateRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                string textSpell = txtText.Text.ToString().Trim();
                if (!string.Equals(textSpell.ToUpper(), selectedSpeakData.ToUpper()))
                {
                    txtText.Background = new SolidColorBrush(Colors.Yellow);
                    LogWriter.LogToReviseAgainSpell(selectedSpeakData);
                }
                else
                {
                    txtText.Background = new SolidColorBrush(Colors.White);
                }
                txtCorrect.Clear();
                txtCorrect.Text = selectedSpeakData;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void comboskipRLSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (RLhasContent != null)
                {
                    ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
                    int skipcount = Convert.ToInt32(cbi.Content.ToString());
                    if (RLhasContent.Count >= skipcount)
                    {
                        LoadWFDContent(skipcount);
                    }
                    else
                    {
                        MessageBox.Show("File does not contain this count of data to skip", "Message");
                    }
                }
                else
                {
                    comboskip.SelectedIndex = -1;
                    MessageBox.Show("Please browse the file", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnMarkRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                LogWriter.LogToSaveAgainASQ(selectedSpeakData);

                MessageBox.Show("Saved Successfully.", "Message");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnASQRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    if (firstTimeRun)
                    {
                        gbSpChk.IsEnabled = false;
                    }

                    txtASQ.Clear();
                    txtASQ.Focus();
                    synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                    comboVoice.IsEnabled = false;
                    txtASQ.Text = selectedSpeakData;
                    synthesizer.SpeakAsync(selectedSpeakData);
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnResetRLClick(object sender, RoutedEventArgs e)
        {
            gbSpChk.IsEnabled = true;
            gbASW.IsEnabled = true;
        }

        private void btnAsPrevQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtASQ.Clear();
                txtASQ.Focus();
                LoadWFDContent(counter - 1);
                txtASQ.Text = selectedSpeakData;
                synthesizer.SpeakAsync(selectedSpeakData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnASNextQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtASQ.Clear();
                txtASQ.Focus();
                LoadWFDContent(counter + 1);
                txtASQ.Text = selectedSpeakData;
                synthesizer.SpeakAsync(selectedSpeakData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }
    }
}
