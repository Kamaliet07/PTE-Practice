﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media.Imaging;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTEDescribeImage.xaml
    /// </summary>
    public partial class PTEDescribeImage : UserControl
    {
        private Stopwatch tmc;
        private int counter = 0;
        private string filedirPath = string.Empty;
        public PTEDescribeImage()
        {
            InitializeComponent();
            this.Loaded += (s, e) => { tabEssay.SelectionChanged += tabEssayRLSelectionChanged; };
            LoadDITemplate();
        }

        private void tabEssayRLSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl)
            {
                if (tabEssay.SelectedIndex == 0)
                {
                    LoadDITemplate();
                }
                if (tabEssay.SelectedIndex == 1)
                {
                    string appDir = Directory.GetCurrentDirectory().ToString();
                    filedirPath = Path.Combine(appDir, "DImage");
                    counter = 1;
                    DynamicLoadImage();
                }
            }
        }

        private void LoadDITemplate()
        {
            TextRange range;
            string augcontentvalue = Resource.PTERetellLecture.ResourceManager.GetString("DI1");
            if (!string.IsNullOrEmpty(augcontentvalue))
            {
                range = new TextRange(txtdiTemp.Document.ContentStart, txtdiTemp.Document.ContentEnd);
                range.Text = augcontentvalue;
                FormateAugContentLine();
            }
        }

        private void ButtonOKRLClick(object sender, RoutedEventArgs e)
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.DoWork += workerRLDoWork;
            worker.ProgressChanged += workerRLProgressChanged;
            worker.RunWorkerAsync();
            tmc = new Stopwatch();
            tmc.Start();
        }

        private void workerRLProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pbStatus.Value = e.ProgressPercentage;
            //tblProgress.Text = e.ProgressPercentage.ToString() + "%";
            tblTime.Text = String.Format("{0}h {1}m {2}s", tmc.Elapsed.Hours, tmc.Elapsed.Minutes, tmc.Elapsed.Seconds);
        }

        private void workerRLDoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                (sender as BackgroundWorker).ReportProgress(i);
                Thread.Sleep(380);
            }
        }

        private void BtnNextRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                counter = counter + 1;
                DynamicLoadImage();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void DynamicLoadImage()
        {
            string imgName = counter.ToString() + ".png";
            string newImageName = Path.Combine(filedirPath, imgName);
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(newImageName);
            bitmap.EndInit();
            ImageViewer1.Source = bitmap;
        }

        private void btnprevQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                counter = counter - 1;
                DynamicLoadImage();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void FormateAugContentLine()
        {
            foreach (var paragraph in txtdiTemp.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;

                if (text.StartsWith("["))
                {
                    paragraph.Foreground = Brushes.Red;
                    paragraph.FontWeight = FontWeights.Bold;
                }
                if (text.StartsWith("("))
                {
                    paragraph.Foreground = Brushes.Blue;
                    paragraph.FontWeight = FontWeights.Bold;
                }
            }
        }
    }
}
