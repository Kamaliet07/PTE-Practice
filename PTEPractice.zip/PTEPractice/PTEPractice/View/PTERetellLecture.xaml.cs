﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTERetellLecture.xaml
    /// </summary>
    public partial class PTERetellLecture : UserControl
    {
        public PTERetellLecture()
        {
            InitializeComponent();
            //this.Loaded += (s, e) => { tabEssay.SelectionChanged += tabEssayRLSelectionChanged; };
            LoadRLTemplate();
        }

        private void LoadRLTemplate()
        {
            TextRange range;
            string augcontentvalue = Resource.PTERetellLecture.ResourceManager.GetString("RL1");
            if (!string.IsNullOrEmpty(augcontentvalue))
            {
                range = new TextRange(txtRLTemp.Document.ContentStart, txtRLTemp.Document.ContentEnd);
                range.Text = augcontentvalue;
                FormateAugContentLine();
            }
        }

        private void FormateAugContentLine()
        {
            foreach (var paragraph in txtRLTemp.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;

                if (text.StartsWith("["))
                {
                    paragraph.Foreground = Brushes.Red;
                    paragraph.FontWeight = FontWeights.Bold;
                }
                if (text.StartsWith("("))
                {
                    paragraph.Foreground = Brushes.Blue;
                    paragraph.FontWeight = FontWeights.Bold;
                }
            }
        }
    }
}
