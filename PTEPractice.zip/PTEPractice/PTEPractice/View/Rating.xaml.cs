﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for Rating.xaml
    /// </summary>
    public partial class Rating : UserControl
    {
        SolidColorBrush orange = new SolidColorBrush(Color.FromRgb(255, 102, 0));
        SolidColorBrush clear = new SolidColorBrush(Color.FromRgb(255, 255, 255));
        public int selected = 0;
        public Rating()
        {
            InitializeComponent();
        }

        static Rating()
        {
            ValueProperty = DependencyProperty.Register("Value", typeof(int), typeof(Rating), new FrameworkPropertyMetadata(0, new PropertyChangedCallback(OnValueChanged), new CoerceValueCallback(CoerceValueValue)));
            MaximumProperty = DependencyProperty.Register("Maximum", typeof(int), typeof(Rating), new FrameworkPropertyMetadata(5));
            MinimumProperty = DependencyProperty.Register("Minimum", typeof(int), typeof(Rating), new FrameworkPropertyMetadata(0));
        }

        #region Events

        /// <summary>
        /// Notifies when rating has been changed.
        /// </summary>
        public event EventHandler<RatingChangedEventArgs> RatingChanged;

        #endregion

        #region Dependency Properties

        /// <summary>
        /// Value dependency property.
        /// </summary>
        public static readonly DependencyProperty ValueProperty;

        /// <summary>
        /// Maximum dependency property.
        /// </summary>
        public static readonly DependencyProperty MaximumProperty;

        /// <summary>
        /// Minimum dependency property.
        /// </summary>
        public static readonly DependencyProperty MinimumProperty;

        /// <summary>
        /// Star on color dependency property.
        /// </summary>
        public static readonly DependencyProperty StarOnColorProperty;

        /// <summary>
        /// Star off color dependency property.
        /// </summary>
        public static readonly DependencyProperty StarOffColorProperty;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        public int Value
        {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        /// <summary>
        /// Gets or sets the maximum value.
        /// </summary>
        public int Maximum
        {
            get { return (int)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        /// <summary>
        /// Gets or sets the minimum value.
        /// </summary>
        public int Minimum
        {
            get { return (int)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }

        /// <summary>
        /// Gets or sets the star on color.
        /// </summary>
        public Brush StarOnColor
        {
            get { return (Brush)GetValue(StarOnColorProperty); }
            set { SetValue(StarOnColorProperty, value); }
        }

        /// <summary>
        /// Gets or sets the star off color.
        /// </summary>
        public Brush StarOffColor
        {
            get { return (Brush)GetValue(StarOffColorProperty); }
            set { SetValue(StarOffColorProperty, value); }
        }

        #endregion

        private static void OnValueChanged(DependencyObject obj, DependencyPropertyChangedEventArgs e)
        {
            Rating rating = obj as Rating;

            if (rating != null)
            {
                rating.OnRatingChanged();
            }
        }

        private static object CoerceValueValue(DependencyObject obj, object value)
        {
            Rating rating = (Rating)obj;

            int current = (int)value;

            if (current < rating.Minimum)
            {
                current = rating.Minimum;
            }

            if (current > rating.Maximum)
            {
                current = rating.Maximum;
            }

            return current;
        }

        private void OnRatingChanged()
        {
            if (RatingChanged != null)
            {
                RatingChanged(this, new RatingChangedEventArgs(this.Value));
            }
        }

        private void s1RLMouseEnter(object sender, MouseEventArgs e)
        {
            s1.Fill = orange;
            s2.Fill = clear;
            s3.Fill = clear;
            s4.Fill = clear;
            s5.Fill = clear;
        }

        private void s2RLMouseEnter(object sender, MouseEventArgs e)
        {
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = clear;
            s4.Fill = clear;
            s5.Fill = clear;
        }

        private void s3RLMouseEnter(object sender, MouseEventArgs e)
        {
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = orange;
            s4.Fill = clear;
            s5.Fill = clear;
        }

        private void s4RLMouseEnter(object sender, MouseEventArgs e)
        {
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = orange;
            s4.Fill = orange;
            s5.Fill = clear;

        }

        private void s5RLMouseEnter(object sender, MouseEventArgs e)
        {
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = orange;
            s4.Fill = orange;
            s5.Fill = orange;

        }


        private void s1RLMouseLeave(object sender, MouseEventArgs e)
        {
            s1.Fill = clear;
        }

        private void s2RLMouseLeave(object sender, MouseEventArgs e)
        {
            s1.Fill = clear;
            s2.Fill = clear;
        }

        private void s3RLMouseLeave(object sender, MouseEventArgs e)
        {
            s1.Fill = clear;
            s2.Fill = clear;
            s3.Fill = clear;
        }

        private void s4RLMouseLeave(object sender, MouseEventArgs e)
        {
            s1.Fill = clear;
            s2.Fill = clear;
            s3.Fill = clear;
            s4.Fill = clear;
        }

        private void s5RLMouseLeave(object sender, MouseEventArgs e)
        {
            s1.Fill = clear;
            s2.Fill = clear;
            s3.Fill = clear;
            s4.Fill = clear;
            s5.Fill = clear;
        }

        private void s1RLMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            selected = 1;
            s1.Fill = orange;
            s2.Fill = clear;
            s3.Fill = clear;
            s4.Fill = clear;
            s5.Fill = clear;
        }
        private void s2RLMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            selected = 2;
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = clear;
            s4.Fill = clear;
            s5.Fill = clear;
        }
        private void s3RLMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            selected = 3;
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = orange;
            s4.Fill = clear;
            s5.Fill = clear;
        }
        private void s4RLMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            selected = 4;
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = orange;
            s4.Fill = orange;
            s5.Fill = clear;
        }

        private void s5RLMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            selected = 5;
            s1.Fill = orange;
            s2.Fill = orange;
            s3.Fill = orange;
            s4.Fill = orange;
            s5.Fill = orange;
        }
        private void UserControlRLMouseLeave(object sender, MouseEventArgs e)
        {
            if (selected == 1)
            {
                s1.Fill = orange;
                s2.Fill = clear;
                s3.Fill = clear;
                s4.Fill = clear;
                s5.Fill = clear;
            }

            if (selected == 2)
            {
                s1.Fill = orange;
                s2.Fill = orange;
                s3.Fill = clear;
                s4.Fill = clear;
                s5.Fill = clear;
            }

            if (selected == 3)
            {
                s1.Fill = orange;
                s2.Fill = orange;
                s3.Fill = orange;
                s4.Fill = clear;
                s5.Fill = clear;
            }

            if (selected == 4)
            {
                s1.Fill = orange;
                s2.Fill = orange;
                s3.Fill = orange;
                s4.Fill = orange;
                s5.Fill = clear;
            }

            if (selected == 5)
            {
                s1.Fill = orange;
                s2.Fill = orange;
                s3.Fill = orange;
                s4.Fill = orange;
                s5.Fill = orange;
            }

        }
    }

    public class RatingChangedEventArgs
    {
        /// <summary>
        /// Gets the value of the rating.
        /// </summary>
        public int Value { get; private set; }

        public RatingChangedEventArgs(int value)
            : base()
        {
            this.Value = value;
        }
    }
}
