﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Threading;
using System.Xml;
using System.Configuration;
using PTEPractice.ErrorLog;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTEWriteFromDictation.xaml
    /// </summary>
    public partial class PTEWriteFromDictation : UserControl
    {
        //speech synthesizer
        private SpeechSynthesizer synthesizer;
        private string selectedSpeakData;
        private int counter = 0;
        bool firstTimeRun = true;
        private List<string> erroList;
        private Hashtable RLhasContent;
        private string selectedTextData;
        int totalCount = 0;

        public PTEWriteFromDictation()
        {
            InitializeComponent();
        }

        private void UserControlRLLoaded(object sender, RoutedEventArgs e)
        {
            synthesizer = new SpeechSynthesizer();
            LoadInstalledVoices();
        }

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
        }

        private void BtnBrowseRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == true)
                {
                    LoadTextDocument(openFileDialog.FileName);
                    txtFileName.Text = openFileDialog.FileName;
                    LoadWFDContent(1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void LoadTextDocument(string fileName)
        {
            if (File.Exists(fileName))
            {
                RLhasContent = new Hashtable();
                string[] lines = File.ReadAllLines(fileName);
                if (lines.Length > 0)
                {
                    bool rearranged = RearrangeTextNumbers(lines);
                    if (rearranged)
                    {
                        LoadWFDContent(1);
                        //int number = Convert.ToInt32(Regex.Replace(newstring, "[^0-9]", ""));
                    }
                }
            }
        }

        private bool RearrangeTextNumbers(string[] lines)
        {
            bool status = false;
            int hashCounter = 0;
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                if (!string.IsNullOrEmpty(newstring))
                {
                    string content = newstring.Replace(Regex.Replace(newstring, "[^0-9]", ""), "").Replace(".", "").Replace("\t", "").Trim();
                    hashCounter = hashCounter + 1;
                    RLhasContent.Add(hashCounter, content);
                }
            }

            totalCount = RLhasContent.Count;

            if (totalCount > 0)
            {
                status = true;
            }

            return status;
        }

        private void LoadWFDContent(int value)
        {
            string contentvalue = RLhasContent[value].ToString();

            if (!string.IsNullOrEmpty(contentvalue))
            {
                selectedSpeakData = contentvalue;
                labelCount.Content = value.ToString() + '/' + totalCount.ToString();

            }

            counter = value;
        }

        private void BtnStartRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    if (firstTimeRun)
                    {
                        Thread.Sleep(2000);
                        synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                        comboVoice.IsEnabled = false;
                        switch (synthesizer.State)
                        {
                            //if synthesizer is ready
                            case SynthesizerState.Ready:
                                synthesizer.SpeakAsync(selectedSpeakData);
                                break;
                            //if synthesizer is paused
                            case SynthesizerState.Paused:
                                synthesizer.Resume();
                                break;
                            //if synthesizer is speaking
                            case SynthesizerState.Speaking:
                                synthesizer.Pause();
                                break;
                        }

                        firstTimeRun = false;

                    }

                    else
                    {
                        txtWFD.Clear();
                        txtWFD.Focus();
                        synthesizer.SpeakAsync(selectedSpeakData);
                    }

                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnValidateRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                // Clear List
                lstError.DataContext = null;

                // Validate Words
                CompareAllLetters(selectedSpeakData, txtWFD.Text);
                lbltext.Content = counter + "." + " " + selectedSpeakData;

                // Bind Error Words
                ObservableCollection<string> oList;
                oList = new ObservableCollection<string>(erroList);
                lstError.DataContext = oList;

                Binding binding = new Binding();
                lstError.SetBinding(ListBox.ItemsSourceProperty, binding);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        //checks if the letters in any order
        public void CompareAllLetters(string mainString, string typedString)
        {
            erroList = new List<string>();
            string[] mainwords = Regex.Split(mainString, @"\W+");
            string[] typedwords = Regex.Split(typedString, @"\W+");
            foreach (string value in mainwords)
            {
                if (!typedwords.Contains(value))
                {
                    erroList.Add(value);
                }
            }
        }

        private void comboskipRLSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (RLhasContent != null)
                {
                    ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
                    int skipcount = Convert.ToInt32(cbi.Content.ToString());
                    if (RLhasContent.Count >= skipcount)
                    {
                        LoadWFDContent(skipcount);
                    }
                    else
                    {
                        MessageBox.Show("File does not contain this count of data to skip", "Message");
                    }
                }
                else
                {
                    comboskip.SelectedIndex = -1;
                    MessageBox.Show("Please browse the file", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void WriteOnTextToRePrepare(string selectedSpeakData)
        {
            LogWriter.LogToReviseAgainWFD(selectedSpeakData);
        }

        private void btnNextQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtWFD.Clear();
                txtWFD.Focus();
                gbWFDSysnc.IsEnabled = false;
                lstError.DataContext = null;
                Binding binding = new Binding();
                lstError.SetBinding(ListBox.ItemsSourceProperty, binding);
                lbltext.Content = String.Empty;
                LoadWFDContent(counter + 1);
                Thread.Sleep(2000);
                synthesizer.SpeakAsync(selectedSpeakData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnPrevQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                txtWFD.Clear();
                txtWFD.Focus();
                gbWFDSysnc.IsEnabled = false;
                lstError.DataContext = null;
                Binding binding = new Binding();
                lstError.SetBinding(ListBox.ItemsSourceProperty, binding);
                lbltext.Content = String.Empty;
                LoadWFDContent(counter - 1);
                Thread.Sleep(2000);
                synthesizer.SpeakAsync(selectedSpeakData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void CheckBoxRLChecked(object sender, RoutedEventArgs e)
        {
            try
            {
                gbWFD.IsEnabled = false;
                LoadListeningFIBContent(1);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void LoadListeningFIBContent(int value)
        {
            TextRange range;

            string contentvalue = Resource.ListeningFIBResource.ResourceManager.GetString("L" + value);

            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(richTextBoxdata.Document.ContentStart, richTextBoxdata.Document.ContentEnd);
                range.Text = contentvalue;
            }

            counter = value;

            selectedTextData = GetSpokenTextFromTheResourceFile(value);
        }

        private string GetSpokenTextFromTheResourceFile(int value)
        {
            string contenttospeak = string.Empty;
            XmlDocument doc = new XmlDocument();
            string appDir = Directory.GetCurrentDirectory().ToString();
            string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("bin")), ConfigurationManager.AppSettings["LstFIBFile"]);
            if (File.Exists(filePath))
            {
                doc.Load(filePath);
                contenttospeak = ReadResourceComment(doc, "L" + value);
            }

            return contenttospeak;
        }

        private string ReadResourceComment(XmlDocument doc, string FieldName)
        {
            string strSpekData = string.Empty;
            if (doc != null && !string.IsNullOrEmpty(doc.InnerXml))
            {
                if (doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"] != null)
                {
                    strSpekData = doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"].InnerText;
                }
            }

            return strSpekData;
        }

        private void btnSpeakFIBRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                    comboVoice.IsEnabled = false;
                    if (string.IsNullOrEmpty(selectedTextData))
                    {
                        selectedTextData = ConvertRichTextBoxContentsToString();
                    }
                    if (!string.IsNullOrEmpty(selectedTextData))
                    {
                        synthesizer.SpeakAsync(selectedTextData);
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private string ConvertRichTextBoxContentsToString()
        {
            TextRange textRange = new TextRange(richTextBoxdata.Document.ContentStart, richTextBoxdata.Document.ContentEnd);
            return textRange.ToString();
        }


        private void btnSaveRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(selectedSpeakData))
                {
                    WriteOnTextToRePrepare(selectedSpeakData);
                    MessageBox.Show("WFD Save Successfully.", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnValidateFIBRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                TextRange range;
                if (!string.IsNullOrEmpty(selectedTextData))
                {
                    range = new TextRange(richTextBoxdata.Document.ContentStart, richTextBoxdata.Document.ContentEnd);
                    range.Text = selectedTextData;
                    //CapitalizeBoldFIB();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnPrevLFIBRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadListeningFIBContent(counter - 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnNextLFIBRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadListeningFIBContent(counter + 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }
    }
}
