﻿using System;
using System.Linq;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTEEssayWriting.xaml
    /// </summary>
    public partial class PTEEssayWriting : UserControl
    {
        private SpeechSynthesizer synthesizer;
        private TextRange selectedSpeakData;
        private int counter = 0;
        bool firstTimeRun = true;

        public PTEEssayWriting()
        {
            InitializeComponent();
            this.Loaded += (s, e) => { tabEssay.SelectionChanged += tabEssayRLSelectionChanged; };
        }

        private void UserControlRLLoaded(object sender, RoutedEventArgs e)
        {
            try
            {
                synthesizer = new SpeechSynthesizer();
                synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizerRLSpeakCompleted);
                LoadInstalledVoices();
                LoadAugEssayContent();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        #region Synthesizer events
        private void synthesizerRLSpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {

        }
        #endregion

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
        }

        private void tabEssayRLSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl)
            {
                TextRange range;

                if (tabEssay.SelectedIndex == 0)
                {
                    string augcontentvalue = Resource.EssayCollection.ResourceManager.GetString("M1"); ;
                    if (!string.IsNullOrEmpty(augcontentvalue))
                    {
                        range = new TextRange(txtaugEssay.Document.ContentStart, txtaugEssay.Document.ContentEnd);
                        range.Text = augcontentvalue;
                        FormateAugContentLine();
                    }
                }
                if (tabEssay.SelectedIndex == 1)
                {
                    string augcontentvalue = Resource.EssayCollection.ResourceManager.GetString("M2"); ;
                    if (!string.IsNullOrEmpty(augcontentvalue))
                    {
                        range = new TextRange(txtprbEssay.Document.ContentStart, txtprbEssay.Document.ContentEnd);
                        range.Text = augcontentvalue;
                    }
                }
                if (tabEssay.SelectedIndex == 2)
                {
                    LoadEssayContent(1);
                }
            }
        }

        private void ComboskipRLSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
                int skipcount = Convert.ToInt32(cbi.Content.ToString());
                string text = GetTextFromResource(skipcount);
                if (!string.IsNullOrEmpty(text))
                {
                    LoadEssayContent(skipcount);
                }
                else
                {
                    comboskip.SelectedIndex = -1;
                    MessageBox.Show("File does not contain this count of data to skip", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private static string GetTextFromResource(int value)
        {
            return Resource.EssayCollection.ResourceManager.GetString("E" + value);
        }

        private void LoadEssayContent(int value)
        {
            TextRange range;

            string contentvalue = GetTextFromResource(value);
            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
                range.Text = value.ToString() + ". " + contentvalue;
                FormateContentLine();
            }

            counter = value;

            selectedSpeakData = ConvertRichTextBoxContentsToString();
        }

        private void LoadAugEssayContent()
        {
            TextRange augrange;
            string augcontentvalue = Resource.EssayCollection.ResourceManager.GetString("M1"); ;
            if (!string.IsNullOrEmpty(augcontentvalue))
            {
                augrange = new TextRange(txtaugEssay.Document.ContentStart, txtaugEssay.Document.ContentEnd);
                augrange.Text = augcontentvalue;
                FormateAugContentLine();
            }
        }

        private void FormateContentLine()
        {
            foreach (var paragraph in richTextBox1.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;

                if (text.StartsWith("•"))
                {
                    paragraph.Foreground = Brushes.Blue;
                }
            }
        }

        private void FormateAugContentLine()
        {
            foreach (var paragraph in txtaugEssay.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;

                if (text.StartsWith("["))
                {
                    paragraph.Foreground = Brushes.Red;
                    paragraph.FontWeight = FontWeights.Bold;
                }
                if (text.StartsWith("("))
                {
                    paragraph.Foreground = Brushes.Blue;
                    paragraph.FontWeight = FontWeights.Bold;
                }
            }
        }

        private TextRange ConvertRichTextBoxContentsToString()
        {
            TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
            return textRange;
        }

        private void btnNextQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                firstTimeRun = false;
                LoadEssayContent(counter + 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnPrevQueRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadEssayContent(counter - 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnStartRLClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    if (firstTimeRun)
                    {
                        synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                        comboVoice.IsEnabled = false;
                    }
                    if (!string.IsNullOrEmpty(selectedSpeakData.Text))
                    {
                        synthesizer.SpeakAsync(selectedSpeakData.Text);
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }
    }
}
