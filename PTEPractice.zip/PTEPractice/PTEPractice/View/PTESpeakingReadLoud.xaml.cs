﻿using PTEPractice.ErrorLog;
using System;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;

namespace PTEPractice.View
{
    /// <summary>
    /// Interaction logic for PTESpeakingReadLoud.xaml
    /// </summary>
    public partial class PTESpeakingReadLoud : UserControl
    {
       private SpeechSynthesizer synthesizer;
		private string selectedSpeakData;
		private int counter = 0;
		private Stopwatch tmc;
		private Stopwatch speaktmc;	

        public PTESpeakingReadLoud()
        {
            InitializeComponent();
        }

        private void UserControlRLLoaded(object sender, RoutedEventArgs e)
        {
            try
            {
                synthesizer = new SpeechSynthesizer();

                #region synthesizer eventes
                synthesizer.SpeakStarted += new EventHandler<SpeakStartedEventArgs>(synthesizer_SpeakStarted);
                synthesizer.SpeakProgress += new EventHandler<SpeakProgressEventArgs>(synthesizer_SpeakProgress);
                synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
                #endregion

                LoadInstalledVoices();
                LoadReadLoudContent(1);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        #region Synthesizer events
        private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            //reset when complete 
            tblTime.Text = String.Format("{0}h {1}m {2}s", tmc.Elapsed.Hours, tmc.Elapsed.Minutes, tmc.Elapsed.Seconds);
            //btnSpeak.Content = "Read Text";			
        }

        private void synthesizer_SpeakProgress(object sender, SpeakProgressEventArgs e)
        {
            if (synthesizer.Volume != Convert.ToInt32(sliderVolume.Value) || synthesizer.Rate != Convert.ToInt32(sliderRate.Value))
            {
                synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
                synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
                synthesizer.SpeakAsyncCancelAll();
                synthesizer.SpeakAsync(selectedSpeakData);
            }
        }

        private void synthesizer_SpeakStarted(object sender, SpeakStartedEventArgs e)
        {
            tmc = new Stopwatch();
            tmc.Start();
        }
        
        private void SliderVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (synthesizer != null)
            {
                synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
            }
        }

        private void SliderRate_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (synthesizer != null)
            {
                synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
            }
        }
        #endregion

        private void LoadReadLoudContent(int value)
        {
            string contentvalue = GetTextFromResource(value);
            if (!string.IsNullOrEmpty(contentvalue))
            {
                selectedSpeakData = contentvalue;
                txtReadAloud.Text = contentvalue.Trim();
                labelCount.Content = value.ToString();
            }

            counter = value;
        }

        private static string GetTextFromResource(int value)
        {
            return Resource.ReadAloud.ResourceManager.GetString("_" + value);
        }

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
            //cmbFile.DataContext = LoadFiles();

        }


        private void btnSpeak_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                tblTime.Text = string.Empty;
                if (comboVoice.SelectedItem != null)
                {
                    synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                    sliderVolume.IsEnabled = false;
                    sliderRate.IsEnabled = false;
                    comboVoice.IsEnabled = false;
                    switch (synthesizer.State)
                    {
                        //if synthesizer is ready
                        case SynthesizerState.Ready:
                            synthesizer.SpeakAsync(selectedSpeakData);
                            //btnSpeak.Content = "Pause";
                            break;
                        //if synthesizer is paused
                        case SynthesizerState.Paused:
                            synthesizer.Resume();
                            //btnSpeak.Content = "Pause";
                            break;
                        //if synthesizer is speaking
                        case SynthesizerState.Speaking:
                            synthesizer.Pause();
                            //btnSpeak.Content = "Resume";
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnNextQue_Click(object sender, RoutedEventArgs e)
        {
            LoadReadLoudContent(counter + 1);
        }

        private void btnTimer_Click(object sender, RoutedEventArgs e)
        {
            tmc = new Stopwatch();
            tmc.Start();
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            btnStart.IsEnabled = false;
            speaktmc = new Stopwatch();
            speaktmc.Start();
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            btnStart.IsEnabled = true;
            tblTimer.Text = String.Format("{0}h {1}m {2}s", speaktmc.Elapsed.Hours, speaktmc.Elapsed.Minutes, speaktmc.Elapsed.Seconds);
        }

        private void Comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
                int skipcount = Convert.ToInt32(cbi.Content.ToString());
                string text = GetTextFromResource(skipcount);
                if (!string.IsNullOrEmpty(text))
                {
                    LoadReadLoudContent(skipcount);
                }
                else
                {
                    comboskip.SelectedIndex = -1;
                    MessageBox.Show("File does not contain this count of data to skip", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void btnPrevQue_Click(object sender, RoutedEventArgs e)
        {
            LoadReadLoudContent(counter - 1);
        }

        private void btnRMark_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LogWriter.LogToReviseRL(counter.ToString());
                MessageBox.Show("Reorder Number " + counter.ToString() + " Saved Successfully To Revise.", "Message");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }
    }
}
