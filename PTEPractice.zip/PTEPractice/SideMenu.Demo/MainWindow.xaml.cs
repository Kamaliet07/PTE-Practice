﻿using SideMenu.Demo.UserControls;
using System;
using System.Windows;

namespace SideMenu.Demo
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            this.InitializeComponent();
        }

		private void Window_Loaded(object sender, System.Windows.RoutedEventArgs e)
		{
		    try
		    {
		        cntCtrl.Content = new PTEReadLoud();
            }
		    catch (Exception exception)
		    {
		        MessageBox.Show(exception.Message, "Exception");
		    }
            
		}

		private void ClickableMenuItem_Click(object sender, System.Windows.RoutedEventArgs e)
		{
		    try
		    {
		        cntCtrl.Content = new PTESummariseText();
            }
		    catch (Exception exception)
		    {
		        MessageBox.Show(exception.Message, "Exception");
		    }
		}	

        private void ClickableMenuItem_Click_3(object sender, System.Windows.RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEFillinBlanks();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
            
        } 

		private void readAloud_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new PTEReadLoud();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void desImage_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new RetellLectureDI();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void repeatSent_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new RepeatSentence();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void wfd_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new WriteFromDictation();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void ocrText_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new OCRToTextConverter();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

        private void Rdrbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                cntCtrl.Content = new PTEReorderParagraph();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

		private void sstBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new PTESummarizeSpocText();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void readtxt_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new PTEReadText();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void LFIBtxt_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				cntCtrl.Content = new ListeningFIB();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}
	}
}
