﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace SideMenu.Demo.Model
{
	public class ReadLoudFileModel : INotifyPropertyChanged
	{
		private string _FileNameEntry;
		private readonly CollectionView _FileNameEntries;

		public event PropertyChangedEventHandler PropertyChanged;		
		public string FileNameEntry
		{
			get { return _FileNameEntry; }
			set
			{
				if (_FileNameEntry == value) return;
				_FileNameEntry = value;
				OnPropertyChanged("FileNameEntry");
			}
		}

		private void OnPropertyChanged(string propertyName)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}				
		}

		public ReadLoudFileModel()
		{
			IList<FileName> list = new List<FileName>
											 {
												 new FileName("ReadAloud"),
												 new FileName("ReadAloudMain")
											 };
			_FileNameEntries = new CollectionView(list);
		}

		public CollectionView FileNameEntries
		{
			get { return _FileNameEntries; }
		}


	}

	public class FileName
	{
		public string Name { get; set; }
		public FileName(string name)
		{
			Name = name;
		}
	}
}
