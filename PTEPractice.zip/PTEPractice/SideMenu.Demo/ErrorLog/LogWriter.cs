﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideMenu.Demo.ErrorLog
{
    public class LogWriter
    {
        /// <summary>
        /// Method To Log High Level Progress into Log File
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="sbMessage"></param>
        public static void LogToReviseAgainWFD(string sbMessage)
        {
			if (!string.IsNullOrEmpty(sbMessage))
			{
				string appDir = Directory.GetCurrentDirectory().ToString();
				string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("SideMenu.Demo")), ConfigurationManager.AppSettings["WFDFile"]);

				if (!File.Exists(filePath))
				{
					File.Create(filePath).Dispose();
					TextWriter tw = new StreamWriter(filePath);
					tw.WriteLine(sbMessage);
					tw.Close();
				}
				else if (File.Exists(filePath))
				{
					using (var tw = new StreamWriter(filePath, true))
					{
						tw.WriteLine(sbMessage);
					}
				}
			}		    			
        }

        /// <summary>
        /// Method To Log High Level Progress into Log File
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="sbMessage"></param>
        public static void LogToReviseAgainRS(string sbMessage)
        {
			if (!string.IsNullOrEmpty(sbMessage))
			{
				string appDir = Directory.GetCurrentDirectory().ToString();
				string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("SideMenu.Demo")), ConfigurationManager.AppSettings["RSFile"]);

				if (!File.Exists(filePath))
				{
					File.Create(filePath).Dispose();
					TextWriter tw = new StreamWriter(filePath);
					tw.WriteLine(sbMessage);
					tw.Close();
				}
				else if (File.Exists(filePath))
				{
					using (var tw = new StreamWriter(filePath, true))
					{
						tw.WriteLine(sbMessage);
					}
				}
			}			
		}

		public static void LogToReviseAgainRO(string str)
		{
			if (!string.IsNullOrEmpty(str))
			{
				string appDir = Directory.GetCurrentDirectory().ToString();
				string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("SideMenu.Demo")), ConfigurationManager.AppSettings["ROFile"]);

				if (!File.Exists(filePath))
				{
					File.Create(filePath).Dispose();
					TextWriter tw = new StreamWriter(filePath);
					tw.WriteLine(str);
					tw.Close();
				}
				else if (File.Exists(filePath))
				{
					using (var tw = new StreamWriter(filePath, true))
					{
						tw.WriteLine(str);
					}
				}
			}
		}

		internal static void LogToSaveAgainASQ(string str)
		{
			if (!string.IsNullOrEmpty(str))
			{
				string appDir = Directory.GetCurrentDirectory().ToString();
				string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("SideMenu.Demo")), ConfigurationManager.AppSettings["ASQFile"]);

				if (!File.Exists(filePath))
				{
					File.Create(filePath).Dispose();
					TextWriter tw = new StreamWriter(filePath);
					tw.WriteLine(str);
					tw.Close();
				}
				else if (File.Exists(filePath))
				{
					using (var tw = new StreamWriter(filePath, true))
					{
						tw.WriteLine(str);
					}
				}
			}
		}

        internal static void LogToSaveListFIB(string text)
        {
            if (!string.IsNullOrEmpty(text))
            {
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("SideMenu.Demo")), ConfigurationManager.AppSettings["ListFIBFile"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    TextWriter tw = new StreamWriter(filePath);
                    tw.WriteLine(text);
                    tw.Close();
                }
                else if (File.Exists(filePath))
                {
                    using (var tw = new StreamWriter(filePath, true))
                    {
                        tw.WriteLine(text);
                    }
                }
            }
        }
    }
}
