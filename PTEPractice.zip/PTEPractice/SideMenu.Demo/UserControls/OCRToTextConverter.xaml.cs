﻿using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;


namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for OCRToTextConverter.xaml
    /// </summary>
    public partial class OCRToTextConverter : UserControl
    {
        //private AutoOcr ocr;
        private string textpath;
        public OCRToTextConverter()
        {
            InitializeComponent();
        }

        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            LoadingAdorner.IsAdornerVisible = false;
            richTextBox1.IsEnabled = true;
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
			var Result = string.Empty;

			//ocr = new AutoOcr();
			//var Result = ocr.Read(textpath);
			LoadTextDocument(Result.ToString());
        }

        private void OpenTextFileButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                //openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == true)
                {
                    textpath = openFileDialog.FileName;
                    StartStopWait();
                    BackgroundWorker worker = new BackgroundWorker();
                    worker.DoWork += worker_DoWork;
                    worker.RunWorkerCompleted += worker_RunWorkerCompleted;
                    worker.RunWorkerAsync();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void LoadTextDocument(string fileName)
        {
            TextRange range;
            if (!string.IsNullOrEmpty(fileName))
            {
                this.Dispatcher.Invoke((Action)(() =>
                {//this refer to form in WPF application 
                    range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
                    range.Text = fileName;
                }));
            }
        }
        private void StartStopWait()
        {
            LoadingAdorner.IsAdornerVisible = !LoadingAdorner.IsAdornerVisible;
        }
    }
}
