﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using SideMenu.Demo.ErrorLog;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTEReorderParagraph.xaml
    /// </summary>
    public partial class PTEReorderParagraph : UserControl
    {
        ObservableCollection<string> orderList;
        private int counter = 0;

        public PTEReorderParagraph()
        {
            InitializeComponent();
            LoadTextFromResource(1);
        }

        private void BtnNextQue_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (orderList.Count > 0)
                {
                    orderList.Clear();
                    PanelReorder.Children.Clear();
                }

                LoadTextFromResource(counter + 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void RemovePreviousData()
        {
            int count = orderList.Count;
            for (int i = 0; i <= count - 1; i++)
            {
                orderList.RemoveAt(i);
            }
        }

        private void LoadTextFromResource(int value)
        {
			if (value == 1)
			{btnPrev.IsEnabled = false; }
			else
			{ btnPrev.IsEnabled = true; }

			// Method to Load the reorder content
			string str = GetTextFromResource(value);
            string[] lines = str.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            // Method To Arrange Reorder Content - For correct Answer
            bool arranged = RearrangeContent(lines);
            if (arranged)
            {
                LoadDynamicContent();
				tblCounter.Text = value.ToString();
			}
            counter = value;
        }

		private static string GetTextFromResource(int value)
		{
			return Resource.ReorderParagraph.ResourceManager.GetString("_" + value);
		}

		private bool RearrangeContent(string[] lines)
        {
            bool returnvalue = false;
            orderList = new ObservableCollection<string>();
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                if (str.Length > 0)
                {
                    string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                    if (!string.IsNullOrEmpty(newstring))
                    {
                        string content = newstring.Replace(Regex.Replace(newstring, "[^0-9]", ""), "").Replace(".", "").Replace("\t", "").Trim();
                        bool isDigit = char.IsDigit(content[0]);
                        if (isDigit)
                        {
                            orderList.Add(content.Remove(0, 1));
                        }
                        else
                        {
                            orderList.Add(content);
                        }
                    }
                }
            }

            if (orderList.Count > 0)
            {
                returnvalue = true;
            }

            return returnvalue;
        }

        private void LoadDynamicContent()
        {
            var rnd = new Random();
            int tabcount = 0;
            foreach (string str in orderList.OrderBy(item => rnd.Next()))
            {
                tabcount = tabcount + 1;
                TextBlock txtb = CreateATextBox(tabcount, str);
                Separator spt = CreateSeparator(tabcount);
                PanelReorder.Children.Add(txtb);
                PanelReorder.Children.Add(spt);
            }
            PanelReorder.UpdateLayout();
        }
        private TextBlock CreateATextBox(int i, string content)
        {
            double all = 5;
            TextBlock txtb = new TextBlock();
            txtb.Name = "txtBlock" + i.ToString();
            txtb.Margin = new Thickness(all);
            txtb.TextWrapping = TextWrapping.Wrap;
            txtb.FontSize = 18;
            txtb.FontFamily = new FontFamily("Calibri");
            txtb.Text = content;
            txtb.Background = Brushes.WhiteSmoke;
            return txtb;
        }

        private Separator CreateSeparator(int i)
        {
            Separator btnblnk = new Separator();
            btnblnk.Name = "SPT" + i.ToString();
            btnblnk.Background = Brushes.Transparent;
            return btnblnk;
        }

        private void BtnValidate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PanelReorder.Children.Clear();
                int tabcount = 0;
                foreach (string str in orderList)
                {
                    tabcount = tabcount + 1;
                    TextBlock txtb = CreateATextBox(tabcount, str);
                    Separator spt = CreateSeparator(tabcount);
                    PanelReorder.Children.Add(txtb);
                    PanelReorder.Children.Add(spt);
                }
                PanelReorder.UpdateLayout();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

		private void comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());
				string text = GetTextFromResource(skipcount);
				if (!string.IsNullOrEmpty(text))
				{
					orderList.Clear();
					PanelReorder.Children.Clear();
					LoadTextFromResource(skipcount);					
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("File does not contain this count of data to skip", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnPrev_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (orderList.Count > 0)
				{
					orderList.Clear();
					PanelReorder.Children.Clear();
				}

				LoadTextFromResource(counter - 1);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnMark_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				string space = "--------------------------------------------------------------";

				foreach (string str in orderList)
				{
					LogWriter.LogToReviseAgainRO(str);
				}

				LogWriter.LogToReviseAgainRO(space);

				MessageBox.Show("Saved Successfully.", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}							
		}
	}
}
