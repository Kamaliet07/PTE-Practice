﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using SideMenu.Demo.ErrorLog;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTEReorderParagraph.xaml
    /// </summary>
    public partial class PTEReorderParagraph : UserControl
    {
		public delegate Point GetPosition(IInputElement element);
		int rowIndex = -1;
		ObservableCollection<string> orderList;
        private int counter = 0;
		DataTable dtParaGraph;
		private int hashloopcount = 0;		
		private Hashtable _hasContent;

		public PTEReorderParagraph()
        {
            InitializeComponent();
            LoadTextFromResource(1);
			ParaGrid.PreviewMouseLeftButtonDown += new MouseButtonEventHandler(ParaGrid_PreviewMouseLeftButtonDown);
			ParaGrid.Drop += new DragEventHandler(ParaGrid_Drop);
		}

		void ParaGrid_Drop(object sender, DragEventArgs e)
		{
			if (rowIndex < 0)
				return;
			int index = this.GetCurrentRowIndex(e.GetPosition);
			if (index < 0)
				return;
			if (index == rowIndex)
				return;
			if (index == ParaGrid.Items.Count - 1)
			{
				MessageBox.Show("This row-index cannot be drop");
				return;
			}

			// Update Index Value of the DataTable and Rebind Grid
			UpdateDataTableIndexAndRebind(index);
		}

		private void UpdateDataTableIndexAndRebind(int index)
		{
			DataRow selectedRow = dtParaGraph.Rows[rowIndex];
			DataRow newRow = dtParaGraph.NewRow();
			newRow.ItemArray = selectedRow.ItemArray; // copy data
			dtParaGraph.Rows.Remove(selectedRow);
			dtParaGraph.Rows.InsertAt(newRow, index);
			ParaGrid.DataContext = dtParaGraph;
		}

		void ParaGrid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			rowIndex = GetCurrentRowIndex(e.GetPosition);
			if (rowIndex < 0)
				return;
			ParaGrid.SelectedIndex = rowIndex;
			DataRowView selectedEmp = ParaGrid.Items[rowIndex] as DataRowView;
			if (selectedEmp == null)
				return;
			DragDropEffects dragdropeffects = DragDropEffects.Move;
			if (DragDrop.DoDragDrop(ParaGrid, selectedEmp, dragdropeffects)
								!= DragDropEffects.None)
			{
				ParaGrid.SelectedItem = selectedEmp;
			}
		}

		private int GetCurrentRowIndex(GetPosition pos)
		{
			int curIndex = -1;
			for (int i = 0; i < ParaGrid.Items.Count; i++)
			{
				DataGridRow itm = GetRowItem(i);
				if (GetMouseTargetRow(itm, pos))
				{
					curIndex = i;
					break;
				}
			}
			return curIndex;
		}

		private bool GetMouseTargetRow(Visual theTarget, GetPosition position)
		{
			Rect rect = VisualTreeHelper.GetDescendantBounds(theTarget);
			Point point = position((IInputElement)theTarget);
			return rect.Contains(point);
		}

		private DataGridRow GetRowItem(int index)
		{
			if (ParaGrid.ItemContainerGenerator.Status
					!= GeneratorStatus.ContainersGenerated)
				return null;
			return ParaGrid.ItemContainerGenerator.ContainerFromIndex(index)
															as DataGridRow;
		}

		private void LoadTextFromResource(int value)
        {
			if (value == 1)
			{btnPrev.IsEnabled = false; }
			else
			{ btnPrev.IsEnabled = true; }

			// Method to Load the reorder content
			string str = GetTextFromResource(value);
            string[] lines = str.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            // Method To Arrange Reorder Content - For correct Answer
            bool arranged = RearrangeContent(lines);
            if (arranged)
            {
                LoadDynamicContent();
				tblCounter.Text = value.ToString();
			}
            counter = value;
        }

		private static string GetTextFromResource(int value)
		{
			return Resource.ReorderParagraph.ResourceManager.GetString("_" + value);
		}

		private bool RearrangeContent(string[] lines)
        {
            bool returnvalue = false;
            orderList = new ObservableCollection<string>();
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                if (str.Length > 0)
                {
                    string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                    if (!string.IsNullOrEmpty(newstring))
                    {
                        string content = newstring.Replace(Regex.Replace(newstring, "[^0-9]", ""), "").Replace(".", "").Replace("\t", "").Trim();
                        bool isDigit = char.IsDigit(content[0]);
                        if (isDigit)
                        {
                            orderList.Add(content.Remove(0, 1));
                        }
                        else
                        {
                            orderList.Add(content);
                        }
                    }
                }
            }

            if (orderList.Count > 0)
            {
                returnvalue = true;
            }

            return returnvalue;
        }

        private void LoadDynamicContent()
        {
            var rnd = new Random();            
			dtParaGraph = ReorderParaGroup();
			DataRow dr;
			foreach (string str in orderList.OrderBy(item => rnd.Next()))
            {
				if (!string.IsNullOrEmpty(str))
				{
					dr = dtParaGraph.NewRow();
					dr["ParaContent"] = str;
					dtParaGraph.Rows.Add(dr);
				}						
			}

			ParaGrid.DataContext = dtParaGraph;	
		}

		private static DataTable ReorderParaGroup()
		{
			DataTable objDT = new DataTable();			
			objDT.Columns.Add(new DataColumn("ParaContent", typeof(string)));
			return objDT;
		}		    

		private void BtnNextQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (orderList.Count > 0)
				{
					orderList.Clear();					
				}

				if (_hasContent == null)
				{
					LoadTextFromResource(counter + 1);
				}
				else
				{
					int number;
					if (int.TryParse(_hasContent[hashloopcount + 1].ToString(), out number))
					{
						LoadTextFromResource(number);
						hashloopcount = hashloopcount + 1;
						counter = number;
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void BtnValidate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
				dtParaGraph.Clear();
				DataRow dr;
				foreach (string str in orderList)
				{
					if (!string.IsNullOrEmpty(str))
					{
						dr = dtParaGraph.NewRow();
						dr["ParaContent"] = str;
						dtParaGraph.Rows.Add(dr);
					}
				}

				ParaGrid.DataContext = dtParaGraph;	
			}
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

		private void comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());
				string text = GetTextFromResource(skipcount);
				if (!string.IsNullOrEmpty(text))
				{
					orderList.Clear();					
					LoadTextFromResource(skipcount);					
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("File does not contain this count of data to skip", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnPrev_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (orderList.Count > 0)
				{
					orderList.Clear();
				}

				if (_hasContent == null)
				{
					LoadTextFromResource(counter - 1);
				}
				else
				{
					int number;
					if (int.TryParse(_hasContent[hashloopcount - 1].ToString(), out number))
					{
						LoadTextFromResource(number);
						hashloopcount = hashloopcount - 1;
						counter = number;
					}
				}				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnMark_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				//string space = "--------------------------------------------------------------";

				//foreach (string str in orderList)
				//{
				//	LogWriter.LogToReviseAgainRO(str);
				//}

				LogWriter.LogToReviseAgainRO(counter.ToString());
				MessageBox.Show("Reorder Number "+ counter.ToString() +" Saved Successfully To Revise.", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}							
		}

		private void btnReset_Click(object sender, RoutedEventArgs e)
		{
			if (_hasContent != null)
			{
				hashloopcount = 0;				
				// To remove all elements from Hashtable 
				_hasContent.Clear();
				_hasContent = null;
				comboskip.IsEnabled = true;
				comboskip.SelectedIndex = -1;
				txtFileName.Clear();
				LoadTextFromResource(1);
			}
		}

		private void btnBrowse_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
				openFileDialog.RestoreDirectory = true;
				if (openFileDialog.ShowDialog() == true)
				{
					comboskip.IsEnabled = false;
					LoadReorderNumber(openFileDialog.FileName);
					txtFileName.Text = openFileDialog.FileName;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void LoadReorderNumber(string fileName)
		{
			if (File.Exists(fileName))
			{
				_hasContent = new Hashtable();
				string[] lines = File.ReadAllLines(fileName);
				if (lines.Length > 0)
				{
					bool rearranged = RearrangeTextNumbers(lines);
					if (rearranged)
					{
						int reviseCount = Convert.ToInt16(_hasContent[1]);
						LoadTextFromResource(reviseCount);
						hashloopcount = 1;
					}
				}
			}
		}

		private bool RearrangeTextNumbers(string[] lines)
		{
			bool status = false;
			int hashCounter = 0;
			RegexOptions options = RegexOptions.None;
			Regex regex = new Regex("[ ]{2,}", options);
			foreach (string str in lines)
			{
				string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
				if (!string.IsNullOrEmpty(newstring))
				{
					hashCounter = hashCounter + 1;
					_hasContent.Add(hashCounter, newstring);
				}
			}

			if (_hasContent.Count > 0)
			{
				status = true;
			}

			return status;
		}
	}
}
