﻿using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Runtime.Remoting.Channels;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTESummariseText.xaml
    /// </summary>
    public partial class PTESummariseText : UserControl
    {
        private SpeechSynthesizer synthesizer;
        private TextRange selectedSpeakData;
        private int counter = 0;

        public PTESummariseText()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                synthesizer = new SpeechSynthesizer();

                #region synthesizer eventes
                synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
                #endregion

                LoadInstalledVoices();

                LoadFIBContent(1);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void LoadFIBContent(int value)
        {
            TextRange range;

			if (value == 1)
			{ btnprevQue.IsEnabled = false; }
			else
			{ btnprevQue.IsEnabled = true; }

			string contentvalue = Resource.SWTResource.ResourceManager.GetString("_" + value);

            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
                range.Text = value.ToString() + ". " + contentvalue;
                //CapitalizeBoldFirstLine();
            }

            counter = value;

            selectedSpeakData = ConvertRichTextBoxContentsToString();
        }

        private void CapitalizeBoldFirstLine()
        {
            foreach (var paragraph in richTextBox1.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;
                paragraph.LineHeight = 10;
                //paragraph.FontWeight = text.StartsWith("FIB.") ? FontWeights.Bold : FontWeights.Normal;

                if (text.StartsWith("WFD."))
                {
                    paragraph.FontWeight = FontWeights.Bold;
                    paragraph.FontSize = 25;
                    paragraph.Foreground = Brushes.Red;
                }
                else
                {
                    paragraph.FontSize = 15;
                }
            }
        }

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
        }

        #region Synthesizer events
        private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {            
        }

        #endregion

        private TextRange ConvertRichTextBoxContentsToString()
        {
            TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
            return textRange;
        }

        private void BtnSpeak_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                    comboVoice.IsEnabled = false;
                    switch (synthesizer.State)
                    {
                        //if synthesizer is ready
                        case SynthesizerState.Ready:
                            synthesizer.SpeakAsync(selectedSpeakData.Text);                            
                            break;
                        //if synthesizer is paused
                        case SynthesizerState.Paused:
                            synthesizer.Resume();                            
                            break;
                        //if synthesizer is speaking
                        case SynthesizerState.Speaking:
                            synthesizer.Pause();                           
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnNextQue_Click(object sender, RoutedEventArgs e)
        {
			txtSumm.Clear();
			LoadFIBContent(counter + 1);
        }

        private void BtnValidate_Click(object sender, RoutedEventArgs e)
        {
			string comment = string.Empty;
			XmlDocument doc = new XmlDocument();
			string appDir = Directory.GetCurrentDirectory().ToString();			
			string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("bin")), ConfigurationManager.AppSettings["SWTFile"]);
			if (File.Exists(filePath))
			{
				doc.Load(filePath);
				comment = ReadResourceComment(doc, "_" + counter);
			}

			if (!string.IsNullOrEmpty(comment))
			{
				MessageBox.Show(comment, "Message");
			}            
        }

        public string ReadResourceComment(XmlDocument doc, string FieldName)
        {
            if (doc != null && !string.IsNullOrEmpty(doc.InnerXml))
            {
                return doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"].InnerText;
            }

            return string.Empty;
        }

		private void comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());
				string text = GetTextFromResource(skipcount);
				if (!string.IsNullOrEmpty(text))
				{
					LoadFIBContent(skipcount);
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("File does not contain this count of data to skip", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private string GetTextFromResource(int skipcount)
		{
			return Resource.SWTResource.ResourceManager.GetString("_" + skipcount);
		}
	}
}
