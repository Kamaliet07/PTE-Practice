﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using SideMenu.Demo.ErrorLog;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for ListeningFIB.xaml
    /// </summary>
    public partial class ListeningFIB : UserControl
    {
		//speech synthesizer
		private SpeechSynthesizer synthesizer;
		private string selectedSpeakData;
		private int counter = 0;
		bool firstTimeRun = true;		
		private Hashtable _hasContent;

		public ListeningFIB()
        {
            InitializeComponent();
        }

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			synthesizer = new SpeechSynthesizer();					
			synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
			LoadInstalledVoices();
		}

		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{
			
		}
		#endregion

		private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
		}

		private void BtnBrowse_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
				openFileDialog.RestoreDirectory = true;
				if (openFileDialog.ShowDialog() == true)
				{
					LoadTextDocument(openFileDialog.FileName);
					txtFileName.Text = openFileDialog.FileName;
					LoadWFDContent(1);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void LoadTextDocument(string fileName)
		{
			if (File.Exists(fileName))
			{
				_hasContent = new Hashtable();
				string[] lines = File.ReadAllLines(fileName);
				if (lines.Length > 0)
				{
					bool rearranged = RearrangeTextNumbers(lines);
					if (rearranged)
					{
						LoadWFDContent(1);
						//int number = Convert.ToInt32(Regex.Replace(newstring, "[^0-9]", ""));
					}
				}
			}
		}

		private bool RearrangeTextNumbers(string[] lines)
		{
			bool status = false;
			int hashCounter = 0;
			RegexOptions options = RegexOptions.None;
			Regex regex = new Regex("[ ]{2,}", options);
			foreach (string str in lines)
			{
				string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
				if (!string.IsNullOrEmpty(newstring))
				{					
					hashCounter = hashCounter + 1;
					_hasContent.Add(hashCounter, newstring);
				}
			}

			if (_hasContent.Count > 0)
			{
				status = true;
			}

			return status;
		}

		private void LoadWFDContent(int value)
		{
			string contentvalue = _hasContent[value].ToString();

			if (!string.IsNullOrEmpty(contentvalue))
			{
				selectedSpeakData = contentvalue;
			}

			counter = value;
		}

		private void BtnStart_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				gbASW.IsEnabled = false;
				txtText.Clear();
				txtText.Focus();		
				
				if (comboVoice.SelectedItem != null)
				{
					if (firstTimeRun)
					{
						Thread.Sleep(2000);
						synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());						
						comboVoice.IsEnabled = false;
						switch (synthesizer.State)
						{
							//if synthesizer is ready
							case SynthesizerState.Ready:
								synthesizer.SpeakAsync(selectedSpeakData);								
								break;
							//if synthesizer is paused
							case SynthesizerState.Paused:
								synthesizer.Resume();								
								break;
							//if synthesizer is speaking
							case SynthesizerState.Speaking:
								synthesizer.Pause();								
								break;
						}

						firstTimeRun = false;

					}

					else
					{
						LoadWFDContent(counter + 1);
						Thread.Sleep(2000);
						synthesizer.SpeakAsync(selectedSpeakData);
					}

				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void BtnRepeat_Click(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(selectedSpeakData))
			{
				txtText.Clear();
				txtText.Focus();
				synthesizer.SpeakAsync(selectedSpeakData);
			}
		}

		private void BtnValidate_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				txtCorrect.Clear();
				txtCorrect.Text = selectedSpeakData;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				if (_hasContent != null)
				{
					ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
					int skipcount = Convert.ToInt32(cbi.Content.ToString());
					if (_hasContent.Count >= skipcount)
					{
						LoadWFDContent(skipcount);
					}
					else
					{
						MessageBox.Show("File does not contain this count of data to skip", "Message");
					}
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("Please browse the file", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnMark_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				LogWriter.LogToSaveAgainASQ(selectedSpeakData);

				MessageBox.Show("Saved Successfully.", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnASQ_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				gbSpChk.IsEnabled = false;
				txtASQ.Clear();
				txtASQ.Focus();

				if (comboVoice.SelectedItem != null)
				{
					if (firstTimeRun)
					{
						Thread.Sleep(2000);
						synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
						comboVoice.IsEnabled = false;
						switch (synthesizer.State)
						{
							//if synthesizer is ready
							case SynthesizerState.Ready:
								synthesizer.SpeakAsync(selectedSpeakData);
								break;
							//if synthesizer is paused
							case SynthesizerState.Paused:
								synthesizer.Resume();
								break;
							//if synthesizer is speaking
							case SynthesizerState.Speaking:
								synthesizer.Pause();
								break;
						}

						firstTimeRun = false;

					}

					else
					{
						LoadWFDContent(counter + 1);
						Thread.Sleep(2000);
						synthesizer.SpeakAsync(selectedSpeakData);
					}

					txtASQ.Text = selectedSpeakData;
					lblContAsq.Content = counter + 1;
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnReset_Click(object sender, RoutedEventArgs e)
		{
			gbSpChk.IsEnabled = true;
			gbASW.IsEnabled = true;
		}
	}
}
