﻿using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTEFillinBlanks.xaml
    /// </summary>
    public partial class PTEFillinBlanks : UserControl
    {
        //speech synthesizer
        private SpeechSynthesizer synthesizer;
        private TextRange selectedSpeakData;
        private int counter = 0;

        public PTEFillinBlanks()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                synthesizer = new SpeechSynthesizer();

                #region synthesizer eventes
                synthesizer.StateChanged += new EventHandler<StateChangedEventArgs>(synthesizer_StateChanged);
                synthesizer.SpeakStarted += new EventHandler<SpeakStartedEventArgs>(synthesizer_SpeakStarted);
                synthesizer.SpeakProgress += new EventHandler<SpeakProgressEventArgs>(synthesizer_SpeakProgress);
                synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
                #endregion

                LoadInstalledVoices();

                LoadFIBContent(1);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception");
            }
        }

        private void LoadFIBContent(int value)
        {
            TextRange range;

            string contentvalue = Resource.FIBResource.ResourceManager.GetString("_" + value);

            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
                range.Text = contentvalue;
                CapitalizeBoldFirstLine();
            }

            counter = value;

            selectedSpeakData = ConvertRichTextBoxContentsToString();
        }

        private void CapitalizeBoldFirstLine()
        {
            foreach (var paragraph in richTextBox1.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;
                paragraph.LineHeight = 10;
                //paragraph.FontWeight = text.StartsWith("FIB.") ? FontWeights.Bold : FontWeights.Normal;

                if (text.StartsWith("FIB."))
                {
                    paragraph.FontWeight = FontWeights.Bold;
                    paragraph.FontSize = 25;
                    paragraph.Foreground = Brushes.Red;
                }

                else if (text.StartsWith("Options:"))
                {
                    paragraph.FontWeight = FontWeights.Bold;
                    paragraph.Foreground = Brushes.Blue;
                    text.ToUpper();
                }
                else
                {
                    paragraph.FontSize = 15;
                }
            }
        }

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                                      select e.VoiceInfo.Name);
        }

        #region Synthesizer events
        private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            //reset when complete 
            btnSpeak.Content = "Read Text";
            labelProgress.Content = "";
        }

        private void synthesizer_SpeakProgress(object sender, SpeakProgressEventArgs e)
        {
            if (synthesizer.Volume != Convert.ToInt32(sliderVolume.Value) || synthesizer.Rate != Convert.ToInt32(sliderRate.Value))
            {
                synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
                synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
                synthesizer.SpeakAsyncCancelAll();
                synthesizer.SpeakAsync(selectedSpeakData.Text);
            }
        }

        private void synthesizer_SpeakStarted(object sender, SpeakStartedEventArgs e)
        {

        }

        private void synthesizer_StateChanged(object sender, StateChangedEventArgs e)
        {
            //show the synthesizer's current state 
            labelState.Content = e.State.ToString();
        }
        #endregion

        private void SliderVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (synthesizer != null)
            {
                synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
            }
        }

        private void SliderRate_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (synthesizer != null)
            {
                synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
            }
        }

        private TextRange ConvertRichTextBoxContentsToString()
        {
            TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
            return textRange;
        }

        private void BtnSpeak_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (comboVoice.SelectedItem != null)
                {
                    synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
                    sliderVolume.IsEnabled = false;
                    sliderRate.IsEnabled = false;
                    comboVoice.IsEnabled = false;
                    switch (synthesizer.State)
                    {
                        //if synthesizer is ready
                        case SynthesizerState.Ready:
                            synthesizer.SpeakAsync(selectedSpeakData.Text);
                            btnSpeak.Content = "Pause";
                            break;
                        //if synthesizer is paused
                        case SynthesizerState.Paused:
                            synthesizer.Resume();
                            btnSpeak.Content = "Pause";
                            break;
                        //if synthesizer is speaking
                        case SynthesizerState.Speaking:
                            synthesizer.Pause();
                            btnSpeak.Content = "Resume";
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnNextQue_Click(object sender, RoutedEventArgs e)
        {
            LoadFIBContent(counter + 1);
        }
    }
}
