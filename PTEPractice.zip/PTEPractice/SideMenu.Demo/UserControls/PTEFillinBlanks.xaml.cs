﻿using System;
using System.Configuration;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml;
using SideMenu.Demo.ErrorLog;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTEFillinBlanks.xaml
    /// </summary>
    public partial class PTEFillinBlanks : UserControl
    {
        private int fibcounter = 0;
        private int rwfibcounter = 0;

        public PTEFillinBlanks()
        {
            InitializeComponent();
			this.Loaded += (s, e) => { TabsFib.SelectionChanged += TabsFib_SelectionChanged; };
			LoadRFIBContent(1);
		}

		private void TabsFib_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (e.Source is TabControl)
			{	
				if (TabsFib.SelectedIndex == 0)
				{
					LoadRFIBContent(1);
				}
				if (TabsFib.SelectedIndex == 1)
				{
					LoadRWFIBContent(1);
				}				
			}
		}

		private void LoadRFIBContent(int value)
        {
            string contentvalue = Resource.FIBResource.ResourceManager.GetString("R" + value);
            TextRange range;
            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(txtReadingFIB.Document.ContentStart, txtReadingFIB.Document.ContentEnd);
                range.Text = contentvalue;
                lblRCount.Content = value.ToString();
                CapitalizeBoldFirstLine();
            }
			else
			{
				cmbRFib.SelectedIndex = -1;
				MessageBox.Show("File does not contain this count of data to skip", "Message");
			}

			fibcounter = value;
        }

        private void LoadRWFIBContent(int value)
        {
            string contentvalue = Resource.RWFibResource.ResourceManager.GetString("R" + value);
            TextRange range;
            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(txtRWFib.Document.ContentStart, txtRWFib.Document.ContentEnd);
                range.Text = contentvalue;
                lblRWCount.Content = value.ToString();
                CapitalizeBoldRWFirstLine();
            }
			else
			{
				cmbRWFib.SelectedIndex = -1;
				MessageBox.Show("File does not contain this count of data to skip", "Message");
			}

			rwfibcounter = value;
        }

        private void CapitalizeBoldFirstLine()
        {
            foreach (var paragraph in txtReadingFIB.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;
                paragraph.LineHeight = 10;

                if (text.StartsWith("Options:"))
                {
                    paragraph.FontWeight = FontWeights.Bold;
                    paragraph.Foreground = Brushes.Blue;
                    text.ToUpper();
                }                
            }
        }

        private void CapitalizeBoldRWFirstLine()
        {
            foreach (var paragraph in txtRWFib.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;
                paragraph.LineHeight = 10;

                if (text.StartsWith("Options:"))
                {
                    paragraph.FontWeight = FontWeights.Bold;
                    paragraph.Foreground = Brushes.Blue;
                    text.ToUpper();
                }                
            }
        }

        private void BtnRAnswer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string comment = string.Empty;
                XmlDocument doc = new XmlDocument();
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("bin")), ConfigurationManager.AppSettings["RFIBFile"]);
                if (File.Exists(filePath))
                {
                    doc.Load(filePath);
                    comment = ReadResourceComment(doc, "R" + fibcounter);
                }

                if (!string.IsNullOrEmpty(comment))
                {
                    MessageBox.Show(comment, "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        public string ReadResourceComment(XmlDocument doc, string FieldName)
        {
            string validate = string.Empty;
            if (doc != null && !string.IsNullOrEmpty(doc.InnerXml))
            {
                if (doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"] != null)
                {
                    validate = doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"].InnerText;
                }
            }

            return validate;
        }

        private void BtnPrevQue_Click(object sender, RoutedEventArgs e)
        {
            LoadRFIBContent(fibcounter - 1);
        }

        private void BtnNextQue_Click_1(object sender, RoutedEventArgs e)
        {
            LoadRFIBContent(fibcounter + 1);
        }

        /// <summary>
        /// Read and Write Fill in Blank
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkRWFib_Checked_1(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadRWFIBContent(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        /// <summary>
        /// Reading Fill in Blanks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkRFib_Checked_1(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadRFIBContent(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnFIBNextQue_Click(object sender, RoutedEventArgs e)
        {
            LoadRWFIBContent(rwfibcounter + 1);
        }

        private void BtnFIBPrevQue_Click(object sender, RoutedEventArgs e)
        {
            LoadRWFIBContent(rwfibcounter - 1);
        }

        private void BtnRWAnswer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string comment = string.Empty;
                XmlDocument doc = new XmlDocument();
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("bin")), ConfigurationManager.AppSettings["RWFIBFile"]);
                if (File.Exists(filePath))
                {
                    doc.Load(filePath);
                    comment = ReadResourceComment(doc, "R" + rwfibcounter);
                }

                if (!string.IsNullOrEmpty(comment))
                {
                    MessageBox.Show(comment, "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

		private void cmbRWFib_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)cmbRWFib.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());				
				LoadRWFIBContent(skipcount);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void cmbRFib_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)cmbRFib.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());
				LoadRFIBContent(skipcount);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnRMark_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				LogWriter.LogToReviseRFIB(fibcounter.ToString());
				MessageBox.Show("Reorder Number " + fibcounter.ToString() + " Saved Successfully To Revise.", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnRWMark_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				LogWriter.LogToReviseRWFIB(rwfibcounter.ToString());
				MessageBox.Show("Reorder Number " + rwfibcounter.ToString() + " Saved Successfully To Revise.", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}
	}
}
