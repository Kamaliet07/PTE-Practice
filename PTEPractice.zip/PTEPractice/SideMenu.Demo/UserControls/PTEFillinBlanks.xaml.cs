﻿using System;
using System.Configuration;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTEFillinBlanks.xaml
    /// </summary>
    public partial class PTEFillinBlanks : UserControl
    {
        private int fibcounter = 0;
        //private int rwfibcounter = 0;

        public PTEFillinBlanks()
        {
            InitializeComponent();
        }

        private void LoadRFIBContent(int value)
        {
            string contentvalue = Resource.FIBResource.ResourceManager.GetString("R" + value);
            TextRange range;
            if (!string.IsNullOrEmpty(contentvalue))
            {
                range = new TextRange(txtReadingFIB.Document.ContentStart, txtReadingFIB.Document.ContentEnd);
                range.Text = contentvalue;
                CapitalizeBoldFirstLine();
            }

            fibcounter = value;
        }

        private void CapitalizeBoldFirstLine()
        {
            foreach (var paragraph in txtReadingFIB.Document.Blocks)
            {
                var text = new TextRange(paragraph.ContentStart,
                    paragraph.ContentEnd).Text;
                paragraph.LineHeight = 10;

                if (text.StartsWith("Options:"))
                {
                    paragraph.FontWeight = FontWeights.Bold;
                    paragraph.Foreground = Brushes.Blue;
                    text.ToUpper();
                }
                else
                {
                    paragraph.FontSize = 15;
                }
            }
        }
       
        private void ChkRWFib_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadRFIBContent(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnRAnswer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string comment = string.Empty;
                XmlDocument doc = new XmlDocument();
                string appDir = Directory.GetCurrentDirectory().ToString();
                string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("bin")), ConfigurationManager.AppSettings["RFIBFile"]);
                if (File.Exists(filePath))
                {
                    doc.Load(filePath);
                    comment = ReadResourceComment(doc, "R" + fibcounter);
                }

                if (!string.IsNullOrEmpty(comment))
                {
                    MessageBox.Show(comment, "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        public string ReadResourceComment(XmlDocument doc, string FieldName)
        {
            string validate = string.Empty;
            if (doc != null && !string.IsNullOrEmpty(doc.InnerXml))
            {
                if (doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"] != null)
                {
                    validate = doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"].InnerText;
                }
            }

            return validate;
        }

        private void ChkRFib_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                //gbWFD.IsEnabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnPrevQue_Click(object sender, RoutedEventArgs e)
        {
            LoadRFIBContent(fibcounter - 1);
        }

        private void BtnNextQue_Click_1(object sender, RoutedEventArgs e)
        {
            LoadRFIBContent(fibcounter + 1);
        }
    }
}
