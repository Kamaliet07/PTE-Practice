﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using SideMenu.Demo.ErrorLog;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for WriteFromDictation.xaml
    /// </summary>
    public partial class WriteFromDictation : UserControl
    {
        //speech synthesizer
        private SpeechSynthesizer synthesizer;
        private string selectedSpeakData;
        private int counter = 0;
		bool firstTimeRun = true;
        private List<string> erroList;
        private Hashtable _hasContent;



        public WriteFromDictation()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            synthesizer = new SpeechSynthesizer();  
            LoadInstalledVoices();
        }       

        private void LoadInstalledVoices()
        {
            comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
                select e.VoiceInfo.Name);
        }  

        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == true)
                {
                    LoadTextDocument(openFileDialog.FileName);
                    txtFileName.Text = openFileDialog.FileName;
                    LoadWFDContent(1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void LoadTextDocument(string fileName)
        {
            if (File.Exists(fileName))
            {
                _hasContent = new Hashtable();
                string[] lines = File.ReadAllLines(fileName);
                if (lines.Length > 0)
                {
                    bool rearranged = RearrangeTextNumbers(lines);
                    if (rearranged)
                    {
                        LoadWFDContent(1);
                        //int number = Convert.ToInt32(Regex.Replace(newstring, "[^0-9]", ""));
                    }
                }
            }
        }

        private bool RearrangeTextNumbers(string[] lines)
        {
            bool status = false;
            int hashCounter = 0;
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                if (!string.IsNullOrEmpty(newstring))
                {
                    string content = newstring.Replace(Regex.Replace(newstring, "[^0-9]", ""), "").Replace(".", "").Replace("\t", "").Trim();
                    hashCounter = hashCounter + 1;
                    _hasContent.Add(hashCounter, content);
                }
            }

            if (_hasContent.Count > 0)
            {
                status = true;
            }

            return status;
        }

        private void LoadWFDContent(int value)
        {
            string contentvalue = _hasContent[value].ToString();

            if (!string.IsNullOrEmpty(contentvalue))
            {
                selectedSpeakData = contentvalue;
            }

            counter = value;
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                txtWFD.Clear();
                txtWFD.Focus();
				gbWFDSysnc.IsEnabled = false;
				lstError.DataContext = null;
                Binding binding = new Binding();
                lstError.SetBinding(ListBox.ItemsSourceProperty, binding);
				lbltext.Content = String.Empty;
				if (comboVoice.SelectedItem != null)
                {
                    if (firstTimeRun)
                    {
						Thread.Sleep(2000);
						synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());                        
                        comboVoice.IsEnabled = false;
                        switch (synthesizer.State)
                        {
                            //if synthesizer is ready
                            case SynthesizerState.Ready:
                                synthesizer.SpeakAsync(selectedSpeakData);                                
                                break;
                            //if synthesizer is paused
                            case SynthesizerState.Paused:
                                synthesizer.Resume();                                
                                break;
                            //if synthesizer is speaking
                            case SynthesizerState.Speaking:
                                synthesizer.Pause();                               
                                break;
                        }

						firstTimeRun = false;

					}

                    else
                    {
                        LoadWFDContent(counter + 1);
						Thread.Sleep(2000);
						synthesizer.SpeakAsync(selectedSpeakData);
                    }
                    
                }
                else
                {
                    MessageBox.Show("Please select the Voice", "Message");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

        private void BtnRepeat_Click(object sender, RoutedEventArgs e)
        {
			if (!string.IsNullOrEmpty(selectedSpeakData))
			{
				txtWFD.Clear();
				txtWFD.Focus();
				synthesizer.SpeakAsync(selectedSpeakData);
			}			
        }

        private void BtnValidate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Clear List
                lstError.DataContext = null;

                // Validate Words
                CompareAllLetters(selectedSpeakData, txtWFD.Text);
                lbltext.Content = counter + "." + " " + selectedSpeakData;

                // Bind Error Words
                ObservableCollection<string> oList;
                oList = new ObservableCollection<string>(erroList);
                lstError.DataContext = oList;

                Binding binding = new Binding();
                lstError.SetBinding(ListBox.ItemsSourceProperty, binding);

                if (erroList.Count > 1)
                {
                    WriteOnTextToRePrepare(selectedSpeakData);
                }
            }
            catch (Exception ex)
            {
				MessageBox.Show(ex.Message, "Exception");
			}
        }

        //checks if the letters in any order
        public void CompareAllLetters(string mainString, string typedString)
        {
            erroList = new List<string>();
            string[] mainwords = Regex.Split(mainString, @"\W+");
            string[] typedwords = Regex.Split(typedString, @"\W+");
            foreach (string value in mainwords)
            {
                if (!typedwords.Contains(value))
                {
                    erroList.Add(value);
                }
            }
        }

		private void comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				if (_hasContent != null)
				{					
					ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
					int skipcount = Convert.ToInt32(cbi.Content.ToString());
					if (_hasContent.Count >= skipcount)
					{
						LoadWFDContent(skipcount);
					}
					else
					{
						MessageBox.Show("File does not contain this count of data to skip", "Message");
					}					
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("Please browse the file", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}			
		}

        private void WriteOnTextToRePrepare(string selectedSpeakData)
        {
            LogWriter.LogToReviseAgainWFD(selectedSpeakData);
        }

		private void CheckBox_Checked(object sender, RoutedEventArgs e)
		{
			try
			{
				if (_hasContent != null)
				{
					gbWFD.IsEnabled = false;
					foreach (DictionaryEntry s in _hasContent)
					{
						lstAllWFD.Items.Add(s.Value);
					}						
				}					
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnSyncSpeak_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				foreach (DictionaryEntry s in _hasContent)
				{
					Thread.Sleep(2000);
					synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
					comboVoice.IsEnabled = false;
					synthesizer.SpeakAsync(s.Value.ToString());					
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnMark_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				LogWriter.LogToReviseAgainWFD(selectedSpeakData);

				MessageBox.Show("Saved Successfully.", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}
	}
}
