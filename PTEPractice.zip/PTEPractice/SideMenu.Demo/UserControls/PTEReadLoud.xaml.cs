﻿using System;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace SideMenu.Demo.UserControls
{
	/// <summary>
	/// Interaction logic for PTEReadLoud.xaml
	/// </summary>
	public partial class PTEReadLoud : UserControl
    {
		private SpeechSynthesizer synthesizer;
		private string selectedSpeakData;
		private int counter = 0;
		private Stopwatch tmc;
		private Stopwatch speaktmc;
		private string _FileNameEntry;
		
		public PTEReadLoud()
        {
            InitializeComponent();
        }

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				synthesizer = new SpeechSynthesizer();

				#region synthesizer eventes
				synthesizer.StateChanged += new EventHandler<StateChangedEventArgs>(synthesizer_StateChanged);
				synthesizer.SpeakStarted += new EventHandler<SpeakStartedEventArgs>(synthesizer_SpeakStarted);
				synthesizer.SpeakProgress += new EventHandler<SpeakProgressEventArgs>(synthesizer_SpeakProgress);
				synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
				#endregion

				LoadInstalledVoices();
				LoadReadLoudContent(1);
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}
		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{
			//reset when complete 
			tblTime.Text = String.Format("{0}h {1}m {2}s", tmc.Elapsed.Hours, tmc.Elapsed.Minutes, tmc.Elapsed.Seconds);
			//btnSpeak.Content = "Read Text";			
		}

		private void synthesizer_SpeakProgress(object sender, SpeakProgressEventArgs e)
		{
			if (synthesizer.Volume != Convert.ToInt32(sliderVolume.Value) || synthesizer.Rate != Convert.ToInt32(sliderRate.Value))
			{
				synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
				synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
				synthesizer.SpeakAsyncCancelAll();
				synthesizer.SpeakAsync(selectedSpeakData);				
			}
		}

		private void synthesizer_SpeakStarted(object sender, SpeakStartedEventArgs e)
		{
			tmc = new Stopwatch();
			tmc.Start();
		}

		private void synthesizer_StateChanged(object sender, StateChangedEventArgs e)
		{
			
		}

		private void SliderVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (synthesizer != null)
			{
				synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
			}
		}

		private void SliderRate_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (synthesizer != null)
			{
				synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
			}
		}
		#endregion		

		private void LoadReadLoudContent(int value)
		{
			string contentvalue = GetTextFromResource(value);			
			if (!string.IsNullOrEmpty(contentvalue))
			{
				selectedSpeakData = contentvalue;
				txtReadAloud.Text = contentvalue.Trim();
			}

			counter = value;
		}

        private static string GetTextFromResource(int value)
        {
            return Resource.ReadAloud.ResourceManager.GetString("_" + value);
        }

        private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
			//cmbFile.DataContext = LoadFiles();
			
		}
		

		private void btnSpeak_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				tblTime.Text = string.Empty;
				if (comboVoice.SelectedItem != null)
				{
					synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
					sliderVolume.IsEnabled = false;
					sliderRate.IsEnabled = false;
					comboVoice.IsEnabled = false;					
					switch (synthesizer.State)
					{
						//if synthesizer is ready
						case SynthesizerState.Ready:
							synthesizer.SpeakAsync(selectedSpeakData);
							//btnSpeak.Content = "Pause";
							break;
						//if synthesizer is paused
						case SynthesizerState.Paused:							
							synthesizer.Resume();
							//btnSpeak.Content = "Pause";
							break;
						//if synthesizer is speaking
						case SynthesizerState.Speaking:							
							synthesizer.Pause();
							//btnSpeak.Content = "Resume";
							break;
					}
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnNextQue_Click(object sender, RoutedEventArgs e)
		{			
			LoadReadLoudContent(counter + 1);
		}

		private void btnTimer_Click(object sender, RoutedEventArgs e)
		{
			tmc = new Stopwatch();
			tmc.Start();
		}

		private void btnStart_Click(object sender, RoutedEventArgs e)
		{
			btnStart.IsEnabled = false;
			speaktmc = new Stopwatch();
			speaktmc.Start();
		}

		private void btnStop_Click(object sender, RoutedEventArgs e)
		{
			btnStart.IsEnabled = true;
			tblTimer.Text = String.Format("{0}h {1}m {2}s", speaktmc.Elapsed.Hours, speaktmc.Elapsed.Minutes, speaktmc.Elapsed.Seconds);
		}

		//private void cmbFile_SelectionChanged(object sender, SelectionChangedEventArgs e)
		//{
		//	try
		//	{
		//		ComboBoxItem cbi = (ComboBoxItem)cmbFile.SelectedItem;
		//		FileNameEntry = cbi.Content.ToString();
		//		if (!string.IsNullOrEmpty(FileNameEntry))
		//		{
		//			string basename = "Resource" + "." + FileNameEntry;
		//			rm = new ResourceManager(basename, Assembly.GetExecutingAssembly());
		//			LoadReadLoudContent(1);
		//		}	
		//	}
		//	catch (Exception ex)
		//	{
		//		MessageBox.Show(ex.Message, "Exception");
		//	}
		//}

        private void Comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
                int skipcount = Convert.ToInt32(cbi.Content.ToString());
                string text = GetTextFromResource(skipcount);
                if (!string.IsNullOrEmpty(text))
                {
                    LoadReadLoudContent(skipcount);
                }
                else
                {
                    comboskip.SelectedIndex = -1;
                    MessageBox.Show("File does not contain this count of data to skip", "Message");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception");
            }
        }

		private void btnPrevQue_Click(object sender, RoutedEventArgs e)
		{			
			LoadReadLoudContent(counter - 1);
		}
	}
}
