﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Xml;
namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for PTESummarizeSpocText.xaml
    /// </summary>
    public partial class PTESummarizeSpocText : UserControl
    {
		private SpeechSynthesizer synthesizer;
		private TextRange selectedSpeakData;
		private int counter = 0;

		public PTESummarizeSpocText()
        {
            InitializeComponent();
        }	

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				synthesizer = new SpeechSynthesizer();

				#region synthesizer eventes
				synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
				#endregion

				LoadInstalledVoices();

				LoadSSTContent(1);
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void LoadSSTContent(int value)
		{
			if (value == 1)
			{ btnprevQue.IsEnabled = false; }
			else
			{ btnprevQue.IsEnabled = true; }

			TextRange range;

			string contentvalue = Resource.SSTResource.ResourceManager.GetString("_" + value);

			if (!string.IsNullOrEmpty(contentvalue))
			{				
				range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
				range.Text = value.ToString() + ". " + contentvalue;
				//CapitalizeBoldFirstLine();
			}

			counter = value;

			selectedSpeakData = ConvertRichTextBoxContentsToString();
		}
		
		private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
		}

		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{			
			
		}

		#endregion

		private TextRange ConvertRichTextBoxContentsToString()
		{
			TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
			return textRange;
		}

		private void BtnSpeak_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (comboVoice.SelectedItem != null)
				{
					synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
					comboVoice.IsEnabled = false;
					switch (synthesizer.State)
					{
						//if synthesizer is ready
						case SynthesizerState.Ready:
							synthesizer.SpeakAsync(selectedSpeakData.Text);							
							break;
						//if synthesizer is paused
						case SynthesizerState.Paused:
							synthesizer.Resume();							
							break;
						//if synthesizer is speaking
						case SynthesizerState.Speaking:
							synthesizer.Pause();							
							break;
					}
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void BtnNextQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				txtSumm.Clear();
				LoadSSTContent(counter + 1);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}			
		}

		private void BtnValidate_Click(object sender, RoutedEventArgs e)
		{	
			string comment = string.Empty;
			XmlDocument doc = new XmlDocument();
			string appDir = Directory.GetCurrentDirectory().ToString();
			string filePath = Path.Combine(appDir.Substring(0, appDir.LastIndexOf("bin")), ConfigurationManager.AppSettings["SSTFile"]);
			if (File.Exists(filePath))
			{
				doc.Load(filePath);
				comment = ReadResourceComment(doc, "_" + counter);
			}

			if (!string.IsNullOrEmpty(comment))
			{
				MessageBox.Show(comment, "Message");
			}
		}

		public string ReadResourceComment(XmlDocument doc, string FieldName)
		{
			string validate = string.Empty;
			if (doc != null && !string.IsNullOrEmpty(doc.InnerXml))
			{
				if (doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"] != null)
				{
					validate = doc.SelectSingleNode("root/data[@name='" + FieldName + "']")["comment"].InnerText;
				}				
			}

			return validate;
		}

		private void btnprevQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				txtSumm.Clear();
				LoadSSTContent(counter - 1);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());
				string text = GetTextFromResource(skipcount);
				if (!string.IsNullOrEmpty(text))
				{
					LoadSSTContent(skipcount);
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("File does not contain this count of data to skip", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private static string GetTextFromResource(int value)
		{
			return Resource.SSTResource.ResourceManager.GetString("_" + value);
		}
	}
}
