﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;


namespace SideMenu.Demo.UserControls
{
	/// <summary>
	/// Interaction logic for PTEReadText.xaml
	/// </summary>
	public partial class PTEReadText : UserControl
	{
		private SpeechSynthesizer synthesizer;
		private TextRange selectedSpeakData;
		private Stopwatch tmc;
		private int counter = 0;
		private string filedirPath = string.Empty;

		public PTEReadText()
		{
			InitializeComponent();
			string appDir = Directory.GetCurrentDirectory().ToString();
		}

		private void ButtonOK_Click(object sender, RoutedEventArgs e)
		{
			BackgroundWorker worker = new BackgroundWorker();
			worker.WorkerReportsProgress = true;
			worker.DoWork += worker_DoWork;
			worker.ProgressChanged += worker_ProgressChanged;
			worker.RunWorkerAsync();
			tmc = new Stopwatch();
			tmc.Start();
		}

		private void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
		{
			pbStatus.Value = e.ProgressPercentage;
			//tblProgress.Text = e.ProgressPercentage.ToString() + "%";
			tblTime.Text = String.Format("{0}h {1}m {2}s", tmc.Elapsed.Hours, tmc.Elapsed.Minutes, tmc.Elapsed.Seconds);
		}

		private void worker_DoWork(object sender, DoWorkEventArgs e)
		{
			for (int i = 0; i < 100; i++)
			{
				(sender as BackgroundWorker).ReportProgress(i);
				Thread.Sleep(380);
			}
		}

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				synthesizer = new SpeechSynthesizer();

				#region synthesizer eventes
				synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
				#endregion

				LoadInstalledVoices();
				LoadReadLoudContent(1);
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void LoadReadLoudContent(int value)
		{
			TextRange range;

			string contentvalue = GetTextFromResource(value);
			if (!string.IsNullOrEmpty(contentvalue))
			{
				range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
				range.Text = contentvalue;
			}

			counter = value;
		}

		private string GetTextFromResource(int value)
		{
			return Resource.PTERetellLecture.ResourceManager.GetString("_" + value);
		}

		private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
		}

		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{

		}

		#endregion

		private TextRange ConvertRichTextBoxContentsToString()
		{
			TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
			return textRange;
		}

		private void BtnSpeak_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (comboVoice.SelectedItem != null)
				{
					synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
					comboVoice.IsEnabled = false;
					selectedSpeakData = ConvertRichTextBoxContentsToString();
					if (!selectedSpeakData.IsEmpty)
					{
						switch (synthesizer.State)
						{
							//if synthesizer is ready
							case SynthesizerState.Ready:
								synthesizer.SpeakAsync(selectedSpeakData.Text);
								break;
							//if synthesizer is paused
							case SynthesizerState.Paused:
								synthesizer.Resume();
								break;
							//if synthesizer is speaking
							case SynthesizerState.Speaking:
								synthesizer.Pause();
								break;
						}
					}
					else
					{
						MessageBox.Show("No Records Found To Speak", "Message");
					}
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void BtnNext_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				LoadReadLoudContent(counter + 1);					
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnprevQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				LoadReadLoudContent(counter - 1);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}
	}
}
