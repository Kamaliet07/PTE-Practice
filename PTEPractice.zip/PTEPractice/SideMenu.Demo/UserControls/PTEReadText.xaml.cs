﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SideMenu.Demo.UserControls
{
	/// <summary>
	/// Interaction logic for PTEReadText.xaml
	/// </summary>
	public partial class PTEReadText : UserControl
	{
		private SpeechSynthesizer synthesizer;
		private TextRange selectedSpeakData;
		private int counter = 0;
		public PTEReadText()
		{
			InitializeComponent();
		}

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				synthesizer = new SpeechSynthesizer();

				#region synthesizer eventes
				synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
				#endregion

				LoadInstalledVoices();				
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
		}

		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{

		}

		#endregion

		private TextRange ConvertRichTextBoxContentsToString()
		{
			TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
			return textRange;
		}

		private void BtnSpeak_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (comboVoice.SelectedItem != null)
				{
					synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
					comboVoice.IsEnabled = false;
					selectedSpeakData = ConvertRichTextBoxContentsToString();
					if (!selectedSpeakData.IsEmpty)
					{
						switch (synthesizer.State)
						{
							//if synthesizer is ready
							case SynthesizerState.Ready:
								synthesizer.SpeakAsync(selectedSpeakData.Text);
								break;
							//if synthesizer is paused
							case SynthesizerState.Paused:
								synthesizer.Resume();
								break;
							//if synthesizer is speaking
							case SynthesizerState.Speaking:
								synthesizer.Pause();
								break;
						}
					}
					else
					{
						MessageBox.Show("No Records Found To Speak", "Message");
					}
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}
	}
}
