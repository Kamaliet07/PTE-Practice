﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using Microsoft.Win32;
using SideMenu.Demo.ErrorLog;

namespace SideMenu.Demo.UserControls
{
	/// <summary>
	/// Interaction logic for RepeatSentence.xaml
	/// </summary>
	public partial class RepeatSentence : UserControl
	{
		//speech synthesizer
		private SpeechSynthesizer synthesizer;
		private string selectedSpeakData;
	    private Hashtable _hasContent;
	    private int counter = 0;
	    private bool firstTimeRun = true;
		int totalCount = 0;

		public RepeatSentence()
		{
			InitializeComponent();
		}

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			synthesizer = new SpeechSynthesizer();

			#region synthesizer eventes
			synthesizer.StateChanged += new EventHandler<StateChangedEventArgs>(synthesizer_StateChanged);
			synthesizer.SpeakStarted += new EventHandler<SpeakStartedEventArgs>(synthesizer_SpeakStarted);
			synthesizer.SpeakProgress += new EventHandler<SpeakProgressEventArgs>(synthesizer_SpeakProgress);
			synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);			
			#endregion

			LoadInstalledVoices();
		}
		private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
		}

		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{
			//reset when complete 			
            labelProgress.Content = "";
		    txtRS.Text = selectedSpeakData;
		}

		private void synthesizer_SpeakProgress(object sender, SpeakProgressEventArgs e)
		{
			if (synthesizer.Volume != Convert.ToInt32(sliderVolume.Value) || synthesizer.Rate != Convert.ToInt32(sliderRate.Value))
			{
				synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
				synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
				synthesizer.SpeakAsyncCancelAll();
				synthesizer.SpeakAsync(selectedSpeakData);
			}

			//show the synthesizer's current progress 
			labelProgress.Content = e.Text;
		}

		private void synthesizer_SpeakStarted(object sender, SpeakStartedEventArgs e)
		{

		}

		private void synthesizer_StateChanged(object sender, StateChangedEventArgs e)
		{
			//show the synthesizer's current state 
			//labelState.Content = e.State.ToString();
		}
		#endregion

		private void sliderVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (synthesizer != null)
			{
				synthesizer.Volume = Convert.ToInt32(sliderVolume.Value);
			}
		}

		private void sliderRate_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (synthesizer != null)
			{
				synthesizer.Rate = Convert.ToInt32(sliderRate.Value);
			}
		}

		private void OpenTextFileButton_Click(object sender, RoutedEventArgs e)
		{
		    try
		    {
		        OpenFileDialog openFileDialog = new OpenFileDialog();
		        openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
		        openFileDialog.RestoreDirectory = true;
		        if (openFileDialog.ShowDialog() == true)
		        {
		            LoadTextDocument(openFileDialog.FileName);
		            txtFileName.Text = openFileDialog.FileName;
		        }
            }
		    catch (Exception ex)
		    {
		        MessageBox.Show(ex.Message, "Exception");
            }
		}

	    private void LoadTextDocument(string fileName)
	    {
	        if (File.Exists(fileName))
	        {
	            _hasContent = new Hashtable();
	            string[] lines = File.ReadAllLines(fileName);
	            if (lines.Length > 0)
	            {
	                bool rearranged = RearrangeTextNumbers(lines);
	                if (rearranged)
	                {
	                    LoadWFDContent(1);
                        //int number = Convert.ToInt32(Regex.Replace(newstring, "[^0-9]", ""));
                    }
	            }
	        }
	    }

        private bool RearrangeTextNumbers(string[] lines)
        {
            bool status = false;
            int hashCounter = 0;
            RegexOptions options = RegexOptions.None;
            Regex regex = new Regex("[ ]{2,}", options);
            foreach (string str in lines)
            {
                string newstring = regex.Replace(str, " ").Replace(".", "").Trim();
                if (!string.IsNullOrEmpty(newstring))
                {
                    string content = newstring.Replace(Regex.Replace(newstring, "[^0-9]", ""), "").Replace(".", "").Replace("\t", "").Trim();
                    hashCounter = hashCounter + 1;
                    _hasContent.Add(hashCounter, content);
                }
            }

			totalCount = _hasContent.Count;

			if (totalCount > 0)
            {
                status = true;
            }

            return status;
        }

        //private void LoadRichTextBox(string fileName)
        //{
        //    TextRange range;
        //    if (System.IO.File.Exists(fileName))
        //    {
        //        range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
        //        using (FileStream fStream = new FileStream(fileName, System.IO.FileMode.OpenOrCreate))
        //        {
        //            range.Load(fStream, System.Windows.DataFormats.Text);
        //        }
        //    }
        //}

        private void btnSpeak_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (comboVoice.SelectedItem != null)
				{
				    if (firstTimeRun)
				    {
				        Thread.Sleep(2000);
				        synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
				        sliderVolume.IsEnabled = false;
				        sliderRate.IsEnabled = false;
				        comboVoice.IsEnabled = false;
				        switch (synthesizer.State)
				        {
				            //if synthesizer is ready
				            case SynthesizerState.Ready:
				                synthesizer.SpeakAsync(selectedSpeakData);				                
				                break;
				            //if synthesizer is paused
				            case SynthesizerState.Paused:
				                synthesizer.Resume();				                
				                break;
				            //if synthesizer is speaking
				            case SynthesizerState.Speaking:
				                synthesizer.Pause();				                
				                break;
				        }

				        firstTimeRun = false;

				    }

				    else
				    {				       
				        synthesizer.SpeakAsync(selectedSpeakData);
				    }
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}

		}

	    private void LoadWFDContent(int value)
	    {
			if (value > 0)
			{
				string contentvalue = _hasContent[value].ToString();

				if (!string.IsNullOrEmpty(contentvalue))
				{
					selectedSpeakData = contentvalue;
					labelCount.Content = value.ToString() + '/' + totalCount.ToString();
				}

				counter = value;
			}			
	    }

		private void btnNextQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				txtRS.Clear();
				LoadWFDContent(counter + 1);
				Thread.Sleep(2000);
				synthesizer.SpeakAsync(selectedSpeakData);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnPrevQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				txtRS.Clear();
				LoadWFDContent(counter - 1);
				Thread.Sleep(2000);
				synthesizer.SpeakAsync(selectedSpeakData);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}		

		private void btnRestore_Click(object sender, RoutedEventArgs e)
		{
			try
			{				
				foreach (string value in _hasContent.Values)
				{
					LogWriter.LogToReviseAgainRS(value);
				}

				MessageBox.Show("File Generated Successfully", "Message");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}

		}

		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			LogWriter.LogToReviseAgainRS(selectedSpeakData);
		}
	}
}
