﻿using System;
using System.Linq;
using System.Speech.Synthesis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace SideMenu.Demo.UserControls
{
    /// <summary>
    /// Interaction logic for EssayWriting.xaml
    /// </summary>
    public partial class EssayWriting : UserControl
    {
		private SpeechSynthesizer synthesizer;
		private TextRange selectedSpeakData;
		private int counter = 0;
		bool firstTimeRun = true;

		public EssayWriting()
        {
            InitializeComponent();
        }

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				synthesizer = new SpeechSynthesizer();
				synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synthesizer_SpeakCompleted);
				LoadInstalledVoices();
				LoadEssayContent(1);
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message, "Exception");
			}
		}

		#region Synthesizer events
		private void synthesizer_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
		{

		}
		#endregion

		private void LoadInstalledVoices()
		{
			comboVoice.DataContext = (from e in synthesizer.GetInstalledVoices(System.Globalization.CultureInfo.CurrentUICulture)
									  select e.VoiceInfo.Name);
		}

		private void Comboskip_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				ComboBoxItem cbi = (ComboBoxItem)comboskip.SelectedItem;
				int skipcount = Convert.ToInt32(cbi.Content.ToString());
				string text = GetTextFromResource(skipcount);
				if (!string.IsNullOrEmpty(text))
				{
					LoadEssayContent(skipcount);
				}
				else
				{
					comboskip.SelectedIndex = -1;
					MessageBox.Show("File does not contain this count of data to skip", "Message");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private static string GetTextFromResource(int value)
		{
			return Resource.EssayCollection.ResourceManager.GetString("E" + value);
		}

		private void LoadEssayContent(int value)
		{
			TextRange range;

			string contentvalue = GetTextFromResource(value);
			if (!string.IsNullOrEmpty(contentvalue))
			{
				range = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
				range.Text = value.ToString() + ". " + contentvalue;
				FormateContentLine();
			}

			counter = value;

			selectedSpeakData = ConvertRichTextBoxContentsToString();
		}

		private void FormateContentLine()
		{
			foreach (var paragraph in richTextBox1.Document.Blocks)
			{
				var text = new TextRange(paragraph.ContentStart,
					paragraph.ContentEnd).Text;
				
				if (text.StartsWith("•"))
				{
					paragraph.Foreground = Brushes.Blue;
				}							
			}
		}

		private TextRange ConvertRichTextBoxContentsToString()
		{
			TextRange textRange = new TextRange(richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);
			return textRange;
		}

		private void btnNextQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				firstTimeRun = false;
				LoadEssayContent(counter + 1);				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void btnPrevQue_Click(object sender, RoutedEventArgs e)
		{
			try
			{				
				LoadEssayContent(counter - 1);				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}
		}

		private void BtnStart_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (comboVoice.SelectedItem != null)
				{
					if (firstTimeRun)
					{
						synthesizer.SelectVoice(comboVoice.SelectedItem.ToString());
						comboVoice.IsEnabled = false;
					}					
					if (!string.IsNullOrEmpty(selectedSpeakData.ToString()))
					{
						synthesizer.SpeakAsync(selectedSpeakData.ToString());
					}
				}
				else
				{
					MessageBox.Show("Please select the Voice", "Message");
				}
			}

			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception");
			}			
		}
	}
}
