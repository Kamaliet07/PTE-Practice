﻿namespace SideMenu.Demo
{
    public partial class App
    {
    }
}