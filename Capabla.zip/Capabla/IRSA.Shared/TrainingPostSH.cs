﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class TrainingPostSH
    {
        private string i_Title = string.Empty;
        private string i_Location = string.Empty;
        private string i_Description = string.Empty;
        private string i_Keyword = string.Empty;
        private string i_Keyword3 = string.Empty;
        private string i_Keyword1 = string.Empty;
        private string i_Keyword2 = string.Empty;
        private string i_JobFamilyName = string.Empty;
        private string i_Action = string.Empty;
        private string i_FormatID = string.Empty;
        private string i_StartDate = string.Empty;
        private string i_EndDate = string.Empty;
        private Int16 i_DurationDays = Int16.MinValue;
        private Int16 i_DurationHours = Int16.MinValue;
        private Int16 i_DurationMinute = Int16.MinValue;
        private double  i_Cost = double.Epsilon;
        private string i_CostCurrency = string.Empty;
        private string i_UploadTraining = string.Empty;
        private string i_TrainingURL = string.Empty;
        private string i_Paid = string.Empty;
        private int i_Capacity = int.MinValue;
        private string i_Availability = string.Empty;
        public string Title
        {
            get
            {
                return i_Title;
            }
            set
            {
                this.i_Title = value;
            }
        }
        public string Location
        {
            get
            {
                return i_Location;
            }
            set
            {
                this.i_Location = value;
            }
        }
        public string Description
        {
            get
            {
                return i_Description;
            }
            set
            {
                this.i_Description = value;
            }
        }
        public double Cost
        {
            get
            {
                return i_Cost;
            }
            set
            {
                this.i_Cost = value;
            }
        }
        public string CostCurrency
        {
            get
            {
                return i_CostCurrency;
            }
            set
            {
                this.i_CostCurrency = value;
            }
        }

        public string StartDate
        {
            get
            {
                return i_StartDate;
            }
            set
            {
                this.i_StartDate = value;
            }
        }
        public string EndDate
        {
            get
            {
                return i_EndDate;
            }
            set
            {
                this.i_EndDate = value;
            }
        }
        public string Keyword
        {
            get
            {
                return i_Keyword;
            }
            set
            {
                this.i_Keyword = value;
            }
        }
        public string Keyword1
        {
            get
            {
                return i_Keyword1;
            }
            set
            {
                this.i_Keyword1 = value;
            }
        }
        public string Keyword2
        {
            get
            {
                return i_Keyword2;
            }
            set
            {
                this.i_Keyword2 = value;
            }
        }
        public string Keyword3
        {
            get
            {
                return i_Keyword3;
            }
            set
            {
                this.i_Keyword3 = value;
            }
        }
        public string FormatID
        {
            get
            {
                return i_FormatID;
            }
            set
            {
                this.i_FormatID = value;
            }
        }
        public string JobFamilyName
        {
            get
            {
                return i_JobFamilyName;
            }
            set
            {
                this.i_JobFamilyName = value;
            }
        }
        public string Action
        {
            get
            {
                return i_Action;
            }
            set
            {
                this.i_Action = value;
            }
        }
        public Int16 DurationDays
        {
            get
            {
                return i_DurationDays;
            }
            set
            {
                this.i_DurationDays = value;
            }
        }
        public Int16 DurationHours
        {
            get
            {
                return i_DurationHours;
            }
            set
            {
                this.i_DurationHours = value;
            }
        }
        public Int16 DurationMinute
        {
            get
            {
                return i_DurationMinute;
            }
            set
            {
                this.i_DurationMinute = value;
            }
        }
        public string UploadTraining
        {
            get
            {
                return i_UploadTraining;
            }
            set
            {
                this.i_UploadTraining = value;
            }
        }
        public string TrainingURL
        {
            get
            {
                return i_TrainingURL;
            }
            set
            {
                this.i_TrainingURL = value;
            }
        }
        public int Capacity
        {
            get
            {
                return i_Capacity;
            }
            set
            {
                this.i_Capacity = value;
            }
        }
        public string Availability
        {
            get
            {
                return i_Availability;
            }
            set
            {
                this.i_Availability = value;
            }
        }

        public string Paid
        {
            get
            {
                return i_Paid;
            }
            set
            {
                this.i_Paid = value;
            }
        }
    }
}
