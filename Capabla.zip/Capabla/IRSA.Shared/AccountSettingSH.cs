﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class AccountSettingSH
    {
        private string i_accessiblerole = string.Empty;
        private string i_everyone = string.Empty;
        private string i_mycontacts = string.Empty;
        private string i_mycommunities = string.Empty;
        private string i_ContactBrowse = string.Empty;
        private string i_ProfileView = string.Empty;
        private string i_ContactSettings = string.Empty;
        private string i_iRSANotification = string.Empty;
        private string i_iRSANewsletter = string.Empty;
        private string i_MyProfilephoto = string.Empty;
        private string i_MyVisibility = string.Empty;
        private string i_academics = string.Empty;
        private string i_pastcompany = string.Empty;
        private string i_PresentCompany = string.Empty;
        private string i_Projects = string.Empty;
        private string i_PayDuration = string.Empty;
        private string i_PreferredCurrency = string.Empty;
        private string i_PreferredSalaryAmount = string.Empty;
        private string i_JobTypes = string.Empty;
        private int i_HoursPerweek = int.MinValue;
        private string i_allowrecruiters = string.Empty;
        private string i_Recruitersallowed = string.Empty;
        private string i_PrefIndustries = string.Empty;
        private string i_IndustriesPref = string.Empty;
        private string i_HideName = string.Empty;
        private string i_HideIdentity = string.Empty;
        public string accessiblerole
        {
            get
            {
                return i_accessiblerole;
            }
            set
            {
                this.i_accessiblerole = value;
            }
        }
        public string everyone
        {
            get
            {
                return i_everyone;
            }
            set
            {
                this.i_everyone = value;
            }
        }
        public string mycontacts
        {
            get
            {
                return i_mycontacts;
            }
            set
            {
                this.i_mycontacts = value;
            }
        }
        public string mycommunities
        {
            get
            {
                return i_mycommunities;
            }
            set
            {
                this.i_mycommunities = value;
            }
        }
        public string ContactBrowse
        {
            get
            {
                return i_ContactBrowse;
            }
            set
            {
                this.i_ContactBrowse = value;
            }
        }

        public string ProfileView
        {
            get
            {
                return i_ProfileView;
            }
            set
            {
                this.i_ProfileView = value;
            }
        }
        public string ContactSettings
        {
            get
            {
                return i_ContactSettings;
            }
            set
            {
                this.i_ContactSettings = value;
            }
        }
        public string iRSANotification
        {
            get
            {
                return i_iRSANotification;
            }
            set
            {
                this.i_iRSANotification = value;
            }
        }

        public string iRSANewsletter
        {
            get
            {
                return i_iRSANewsletter;
            }
            set
            {
                this.i_iRSANewsletter = value;
            }
        }

        public string MyProfilephoto
        {
            get
            {
                return i_MyProfilephoto;
            }
            set
            {
                this.i_MyProfilephoto = value;
            }
        }
        public string MyVisibility
        {
            get
            {
                return i_MyVisibility;
            }
            set
            {
                this.i_MyVisibility = value;
            }
        }
        public string academics
        {
            get
            {
                return i_academics;
            }
            set
            {
                this.i_academics = value;
            }
        }
        public string pastcompany
        {
            get
            {
                return i_pastcompany;
            }
            set
            {
                this.i_pastcompany = value;
            }
        }
        public string PresentCompany
        {
            get
            {
                return i_PresentCompany;
            }
            set
            {
                this.i_PresentCompany = value;
            }
        }
        public string Projects
        {
            get
            {
                return i_Projects;
            }
            set
            {
                this.i_Projects = value;
            }
        }
        public string PayDuration
        {
            get
            {
                return i_PayDuration;
            }
            set
            {
                this.i_PayDuration = value;
            }
        }
        public string PreferredCurrency 
        {
            get
            {
                return i_PreferredCurrency;
            }
            set
            {
                this.i_PreferredCurrency = value;
            }
        }
        public string PreferredSalaryAmount 
        {
            get
            {
                return i_PreferredSalaryAmount;
            }
            set
            {
                this.i_PreferredSalaryAmount = value;
            }
        }
        public string JobTypes 
        {
            get
            {
                return i_JobTypes;
            }
            set
            {
                this.i_JobTypes = value;
            }
        }

        public int HoursPerweek
        {
            get
            {
                return i_HoursPerweek;
            }
            set
            {
                this.i_HoursPerweek = value;
            }
        }

        public string allowrecruiters 
        {
            get
            {
                return i_allowrecruiters;
            }
            set
            {
                this.i_allowrecruiters = value;
            }
        }
        public string Recruitersallowed 
        {
            get
            {
                return i_Recruitersallowed;
            }
            set
            {
                this.i_Recruitersallowed = value;
            }
        }

        public string PrefIndustries 
        {
            get
            {
                return i_PrefIndustries;
            }
            set
            {
                this.i_PrefIndustries = value;
            }
        }
        public string IndustriesPref
        {
            get
            {
                return i_IndustriesPref;
            }
            set
            {
                this.i_IndustriesPref = value;
            }
        }

        public string HideName
        {
            get
            {
                return i_HideName;
            }
            set
            {
                this.i_HideName = value;
            }
        }

        public string HideIdentity
        {
            get
            {
                return i_HideIdentity;
            }
            set
            {
                this.i_HideIdentity = value;
            }
        }
    }
}
