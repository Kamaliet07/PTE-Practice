﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class CandidateSearchSH
    {
        private int i_Title = int.MinValue;
        private int i_RangeFrom = int.MinValue;
        private int i_RangeTo = int.MinValue;
        private string i_Status = string.Empty;



        public int Title
        {
            get
            {
                return i_Title;
            }
            set
            {
                this.i_Title = value;
            }
        }
        public int RangeFrom
        {
            get
            {
                return i_RangeFrom;
            }
            set
            {
                this.i_RangeFrom = value;
            }
        }
        public int RangeTo 
       {
           get
           {
               return i_RangeTo;
           }
           set
           {
               this.i_RangeTo = value;
           }
       }
        public string Status
        {
            get
            {
                return i_Status;
            }
            set
            {
                this.i_Status = value;
            }
        }
    }
 }

