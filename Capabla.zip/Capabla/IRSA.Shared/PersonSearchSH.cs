﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class PersonSearchSH
    {
        public string i_FirstName = string.Empty;
        public string i_LastName = string.Empty;
        public string i_City = string.Empty;
        public string i_Country = string.Empty;
        public string i_Keyword = string.Empty;
        public string i_HighestEducation = string.Empty;
        public string i_University = string.Empty;
        public string i_ProfessionalTitle = string.Empty;
        public string i_Company = string.Empty;

        public string FirstName
        {
            get
            {
                return i_FirstName;
            }
            set
            {
                this.i_FirstName = value;
            }
        }
        public string Keyword
        {
            get
            {
                return i_Keyword;
            }
            set
            {
                this.i_Keyword = value;
            }
        }
        
        public string City 
        {
            get
            {
                return i_City;
            }
            set
            {
                this.i_City = value;
            }
        }
        
        public string Country 
        {
            get
            {
                return i_Country;
            }
            set
            {
                this.i_Country = value;
            }
        }
        public string LastName
        {
            get
            {
                return i_LastName;
            }
            set
            {
                this.i_LastName = value;
            }
        }
        public string HighestEducation
        {
            get
            {
                return i_HighestEducation;
            }
            set
            {
                this.i_HighestEducation = value;
            }
        }
        public string University
        {
            get
            {
                return i_University;
            }
            set
            {
                this.i_University = value;
            }
        }
        public string Company
        {
            get
            {
                return i_Company;
            }
            set
            {
                this.i_Company = value;
            }
        }
        
            
             public string ProfessionalTitle
             {
                 get
                 {
                     return i_ProfessionalTitle;
                 }
                 set
                 {
                     this.i_ProfessionalTitle = value;
                 }
             }
        


    }
}
