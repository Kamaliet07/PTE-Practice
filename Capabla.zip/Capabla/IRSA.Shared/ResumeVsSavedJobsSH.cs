﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class ResumeVsSavedJobsSH
    {

        //Declaring Data Members
        int i_UserID=int.MinValue;
        string i_DateFrom=string.Empty;
        string i_DateTo=string.Empty;
        int i_CandidateID = int.MinValue;
        int i_JobID = int.MinValue;
        string i_CreateDate = string.Empty;
        string i_ModifyDate = string.Empty;
        bool i_Deleted = false;
        int i_ExperienceFrom = int.MinValue;
        int i_ExperienceTo = int.MinValue;
        string i_Skills = string.Empty;
        string i_Degree = string.Empty;
        string i_JobFamilyID = string.Empty;
       

        //Declaring Member Functions
        public int UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public string DateFrom
        {
            get
            {
                return i_DateFrom;
            }
            set
            {
                this.i_DateFrom = value;
            }
        }
        public string DateTo
        {
            get
            {
                return i_DateTo;
            }
            set
            {
                this.i_DateTo = value;
            }
        }
        public int CandidateID
        {
            get
            {
                return i_CandidateID;
            }
            set
            {
                this.i_CandidateID = value;
            }
        }
        public int JobID
        {
            get
            {
                return i_JobID;
            }
            set
            {
                this.i_JobID = value;
            }
        }
        public string CreateDate
        {
            get
            {
                return i_CreateDate;
            }
            set
            {
                this.i_CreateDate = value;
            }
        }
        public string ModifyDate
        {
            get
            {
                return i_ModifyDate;
            }
            set
            {
                this.i_ModifyDate = value;
            }
        }
        public bool Deleted
        {
            get
            {
                return i_Deleted;
            }
            set
            {
                this.i_Deleted = value;
            }
        }
        public int ExperienceFrom
        {
            get
            {
                return i_ExperienceFrom;
            }
            set
            {
                this.i_ExperienceFrom = value;
            }
        }
        public int ExperienceTo
        {
            get
            {
                return i_ExperienceTo;
            }
            set
            {
                this.i_ExperienceTo = value;
            }
        }
        public string Skills
        {
            get
            {
                return i_Skills;
            }
            set
            {
                this.i_Skills = value;
            }
        }
        public string Degree
        {
            get
            {
                return i_Degree;
            }
            set
            {
                this.i_Degree = value;
            }
        }
        public string JobFamilyID
        {
            get
            {
                return i_JobFamilyID;
            }
            set
            {
                this.i_JobFamilyID = value;
            }
        }
       
    }
}
