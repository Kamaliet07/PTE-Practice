﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class LearningManagementSH
    {
        private string i_Keyword = string.Empty;

        private string i_Country = string.Empty;
        private string i_City = string.Empty;

         public string Keyword
        {
            get
            {
                return i_Keyword;
            }
            set
            {
                this.i_Keyword = value;
            }
        }
     
       public string Country
       {
           get
           {
               return i_Country;
           }
           set
           {
               this.i_Country = value;
           }
       }
       public string City
       {
           get
           {
               return i_City;
           }
           set
           {
               this.i_City = value;
           }
       }
    }
}

   
