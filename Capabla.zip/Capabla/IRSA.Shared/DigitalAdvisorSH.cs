﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class DigitalAdvisorSH
    {

       private string i_PhaseTopic = string.Empty;
       private string i_PhaseSituation = string.Empty;
       private string i_PhaseStatus = string.Empty;
       private int i_AdviseRate = int.MinValue;
       private string i_AdviseName = string.Empty;
       private int i_CategoryID = int.MinValue;
       private int i_TopicID = int.MinValue;
       

       public string PhaseTopic
       {
           get
           {
               return i_PhaseTopic;
           }
           set
           {
               this.i_PhaseTopic = value;
           }
       }

       public string PhaseSituation
       {
           get
           {
               return i_PhaseSituation;
           }
           set
           {
               this.i_PhaseSituation = value;
           }
       }

       public string PhaseStatus
       {
           get
           {
               return i_PhaseStatus;
           }
           set
           {
               this.i_PhaseStatus = value;
           }
       }

       public string AdviseName
       {
           get
           {
               return i_AdviseName;
           }
           set
           {
               this.i_AdviseName = value;
           }
       }

       public int CategoryID
       {
           get
           {
               return i_CategoryID;
           }
           set
           {
               this.i_CategoryID = value;
           }
       }

       public int TopicID
       {
           get
           {
               return i_TopicID;
           }
           set
           {
               this.i_TopicID = value;
           }
       }

       
       public int AdviseRate
       {
           get
           {
               return i_AdviseRate;
           }
           set
           {
               this.i_AdviseRate = value;
           }
       }

    }
    
}
