﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class RegistrationSH
    {
        private string i_FirstName = string.Empty;
        private string i_LastName = string.Empty;
        private string i_EmailID = string.Empty;
        private string i_Password = string.Empty;
        private string i_Country = string.Empty;
        private string i_Postalcode = string.Empty;
        private string i_Who = string.Empty;
        private string i_Education = string.Empty;
        private string i_Company = string.Empty;
        private string i_Industry = string.Empty;
        private string i_OrgName= string.Empty;
        private string i_Institute = string.Empty;
        private string i_CapchaCode = string.Empty;
        
       
        public string FirstName
        {
            get
            {
                return i_FirstName;
            }
            set
            {
                this.i_FirstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return i_LastName;
            }
            set
            {
                this.i_LastName = value;
            }
        }
        public string EmailID
        {
            get
            {
                return i_EmailID;
            }
            set
            {
                this.i_EmailID = value;
            }
        }
        public string Password
        {
            get
            {
                return i_Password;
            }
            set
            {
                this.i_Password = value;
            }
        }
        public string Country
        {
            get
            {
                return i_Country;
            }
            set
            {
                this.i_Country = value;
            }
        }
        public string Postalcode
        {
            get
            {
                return i_Postalcode;
            }
            set
            {
                this.i_Postalcode = value;
            }
        }
        public string Who
        {
            get
            {
                return i_Who;
            }
            set
            {
                this.i_Who = value;
            }
        }
        public string Education
        {
            get
            {
                return i_Education;
            }
            set
            {
                this.i_Education = value;
            }
        }
        public string Company
        {
            get
            {
                return i_Company;
            }
            set
            {
                this.i_Company = value;
            }
        }
        public string Industry
        {
            get
            {
                return i_Industry;
            }
            set
            {
                this.i_Industry = value;
            }
        }

        public string OrgName
        {
            get
            {
                return i_OrgName;
            }
            set
            {
                this.i_OrgName = value;
            }
        }


        public string Institute
        {
            get
            {
                return i_Institute;
            }
            set
            {
                this.i_Institute = value;
            }
        }

        public string CapchaCode
        {
            get
            {
                return i_CapchaCode;
            }
            set
            {
                this.i_CapchaCode = value;
            }
        }
    }
}
