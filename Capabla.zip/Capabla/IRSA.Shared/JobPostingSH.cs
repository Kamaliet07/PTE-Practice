﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class JobPostingSH
    {
       private string i_JobTitle = string.Empty;
       private string i_ComanyName = string.Empty;
       private string i_ComanyDescription = string.Empty;
       private string i_ComanyUrl = string.Empty;
       private string i_JobCodeReference = string.Empty;
       private Int16 i_Openings = Int16.MinValue;
       private double i_PayRangeFrom = double.Epsilon;
       private double i_PayRangeTo= double.Epsilon;
       private string i_PayCurrency = string.Empty;
       private string i_JobFamilyName = string.Empty;
       private string i_ExperienceLevel = string.Empty;
       private string i_ONETSOCTitle = string.Empty;
       private string i_PayDescription = string.Empty;
       private string i_Skills = string.Empty;
       private string i_JobDescription = string.Empty;
       private string i_Education = string.Empty;
       private Int16 i_YearExperince = Int16.MinValue;
       private string i_Distance = string.Empty;
       private string i_AvailabilityFrom = string.Empty;
       private string i_AvailabilityTo = string.Empty;
       private string i_Keyword = string.Empty;
       private string i_ToWhom = string.Empty;
       private Int16 i_Age = Int16.MinValue;
       private double i_ReferralBonusAmount = double.Epsilon;
       private string i_ReferralBonusCurrency = string.Empty;
       private string i_JobLocation = string.Empty;
       private string i_JobCountry = string.Empty;
       private string i_JobPotalCode = string.Empty;
       private string i_PostingDate = string.Empty;
       private string i_ExpirationDate = string.Empty;
       private string i_CurrentJobRoleType = string.Empty;
       private string i_CurrentJobFamily = string.Empty;
       private string i_JobType = string.Empty;
       private bool i_DrivingLicence= false;
       private bool i_Sponser = false;
       private Int32 i_ExperinceFrom = Int32.MinValue;
       private Int32 i_ExperinceTo = Int32.MinValue;
       private Int32 i_AgeFrom = Int32.MinValue;
       private Int32 i_AgeTo = Int32.MinValue;
       private string i_Gender = string.Empty;
       private string i_PayNote = string.Empty;
       private string i_JobCity = string.Empty;
       private double i_DataValue = double.Epsilon;
       private Int32 i_Workperweek = Int32.MinValue;
       private Int32 i_CompanyID = Int32.MinValue;
       private string i_IndustryID = string.Empty;
       private string i_OrgName = string.Empty;
       public string JobTitle
       {
           get
           {
               return i_JobTitle;
           }
           set
           {
               this.i_JobTitle = value;
           }
       }
       public string ComanyName
       {
           get
           {
               return i_ComanyName;
           }
           set
           {
               this.i_ComanyName = value;
           }
       }
       public string ComanyDescription
       {
           get
           {
               return i_ComanyDescription;
           }
           set
           {
               this.i_ComanyDescription = value;
           }
       }
       public string ComanyUrl
       {
           get
           {
               return i_ComanyUrl;
           }
           set
           {
               this.i_ComanyUrl = value;
           }
       }
       public string JobCodeReference
       {
           get
           {
               return i_JobCodeReference;
           }
           set
           {
               this.i_JobCodeReference = value;
           }
       }
       public Int16 Openings
       {
           get
           {
               return i_Openings;
           }
           set
           {
               this.i_Openings = value;
           }
       }
       public double PayRangeFrom
       {
           get
           {
               return i_PayRangeFrom;
           }
           set
           {
               this.i_PayRangeFrom = value;
           }
       }
       public double PayRangeTo
       {
           get
           {
               return i_PayRangeTo;
           }
           set
           {
               this.i_PayRangeTo = value;
           }
       }
       public string PayCurrency
       {
           get
           {
               return i_PayCurrency;
           }
           set
           {
               this.i_PayCurrency = value;
           }
       }
       public string JobFamilyName
       {
           get
           {
               return i_JobFamilyName;
           }
           set
           {
               this.i_JobFamilyName = value;
           }
       }
       public string ExperienceLevel
       {
           get
           {
               return i_ExperienceLevel;
           }
           set
           {
               this.i_ExperienceLevel = value;
           }
       }
       public string ONETSOCTitle
       {
           get
           {
               return i_ONETSOCTitle;
           }
           set
           {
               this.i_ONETSOCTitle = value;
           }
       }
       public string PayDescription
       {
           get
           {
               return i_PayDescription;
           }
           set
           {
               this.i_PayDescription = value;
           }
       }
       public string Skills
       {
           get
           {
               return i_Skills;
           }
           set
           {
               this.i_Skills = value;
           }
       }
       public string JobDescription
       {
           get
           {
               return i_JobDescription;
           }
           set
           {
               this.i_JobDescription = value;
           }
       }
       public string Education
       {
           get
           {
               return i_Education;
           }
           set
           {
               this.i_Education = value;
           }
       }
       public Int16 YearExperince
       {
           get
           {
               return i_YearExperince;
           }
           set
           {
               this.i_YearExperince = value;
           }
       }
       public string Distance
       {
           get
           {
               return i_Distance;
           }
           set
           {
               this.i_Distance = value;
           }
       }
       public string AvailabilityFrom
       {
           get
           {
               return i_AvailabilityFrom;
           }
           set
           {
               this.i_AvailabilityFrom = value;
           }
       }
       public string AvailabilityTo
       {
           get
           {
               return i_AvailabilityTo;
           }
           set
           {
               this.i_AvailabilityTo = value;
           }
       }
       public string Keyword
       {
           get
           {
               return i_Keyword;
           }
           set
           {
               this.i_Keyword = value;
           }
       }
       public Int16 Age
       {
           get
           {
               return i_Age;
           }
           set
           {
               this.i_Age = value;
           }
       }
       public string ToWhom
       {
           get
           {
               return i_ToWhom;
           }
           set
           {
               this.i_ToWhom = value;
           }
       }
       public double ReferralBonusAmount
       {
           get
           {
               return i_ReferralBonusAmount;
           }
           set
           {
               this.i_ReferralBonusAmount = value;
           }
       }
       public string ReferralBonusCurrency
       {
           get
           {
               return i_ReferralBonusCurrency;
           }
           set
           {
               this.i_ReferralBonusCurrency = value;
           }
       }
       public string JobLocation
       {
           get
           {
               return i_JobLocation;
           }
           set
           {
               this.i_JobLocation = value;
           }
       }
       public string JobCountry
       {
           get
           {
               return i_JobCountry;
           }
           set
           {
               this.i_JobCountry = value;
           }
       }
       public string JobPotalCode
       {
           get
           {
               return i_JobPotalCode;
           }
           set
           {
               this.i_JobPotalCode = value;
           }
       }
       public string PostingDate
       {
           get
           {
               return i_PostingDate;
           }
           set
           {
               this.i_PostingDate = value;
           }
       }
       public string ExpirationDate
       {
           get
           {
               return i_ExpirationDate;
           }
           set
           {
               this.i_ExpirationDate = value;
           }
       }
       public bool DrivingLicence
       {
           get
           {
               return i_DrivingLicence;
           }
           set
           {
               this.i_DrivingLicence = value;
           }
       }

       public string CurrentJobRoleType
       {
           get
           {
               return i_CurrentJobRoleType;
           }
           set
           {
               this.i_CurrentJobRoleType = value;
           }
       }
       public string CurrentJobFamily
       {
           get
           {
               return i_CurrentJobFamily;
           }
           set
           {
               this.i_CurrentJobFamily = value;
           }
       }
       public string JobType
       {
           get
           {
               return i_JobType;
           }
           set
           {
               this.i_JobType = value;
           }
       }
       public bool Sponser
       {
           get
           {
               return i_Sponser;
           }
           set
           {
               this.i_Sponser = value;
           }
       }
       public Int32 ExperinceFrom 
       {
           get
           {
               return i_ExperinceFrom;
           }
           set
           {
               this.i_ExperinceFrom = value;
           }

       }
       public Int32 ExperinceTo
       {
           get
           {
               return i_ExperinceTo;
           }
           set
           {
               this.i_ExperinceTo = value;
           }

       }
       public Int32 AgeFrom
       {
           get
           {
               return i_AgeFrom;
           }
           set
           {
               this.i_AgeFrom = value;
           }

       }
       public Int32 AgeTo
       {
           get
           {
               return i_AgeTo;
           }
           set
           {
               this.i_AgeTo = value;
           }

       }
       public string Gender
       {
           get
           {
               return i_Gender;
           }
           set
           {
               this.i_Gender = value;
           }
       }
       public string PayNote 
       {
           get
           {
               return i_PayNote;
           }
           set
           {
               this.i_PayNote = value;
           }
       }
       public string JobCity
       {
           get
           {
               return i_JobCity;
           }
           set
           {
               this.i_JobCity = value;
           }
       }
       public double DataValue
       {
           get
           {
               return i_DataValue;
           }
           set
           {
               this.i_DataValue = value;
           }
       }
       public Int32 Workperweek
       {
           get
           {
               return i_Workperweek;
           }
           set
           {
               this.i_Workperweek = value;
           }

       }
       public Int32 CompanyID
       {
           get
           {
               return i_CompanyID;
           }
           set
           {
               this.i_CompanyID = value;
           }

       }
       public string IndustryID
       {
           get
           {
               return i_IndustryID;
           }
           set
           {
               this.i_IndustryID = value;
           }
       }
       public string OrgName
       {
           get
           {
               return i_OrgName;
           }
           set
           {
               this.i_OrgName = value;
           }
       }
    }
}
