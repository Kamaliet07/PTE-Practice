﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
  public class JobStatusSH
    {
    //  private string i_RadComboBox1 = string.Empty;
      private string i_RadComboBox2 = string.Empty;
      private string i_RadComboBox3 = string.Empty;
      private string i_RadComboBox4 = string.Empty;
      private string i_RadComboBox5 = string.Empty;
      private string i_RadComboBox6 = string.Empty;
      private string i_RadComboBox7 = string.Empty;
      private string i_RadComboBox8 = string.Empty;
     // private string i_RadDatePicker1 = System.DateTime.Now.ToString("dd/MMM/yyyy");
      private string i_RadDatePicker2 = System.DateTime.Now.ToString("dd/MMM/yyyy");
      private string i_info = string.Empty;
      private string i_TextBox1 = string.Empty;
      private string i_radio = string.Empty;


      //public string RadComboBox1
      //{
      //    get
      //    {
      //        return i_RadComboBox1;
      //    }
      //    set
      //    {
      //        this.i_RadComboBox1 = value;
      //    }
      //}
      public string RadComboBox2
      {
          get
          {
              return i_RadComboBox2;
          }
          set
          {
              this.i_RadComboBox2 = value;
          }
      }
      public string RadComboBox3
      {
          get
          {
              return i_RadComboBox3;
          }
          set
          {
              this.i_RadComboBox3 = value;
          }
      }
      public string RadComboBox4
      {
          get
          {
              return i_RadComboBox4;
          }
          set
          {
              this.i_RadComboBox4 = value;
          }
      }
      public string RadComboBox5
      {
          get
          {
              return i_RadComboBox5;
          }
          set
          {
              this.i_RadComboBox5 = value;
          }
      }
      public string RadComboBox6
      {
          get
          {
              return i_RadComboBox6;
          }
          set
          {
              this.i_RadComboBox6 = value;
          }
      }
      public string RadComboBox7
      {
          get
          {
              return i_RadComboBox7;
          }
          set
          {
              this.i_RadComboBox7 = value;
          }
      }
      public string RadComboBox8
      {
          get
          {
              return i_RadComboBox8;
          }
          set
          {
              this.i_RadComboBox8 = value;
          }
      }
      //public string RadDatePicker1 
      //{
      //    get
      //    {
      //        return i_RadDatePicker1;
      //    }
      //    set
      //    {
      //        this.i_RadDatePicker1 = value;
      //    }
      //}
      public string RadDatePicker2
      {
          get
          {
              return i_RadDatePicker2;
          }
          set
          {
              this.i_RadDatePicker2 = value;
          }
      }
      public string info
      {
          get
          {
              return i_info;
          }
          set
          {
              this.i_info = value;
          }
      }
      public string TextBox1
      {
          get
          {
              return i_TextBox1;
          }
          set
          {
              this.i_TextBox1 = value;
          }
      }
      public string radio
      {
          get
          {
              return i_radio;
          }
          set
          {
              this.i_radio = value;
          }
      }
    }
}
