﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class ScreeingScheduleSH
    {
        
        string i_Date = string.Empty;
        string i_Time = string.Empty;
        int i_CandidateID = int.MinValue;
        string i_CreateDate = string.Empty;
        string i_Venue = string.Empty;
        string i_ModifyDate = string.Empty;
        bool i_Deleted = false;
        int i_UserID = int.MinValue;
        int i_JobID = int.MinValue;

        //Declaring Member Functions
       
        public string Date
        {
            get
            {
                return i_Date;
            }
            set
            {
                this.i_Date = value;
            }
        }
        public string Time
        {
            get
            {
                return i_Time;
            }
            set
            {
                this.i_Time = value;
            }
        }
        public string Venue
        {
            get
            {
                return i_Venue;
            }
            set
            {
                this.i_Venue = value;
            }
        }
        
        public int CandidateID
        {
            get
            {
                return i_CandidateID;
            }
            set
            {
                this.i_CandidateID = value;
            }
        }
       
        public string CreateDate
        {
            get
            {
                return i_CreateDate;
            }
            set
            {
                this.i_CreateDate = value;
            }
        }
        public string ModifyDate
        {
            get
            {
                return i_ModifyDate;
            }
            set
            {
                this.i_ModifyDate = value;
            }
        }
        public bool Deleted
        {
            get
            {
                return i_Deleted;
            }
            set
            {
                this.i_Deleted = value;
            }
        }
        public int UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public int JobID
        {
            get
            {
                return i_JobID;
            }
            set
            {
                this.i_JobID = value;
            }
        }
        
       
    }
}
