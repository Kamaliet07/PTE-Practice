﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace IRSA
{
    public class IRSAResumeSH
    {
        private string i_UserID = string.Empty;
        private string i_FirstName = string.Empty;
        private string i_LastName = string.Empty;
        private string i_EmailID = string.Empty;
        private string i_DateOfBirth = string.Empty;
        private string i_Phone = string.Empty;
        private string i_City = string.Empty;
        private string i_State = string.Empty;
        private string i_PostalCode = string.Empty;
        private string i_Country = string.Empty;
        private string i_Sex = string.Empty;
        private string i_RoleIndustry = string.Empty;
        private string i_KeySkills = string.Empty;
        private string i_AnnualSalary = string.Empty;
        private string i_SalaryCurrency = string.Empty;
        private string i_TotalExperience = string.Empty;
        private Boolean i_Deleted = false;
        private string i_MaritalStatus = string.Empty;
        private Boolean i_DrivingLicence = true;
        //private string i_PreferredSalaryAnount = string.Empty;
        //private string i_PreferredCurrency = string.Empty;
        //private string i_Relocation = string.Empty;
        //private int i_HoursPerweek = int.MinValue;
        //private string i_Professionaltitle = string.Empty;
        //private string i_Functionalarea = string.Empty;
        //private int i_Photo = int.MinValue;
        //private string i_HighestDegree = string.Empty;
        //private int i_PassingYear = int.MinValue;
        //private string i_University = string.Empty;
        //private string i_DisplayName = string.Empty;
        //private string i_AdditionalNotes = string.Empty;
        //private string i_Specialization = string.Empty;
        //private string i_InstituteName = string.Empty;
        //private int i_SplPasingYear = int.MinValue;
        //private string i_Occupation = string.Empty;
        //private string i_Company = string.Empty;
        //private string i_Designation = string.Empty;
        //private string i_Description = string.Empty;
        //private string i_WorkingFrom = string.Empty;
        //private string i_WorkingTo = string.Empty;
        //private string i_Countryprecmy = string.Empty;
        //private string i_PostalCode = string.Empty;
        //private string i_ProjectName = string.Empty;
        //private string i_ClientName = string.Empty;
        //private string i_Skills = string.Empty;
        //private string i_Location = string.Empty;
        //private string i_DurationFrom = string.Empty;
        //private string i_DurationTo = string.Empty;
        //private string Company = string.Empty;
        //private string Designation = string.Empty;
        //private string Description = string.Empty;
        //private string CompanyEmail = string.Empty;
        //private DateTime i_WorkingFrom = DateTime.MinValue;
        //private DateTime i_WorkingTo = DateTime.MinValue;
        //private string i_ResumeID = string.Empty;
        //private string i_ONETSOCCode = string.Empty;
        //private string i_Title = string.Empty;
        //private string i_IndustryName = string.Empty;
        //private string i_pastcompnyname = string.Empty;
        //private string i_CompanyURL = string.Empty;
        //private string i_ProfessionalExp = string.Empty;

        public string UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public string FirstName
        {
            get
            {
                return i_FirstName;
            }
            set
            {
                this.i_FirstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return i_LastName;
            }
            set
            {
                this.i_LastName = value;
            }
        }
        public string EmailID
        {
            get
            {
                return i_EmailID;
            }
            set
            {
                this.i_EmailID = value;
            }
        }
        public string DateOfBirth
        {
            get
            {
                return i_DateOfBirth;
            }
            set
            {
                this.i_DateOfBirth = value;
            }
        }
        public string Phone
        {
            get
            {
                return i_Phone;
            }
            set
            {
                this.i_Phone = value;
            }
        }
        public string City
        {
            get
            {
                return i_City;
            }
            set
            {
                this.i_City = value;
            }
        }
        public string State
        {
            get
            {
                return i_State;
            }
            set
            {
                this.i_State = value;
            }
        }
        public string PostalCode
        {
            get
            {
                return i_PostalCode;
            }
            set
            {
                this.i_PostalCode = value;
            }
        }
        public string Country
        {
            get
            {
                return i_Country;
            }
            set
            {
                this.i_Country = value;
            }
        }
        public string Sex
        {
            get
            {
                return i_Sex;
            }
            set
            {
                this.i_Sex = value;
            }
        }
        public string RoleIndustry
        {
            get
            {
                return i_RoleIndustry;
            }
            set
            {
                this.i_RoleIndustry = value;
            }
        }
        public string KeySkills
        {
            get
            {
                return i_KeySkills;
            }
            set
            {
                this.i_KeySkills = value;
            }
        }
        public string AnnualSalary
        {
            get
            {
                return i_AnnualSalary;
            }
            set
            {
                this.i_AnnualSalary = value;
            }
        }
        public string SalaryCurrency
        {
            get
            {
                return i_SalaryCurrency;
            }
            set
            {
                this.i_SalaryCurrency = value;
            }
        }
        public string TotalExperience
        {
            get
            {
                return i_TotalExperience;
            }
            set
            {
                this.i_TotalExperience = value;
            }
        }
        public Boolean Deleted
        {
            get
            {
                return i_Deleted;
            }
            set
            {
                this.i_Deleted = value;
            }
        }
        public string MaritalStatus
        {
            get
            {
                return i_MaritalStatus;
            }
            set
            {
                this.i_MaritalStatus = value;
            }
        }
        public Boolean DrivingLicence
        {
            get
            {
                return i_DrivingLicence;
            }
            set
            {
                this.i_DrivingLicence = value;
            }
        }
//        public string Professionaltitle
//        {
//            get
//            {
//                return i_Professionaltitle;
//            }
//            set
//            {
//                this.i_Professionaltitle = value;
//            }
//        }
//        public string Functionalarea
//        {
//            get
//            {
//                return i_Functionalarea;
//            }
//            set
//            {
//                this.i_Functionalarea = value;
//            }
//        }
       
//        public string DisplayName
//        {
//            get
//            {
//                return i_DisplayName;
//            }
//            set
//            {
//                this.i_DisplayName = value;
//            }
//        }
        
       
        
//        public string Postalcode
//        {
//            get
//            {
//                return i_Postalcode;
//            }
//            set
//            {
//                this.i_Postalcode = value;
//            }
//        }
//        public string dateofbirth
//        {
//            get
//            {
//                return i_dateofbirth;
//            }
//            set
//            {
//                this.i_dateofbirth = value;
//            }
//        }
//        public int Photo
//        {
//            get
//            {
//                return i_Photo;
//            }
//            set
//            {
//                this.i_Photo = value;
//            }
//        }
//        public string HighestDegree
//        {
//            get
//            {
//                return i_HighestDegree;
//            }
//            set
//            {
//                this.i_HighestDegree = value;
//            }
//        }

//        public int PassingYear
//        {
//            get
//            {
//                return i_PassingYear;
//            }
//            set
//            {
//                this.i_PassingYear = value;
//            }
//        }
//        public string University
//        {
//            get
//            {
//                return i_University;
//            }
//            set
//            {
//                this.i_University = value;
//            }
//        }

//        public string InstituteName
//        {
//            get
//            {
//                return i_InstituteName;
//            }
//            set
//            {
//                this.i_InstituteName = value;
//            }
//        }
//        public string AdditionalNotes
//        {
//            get
//            {
//                return i_AdditionalNotes;
//            }
//            set
//            {
//                this.i_AdditionalNotes = value;
//            }
//        }
//        public string Specialization
//        {
//            get
//            {
//                return i_Specialization;
//            }
//            set
//            {
//                this.i_Specialization = value;
//            }
//        }
//        public int SplPasingYear
//        {
//            get
//            {
//                return i_SplPasingYear;
//            }
//            set
//            {
//                this.i_SplPasingYear = value;
//            }
//        }


//        public string Occupation
//        {
//            get
//            {
//                return i_Occupation;
//            }
//            set
//            {
//                this.i_Occupation = value;
//            }
//        }
//        public string Company
//        {
//            get
//            {
//                return i_Company;
//            }
//            set
//            {
//                this.i_Company = value;
//            }
//        }
//        public string Designation
//        {
//            get
//            {
//                return i_Designation;
//            }
//            set
//            {
//                this.i_Designation = value;
//            }
//        }
//        public string Description
//        {
//            get
//            {
//                return i_Description;
//            }
//            set
//            {
//                this.i_Description = value;
//            }
//        }
//        public string WorkingFrom
//        {
//            get
//            {
//                return i_WorkingFrom;
//            }
//            set
//            {
//                this.i_WorkingFrom = value;
//            }
//        }

//        public string WorkingTo
//        {
//            get
//            {
//                return i_WorkingTo;
//            }
//            set
//            {
//                this.i_WorkingTo = value;
//            }
//        }
//        public string Countryprecmy
//        {
//            get
//            {
//                return i_Countryprecmy;
//            }
//            set
//            {
//                this.i_Countryprecmy = value;
//            }
//        }
//        public string PostalCode
//        {
//            get
//            {
//                return i_PostalCode;
//            }
//            set
//            {
//                this.i_PostalCode = value;
//            }
//        }
//        public string ProjectName
//        {
//            get
//            {
//                return i_ProjectName;
//            }
//            set
//            {
//                this.i_ProjectName = value;
//            }
//        }
//        public string ClientName
//        {
//            get
//            {
//                return i_ClientName;
//            }
//            set
//            {
//                this.i_ClientName = value;
//            }
//        }
       
//        public string Location
//        {
//            get
//            {
//                return i_Location;
//            }
//            set
//            {
//                this.i_Location = value;
//            }
//        }

//        public string DurationFrom
//        {
//            get
//            {
//                return i_DurationFrom;
//            }
//            set
//            {
//                this.i_DurationFrom = value;
//            }
//        }
//        public string DurationTo
//        {
//            get
//            {
//                return i_DurationTo;
//            }
//            set
//            {
//                this.i_DurationTo = value;
//            }
//        }
//        //public string Company
//        //{
//        //    get
//        //    {
//        //        return i_Company;
//        //    }
//        //    set
//        //    {
//        //        this.i_Company = value;
//        //    }
//        //}
//        //public string Description
//        //{
//        //    get
//        //    {
//        //        return i_Description;
//        //    }
//        //    set
//        //    {
//        //        this.i_Description = value;
//        //    }
//        //}
//        //public string Designation
//        //{
//        //    get
//        //    {
//        //        return i_Designation;
//        //    }
//        //    set
//        //    {
//        //        this.i_Designation = value;
//        //    }
//        //}
//        //public string CompanyEmail
//        //{
//        //    get
//        //    {
//        //        return i_CompanyEmail;
//        //    }
//        //    set
//        //    {
//        //        this.i_CompanyEmail = value;
//        //    }
//        //}
//        //public DateTime WorkingFrom
//        //{
//        //    get
//        //    {
//        //        return i_WorkingFrom;
//        //    }
//        //    set
//        //    {
//        //        this.i_WorkingFrom = DateTime.MinValue;
//        //    }
//        //}

//        //public DateTime WorkingTo
//        //{
//        //    get
//        //    {
//        //        return i_WorkingTo;
//        //    }
//        //    set
//        //    {
//        //        this.i_WorkingTo = DateTime.MinValue;
//        //    }
//        //}


//        public string RoleIndustry
//        {
//            get
//            {
//                return i_RoleIndustry;
//            }
//            set
//            {
//                this.i_RoleIndustry = value;
//            }
//        }
//        public string AnnualSalary
//        {
//            get
//            {
//                return i_AnnualSalary;
//            }
//            set
//            {
//                this.i_AnnualSalary = value;
//            }
//        }
//        public string KeySkills
//        {
//            get
//            {
//                return i_KeySkills;
//            }
//            set
//            {
//                this.i_KeySkills = value;
//            }
//        }

//        public string SalaryCurrency
//        {
//            get
//            {
//                return i_SalaryCurrency;
//            }
//            set
//            {
//                this.i_SalaryCurrency = value;
//            }
//        }
//        public string TotalExperience
//        {
//            get
//            {
//                return i_TotalExperience;
//            }
//            set
//            {
//                this.i_TotalExperience = value;
//            }
//        }
//        public string ResumeID
//        {
//            get
//            {
//                return i_ResumeID;
//            }
//            set
//            {
//                this.i_ResumeID = value;
//            }
//        }

//        public string ONETSOCCode
//        {
//            get
//            {
//                return i_ONETSOCCode;
//            }
//            set
//            {
//                this.i_ONETSOCCode = value;
//            }
//        }
//        public string Title
//        {
//            get
//            {
//                return i_Title;
//            }
//            set
//            {
//                this.i_Title = value;
//            }
//        }
//        //public string IndustryName 
//        //{
//        //    get
//        //    {
//        //        return i_IndustryName;
//        //    }
//        //    set
//        //    {
//        //        this.i_IndustryName = value;
//        //    }
//        //}


//        public string pastcompnyname
//        {
//            get
//            {
//                return i_pastcompnyname;
//            }
//            set
//            {
//                this.i_pastcompnyname = value;
//            }
//        }
//        public string CompanyURL
//        {
//            get
//            {
//                return i_CompanyURL;
//            }
//            set
//            {
//                this.i_CompanyURL = value;
//            }
//        }
//        public string ProfessionalExp
//        {
//            get
//            {
//                return i_ProfessionalExp
//;
//            }
//            set
//            {
//                this.i_ProfessionalExp = value;
//            }
//        }

        //public int IndustryID
        //{
        //    get
        //    {
        //        return i_IndustryID;
        //    }
        //    set
        //    {
        //        this.i_IndustryID = value;
        //    }
        //}
    }

}

