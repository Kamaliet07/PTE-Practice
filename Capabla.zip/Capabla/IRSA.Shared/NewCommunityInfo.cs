﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class NewCommunityInfo
    {
       private string i_CommunityName = string.Empty;
       private string i_CommunityLogo = string.Empty;
       private string i_CommunityType = string.Empty;
       private string i_FunctionalDomain = string.Empty;
       private string i_ShortDescription = string.Empty;
       private string i_DetailDescription = string.Empty;
       private string i_WebSiteURL = string.Empty;
       private string i_CommunityOwnerName = string.Empty;
       private string i_CommunityOwnerEmail = string.Empty;
       private bool i_CommunityDirectoryDisplay = false;
       private bool i_CommunityLogoDisplay = false;
       private bool i_CommunityOwnerApproval = false;
       private bool i_Status = false;

       public bool Status
       {
           get
           {
               return i_Status;
           }
           set
           {
               this.i_Status = value;
           }
       }
       public bool CommunityDirectoryDisplay
       {
           get
           {
               return i_CommunityDirectoryDisplay;
           }
           set
           {
               this.i_CommunityDirectoryDisplay = value;
           }
       }

       public bool CommunityOwnerApproval
       {
           get
           {
               return i_CommunityOwnerApproval;
           }
           set
           {
               this.i_CommunityOwnerApproval = value;
           }
       }
       public bool CommunityLogoDisplay
       {
           get
           {
               return i_CommunityLogoDisplay;
           }
           set
           {
               this.i_CommunityLogoDisplay = value;
           }
       }
       public string CommunityName
       {
           get
           {
               return i_CommunityName;
           }
           set
           {
               this.i_CommunityName = value;
           }
       }
       public string CommunityLogo
       {
           get
           {
               return i_CommunityLogo;
           }
           set
           {
               this.i_CommunityLogo = value;
           }
       }
       public string CommunityType
       {
           get
           {
               return i_CommunityType;
           }
           set
           {
               this.i_CommunityType = value;
           }
       }
       public string FunctionalDomain
       {
           get
           {
               return i_FunctionalDomain;
           }
           set
           {
               this.i_FunctionalDomain = value;
           }
       }
       public string ShortDescription
       {
           get
           {
               return i_ShortDescription;
           }
           set
           {
               this.i_ShortDescription = value;
           }
       }
       public string DetailDescription
       {
           get
           {
               return i_DetailDescription;
           }
           set
           {
               this.i_DetailDescription = value;
           }
       }
       public string WebSiteURL
       {
           get
           {
               return i_WebSiteURL;
           }
           set
           {
               this.i_WebSiteURL = value;
           }
       }
       public string CommunityOwnerName
       {
           get
           {
               return i_CommunityOwnerName;
           }
           set
           {
               this.i_CommunityOwnerName = value;
           }
       }
       public string CommunityOwnerEmail
       {
           get
           {
               return i_CommunityOwnerEmail;
           }
           set
           {
               this.i_CommunityOwnerEmail = value;
           }
       }


    }
}
