﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class EventInterfaceSH
    {
        private string i_City = string.Empty;
        private string i_Country = string.Empty; 
        private string i_Title = string.Empty;
        private string i_Description = string.Empty;
        private string i_StartDate = string.Empty;
        private string i_EndDate = string.Empty;
        private string i_Url = string.Empty;

        public string Title
        {
            get
            {
                return i_Title;
            }
            set
            {
                this.i_Title = value;
            }
        }
        public string City
        {
            get
            {
                return i_City;
            }
            set
            {
                this.i_City = value;
            }
        }
        public string Country
        {
            get
            {
                return i_Country;
            }
            set
            {
                this.i_Country = value;
            }
        }
        public string Description
        {
            get
            {
                return i_Description;
            }
            set
            {
                this.i_Description = value;
            }
        }
        public string StartDate
        {
            get
            {
                return i_StartDate;
            }
            set
            {
                this.i_StartDate = value;
            }
        }
        public string EndDate
        {
            get
            {
                return i_EndDate;
            }
            set
            {
                this.i_EndDate = value;
            }
        }
        public string Url
        {
            get
            {
                return i_Url;
            }
            set
            {
                this.i_Url = value;
            }
        }
    }
}
