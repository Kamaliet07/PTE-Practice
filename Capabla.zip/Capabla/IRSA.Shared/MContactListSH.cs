﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class MContactListSH
    {
       private int i_UserID = int.MinValue;
       private string i_FullName = string.Empty;
       private string i_ProfessionalTitle = string.Empty;
       private string i_EmailID = string.Empty;
       private string i_Phone = string.Empty;
       private string i_Company = string.Empty;

       public int UserID
       {
           get
           {
               return i_UserID;
           }
           set
           {
               this.i_UserID = value;
           }
       }
       public string FullName
       {
           get
           {
               return i_FullName;
           }
           set
           {
               this.i_FullName = value;
           }
       }
       public string ProfessionalTitle
       {
           get
           {
               return i_ProfessionalTitle;
           }
           set
           {
               this.i_ProfessionalTitle = value;
           }
       }
       public string EmailID
       {
           get
           {
               return i_EmailID;
           }
           set
           {
               this.i_EmailID = value;
           }
       }
       public string Phone
       {
           get
           {
               return i_Phone;
           }
           set
           {
               this.i_Phone = value;
           }
       }
       public string Company
       {
           get
           {
               return i_Company;
           }
           set
           {
               this.i_Company = value;
           }
       }
    }
}
