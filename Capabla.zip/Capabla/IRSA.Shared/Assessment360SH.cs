﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
  public class Assessment360SH
  {
      private string i_QuestionnaireTemplate = string.Empty;
      private string i_ElementID = string.Empty;
      private string i_ScaleID = string.Empty;
      private string i_DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
      private double i_DataValue = double.Epsilon;
      private string i_Status = string.Empty;
      private string i_OccupationID = string.Empty;
      private int i_IndustryID = int.MinValue;
      private string i_WhoIs = string.Empty;
      private string i_Name = string.Empty;
      private string i_EmailID = string.Empty;
      private string i_SubmitStatus = string.Empty;
      private string i_InvitationStatus = string.Empty;
      private string i_DateofSendingInvitation = System.DateTime.Now.ToString("dd/MMM/yyyy");
      private string i_DateofAcceptingInvitation = string.Empty;
      private string i_Message = string.Empty;
      private int i_AttemptID = int.MinValue;
      

      public string QuestionnaireTemplate
      {
          get
          {
              return i_QuestionnaireTemplate;
          }
          set
          {
              this.i_QuestionnaireTemplate = value;
          }
      }

      public string ElementID
      {
          get
          {
              return i_ElementID;
          }
          set
          {
              this.i_ElementID = value;
          }
      }

      public string ScaleID
      {
          get
          {
              return i_ScaleID;
          }
          set
          {
              this.i_ScaleID = value;
          }
      }

      public string DateofSubmit
      {
          get
          {
              return i_DateofSubmit;
          }
          set
          {
              this.i_DateofSubmit = value;
          }
      }


      public double DataValue
      {
          get
          {
              return i_DataValue;
          }
          set
          {
              this.i_DataValue = value;
          }
      }

      public string Status
      {
          get
          {
              return i_Status;
          }
          set
          {
              this.i_Status = value;
          }
      }
      public string OccupationID
      {
          get
          {
              return i_OccupationID;
          }
          set
          {
              this.i_OccupationID = value;
          }
      }
      public int IndustryID
      {
          get
          {
              return i_IndustryID;
          }
          set
          {
              this.i_IndustryID = value;
          }
      }
      public string WhoIs
      {
          get
          {
              return i_WhoIs;
          }
          set
          {
              this.i_WhoIs = value;
          }
      }
      public string Name
      {
          get
          {
              return i_Name;
          }
          set
          {
              this.i_Name = value;
          }
      }
      public string EmailID
      {
          get
          {
              return i_EmailID;
          }
          set
          {
              this.i_EmailID = value;
          }
      }
      public string SubmitStatus
      {
          get
          {
              return i_SubmitStatus;
          }
          set
          {
              this.i_SubmitStatus = value;
          }
      }
      public string InvitationStatus
      {
          get
          {
              return i_InvitationStatus;
          }
          set
          {
              this.i_InvitationStatus = value;
          }
      }
      public string DateofSendingInvitation
      {
          get
          {
              return i_DateofSendingInvitation;
          }
          set
          {
              this.i_DateofSendingInvitation = value;
          }
      }
      public string DateofAcceptingInvitation
      {
          get
          {
              return i_DateofAcceptingInvitation;
          }
          set
          {
              this.i_DateofAcceptingInvitation = value;
          }
      }
      public string Message
      {
          get
          {
              return i_Message;
          }
          set
          {
              this.i_Message = value;
          }
      }
      public int AttemptID
      {
          get
          {
              return i_AttemptID;
          }
          set
          {
              this.i_AttemptID = value;
          }
      }
  }
}
