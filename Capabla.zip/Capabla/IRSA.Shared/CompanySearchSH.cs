﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
  public  class CompanySearchSH
  {
      public string i_CompanyName = string.Empty;
      public string i_City = string.Empty;
      public string i_CountryName = string.Empty;
      public string i_IndustryName = string.Empty;
      public string i_CompanyURL = string.Empty;
      public string i_Type = string.Empty;

      public string CompanyName
      {
          get
          {
              return i_CompanyName;
          }
          set
          {
              this.i_CompanyName = value;
          }
      }
      
      public string City
      {
          get
          {
              return i_City;
          }
          set
          {
              this.i_City = value;
          }
      }
      public string CountryName
      {
          get
          {
              return i_CountryName;
          }
          set
          {
              this.i_CountryName = value;
          }
      }
      
          public string IndustryName
      {
          get
          {
              return i_IndustryName;
          }
          set
          {
              this.i_IndustryName = value;
          }
      }
          public string CompanyURL
          {
              get
              {
                  return i_CompanyURL;
              }
              set
              {
                  this.i_CompanyURL = value;
              }
          }
          public string Type
          {
              get
              {
                  return i_Type;
              }
              set
              {
                  this.i_Type = value;
              }
          }
      
      }

    }

