﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class EmailSendingInterfaceSH
    {
        private int i_InboxID = int.MinValue;
        private string i_UserName = string.Empty;
        private string i_Subject = string.Empty;
        private string i_Description = string.Empty;
        private string i_RecieverName = string.Empty;
        private string i_Status = string.Empty;
        private string i_SentDate = System.DateTime.Now.ToString("dd/MMM/yyyy");




        public int InboxID
        {
            get
            {
                return i_InboxID;
            }
            set
            {
                this.i_InboxID = value;
            }
        }

        public string UserName
        {
            get
            {
                return i_UserName;
            }
            set
            {
                this.i_UserName = value;
            }
        }
        public string Subject
        {
            get
            {
                return i_Subject;
            }
            set
            {
                this.i_Subject = value;
            }
        }
        public string Description
        {
            get
            {
                return i_Description;
            }
            set
            {
                this.i_Description = value;
            }
        }
        public string RecieverName
        {
            get
            {
                return i_RecieverName;
            }
            set
            {
                this.i_RecieverName = value;
            }
        }
        public string Status
        {
            get
            {
                return i_Status;
            }
            set
            {
                this.i_Status = value;
            }
        }
        public string SentDate
        {
            get
            {
                return i_SentDate;
            }
            set
            {
                this.i_SentDate = value;
            }
        }
    }
}
        

