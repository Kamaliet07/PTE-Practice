﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
  public  class ListSh
    {


        private string i_Task = string.Empty;
        private string i_Description = string.Empty;
        private int i_TaskID = int.MinValue;
        private string i_Date = string.Empty;
        private string i_Time = string.Empty;
        private string i_Days = string.Empty;
        private string i_Stampdate = string.Empty;
        private string i_Final = string.Empty;



        public string Task
        {
            get
            {
                return i_Task;
            }
            set
            {
                this.i_Task = value;
            }
        }
        public string Description
        {
            get
            {
                return i_Description;
            }
            set
            {
                this.i_Description = value;
            }
        }
        public string Date
        {
            get
            {
                return i_Date;
            }
            set
            {
                this.i_Date = value;
            }
        }
        public string Time
        {
            get
            {
                return i_Time;
            }
            set
            {
                this.i_Time = value;
            }
        }
        public string Days
        {
            get
            {
                return i_Days;
            }
            set
            {
                this.i_Days = value;
            }
        }
        public string Stampdate
        {
            get
            {
                return i_Stampdate;
            }
            set
            {
                this.i_Stampdate = value;
            }
        }
        public int TaskID
        {
            get
            {
                return i_TaskID;
            }
            set
            {
                this.i_TaskID = value;
            }
        }
        public string Final
        {
            get
            {
                return i_Final;
            }
            set
            {
                this.i_Final = value;
            }
        }
    }
}
