﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class ForgotPasswordSH
    {
        private string i_UserName = string.Empty;
        private string i_Password = string.Empty;
        
        public string UserName
        {
            get
            {
                return i_UserName;
            }
            set
            {
                this.i_UserName = value;
            }
        }

        public string Password
        {
            get
            {
                return i_Password;
            }
            set
            {
                this.i_Password = value;
            }
        }
            
    }
}
