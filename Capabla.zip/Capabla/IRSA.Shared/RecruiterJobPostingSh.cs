﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class RecruiterJobPostingSh
    {
        private string i_From = string.Empty;
        private string i_To = string.Empty;
        private string i_Title = string.Empty;

        public string From
        {
            get
            {
                return i_From;
            }
            set
            {
                this.i_From = value;
            }
        }
        public string To
        {
            get
            {
                return i_To;
            }
            set
            {
                this.i_To = value;
            }
        }
        public string Title
        {
            get
            {
                return i_Title;
            }
            set
            {
                this.i_Title = value;
            }
        }
    }
}
