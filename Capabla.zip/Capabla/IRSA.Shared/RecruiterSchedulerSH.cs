﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class RecruiterSchedulerSH
    {
        private int i_ID = int.MinValue;
        private string i_Subject = string.Empty;
        private string i_Start = System.DateTime.Now.ToString();
        private string i_End = System.DateTime.Now.ToString();
        private string i_TypeOfWork = string.Empty;
        private int i_RecuriterID = int.MinValue;
        private int i_UserID = 0;
        private int i_JobID = 0;
        private string i_Vennue = string.Empty;
        private string i_Date = System.DateTime.Now.ToString("dd/MMM/yyyy");
        private string i_Time = string.Empty;
        private string i_Status = string.Empty;

        public int JobID
        {
            get
            {
                return i_JobID;
            }
            set
            {
                this.i_JobID = value;
            }
        }
        public int UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public int ID
        {
            get
            {
                return i_ID;
            }
            set
            {
                this.i_ID = value;
            }
        }
        public string Subject
        {
            get
            {
                return i_Subject;
            }
            set
            {
                this.i_Subject = value;
            }
        }
        public string Start
        {
            get
            {
                return i_Start;
            }
            set
            {
                this.i_Start = value;
            }
        }
        public string End
        {
            get
            {
                return i_End;
            }
            set
            {
                this.i_End = value;
            }
        }
        public string TypeOfWork
        {
            get
            {
                return i_TypeOfWork;
            }
            set
            {
                this.i_TypeOfWork = value;
            }
        }
        public string Vennue
        {
            get
            {
                return i_Vennue;
            }
            set
            {
                this.i_Vennue = value;
            }
        }
        public string Time
        {
            get
            {
                return i_Time;
            }
            set
            {
                this.i_Time = value;
            }
        }
        public string Date
        {
            get
            {
                return i_Date;
            }
            set
            {
                this.i_Date = value;
            }
        }
        public string Status
        {
            get
            {
                return i_Status;
            }
            set
            {
                this.i_Status = value;
            }
        }
    }
}
