﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
  public  class MyDocumentsSH
    {


      private string i_FileName = string.Empty;
        private string i_imagetype = string.Empty;
        private string i_FileDate = System.DateTime.Now.ToString("dd/MMM/yyyy");
        private string i_ReName = string.Empty;



        public string FileName
        {
            get
            {
                return i_FileName;
            }
            set
            {
                this.i_FileName = value;
            }
        }
        public string imagetype
        {
            get
            {
                return i_imagetype;
            }
            set
            {
                this.i_imagetype = value;
            }
        }
        public string FileDate
        {
            get
            {
                return i_FileDate;
            }
            set
            {
                
                this.i_FileDate = value;
            }

        }
        public string ReName
        {
            get
            {
                return i_ReName;
            }
            set
            {
                this.i_ReName = value;
            }
        }

    }
    }

