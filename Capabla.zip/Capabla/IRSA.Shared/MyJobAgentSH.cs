﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class MyJobAgentSH
    {
        //Declaring Data Members
        private int i_UserID = int.MinValue;
        private string i_AgentName = string.Empty;
        private string i_KeyWord = string.Empty;
        private Boolean i_Location = false;
        private string i_Country = string.Empty;
        private string i_City = string.Empty;
        private int i_Experience = int.MinValue;
        private string i_JobFamilyID = string.Empty;
        private string i_JobType = string.Empty;
        private string i_OccupationID=string.Empty;
        private Boolean i_UpdateOnMobile = true;
        private Boolean i_UpdateOnEmail = true;
        private int i_JobAlertNoMobile = int.MinValue;
        private int i_JobAlertNoEmail = int.MinValue;
        private string i_FrequencyEmail = string.Empty;
        private string i_FrequencyMobile = string.Empty;
        private string i_PostedEmail = string.Empty;
        private string i_PostedMobile = string.Empty;
        private string i_PayCurrency = string.Empty;
        private double i_PreferredSalary = double.MinValue;
        private string i_AvailabilityFrom = string.Empty;
        private string i_AvailabilityTo = string.Empty;
        private Boolean i_Deleted = false;
        //private int i_LocationWeight = int.MinValue;
        //private int i_ExpWeight = int.MinValue;
        //private int i_SalaryWeight = int.MinValue;
        //private int i_AvailabilityWeight = int.MinValue;
        private string i_CreateDate;


        //Declaring Member Functions
        public int UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public string AgentName
        {
            get
            {
                return i_AgentName;
            }
            set
            {
                this.i_AgentName = value;
            }
        }
        public string KeyWord
        {
            get
            {
                return i_KeyWord;
            }
            set
            {
                this.i_KeyWord = value;
            }
        }
        public Boolean Location
        {
            get
            {
                return i_Location;
            }
            set
            {
                this.i_Location = value;
            }
        }
        public String Country
        {
            get
            {
                return i_Country;
            }
            set
            {
                this.i_Country = value;
            }
        }
        public string City
        {
            get
            {
                return i_City;
            }
            set
            {
                this.i_City = value;
            }
        }
        public int Experience
        {
            get
            {
                return i_Experience;
            }
            set
            {
                this.i_Experience = value;
            }
        }
        public string JobFamilyID
        {
            get
            {
                return i_JobFamilyID;
            }
            set
            {
                this.i_JobFamilyID = value;
            }
        }
        public string JobType
        {
            get
            {
                return i_JobType;
            }
            set
            {
                this.i_JobType = value;
            }
        }
        public string OccupationID
        {
            get
            {
                return i_OccupationID;
            }
            set
            {
                this.i_OccupationID = value;
            }
        }
        public Boolean UpdateOnMobile
        {
            get
            {
                return i_UpdateOnMobile;
            }
            set
            {
                this.i_UpdateOnMobile = value;
            }
        }
        public Boolean UpdateOnEmail
        {
            get
            {
                return i_UpdateOnEmail;
            }
            set
            {
                this.i_UpdateOnEmail = value;
            }
        }
        public int JobAlertNoMobile
        {
            get
            {
                return i_JobAlertNoMobile;
            }
            set
            {
                this.i_JobAlertNoMobile = value;
            }
        }
        public int JobAlertNoEmail
        {
            get
            {
                return i_JobAlertNoEmail;
            }
            set
            {
                this.i_JobAlertNoEmail = value;
            }
        }
        public string FrequencyEmail
        {
            get
            {
                return i_FrequencyEmail;
            }
            set
            {
                this.i_FrequencyEmail = value;
            }
        }
        public string FrequencyMobile
        {
            get
            {
                return i_FrequencyMobile;
            }
            set
            {
                this.i_FrequencyMobile = value;
            }
        }
        public string PostedEmail
        {
            get
            {
                return i_PostedEmail;
            }
            set
            {
                this.i_PostedEmail = value;
            }
        }
        public string PostedMobile
        {
            get
            {
                return i_PostedMobile;
            }
            set
            {
                this.i_PostedMobile = value;
            }
        }
        public string PayCurrency
        {
            get
            {
                return i_PayCurrency;
            }
            set
            {
                this.i_PayCurrency = value;
            }
        }
        public double PreferredSalary
        {
            get
            {
                return i_PreferredSalary;
            }
            set
            {
                this.i_PreferredSalary = value;
            }
        }
       public string AvailabilityFrom
        {
            get
            {
                return i_AvailabilityFrom;
            }
            set
            {
                this.i_AvailabilityFrom = value;
            }
        }
        public string AvailabilityTo
        {
            get
            {
                return i_AvailabilityTo;
            }
            set
            {
                this.i_AvailabilityTo = value;
            }
        }
        public Boolean Deleted
        {
            get
            {
                return i_Deleted;
            }
            set
            {
                this.i_Deleted = value;
            }
        }
    
        public string CreateDate
        {
            get
            {
                return i_CreateDate;
            }
            set
            {
                this.i_CreateDate = value;
            }
        }
    }
}
