﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace IRSA.Shared
{
    public class LoginSH
    {


        public string i_UserID = string.Empty;
        public string i_Password = string.Empty;
        public string i_EmailID = string.Empty;



        public string UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }

        public string Password
        {
            get
            {
                return i_Password;
            }
            set
            {
                this.i_Password = value;
            }
        }
        public string EmailID
        {
            get
            {
                return i_EmailID;
            }
            set
            {
                this.i_EmailID = value;
            }
        }


    }
}

