﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class JobSearchSH
   {
       public string i_Title = string.Empty;
       public string i_JobDescription = string.Empty;
       public string i_KeyWord = string.Empty;
       public string i_Skills = string.Empty;
       public string i_CountryName = string.Empty;
       public string i_CompanyName = string.Empty;
       public string i_City = string.Empty;
       public string i_IndustryName = string.Empty;

       public string Title
       {
           get
           {
               return i_Title;
           }
           set
           {
               this.i_Title = value;
           }
       }
       public string JobDescription
       {
           get
           {
               return i_JobDescription;
           }
           set
           {
               this.i_JobDescription = value;
           }
       }
       public string KeyWord
       {
           get
           {
               return i_KeyWord;
           }
           set
           {
               this.i_KeyWord = value;
           }
       }
           public string Skills
          {
           get
           {
               return i_Skills;
           }
           set
           {
               this.i_Skills = value;
           }
        }
               public string CountryName
           {
           get
           {
               return i_CountryName;
           }
           set
           {
               this.i_CountryName = value;
           }

       }
        public string City
           {
           get
           {
               return i_City;
           }
           set
           {
               this.i_City = value;
           }
       }
        public string IndustryName
        {
            get
            {
                return i_IndustryName;
            }
            set
            {
                this.i_IndustryName = value;
            }
        }
       }










    }

