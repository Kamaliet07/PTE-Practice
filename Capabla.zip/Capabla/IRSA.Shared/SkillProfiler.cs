﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public  class SkillProfiler
     {
        private int i_SkillProfileID = int.MinValue;
        private string i_SkillProfileName = string.Empty;
        private string i_ONETSOCCode = string.Empty;
        private string i_ElementID = string.Empty;
        private string i_Option = string.Empty;
        private string i_SkillID = string.Empty;
        private int i_datavalue = int.MinValue;
        private int i_UserID = int.MinValue;
        private string i_CultureID = string.Empty;
        private string i_QuestionaireTemplateName = string.Empty;
        private string i_ScaleID = string.Empty;
        private DateTime i_CreateDate = DateTime.MinValue;
        private DateTime i_ModifyDate = DateTime.MinValue;
        private Boolean i_Deleted = false;

        
        public int SkillProfileID
        {
            get
            {
                return i_SkillProfileID;
            }
            set
            {
                this.i_SkillProfileID = value;
            }
        }

        public string SkillProfileName
        {
            get
            {
                return i_SkillProfileName;
            }
            set
            {
                this.i_SkillProfileName = value;
            }
        }

        public string Option
        {
            get
            {
                return i_Option;
            }
            set
            {
                this.i_Option = value;
            }
        }

        public string ONETSOCCode
        {
            get
            {
                return i_ONETSOCCode;
            }
            set
            {
                this.i_ONETSOCCode = value;
            }
        }
        public string ElementID
        {
            get
            {
                return i_ElementID;
            }
            set
            {
                this.i_ElementID = value;
            }
        }
        public string SkillID
        {
            get
            {
                return i_SkillID;
            }
            set
            {
                this.i_SkillID = value;
            }
        }
        public int UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public int datavalue
        {
            get
            {
                return i_datavalue;
            }
            set
            {
                this.i_datavalue = value;
            }
        }
         public string CultureID
        {
            get
            {
                return i_CultureID;
            }
            set
            {
                this.i_CultureID = value;
            }
        }

         public string QuestionaireTemplateName
         {
             get
             {
                 return i_QuestionaireTemplateName;
             }
             set
             {
                 this.i_QuestionaireTemplateName = value;
             }
         }

         public string ScaleID
         {
             get
             {
                 return i_ScaleID;
             }
             set
             {
                 this.i_ScaleID = value;
             }
         }






         public DateTime CreateDate
         {
             get
             {
                 return i_CreateDate;
             }
             set
             {
                 this.i_CreateDate = value;
             }
         }
         public DateTime ModifyDate
         {
             get
             {
                 return i_ModifyDate;
             }
             set
             {
                 this.i_ModifyDate = value;
             }
         }

         public Boolean Deleted
                {
                get
                {
                    return i_Deleted;
                }
                set
                {
                    this.i_Deleted = value;
                }
            }


    }
}
