﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class AccountsetupSH
    {
        private string i_UserID = string.Empty;
        private string i_FirstName = string.Empty;
        private string i_Professionaltitle = string.Empty;
        private string i_Functionalarea = string.Empty;
        private string i_LastName = string.Empty;
        private string i_DisplayName = string.Empty;
        private string i_sex = string.Empty;
        private string i_Phone = string.Empty;
        private string i_City = string.Empty;
        private string i_State = string.Empty;
        private string i_Country = string.Empty;
        private string i_Postalcode = string.Empty;
        private string i_dateofbirth = string.Empty;
        private string i_Photo = string.Empty;
        private string i_HighestDegree = string.Empty;
        private int i_PassingYear = int.MinValue;
        private string i_University = string.Empty;
        private string i_AdditionalNotes = string.Empty;
        private string i_Specialization = string.Empty;
        private string i_InstituteName = string.Empty;
        private int i_SplPasingYear = int.MinValue;
        private string i_Occupation = string.Empty;
        private string i_Company = string.Empty;
        private string i_Designation = string.Empty;
        private string i_Description = string.Empty;
        private string i_WorkingFrom = string.Empty;
        private string i_WorkingTo = string.Empty;
        private string i_Countryprecmy = string.Empty;
        private string i_PostalCode = string.Empty;
        private string i_ProjectName = string.Empty;
        private string i_ClientName = string.Empty;
        private string i_Skills = string.Empty;
        private string i_Location = string.Empty;
        private string i_DurationFrom = string.Empty;
        private string i_DurationTo = string.Empty;
        //private string Company = string.Empty;
        //private string Designation = string.Empty;
        //private string Description = string.Empty;
        private string CompanyEmail = string.Empty;
        //private DateTime i_WorkingFrom = DateTime.MinValue;
        //private DateTime i_WorkingTo = DateTime.MinValue;
        private string i_OtherIndustry = string.Empty;
        private string i_KeySkills = string.Empty;
        private double i_AnnualSalary = double.Epsilon;
        private string i_SalaryCurrency = string.Empty;
        private int i_TotalExperience = 0;
        private string i_ResumeID = string.Empty;
        private string i_ONETSOCCode = string.Empty;
        private string i_Title = string.Empty;
        private string i_IndustryName = string.Empty;
        private string i_pastcompnyname = string.Empty;
        private string i_CompanyURL = string.Empty;
         private string i_ProfessionalExp = string.Empty;
         private string i_MaritalStatus = string.Empty;
         private bool i_DrivingLicence = false;
         private string i_Workpermit = string.Empty;
         private string i_VisaCountry = string.Empty;
         private string i_WPvalidFrm = string.Empty;
         private string i_WPValidTo = string.Empty;
         private string i_SecurityClearance = string.Empty;
         private string i_SCIssuingAuthority = string.Empty;
         private string i_SCDescription = string.Empty;
         private string i_SCObtained = string.Empty;
         private string i_SCValidfrm = string.Empty;
         private string i_SCValidto = string.Empty;
         private string i_AssociationName = string.Empty;
         private string i_AssociationURL = string.Empty;
         private string i_AssoSince = string.Empty;
         private string i_AssoUntil = string.Empty;
         private string i_Licensename = string.Empty;
         private string i_LicenseID = string.Empty;
         private string i_LicenseIssuedby = string.Empty;
         private string i_LicenseValidfrm = string.Empty;
         private string i_LicenseValidTo = string.Empty;
         private string i_Awards = string.Empty;
         private string i_Education = string.Empty;
         private string i_PersonalInterest = string.Empty;
         private string i_LangSkill= string.Empty;
         private bool i_CompSkill = false;
         private string i_HouseNo = string.Empty;
         private string i_Placeofbirth = string.Empty;
         private string i_Countryofbirth = string.Empty;
         private string i_Nationality = string.Empty;
         //private int i_ProfileStatus = int.MinValue;
         //private int i_ProfileStatusAccount = int.MinValue;
         //private int i_ProfileStatusExp = int.MinValue;
         private string i_SpecializationArea = string.Empty;
        public string UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public string FirstName
        {
            get
            {
                return i_FirstName;
            }
            set
            {
                this.i_FirstName = value;
            }
        }
        public string Professionaltitle
        {
            get
            {
                return i_Professionaltitle;
            }
            set
            {
                this.i_Professionaltitle = value;
            }
        }
       public string Functionalarea
        {
            get
            {
                return i_Functionalarea;
            }
            set
            {
                this.i_Functionalarea = value;
            }
        }
         public string LastName
        {
            get
            {
                return i_LastName;
            }
            set
            {
                this.i_LastName = value;
            }
        }
         public string DisplayName
         {
             get
             {
                 return i_DisplayName;
             }
             set
             {
                 this.i_DisplayName = value;
             }
         }
         public string sex
         {
             get
             {
                 return i_sex;
             }
             set
             {
                 this.i_sex = value;
             }
         }
         public string Phone
         {
             get
             {
                 return i_Phone;
             }
             set
             {
                 this.i_Phone = value;
             }
         }
        public string City
         {
             get
             {
                 return i_City;
             }
             set
             {
                 this.i_City = value;
             }
         }
        public string State
         {
             get
             {
                 return i_State;
             }
             set
             {
                 this.i_State = value;
             }
         }
        public string Country
         {
             get
             {
                 return i_Country;
             }
             set
             {
                 this.i_Country = value;
             }
         }
        public string Postalcode
         {
             get
             {
                 return i_Postalcode;
             }
             set
             {
                 this.i_Postalcode = value;
             }
         }
        public string dateofbirth
         {
             get
             {
                 return i_dateofbirth;
             }
             set
             {
                 this.i_dateofbirth = value;
             }
         }
        public string Photo
        {
            get
            {
                return i_Photo;
            }
            set
            {
                this.i_Photo = value;
            }
        }
        public string HighestDegree
        {
            get
            {
                return i_HighestDegree;
            }
            set
            {
                this.i_HighestDegree = value;
            }
        }

        public int PassingYear
        {
            get
            {
                return i_PassingYear;
            }
            set
            {
                this.i_PassingYear = value;
            }
        }
        public string University
        {
            get
            {
                return i_University;
            }
            set
            {
                this.i_University = value;
            }
        }

        public string InstituteName
        {
            get
            {
                return i_InstituteName;
            }
            set
            {
                this.i_InstituteName = value;
            }
        }
            public string AdditionalNotes
        {
            get
            {
                return i_AdditionalNotes;
            }
            set
            {
                this.i_AdditionalNotes = value;
            }
        }
        public string Specialization
        {
            get
            {
                return i_Specialization;
            }
            set
            {
                this.i_Specialization = value;
            }
        }
        public int SplPasingYear
        {
            get
            {
                return i_SplPasingYear;
            }
            set
            {
                this.i_SplPasingYear = value;
            }
        }
        

        public string Occupation
        {
            get
            {
                return i_Occupation;
            }
            set
            {
                this.i_Occupation = value;
            }
        }
        public string Company
        {
            get
            {
                return i_Company;
            }
            set
            {
                this.i_Company = value;
            }
        }
        public string Designation
        {
            get
            {
                return i_Designation;
            }
            set
            {
                this.i_Designation = value;
            }
        }
        public string Description
        {
            get
            {
                return i_Description;
            }
            set
            {
                this.i_Description = value;
            }
        }
        public string WorkingFrom
        {
            get
            {
                return i_WorkingFrom;
            }
            set
            {
                this.i_WorkingFrom = value;
            }
        }

        public string WorkingTo
        {
            get
            {
                return i_WorkingTo;
            }
            set
            {
                this.i_WorkingTo = value;
            }
        }
        public string Countryprecmy
        {
            get
            {
                return i_Countryprecmy;
            }
            set
            {
                this.i_Countryprecmy = value;
            }
        }
        public string PostalCode
        {
            get
            {
                return i_PostalCode;
            }
            set
            {
                this.i_PostalCode = value;
            }
        }
        public string ProjectName
        {
            get
            {
                return i_ProjectName;
            }
            set
            {
                this.i_ProjectName = value;
            }
        }
        public string ClientName
        {
            get
            {
                return i_ClientName;
            }
            set
            {
                this.i_ClientName = value;
            }
        }
        public string Skills
        {
            get
            {
                return i_Skills;
            }
            set
            {
                this.i_Skills = value;
            }
        }
        public string Location
        {
            get
            {
                return i_Location;
            }
            set
            {
                this.i_Location = value;
            }
        }

        public string DurationFrom
        {
            get
            {
                return i_DurationFrom;
            }
            set
            {
                this.i_DurationFrom = value;
            }
        }
        public string DurationTo
        {
            get
            {
                return i_DurationTo;
            }
            set
            {
                this.i_DurationTo = value;
            }
        }
        //public string Company
        //{
        //    get
        //    {
        //        return i_Company;
        //    }
        //    set
        //    {
        //        this.i_Company = value;
        //    }
        //}
        //public string Description
        //{
        //    get
        //    {
        //        return i_Description;
        //    }
        //    set
        //    {
        //        this.i_Description = value;
        //    }
        //}
        //public string Designation
        //{
        //    get
        //    {
        //        return i_Designation;
        //    }
        //    set
        //    {
        //        this.i_Designation = value;
        //    }
        //}
        //public string CompanyEmail
        //{
        //    get
        //    {
        //        return i_CompanyEmail;
        //    }
        //    set
        //    {
        //        this.i_CompanyEmail = value;
        //    }
        //}
        //public DateTime WorkingFrom
        //{
        //    get
        //    {
        //        return i_WorkingFrom;
        //    }
        //    set
        //    {
        //        this.i_WorkingFrom = DateTime.MinValue;
        //    }
        //}

        //public DateTime WorkingTo
        //{
        //    get
        //    {
        //        return i_WorkingTo;
        //    }
        //    set
        //    {
        //        this.i_WorkingTo = DateTime.MinValue;
        //    }
        //}


        public string OtherIndustry 
        {
            get
            {
                return i_OtherIndustry;
            }
            set
            {
                this.i_OtherIndustry = value;
            }
        }
        public double AnnualSalary
        {
            get
            {
                return i_AnnualSalary;
            }
            set
            {
                this.i_AnnualSalary = value;
            }
        }
        public string KeySkills
        {
            get
            {
                return i_KeySkills;
            }
            set
            {
                this.i_KeySkills = value;
            }
        }
        
        public string SalaryCurrency
        {
            get
            {
                return i_SalaryCurrency;
            }
            set
            {
                this.i_SalaryCurrency = value;
            }
        }
        public int TotalExperience
        {
            get
            {
                return i_TotalExperience;
            }
            set
            {
                this.i_TotalExperience = value;
            }
        }
        public string ResumeID
        {
            get
            {
                return i_ResumeID;
            }
            set
            {
                this.i_ResumeID = value;
            }
        }

        public string ONETSOCCode
        {
            get
            {
                return i_ONETSOCCode;
            }
            set
            {
                this.i_ONETSOCCode = value;
            }
        }
        public string Title
        {
            get
            {
                return i_Title;
            }
            set
            {
                this.i_Title = value;
            }
        }
        //public string IndustryName 
        //{
        //    get
        //    {
        //        return i_IndustryName;
        //    }
        //    set
        //    {
        //        this.i_IndustryName = value;
        //    }
        //}

        
        public string pastcompnyname
        {
            get
            {
                return i_pastcompnyname;
            }
            set
            {
                this.i_pastcompnyname = value;
            }
        }
        public string CompanyURL
        {
            get
            {
                return i_CompanyURL;
            }
            set
            {
                this.i_CompanyURL = value;
            }
        }
        public string ProfessionalExp

        {
            get
            {
                return i_ProfessionalExp
;
            }
            set
            {
                this.i_ProfessionalExp = value;
            }
        }
        //public int ProfileStatus
        //{
        //    get
        //    {
        //        return i_ProfileStatus;
        //    }
        //    set
        //    {
        //        this.i_ProfileStatus = value;
        //    }
        //}
        //public int ProfileStatusAccount
        //{
        //    get
        //    {
        //        return i_ProfileStatusAccount;
        //    }
        //    set
        //    {
        //        this.i_ProfileStatusAccount = value;
        //    }
        //}
        //public int ProfileStatusExp
        //{
        //    get
        //    {
        //        return i_ProfileStatusExp;
        //    }
        //    set
        //    {
        //        this.i_ProfileStatusExp = value;
        //    }
        //}
        //public int IndustryID
        //{
        //    get
        //    {
        //        return i_IndustryID;
        //    }
        //    set
        //    {
        //        this.i_IndustryID = value;
        //    }
        //}

        public string MaritalStatus
        {
            get
            {
                return i_MaritalStatus
;
            }
            set
            {
                this.i_MaritalStatus = value;
            }
        }
        public bool DrivingLicence
        {
            get
            {
                return i_DrivingLicence;

            }
            set
            {
                this.i_DrivingLicence = value;
            }
        }
        public string Workpermit
        {
            get
            {
                return i_Workpermit;

            }
            set
            {
                this.i_Workpermit = value;
            }
        }
        public string VisaCountry
        {
            get
            {
                return i_VisaCountry;

            }
            set
            {
                this.i_VisaCountry = value;
            }
        }
        public string WPvalidFrm
        {
            get
            {
                return i_WPvalidFrm;

            }
            set
            {
                this.i_WPvalidFrm = value;
            }
        }
        public string WPValidTo
        {
            get
            {
                return i_WPValidTo;

            }
            set
            {
                this.i_WPValidTo = value;
            }
        }
        public string SecurityClearance
        {
            get
            {
                return i_SecurityClearance;

            }
            set
            {
                this.i_SecurityClearance = value;
            }
        }
        public string SCIssuingAuthority
        {
            get
            {
                return i_SCIssuingAuthority;

            }
            set
            {
                this.i_SCIssuingAuthority = value;
            }
        }
        public string SCDescription
        {
            get
            {
                return i_SCDescription;

            }
            set
            {
                this.i_SCDescription = value;
            }
        }
        public string SCObtained 
        {
            get
            {
                return i_SCObtained;

            }
            set
            {
                this.i_SCObtained = value;
            }
        }
        public string SCValidfrm
        {
            get
            {
                return i_SCValidfrm;

            }
            set
            {
                this.i_SCValidfrm = value;
            }
        }

        public string SCValidto
        {
            get
            {
                return i_SCValidto;

            }
            set
            {
                this.i_SCValidto = value;
            }
        }
        public string AssociationName
        {
            get
            {
                return i_AssociationName;

            }
            set
            {
                this.i_AssociationName = value;
            }
        }
      
        public string AssociationURL
        {
            get
            {
                return i_AssociationURL;

            }
            set
            {
                this.i_AssociationURL = value;
            }
        }
        public string AssoSince
        {
            get
            {
                return i_AssoSince;

            }
            set
            {
                this.i_AssoSince = value;
            }
        }
        public string AssoUntil
        {
            get
            {
                return i_AssoUntil;

            }
            set
            {
                this.i_AssoUntil = value;
            }
        }
        public string Licensename
        {
            get
            {
                return i_Licensename;

            }
            set
            {
                this.i_Licensename = value;
            }
        }

        public string LicenseID
        {
            get
            {
                return i_LicenseID;

            }
            set
            {
                this.i_LicenseID = value;
            }
        }

        public string LicenseIssuedby
        {
            get
            {
                return i_LicenseIssuedby;

            }
            set
            {
                this.i_LicenseIssuedby = value;
            }
        }

        public string LicenseValidfrm
        {
            get
            {
                return i_LicenseValidfrm;

            }
            set
            {
                this.i_LicenseValidfrm = value;
            }
        }
        public string LicenseValidTo
        {
            get
            {
                return i_LicenseValidTo;

            }
            set
            {
                this.i_LicenseValidTo = value;
            }
        }
        public string Awards
        {
            get
            {
                return i_Awards;

            }
            set
            {
                this.i_Awards = value;
            }
        }


        public string Education
        {
            get
            {
                return i_Education;

            }
            set
            {
                this.i_Education = value;
            }
        }
       
      
      
        public string PersonalInterest
        {
            get
            {
                return i_PersonalInterest;

            }
            set
            {
                this.i_PersonalInterest = value;
            }
        }
        public string LangSkill
        {
            get
            {
                return i_LangSkill;

            }
            set
            {
                this.i_LangSkill = value;
            }
        }
        public bool CompSkill
        {
            get
            {
                return i_CompSkill;

            }
            set
            {
                this.i_CompSkill = value;
            }
        }
       
        public string HouseNo
        {
            get
            {
                return i_HouseNo;

            }
            set
            {
                this.i_HouseNo = value;
            }
        }
        public string Placeofbirth
        {
            get
            {
                return i_Placeofbirth;

            }
            set
            {
                this.i_Placeofbirth = value;
            }
        }
        public string Countryofbirth
        {
            get
            {
                return i_Countryofbirth;

            }
            set
            {
                this.i_Countryofbirth = value;
            }
        }
        public string Nationality
        {
            get
            {
                return i_Nationality;

            }
            set
            {
                this.i_Nationality = value;
            }
        }

        public string SpecializationArea
        {
            get
            {
                return i_SpecializationArea;

            }
            set
            {
                this.i_SpecializationArea = value;
            }
        }
        }
      
    }

