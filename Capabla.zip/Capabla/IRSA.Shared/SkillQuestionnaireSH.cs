﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class SkillQuestionnaireSH
    {
        private string i_QuestionnaireTemplate = string.Empty;
        private string i_ElementID = string.Empty;
        private string i_ScaleID = string.Empty;
        private string i_DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
        private double i_DataValue = double.Epsilon;
        private string i_DateSubmitted = System.DateTime.Now.ToString("dd/MMM/yyyy");
        private string i_Status = string.Empty;
        private int i_jobID = int.MinValue;
        private int i_AttemptID = int.MinValue;
        private string i_OccupationID = string.Empty;
        public string QuestionnaireTemplate
        {
            get
            {
                return i_QuestionnaireTemplate;
            }
            set
            {
                this.i_QuestionnaireTemplate = value;
            }
        }
        public string OccupationID
        {
            get
            {
                return i_OccupationID;
            }
            set
            {
                this.i_OccupationID = value;
            }
        }
        public string ElementID
        {
            get
            {
                return i_ElementID;
            }
            set
            {
                this.i_ElementID = value;
            }
        }

        public string ScaleID
        {
            get
            {
                return i_ScaleID;
            }
            set
            {
                this.i_ScaleID = value;
            }
        }

        public string DateofSubmit
        {
            get
            {
                return i_DateofSubmit;
            }
            set
            {
                this.i_DateofSubmit = value;
            }
        }


        public double DataValue
        {
            get
            {
                return i_DataValue;
            }
            set
            {
                this.i_DataValue = value;
            }
        }
        public int jobID
        {
            get
            {
                return i_jobID;
            }
            set
            {
                this.i_jobID = value;
            }
        }

        public string DateSubmitted
        {
            get
            {
                return i_DateSubmitted;
            }
            set
            {
                this.i_DateSubmitted = value;
            }
        }

        public string Status
        {
            get
            {
                return i_Status;
            }
            set
            {
                this.i_Status = value;
            }
        }
        public int AttemptID
        {
            get
            {
                return i_AttemptID;
            }
            set
            {
                this.i_AttemptID = value;
            }
        }
    }
}
