﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
   public class OrgAccountSH
    {
       private int i_OrganisationID = int.MinValue;
       private int i_UserID = int.MinValue;
      private string i_Name = string.Empty;
      private string i_HeadQuarterAddress = string.Empty;
      private string i_LogoPath = string.Empty;
      private string i_City = string.Empty;
      private string i_Country = string.Empty;
      private string i_IndustryName= string.Empty;
      //private string i_Status = string.Empty;
      private string i_Size = string.Empty;
      private string i_Founded = string.Empty;
      private string i_Website = string.Empty;
      private string i_StockSymbol = string.Empty;
      private string i_Description = string.Empty;
      private string i_GoalsAndValues = string.Empty;
      private string i_OrgStatus = string.Empty;
      private string i_Type = string.Empty;
      private string i_Specilaties = string.Empty;




      private int i_OrgID = int.MinValue;
      //private string i_UserID = string.Empty;
      private string i_FullName = string.Empty;
      private string i_Photo = string.Empty;
      private string i_Flag = string.Empty;
      private string i_JobTitle = string.Empty;
      private string i_Email = string.Empty;
      private string i_DisplayAs = string.Empty;
      private string i_PhFax = string.Empty;
      private string i_PhMobile = string.Empty;
      private int i_Zip = 0;
      
      private string i_PhBusiness = string.Empty;
     
      public int OrganisationID
      {
          get
          {
              return i_OrganisationID;
          }
          set
          {
              this.i_OrganisationID = value;
          }
      }
      public int UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public string Name
        {
            get
            {
                return i_Name;
            }
            set
            {
                this.i_Name = value;
            }
        }
        public string HeadQuarterAddress 
        {
            get
            {
                return i_HeadQuarterAddress;
            }
            set
            {
                this.i_HeadQuarterAddress = value;
            }
        }
        public string LogoPath
        {
            get
            {
                return i_LogoPath;
            }
            set
            {
                this.i_LogoPath = value;
            }
        }
        public string City
        {
            get
            {
                return i_City;
            }
            set
            {
                this.i_City = value;
            }
        }
        public string Country
        {
            get
            {
                return i_Country;
            }
            set
            {
                this.i_Country = value;
            }
        }
        public string IndustryName
        {
            get
            {
                return i_IndustryName;
            }
            set
            {
                this.i_IndustryName = value;
            }
        }
        //public string Status
        //{
        //    get
        //    {
        //        return i_Status;
        //    }
        //    set
        //    {
        //        this.i_Status = value;
        //    }
        //}
        public string Size
        {
            get
            {
                return i_Size;
            }
            set
            {
                this.i_Size = value;
            }
        }
        public string Founded
        {
            get
            {
                return i_Founded;
            }
            set
            {
                this.i_Founded = value;
            }
        }
        public string Website
        {
            get
            {
                return i_Website;
            }
            set
            {
                this.i_Website = value;
            }
        }
        public string StockSymbol
        {
            get
            {
                return i_StockSymbol;
            }
            set
            {
                this.i_StockSymbol = value;
            }
        }
        public string Description
        {
            get
            {
                return i_Description;
            }
            set
            {
                this.i_Description = value;
            }
        }
        public string GoalsAndValues 
        {
            get
            {
                return i_GoalsAndValues;
            }
            set
            {
                this.i_GoalsAndValues = value;
            }
        }
        public string OrgStatus
        {
            get
            {
                return i_OrgStatus;
            }
            set
            {
                this.i_OrgStatus = value;
            }
        }
        public string Type
        {
            get
            {
                return i_Type;
            }
            set
            {
                this.i_Type = value;
            }
        }
        public string JobTitle
        {
            get
            {
                return i_JobTitle;
            }
            set
            {
                this.i_JobTitle = value;
            }
        }
        public string Email
        {
            get
            {
                return i_Email;
            }
            set
            {
                this.i_Email = value;
            }
        }
        public string DisplayAs
        {
            get
            {
                return i_DisplayAs;
            }
            set
            {
                this.i_DisplayAs = value;
            }
        }
        public string PhFax
        {
            get
            {
                return i_PhFax;
            }
            set
            {
                this.i_PhFax = value;
            }
        }
        public string PhMobile
        {
            get
            {
                return i_PhMobile;
            }
            set
            {
                this.i_PhMobile = value;
            }
        }
        public int Zip
        {
            get
            {
                return i_Zip;
            }
            set
            {
                this.i_Zip = value;
            }
        }
        public string PhBusiness
        {
            get
            {
                return i_PhBusiness;
            }
            set
            {
                this.i_PhBusiness = value;
            }
        }
        public int OrgID
        {
            get
            {
                return i_OrgID;
            }
            set
            {
                this.i_OrgID = value;
            }
        }
        public string FullName 
        {
            get
            {
                return i_FullName;
            }
            set
            {
                this.i_FullName = value;
            }
        }
        public string Photo
        {
            get
            {
                return i_Photo;
            }
            set
            {
                this.i_Photo = value;
            }
        }
        public string Flag
        {
            get
            {
                return i_Flag;
            }
            set
            {
                this.i_Flag = value;
            }
        }
        public string Specilaties 
        {
            get
            {
                return i_Specilaties;
            }
            set
            {
                this.i_Specilaties = value;
            }
        }

    }
}
