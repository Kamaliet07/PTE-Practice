﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class MyResSH
    {
        private string i_ResumeID = string.Empty;
        private string i_VidResumeID = string.Empty;
        private string i_TxtResume = string.Empty;
        private string i_GridSrchTxt = string.Empty;
        public string ResumeID
        {
            get
            {
                return i_ResumeID;
            }
            set
            {
                this.i_ResumeID = value;
            }
        }        
        public string VidResumeID
        {
            get
            {
                return i_VidResumeID;
            }
            set
            {
                this.i_VidResumeID = value;
            }
        }
        public string TxtResume
        {
            get
            {
                return i_TxtResume;
            }
            set
            {
                this.i_TxtResume = value;
            }
        }
        public string GridSrchTxt
        {
            get
            {
                return i_GridSrchTxt;
            }
            set
            {
                this.i_GridSrchTxt = value;
            }
        }
    }
}
