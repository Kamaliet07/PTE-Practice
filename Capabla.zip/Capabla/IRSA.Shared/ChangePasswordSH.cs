﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
    public class ChangePasswordSH
    {
        public string i_UserID = string.Empty;
        public string i_Password = string.Empty;
        public string i_NewPassword = string.Empty;
        public string i_ConfirmPassword = string.Empty;


        public string UserID
        {
            get
            {
                return i_UserID;
            }
            set
            {
                this.i_UserID = value;
            }
        }
        public string Password
        {
            get
            {
                return i_Password;
            }
            set
            {
                this.i_Password = value;
            }
        }
        public string NewPassword
        {
            get
            {
                return i_NewPassword;
            }
            set
            {
                this.i_NewPassword = value;
            }
        }
        public string ConfirmPassword
        {
            get
            {
                return i_ConfirmPassword;
            }
            set
            {
                this.i_ConfirmPassword = value;
            }
        }
    }
}
