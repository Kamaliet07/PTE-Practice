﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Shared
{
  public  class MyCaererToolsSH
    {

     
        private int i_ProfileID = int.MinValue;



        public int ProfileID
        {
            get
            {
                return i_ProfileID;
            }
            set
            {
                this.i_ProfileID = value;
            }
        }

    }
}
