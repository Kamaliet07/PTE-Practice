﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Common.GlobalFunction
{
  public class GlobalMethod
    {
        /**************************************************************************************************
          METHOD NAME : GetConnectionString
          PARAMETERS  : None
          RETURN TYPE : Returns Connection String
          CREATE DATE : 23-APRIL-2009
          MODIFY DATE :  
          **************************************************************************************************/
        public static string GetConnectionString()
        {
           
            string connectionString = System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"].ToString();
            return connectionString;

        }
        /**************************************************************************************************
           METHOD NAME : GetDbType
           PARAMETERS  : None
           RETURN TYPE : Returns type of database
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE :  
        **************************************************************************************************/
        public static string GetDbType()
        {
            

            string strDBType = System.Configuration.ConfigurationSettings.AppSettings["DBType"].ToString();
            return strDBType;

        }
    }
}
