﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Configuration;
using System.IO;

namespace IRSA.Common.GlobalFunction
{
    /******************************************************************************************************************
           DEFINTION    : Class contains Get and Set properties for Session Information
           CREATE DATE  : 23-APRIL-2009
           MODIFY DATE  :  
      *******************************************************************************************************************/
   public class SessionInfo
    {
        private static int i_UserId;
        private static string i_Username;
        private static string i_CultureID;
        private static int i_CommunityID;
        public static string i_CategoryName;
        public static string i_CommSearch;
        public static Boolean i_CommunityLogo;
        public static string i_OwnerName;
        public static string i_OwnerEmail;
        public static string i_CommunityName;
        public static string i_Logo;
        public static string i_CommunityType;
        public static string i_FunctionalDomain;
        public static string i_ShortDescription;
        public static string i_DetailedDescription;
        public static string i_WebsiteURL;
        public static Boolean i_CommunityDirectory;
        public static Boolean i_Approval;
        public static Boolean i_Status;
        public static Boolean i_Deleted;
        private static string i_FirstName;
        private static string i_SkillProfilerName;
        private static string i_ONETSOCCode;
        private static string i_ElementID;
        private static string i_WorkActElementID;
        private static string i_JobfamilyID;
        private static int i_Rating;
        private static string i_RoleID;
        private static string i_UserNodeSelect;
        private static string i_NodeValue;
        private static int i_OrganisationID;
        private static int i_OrgID;
        private static int i_AttemptID;
        private static int i_CandidateID;
        private static string i_DisplayName;
        private static string i_ONETSOCCodeId;
        private static string i_JobOccupation;
        private static string i_ComboSearch;
        private static string i_PrevCookieLang;
        private static string i_JobfamilyIDforjobDomain;

     public static string PrevCookieLang
        {
            get
            {
                if (HttpContext.Current.Session["PrevCookieLang"] != null)
                {
                    i_PrevCookieLang = Convert.ToString(HttpContext.Current.Session["PrevCookieLang"]);
                    return i_PrevCookieLang;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["PrevCookieLang"] = value;
                i_PrevCookieLang = value;
            }

        }
        public static string Username
        {
            get
            {
                if (HttpContext.Current.Session["Username"] != null)
                {
                    i_Username = Convert.ToString(HttpContext.Current.Session["Username"]);
                    return i_Username;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["Username"] = value;
                i_Username = value;
            }

        }
        public static string FirstName
        {
            get
            {
                if (HttpContext.Current.Session["FirstName"] != null)
                {
                    i_FirstName = Convert.ToString(HttpContext.Current.Session["FirstName"]);
                    return i_FirstName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["FirstName"] = value;
                i_FirstName = value;
            }

        }
        public static int UserId
        {
            get
            {
                if (HttpContext.Current.Session["UserId"] != null)
                {
                    i_UserId = Convert.ToInt32(HttpContext.Current.Session["UserId"].ToString());
                    return i_UserId;
                }
                else
                {
                    return int.MinValue;
                }
            }
            set
            {
                HttpContext.Current.Session["UserId"] = value;
                i_UserId = value;
            }

        }
        public static string CultureID
        {
            get
            {
                if (HttpContext.Current.Session["CultureID"] != null)
                {
                    i_Username = Convert.ToString(HttpContext.Current.Session["CultureID"]);
                    return i_Username;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["CultureID"] = value;
                i_Username = value;
            }

        }
        public static int CommunityID
        {
            get
            {
                if (HttpContext.Current.Session["CommunityID"] != null)
                {
                    i_CommunityID = Convert.ToInt32(HttpContext.Current.Session["CommunityID"].ToString());
                    return i_CommunityID;
                }
                else
                {
                    return int.MinValue;
                }
            }
            set
            {
                HttpContext.Current.Session["CommunityID"] = value;
                i_CommunityID = value;
            }

        }
        public static string CommunityName
        {
            get
            {
                if (HttpContext.Current.Session["CommunityName"] != null)
                {
                    i_CommunityName = Convert.ToString(HttpContext.Current.Session["CommunityName"]);
                    return i_CommunityName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["CommunityName"] = value;
                i_CommunityName = value;
            }

        }
        public static string CommunityType
        {
            get
            {
                if (HttpContext.Current.Session["CommunityType"] != null)
                {
                    i_CommunityType = Convert.ToString(HttpContext.Current.Session["CommunityType"]);
                    return i_CommunityType;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["CommunityType"] = value;
                i_CommunityType = value;
            }

        }
        public static string FunctionalDomain
        {
            get
            {
                if (HttpContext.Current.Session["FunctionalDomain"] != null)
                {
                    i_FunctionalDomain = Convert.ToString(HttpContext.Current.Session["FunctionalDomain"]);
                    return i_FunctionalDomain;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["FunctionalDomain"] = value;
                i_FunctionalDomain = value;
            }

        }
        public static string ShortDescription
        {
            get
            {
                if (HttpContext.Current.Session["ShortDescription"] != null)
                {
                    i_ShortDescription = Convert.ToString(HttpContext.Current.Session["ShortDescription"]);
                    return i_ShortDescription;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["ShortDescription"] = value;
                i_ShortDescription = value;
            }

        }
        public static string DetailedDescription
        {
            get
            {
                if (HttpContext.Current.Session["DetailedDescription"] != null)
                {
                    i_DetailedDescription = Convert.ToString(HttpContext.Current.Session["DetailedDescription"]);
                    return i_DetailedDescription;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["DetailedDescription"] = value;
                i_DetailedDescription = value;
            }

        }

        public static string WebsiteURL
        {
            get
            {
                if (HttpContext.Current.Session["WebsiteURL"] != null)
                {
                    i_WebsiteURL = Convert.ToString(HttpContext.Current.Session["WebsiteURL"]);
                    return i_WebsiteURL;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["WebsiteURL"] = value;
                i_WebsiteURL = value;
            }

        }


        public static string Logo
        {
            get
            {
                if (HttpContext.Current.Session["Logo"] != null)
                {
                    i_Logo = Convert.ToString(HttpContext.Current.Session["Logo"]);
                    return i_Logo;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["Logo"] = value;
                i_Logo = value;
            }

        }

        public static Boolean CommunityLogo
        {
            get
            {
                if (HttpContext.Current.Session["CommunityLogo"] != null)
                {
                    i_CommunityLogo = Convert.ToBoolean(HttpContext.Current.Session["CommunityLogo"]);
                    return i_CommunityLogo;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["CommunityLogo"] = value;
                i_CommunityLogo = value;
            }

        }
        public static Boolean CommunityDirectory
        {
            get
            {
                if (HttpContext.Current.Session["CommunityDirectory"] != null)
                {
                    i_CommunityDirectory = Convert.ToBoolean(HttpContext.Current.Session["CommunityDirectory"]);
                    return i_CommunityDirectory;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["CommunityDirectory"] = value;
                i_CommunityDirectory = value;
            }

        }
        public static Boolean Deleted
        {
            get
            {
                if (HttpContext.Current.Session["Deleted"] != null)
                {
                    i_Deleted = Convert.ToBoolean(HttpContext.Current.Session["Deleted"]);
                    return i_Deleted;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["Deleted"] = value;
                i_Deleted = value;
            }

        }
        public static Boolean Approval
        {
            get
            {
                if (HttpContext.Current.Session["Approval"] != null)
                {
                    i_Approval = Convert.ToBoolean(HttpContext.Current.Session["Approval"]);
                    return i_Approval;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["Approval"] = value;
                i_Approval = value;
            }

        }
        public static Boolean Status
        {
            get
            {
                if (HttpContext.Current.Session["Status"] != null)
                {
                    i_Status = Convert.ToBoolean(HttpContext.Current.Session["Status"]);
                    return i_Status;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["Status"] = value;
                i_Status = value;
            }

        }



        public static string OwnerName
        {
            get
            {
                if (HttpContext.Current.Session["OwnerName"] != null)
                {
                    i_OwnerName = Convert.ToString(HttpContext.Current.Session["OwnerName"]);
                    return i_OwnerName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["OwnerName"] = value;
                i_OwnerName = value;
            }

        }

        public static string OwnerEmail
        {
            get
            {
                if (HttpContext.Current.Session["OwnerEmail"] != null)
                {
                    i_OwnerEmail = Convert.ToString(HttpContext.Current.Session["OwnerName"]);
                    return i_OwnerEmail;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["OwnerName"] = value;
                i_OwnerName = value;
            }

        }

        public static string CategoryName
        {
            get
            {
                if (HttpContext.Current.Session["CategoryName"] != null)
                {
                    CategoryName = Convert.ToString(HttpContext.Current.Session["CategoryName"]);
                    return i_CategoryName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["CategoryName"] = value;
                i_CategoryName = value;
            }

        }
        public static string CommSearch
        {
            get
            {
                if (HttpContext.Current.Session["CommSearch"] != null)
                {
                    i_CommSearch = Convert.ToString(HttpContext.Current.Session["CommSearch"]);
                    return i_CommSearch;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["CommSearch"] = value;
                i_CommSearch = value;
            }

        }
        public static string SkillProfilerName
        {
            get
            {
                if (HttpContext.Current.Session["SkillProfilerName"] != null)
                {
                    i_SkillProfilerName = Convert.ToString(HttpContext.Current.Session["SkillProfilerName"]);
                    return i_SkillProfilerName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["SkillProfilerName"] = value;
                i_SkillProfilerName = value;
            }

        }
        public static string ONETSOCCode
        {
            get
            {
                if (HttpContext.Current.Session["ONETSOCCode"] != null)
                {
                    i_ONETSOCCode = Convert.ToString(HttpContext.Current.Session["ONETSOCCode"]);
                    return i_ONETSOCCode;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["ONETSOCCode"] = value;
                i_ONETSOCCode = value;
            }

        }
        public static string ElementID
        {
            get
            {
                if (HttpContext.Current.Session["ElementID"] != null)
                {
                    i_ElementID = Convert.ToString(HttpContext.Current.Session["ElementID"]);
                    return i_ElementID;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["ElementID"] = value;
                i_ElementID = value;
            }

        }


        public static string WorkActElementID
        {
            get
            {
                if (HttpContext.Current.Session["WorkActElementID"] != null)
                {
                    i_WorkActElementID = Convert.ToString(HttpContext.Current.Session["WorkActElementID"]);
                    return i_WorkActElementID;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["WorkActElementID"] = value;
                i_WorkActElementID = value;
            }

        }
        public static string JobfamilyID
        {
            get
            {
                if (HttpContext.Current.Session["JobfamilyID"] != null)
                {
                    i_JobfamilyID = Convert.ToString(HttpContext.Current.Session["JobfamilyID"]);
                    return i_JobfamilyID;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["JobfamilyID"] = value;
                i_JobfamilyID = value;
            }

        }
        public static int Rating
        {
            get
            {
                if (HttpContext.Current.Session["Rating"] != null)
                {
                    i_Rating = Convert.ToInt32(HttpContext.Current.Session["Rating"].ToString());
                    return i_Rating;
                }
                else
                {
                    return int.MinValue;
                }
            }
            set
            {
                HttpContext.Current.Session["Rating"] = value;
                i_Rating = value;
            }

        }
        public static string RoleID
        {
            get
            {
                if (HttpContext.Current.Session["RoleID"] != null)
                {
                    i_RoleID = Convert.ToString(HttpContext.Current.Session["RoleID"]);
                    return i_RoleID;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["RoleID"] = value;
                i_RoleID = value;
            }

        }
        public static string UserNodeSelect
        {
            get
            {
                if (HttpContext.Current.Session["UserNodeSelect"] != null)
                {
                    i_UserNodeSelect = Convert.ToString(HttpContext.Current.Session["UserNodeSelect"]);
                    return i_UserNodeSelect;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserNodeSelect"] = value;
                i_UserNodeSelect = value;
            }

        }


        public static string NodeValue
        {
            get
            {
                if (HttpContext.Current.Session["NodeValue"] != null)
                {
                    i_NodeValue = Convert.ToString(HttpContext.Current.Session["NodeValue"]);
                    return i_NodeValue;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["NodeValue"] = value;
                i_NodeValue = value;
            }

        }

    public static int OrganisationID
        {
            get
            {
                if (HttpContext.Current.Session["OrganisationID"] != null)
                {
                    i_OrganisationID = Convert.ToInt32(HttpContext.Current.Session["OrganisationID"].ToString());
                    return i_OrganisationID;
                }
                else
                {
                    return int.MinValue;
                }
            }
            set
            {
                HttpContext.Current.Session["OrganisationID"] = value;
                i_OrganisationID = value;
            }

        }
        public static int OrgID
        {
            get
            {
                if (HttpContext.Current.Session["OrgID"] != null)
                {
                    i_OrgID = Convert.ToInt32(HttpContext.Current.Session["OrgID"].ToString());
                    return i_OrgID;
                }
                else
                {
                    return int.MinValue;
                }
            }
            set
            {
                HttpContext.Current.Session["OrgID"] = value;
                i_OrgID = value;
            }

        }
        public static int CandidateID
        {
            get
            {
                if (HttpContext.Current.Session["CandidateID"] != null)
                {
                    i_CandidateID = Convert.ToInt32(HttpContext.Current.Session["CandidateID"].ToString());
                    return i_CandidateID;
                }
                else
                {
                    return int.MinValue;
                }
            }
            set
            {
                HttpContext.Current.Session["CandidateID"] = value;
                i_CandidateID = value;
            }

        }
        public static string DisplayName
        {
            get
            {
                if (HttpContext.Current.Session["DisplayName"] != null)
                {
                    i_DisplayName = Convert.ToString(HttpContext.Current.Session["DisplayName"]);
                    return i_DisplayName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["DisplayName"] = value;
                i_DisplayName = value;
            }

        }
        public static string ONETSOCCodeId
        {
            get
            {
                if (HttpContext.Current.Session["ONETSOCCodeId"] != null)
                {
                    i_ONETSOCCodeId = Convert.ToString(HttpContext.Current.Session["ONETSOCCodeId"]);
                    return i_ONETSOCCodeId;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["ONETSOCCodeId"] = value;
                i_ONETSOCCodeId = value;
            }

        }
        public static int AttemptID
        {
            get
            {
                if (HttpContext.Current.Session["AttemptID"] != null)
                {
                    i_AttemptID = Convert.ToInt32(HttpContext.Current.Session["AttemptID"].ToString());
                    return i_AttemptID;
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["AttemptID"] = value;
                i_AttemptID = value;
            }

        }
        public static string JobOccupation
        {
            get
            {
                if (HttpContext.Current.Session["JobOccupation"] != null)
                {
                    i_JobOccupation = Convert.ToString(HttpContext.Current.Session["JobOccupation"]);
                    return i_JobOccupation;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["JobOccupation"] = value;
                i_JobOccupation = value;
            }

        }
        public static string ComboSearch
        {
            get
            {
                if (HttpContext.Current.Session["ComboSearch"] != null)
                {
                    i_ComboSearch = Convert.ToString(HttpContext.Current.Session["ComboSearch"]);
                    return i_ComboSearch;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["ComboSearch"] = value;
                i_ComboSearch = value;
            }

        }
        public static string JobfamilyIDforjobDomain
        {
            get
            {
                if (HttpContext.Current.Session["JobfamilyIDforjobDomain"] != null)
                {
                    i_JobfamilyIDforjobDomain = Convert.ToString(HttpContext.Current.Session["JobfamilyIDforjobDomain"]);
                    return i_JobfamilyIDforjobDomain;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["JobfamilyIDforjobDomain"] = value;
                i_JobfamilyIDforjobDomain = value;
            }

        }
    }
}
