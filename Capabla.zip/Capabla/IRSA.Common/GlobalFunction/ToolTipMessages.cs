﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Web;

namespace IRSA.Common.GlobalFunction
{
    public class ToolTipMessages
    {
        public static string GetiRsaToolTipMessage(int tooltipid)
        {
            XmlDocument xErrormsgDoc;
            string ErrorMessage = "";
            try
            {
                xErrormsgDoc = new XmlDocument();
                xErrormsgDoc.Load(HttpContext.Current.Server.MapPath("xml/iRSATooltip.xml"));
                if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == string.Empty || IRSA.Common.GlobalFunction.SessionInfo.CultureID == "EN")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/English/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("ToolTipMessage/English/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }
                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "NL")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/Dutch/MessageID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("ToolTipMessage/Dutch/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }

                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "SP")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/Spanish/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("Error/Spanish/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }
                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "FR")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/French/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("ToolTipMessage/French/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }
                }
                else
                {
                    ErrorMessage = "No Message exist for this id";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "Exception occured while generated error message!" + ex.Message;

            }
            return ErrorMessage;
        }


            public static string GetiRsaToolTipModuleWiseMessage(int tooltipid, string ModuleXML)
        {
            XmlDocument xErrormsgDoc;
            string ErrorMessage = "";
            try
            {
                xErrormsgDoc = new XmlDocument();
                xErrormsgDoc.Load(HttpContext.Current.Server.MapPath("xml/" + ModuleXML));
                if ( IRSA.Common.GlobalFunction.SessionInfo.CultureID == "EN")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/English/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("ToolTipMessage/English/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }
                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == string.Empty ||IRSA.Common.GlobalFunction.SessionInfo.CultureID == "NL")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/Dutch/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("ToolTipMessage/Dutch/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }

                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "SP")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/Spanish/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("Error/Spanish/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }
                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "FR")
                {
                    if (xErrormsgDoc.SelectSingleNode("ToolTipMessage/French/ToolTipID[@ID= \"" + tooltipid.ToString() + "\" ]/ToolTip") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("ToolTipMessage/French/ToolTipID[@ID= \"" + tooltipid.ToString() + "\"]/ToolTip").InnerText;
                    }
                }
                else
                {
                    ErrorMessage = "No Message exist for this id";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "Exception occured while generated error message!" + ex.Message;

            }
            return ErrorMessage;
        }
    }
}
