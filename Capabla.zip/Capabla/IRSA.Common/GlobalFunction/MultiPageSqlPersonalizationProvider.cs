using System;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for MultiPagePersonalizationProvider
/// </summary>

namespace Providers
{
    public class MultiPageSqlPersonalizationProvider : SqlPersonalizationProvider
    {
        private string _groupName = "PageGroup";
        public string GroupName
        {
            get
            {
                return _groupName;
            }
            set
            {
                _groupName = value;
            }
        }

        #region Overrides

        public override PersonalizationStateInfoCollection FindState(PersonalizationScope scope, PersonalizationStateQuery query, int pageIndex, int pageSize, out int totalRecords)
        {
            if (query.PathToMatch != String.Empty)
            {
                query.PathToMatch = GroupName;
            }
            return base.FindState(scope, query, pageIndex, pageSize, out totalRecords);
        }

        public override int GetCountOfState(PersonalizationScope scope, PersonalizationStateQuery query)
        {
            if (query.PathToMatch != String.Empty)
            {
                query.PathToMatch = GroupName;
            }
            return base.GetCountOfState(scope, query);
        }

        protected override void LoadPersonalizationBlobs(WebPartManager webPartManager, string path, string userName, ref byte[] sharedDataBlob, ref byte[] userDataBlob)
        {
            base.LoadPersonalizationBlobs(webPartManager, GroupName, userName, ref sharedDataBlob, ref userDataBlob);
        }

        protected override void ResetPersonalizationBlob(WebPartManager webPartManager, string path, string userName)
        {
            base.ResetPersonalizationBlob(webPartManager, GroupName, userName);
        }

        public override int ResetState(PersonalizationScope scope, string[] paths, string[] usernames)
        {
            return base.ResetState(scope, new string[] { GroupName }, usernames);
        }

        public override int ResetUserState(string path, DateTime userInactiveSinceDate)
        {
            return base.ResetUserState(GroupName, userInactiveSinceDate);
        }

        protected override void SavePersonalizationBlob(WebPartManager webPartManager, string path, string userName, byte[] dataBlob)
        {
            base.SavePersonalizationBlob(webPartManager, GroupName, userName, dataBlob);
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection configSettings)
        {
            GroupName = configSettings["groupName"];            
            if (string.IsNullOrEmpty(GroupName)) GroupName = "PageGroup";
            configSettings.Remove("groupName");
            base.Initialize(name, configSettings);
        }

        #endregion


        
    }
}