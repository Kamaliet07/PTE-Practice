﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace IRSA.Common.GlobalFunction
{
   public class Encryption
    {
        /**************************************************************************************************
        METHOD NAME : HashPwd
        PARAMETERS  : input
        RETURN TYPE : Returns hexadecimal string of password i.e. Encrypted password
        CREATE DATE : 23-APRIL-2009
        MODIFY DATE :  
        **************************************************************************************************/
        public static string HashPwd(string input)
       {
           
           MD5CryptoServiceProvider md5Hasher = new MD5CryptoServiceProvider();

          
           byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(input));

          
           StringBuilder sBuilder = new StringBuilder();

          
           for (int i = 0; i < data.Length; i++)
           {
               sBuilder.Append(data[i].ToString("x2"));
           }

          
          string password=sBuilder.ToString();
          return password;
       }

        /**************************************************************************************************
         METHOD NAME : verifyPwd
         PARAMETERS  : input,hash
         RETURN TYPE : Returns true if hash string is same otherwise false
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
         **************************************************************************************************/
        public static bool verifyPwd(string input, string hash)
       {
          
           string hashOfInput = HashPwd(input);

          
           StringComparer comparer = StringComparer.OrdinalIgnoreCase;

           if (0 == comparer.Compare(hashOfInput, hash))
           {
               return true;
           }
           else
           {
               return false;
           }
       }

    }
}
