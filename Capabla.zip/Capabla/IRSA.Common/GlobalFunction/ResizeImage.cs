﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Web.UI.WebControls;

namespace IRSA.Common.GlobalFunction
{
   public class ResizeImage
    {
     
 
  
       public void ResizeFromStream(string ImageSavePath, int MaxSideSize, Stream Buffer)
       {
           int intNewWidth;
           int intNewHeight;
           System.Drawing.Image imgInput = System.Drawing.Image.FromStream(Buffer);

           //Determine image format 
           System.Drawing.Imaging.ImageFormat fmtImageFormat = imgInput.RawFormat;

           //get image original width and height 
           int intOldWidth = imgInput.Width;
           int intOldHeight = imgInput.Height;

           //determine if landscape or portrait 
           int intMaxSide;

           if (intOldWidth >= intOldHeight)
           {
               intMaxSide = intOldWidth;
           }
           else
           {
               intMaxSide = intOldHeight;
           }


           if (intMaxSide > MaxSideSize)
           {
               //set new width and height 
               double dblCoef = MaxSideSize / (double)intMaxSide;
               intNewWidth = Convert.ToInt32(dblCoef * intOldWidth);
               intNewHeight = Convert.ToInt32(dblCoef * intOldHeight);
           }
           else
           {
               intNewWidth = intOldWidth;
               intNewHeight = intOldHeight;
           }
           //create new bitmap 
           System.Drawing.Bitmap bmpResized = new System.Drawing.Bitmap(imgInput, intNewWidth, intNewHeight);

           //save bitmap to disk 
           bmpResized.Save(ImageSavePath, fmtImageFormat);

           //release used resources 
           imgInput.Dispose();
           bmpResized.Dispose();
           Buffer.Close();
       } 

  }
}
 