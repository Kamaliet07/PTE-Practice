﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Web;


namespace IRSA.Common.GlobalFunction
{
    public class ErrorMessage
    {
        /**************************************************************************************************
         METHOD NAME : GetiRSAErrorMessage
         PARAMETERS  : Id
         RETURN TYPE : Returns ErrorMessageFormat according to Langauge
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/
        public static string GetiRsaErrorMessage(int errorid)
        {
            XmlDocument xErrormsgDoc;
            string ErrorMessage = "";
            try
            {
                xErrormsgDoc = new XmlDocument();
                xErrormsgDoc.Load(HttpContext.Current.Server.MapPath("xml/IERSAErrorMessage.xml"));
                if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "EN")
                {
                    if (xErrormsgDoc.SelectSingleNode("Error/English/MessageID[@ID= \"" + errorid.ToString() + "\" ]/Message") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("Error/English/MessageID[@ID= \"" + errorid.ToString() + "\"]/Message").InnerText;
                    }
                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == string.Empty || IRSA.Common.GlobalFunction.SessionInfo.CultureID == "NL")
                {
                    if (xErrormsgDoc.SelectSingleNode("Error/Dutch/MessageID[@ID= \"" + errorid.ToString() + "\" ]/Message") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("Error/Dutch/MessageID[@ID= \"" + errorid.ToString() + "\"]/Message").InnerText;
                    }

                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "SP")
                {
                    if (xErrormsgDoc.SelectSingleNode("Error/Spanish/MessageID[@ID= \"" + errorid.ToString() + "\" ]/Message") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("Error/Spanish/MessageID[@ID= \"" + errorid.ToString() + "\"]/Message").InnerText;
                    }
                }
                else if (IRSA.Common.GlobalFunction.SessionInfo.CultureID == "FR")
                {
                    if (xErrormsgDoc.SelectSingleNode("Error/French/MessageID[@ID= \"" + errorid.ToString() + "\" ]/Message") != null)
                    {
                        ErrorMessage = xErrormsgDoc.SelectSingleNode("Error/French/MessageID[@ID= \"" + errorid.ToString() + "\"]/Message").InnerText;
                    }
                }
                else
                {
                    ErrorMessage = "No Message exist for this id";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "Exception occured while generated error message!" + ex.Message;

            }
            return ErrorMessage;
        }
    }
}
