﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace IRSA.Common.Validation
{
   public class Validation
    {
       /**************************************************************************************************
        METHOD NAME : RequiredCheck
        PARAMETERS  : inptval
        DESCRIPTION : Used to identifiy that data are not null
        CREATE DATE : 23-APRIL-2009
        MODIFY DATE :  
       **************************************************************************************************/
        public static bool RequiredCheck(string inptval)
        {
            bool check = true;
            if (inptval != null)
            {
                if (inptval.Trim() == string.Empty)
                {
                    check = false;
                }
            }
            else
            {
                check = false;
            }
            return(check);
        }

        /**************************************************************************************************
         METHOD NAME : IsContainsSpecialCharaters
         PARAMETERS  : inptval
         DESCRIPTION : Checks the data for containing special characters (!@#$%^&*()_+-= etc)
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/

        public static bool IsContainsSpecialCharaters(string inptval)
        {
            
            Regex rg = new Regex(@"^[0-9a-zA-Z\s]*$");
            return (!rg.IsMatch(inptval));
            
        }

        /**************************************************************************************************
          METHOD NAME : IsNumeric
          PARAMETERS  : inptval
          DESCRIPTION : Checks the data whether it is numeric or not
          CREATE DATE : 23-APRIL-2009
          MODIFY DATE :  
         **************************************************************************************************/
       
        public static bool IsNumeric(string inptval)
        {
            double result;
            return (double.TryParse(inptval, out result));
            
        }

        /**************************************************************************************************
          METHOD NAME : IsDateTime
          PARAMETERS  : inptval
          DESCRIPTION : Checks the data contains valid date/time format
          CREATE DATE : 23-APRIL-2009
          MODIFY DATE :  
         **************************************************************************************************/
       
        public static bool IsDateTime(string inptval)
        {
            if (RequiredCheck(inptval))
            {
                DateTime result;
                return (DateTime.TryParse(inptval, out result));
            }
            else
            {
                return true;
            }
        }

        /**************************************************************************************************
           METHOD NAME : IsValidEmailAddress
           PARAMETERS  : inptval
           DESCRIPTION : Checks the data contains valid email address
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE :  
          **************************************************************************************************/
       
        public static bool IsValidEmailAddress(string inptval)
        {
                       
            //Regex rg = new Regex(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
            Regex rg = new Regex(@"^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$");
           //Regex rg = new Regex(@"^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+.([a-zA-Z]{2,4})$");
            if (rg.IsMatch(inptval))
            {
                return  true;
            }
            else
            {
                return false;
            }

            
            
            
        }

        /**************************************************************************************************
            METHOD NAME : IsValidInternetURL
            PARAMETERS  : inptval
            DESCRIPTION : Checks the data contains valid internet URL
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
        **************************************************************************************************/
               
        public static bool IsValidInternetURL(string inptval)
        {
            if (RequiredCheck(inptval))
            {
                Regex rg = new Regex(@"http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?");
                return (rg.IsMatch(inptval));
            }
            else
            {
                return true;
            }
        }
        public static bool IsValidprofessionaltitle(string inptval)
        {

            Regex rg = new Regex(@"^[a-zA-Z0-9\.\s]*$");
            return (rg.IsMatch(inptval));

        }
        public static bool IsValidAddress(string inptval)
        {

            Regex rg = new Regex(@"^[a-zA-Z0-9\.\s,-]*$");
            return (rg.IsMatch(inptval));


        }

        #region "According to US Standards"

        /**************************************************************************************************
            METHOD NAME : IsValidUSPhoneNumber
            PARAMETERS  : inptval
            DESCRIPTION : Checks the data is in valid US Phone Number format
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
        **************************************************************************************************/
       
        public static bool IsValidUSPhoneNumber(string inptval)
        {
            if (RequiredCheck(inptval))
            {
                Regex rg = new Regex(@"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}");
                return (rg.IsMatch(inptval));
            }
            else
            {
                return true;
            }
        }

        /**************************************************************************************************
           METHOD NAME : IsValidUSSocialSecurityNumber
           PARAMETERS  : inptval
           DESCRIPTION : Checks the data is in valid US Social Security Number format
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE :  
       **************************************************************************************************/
       
        public static bool IsValidUSSocialSecurityNumber(string inptval)
        {
            if (RequiredCheck(inptval))
            {
                Regex rg = new Regex(@"\d{3}-\d{2}-\d{4}");
                return (rg.IsMatch(inptval));
            }
            else
            {
                return true;
            }
        }

        /**************************************************************************************************
           METHOD NAME : IsValidUSZipCode
           PARAMETERS  : inptval
           DESCRIPTION : Checks the data is in valid US Zip Code format
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE :  
       **************************************************************************************************/
       
        public static bool IsValidUSZipCode(string inptval)
        {
            if (RequiredCheck(inptval))
            {
                Regex rg = new Regex(@"\d{5}(-\d{4})?");
                return (rg.IsMatch(inptval));
            }
            else
            {
                return true;
            }
        }

        #endregion
    }
    
}
