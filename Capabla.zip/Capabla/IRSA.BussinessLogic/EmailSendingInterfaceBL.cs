﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class EmailSendingInterfaceBL
    {
        public DataTable InserData(EmailSendingInterfaceSH obj)
        {
            int UserID = SessionInfo.UserId;
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_Inbox";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
          

            new SqlParameter("@InboxID", SqlDbType.Int),
            new SqlParameter("@Type",SqlDbType.NVarChar, 50),
            new SqlParameter("@ReceiverName",SqlDbType.NVarChar, 50),
            new SqlParameter("@Subject",SqlDbType.NVarChar, 100),
            new SqlParameter("@Description",SqlDbType.NVarChar, 1500),
            new SqlParameter("@Status", SqlDbType.NVarChar, 30),
             new SqlParameter("@SentDate", SqlDbType.NVarChar, 30),
            new SqlParameter("@UserID", SqlDbType.Int, 4),
           
          
                };
            Parameters[0].Value = obj.InboxID;
            Parameters[1].Value = "";
            Parameters[2].Value = obj.RecieverName;
            Parameters[3].Value = obj.Subject;
            Parameters[4].Value = obj.Description;
            Parameters[5].Value = obj.Status;
            Parameters[6].Value = obj.SentDate;
            Parameters[7].Value = UserID;
          


            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          


        }


        public static DataTable GetComboBoxData()
        {
            int UserID = SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * from (SELECT dbo.txnMemberAccount.UserID ,dbo.txnMemberAccount.EmailID FROM dbo.txnMemberAccount INNER JOIN dbo.txnUserNetworkList ON dbo.txnMemberAccount.UserID = dbo.txnUserNetworkList.NetworkUserID where Accepted='True' and txnUserNetworkList.UserID='" + UserID + "')Table1";

            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }
    }
 }

