﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
   public class EventNewBL
    {
       public static DataTable GetUSerDocumentsEventLst()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM txnEvent ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetUSerDocumentsEventMonth(string Month)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select * from txnEvent where EventMonth='" + Month + "' ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetUSerDocumentsEventLst1(int Event)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM txnEvent where EventID='" + Event + "'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
    }
}
