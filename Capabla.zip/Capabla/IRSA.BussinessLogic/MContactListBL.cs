﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using System.Data.SqlClient;
using IRSA.DALFactory; 
using IRSA.DALInterface;
using IRSA.Facade;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
   public class MContactListBL
    {
       public static DataTable GetUserData(string str4, MContactListSH objcontlistSH, int UserID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_contactlistsearcing";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                { 
                    new SqlParameter("@UserID", SqlDbType.Int ),
                  new SqlParameter("@FullName", SqlDbType.NVarChar,150 ),
                  new SqlParameter("@Company", SqlDbType.NVarChar,50 ),
                  new SqlParameter("@Email", SqlDbType.NVarChar,50 ),
                  new SqlParameter("@Phone", SqlDbType.NVarChar,20 ),
                  new SqlParameter("@Search", SqlDbType.NVarChar,50 ),
                  //new SqlParameter("@Expr1", SqlDbType.NVarChar,50 ),
                 
                
                 

                 
            
                };
           Parameters[0].Value = UserID;
           Parameters[1].Value = objcontlistSH.FullName;
           Parameters[2].Value = objcontlistSH.Company;
           Parameters[3].Value = objcontlistSH.EmailID;
           Parameters[4].Value = objcontlistSH.Phone;
           Parameters[5].Value = str4;
           //Parameters[3].Value = objcontlistSH.


           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject1);
           return rowCount;

       }

       public static DataTable GetUserDetails(string str,int UserID)
       {
           MContactListSH objcontlistSH = new MContactListSH();
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_ContactSearch";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                { 
                    new SqlParameter("@UserID", SqlDbType.Int ),
                  
                  new SqlParameter("@str", SqlDbType.NVarChar,2 ),
                  //new SqlParameter("@Expr1", SqlDbType.NVarChar,50 ),
                 
                
                 

                 
            
                };
           Parameters[0].Value = UserID;
          
           Parameters[1].Value = str;
         


           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject1);
           return rowCount;

       }
    }
}
