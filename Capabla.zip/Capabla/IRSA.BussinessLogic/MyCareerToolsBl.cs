﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
   public  class MyCareerToolsBl
    {
       public static DataTable GetProduct()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM txnProduct";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetProductName()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT * from txnSkillProfiler  ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetProductNameAsses()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT * from txnQuestionnaireSubmissionList where UserID='" + UserID + "'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public static DataTable GetProfile(int ProfileID)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT * FROM  txnSkillProfiler where SkillProfileID='" + ProfileID + "'and  UserID='" + UserID + "'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
    }
}
