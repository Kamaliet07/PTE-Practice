﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class MyDashBoardBL
    {
        public DataTable GetSavedUserControlAccUserId(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  * FROM UserControl where UserId = '" + UserID + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        public void InsertControlAccorUser(int userid, string controlname)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "INSERT INTO UserControl(UserId,ControlName) VALUES (" + userid + ", '" + controlname + "')";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
        }
        public DataTable getGridValue()
        {
            string ErrorMessage = "No Data Found";
          string RoleID = SessionInfo.RoleID;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  * FROM MasterControl where RoleId = '" + RoleID + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }

        public DataTable GetUserDefaultWebPart()
        {
            
                IDbConnection IConnection = null;
                string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                SqlCmd.CommandText = "[Sp_GetDefaultWebPArt]";
                IConnection = objDataAccessLayer.GetConnection();
                SqlCmd.Parameters.AddWithValue("@RoleID", SessionInfo.RoleID);
                SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(Sqldr);
                return rowCount;
            

            
        }
    }
}
