﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{

    public class AccountSettingBL
    {
        string UserID;
        string ContactBrowse;
        string everyone;
        string mycontacts;
        string mycommunities;
        public static DataTable RetrieveRole(int UserID)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select Who from [txnMemberAccount] where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable RetrieveContactbrowse(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ContactBrowse + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }

        public void SaveWhocanaccessData(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ContactBrowse + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ContactBrowse + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.ContactBrowse + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void Savesalarydetails(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Update txnMemberAccount set PreferredSalaryAmount='" + objaccsettSH.PreferredSalaryAmount + "',PreferredCurrency ='" + objaccsettSH.PreferredCurrency + "',PayDuration='" + objaccsettSH.PayDuration + "',JobTypes='" + objaccsettSH.JobTypes + "',HoursPerweek='" + objaccsettSH.HoursPerweek + "' where UserID='" + UserID + "'";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);



        }
        public void Saveproviewer(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ProfileView + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ProfileView + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.ProfileView + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }

        public void SaveShowName(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.HideIdentity + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set HideName='" + objaccsettSH.HideName + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.HideIdentity + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,HideName) values('" + UserID + "','" + objaccsettSH.HideIdentity + "','" + objaccsettSH.HideName + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void Savenotify(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.iRSANewsletter + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set iRSAnotification='" + objaccsettSH.iRSANotification + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.iRSANewsletter + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,iRSAnotification) values('" + UserID + "','" + objaccsettSH.iRSANewsletter + "','" + objaccsettSH.iRSANotification + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }

        public void Saverecallow(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.allowrecruiters + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set RecuriterAllowed='" + objaccsettSH.Recruitersallowed + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.allowrecruiters + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,RecuriterAllowed) values('" + UserID + "','" + objaccsettSH.allowrecruiters + "','" + objaccsettSH.Recruitersallowed + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void Savecontsett(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ContactSettings + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ContactSettings + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.ContactSettings + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public static DataTable Retrieveconsettdata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.ContactSettings + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public void SaveProflephoto(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.MyProfilephoto + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.MyProfilephoto + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.MyProfilephoto + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void SavePrefInd(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.PrefIndustries + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set IndustryPreference='" + objaccsettSH.IndustriesPref + "'where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.PrefIndustries + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,IndustryPreference) values('" + UserID + "','" + objaccsettSH.PrefIndustries + "','" + objaccsettSH.IndustriesPref + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
       
        public static DataTable Retrievepropicdata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.MyProfilephoto + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public void Savevisible(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.MyVisibility + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.MyVisibility + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.MyVisibility + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public static DataTable Retrievenisibledata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.MyVisibility + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable GetUserdata(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from [txnMemberAccount] where UserID='" + UserID + "' ;";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public void Saveacad(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.academics + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.academics + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.academics + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void Saveprojects(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.Projects + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.Projects + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.Projects + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void Saveprecmy(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.PresentCompany + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.PresentCompany + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.PresentCompany + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public void Savepastcmy(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.pastcompany + "'";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                string query2 = "UPDATE txnAccountSettings set EveryOne='" + objaccsettSH.everyone + "',MyContact='" + objaccsettSH.mycontacts + "',MyCommunities='" + objaccsettSH.mycommunities + "' where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.pastcompany + "'";
                objDataAccessLayer.ExecuteNonQuery(query2, CommandType.Text, ref ErrorMessage);

            }
            else
            {
                string query1 = "insert into txnAccountSettings (UserID,Settingtype,EveryOne,MyContact,MyCommunities) values('" + UserID + "','" + objaccsettSH.pastcompany + "','" + objaccsettSH.everyone + "','" + objaccsettSH.mycontacts + "','" + objaccsettSH.mycommunities + "')";
                objDataAccessLayer.ExecuteNonQuery(query1, CommandType.Text, ref ErrorMessage);

            }


        }
        public static DataTable Retrieveacaddata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.academics + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable Retrievepstcmydata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.pastcompany + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable RetrievePrescmydata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.PresentCompany + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable RetrieveProjectsdata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.Projects + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable Retrieveirsadata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.iRSANewsletter + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }

        public static DataTable RetrieveRAdata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.Recruitersallowed+ "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }

        public static DataTable RetrieveNamests(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.HideIdentity+ "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable RetrievePindData(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnAccountSettings where UserID='" + UserID + "' and Settingtype='" + objaccsettSH.PrefIndustries+ "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable Retrievesalarydata(int UserID, AccountSettingSH objaccsettSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnMemberAccount where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }

    }
}
