﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class CareerLadderBL
    {
        public static DataTable GetJobFamilyData()
        {

            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  JobFamilyName FROM lkpJobFamily ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

           
        }

        public DataTable GetSourceData(string JobFamily)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  JobFamilyID FROM lkpJobFamily where JobFamilyName='" + JobFamily + "' ";
            int JobFamilyID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            string query1 = "SELECT  Title FROM lkpOccupationData where ONETSOCCode like '" + JobFamilyID + "'+'%' ";
            return objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);

        }
        public DataTable GetDetailSourceData(string JobFamily, string SourceValue, string TargeValue, int i)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadderSource";
            IConnection = objDataAccessLayer.GetConnection();
            string query = "SELECT  JobFamilyID FROM lkpJobFamily where JobFamilyName='" + JobFamily + "' ";
            int JobFamilyID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));


            SqlParameter[] Parameters =
                {
           
            new SqlParameter("@selectedSource", SqlDbType.NVarChar,150),
            new SqlParameter("@SkillCount", SqlDbType.Int)
                };

            Parameters[0].Value = SourceValue;
            Parameters[1].Value = i;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }


        public DataTable GetOccupationCount(string JobFamily, string SourceValue, string TargeValue, int i)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_OccupationCount";
            IConnection = objDataAccessLayer.GetConnection();
            string query = "SELECT  JobFamilyID FROM lkpJobFamily where JobFamilyName='" + JobFamily + "' ";
            int JobFamilyID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            SqlParameter[] Parameters =
                {
            new SqlParameter("@JobFamilyID", SqlDbType.Char,2),
            new SqlParameter("@selectedSource", SqlDbType.NVarChar,150),
            new SqlParameter("@SkillCount", SqlDbType.Int),
            new SqlParameter("@selectedTarget", SqlDbType.NVarChar,150)
     
                };
            Parameters[0].Value = JobFamilyID;
            Parameters[1].Value = SourceValue;
            Parameters[2].Value = i;
            Parameters[3].Value = TargeValue;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;
        }

        public DataTable GetTargetData(string JobFamily, string SourceValue, string TargeValue, int i)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadder";
            IConnection = objDataAccessLayer.GetConnection();
            string query = "SELECT  JobFamilyID FROM lkpJobFamily where JobFamilyName='" + JobFamily + "' ";
            int JobFamilyID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            SqlParameter[] Parameters =
                {
            new SqlParameter("@JobFamilyID", SqlDbType.Char,2),
            new SqlParameter("@selectedSource", SqlDbType.NVarChar,150),
            new SqlParameter("@SkillCount", SqlDbType.Int),
            new SqlParameter("@selectedTarget", SqlDbType.NVarChar,150)
     
                };
            Parameters[0].Value = JobFamilyID;
            Parameters[1].Value = SourceValue;
            Parameters[2].Value = i;
            Parameters[3].Value = TargeValue;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;

        }


        public DataTable GetSourceZone(string Source)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetJobZone";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@selectedOccupation", SqlDbType.NVarChar,150)
                };
            Parameters[0].Value = Source;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();




            rowCountTarget.Load(drProjectTarget);

            return rowCountTarget;

        }


        //public DataTable GetDetailCLTask(string Onsetcode)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    string query = "SELECT b.task," +
        //        " '%Age' = Round(Cast(a.DataValue*20 as float(50)),0) FROM [IRSA].[dbo].[domTaskRatings] a join domTaskStatement " +
        //        " b  on a.TaskID = b.TaskID where a.ONETSOCCode = '" + Onsetcode + "' and a.ScaleID  = 'IM'";

        //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        //}

        //public DataTable GetDetailCLKnowlwdge(string Onsetcode)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    string query = "SELECT a.ElementName, b.Description, '%Age' = Round(Cast(a.DataValue*20 as float(50)),0)" +
        //        " FROM [IRSA].[dbo].[domKnowledge] a join [IRSA].[dbo].lkpContentModelReference  " +
        //        " b  on a.ElementID = b.ElementID where a.ONETSCOCode = '" + Onsetcode + "' and a.ScaleID  = 'IM' order by [%Age] desc";

        //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        //}
        //public DataTable GetDetailCLAbility(string Onsetcode)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    string query = "SELECT a.ElementName, b.Description, '%Age' = Round(Cast(a.DataValue*20 as float(50)),0)" +
        //        " FROM [IRSA].[dbo].[domAbilities] a join [IRSA].[dbo].lkpContentModelReference " +
        //        " b on a.ElementID = b.ElementID where a.ONETSOCCode = '" + Onsetcode + "' and a.ScaleID  = 'IM' order by [%Age] desc";

        //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        //}
        //public DataTable GetDetailCLSkills(string Onsetcode)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    string query = "SELECT a.ElementName, b.Description, '%Age' = Round(Cast(a.DataValue*20 as float(50)),0)" +
        //         " FROM [IRSA].[dbo].[domSkills] a join [IRSA].[dbo].lkpContentModelReference " +
        //         " b on a.ElementID = b.ElementID where a.ONETSOCCode  = '" + Onsetcode + "' and a.ScaleID  = 'IM' order by [%Age] desc";

        //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        //}
        //public DataTable GetDetailCLWorkActivities(string Onsetcode)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    string query = "SELECT a.ElementName, b.Description, '%Age' = Round(Cast(a.DataValue*20 as float(50)),0)" +
        //          " FROM [IRSA].[dbo].[domWorkActivities] a join [IRSA].[dbo].lkpContentModelReference " +
        //          " b   on a.ElementID = b.ElementID where a.ONETSOCCode = '" + Onsetcode + "' and a.ScaleID  = 'IM' order by [%Age] desc";

        //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        //}


        public DataTable GetDetailCLTask(string Onsetcode, int flag)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadderDetails";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@ONETSCOCode", SqlDbType.NVarChar,255),
            new SqlParameter("@flag", SqlDbType.Int),
           
     
                };
            Parameters[0].Value = Onsetcode;
            Parameters[1].Value = flag;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;


        }

        public DataTable GetDetailCLKnowlwdge(string Onsetcode, int flag)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadderDetails";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@ONETSCOCode", SqlDbType.NVarChar,255),
            new SqlParameter("@flag", SqlDbType.Int),
           
     
                };
            Parameters[0].Value = Onsetcode;
            Parameters[1].Value = flag;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;


        }
        public DataTable GetDetailCLAbility(string Onsetcode, int flag)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadderDetails";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@ONETSCOCode", SqlDbType.NVarChar,255),
            new SqlParameter("@flag", SqlDbType.Int),
           
     
                };
            Parameters[0].Value = Onsetcode;
            Parameters[1].Value = flag;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;

        }
        public DataTable GetDetailCLSkills(string Onsetcode, int flag)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadderDetails";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@ONETSCOCode", SqlDbType.NVarChar,255),
            new SqlParameter("@flag", SqlDbType.Int),
           
     
                };
            Parameters[0].Value = Onsetcode;
            Parameters[1].Value = flag;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;

        }
        public DataTable GetDetailCLWorkActivities(string Onsetcode, int flag)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_CareerLadderDetails";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@ONETSCOCode", SqlDbType.NVarChar,255),
            new SqlParameter("@flag", SqlDbType.Int),
           
     
                };
            Parameters[0].Value = Onsetcode;
            Parameters[1].Value = flag;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProjectTarget = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCountTarget = new DataTable();
            rowCountTarget.Load(drProjectTarget);
            return rowCountTarget;

        }

    }
}
    
      
  
  
  
 