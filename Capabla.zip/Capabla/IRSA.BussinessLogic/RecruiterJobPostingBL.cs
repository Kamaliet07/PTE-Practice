﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class RecruiterJobPostingBL
    {
        public static DataTable GetData(RecruiterJobPostingSh objsh)
        {
            int UserID = SessionInfo.UserId;
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_JobSearchRecuiter";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
          

           
            new SqlParameter("@Title", SqlDbType.NVarChar, 50),
            new SqlParameter("@Postingdate",SqlDbType.NVarChar, 15),
            new SqlParameter("@Expirationdate",SqlDbType.NVarChar, 15),
             new SqlParameter("@UserID",SqlDbType.Int),
           
          
                };
          
            Parameters[0].Value = objsh.Title;
            Parameters[1].Value = objsh.From;
            Parameters[2].Value = objsh.To;
            Parameters[3].Value = UserID;
         


            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          
            //int UserID = SessionInfo.UserId;
            //string ErrorMessage = "No Data Found";
            //string ConnectionString = GlobalMethod.GetConnectionString();
            //string dbType = GlobalMethod.GetDbType();
            //Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            //IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            //objDataAccessLayer.ConnectionString = ConnectionString;
            //string query = "SELECT COUNT(dbo.txnUserAppliedJob.JobID) AS Candidates, dbo.txnJobPosting.JobID, dbo.txnJobPosting.Title, dbo.txnJobPosting.ExpirationDate,dbo.txnJobPosting.Skills,dbo.txnJobPosting.JobDescription,dbo.txnJobPosting.Education,dbo.txnJobPosting.JobType,dbo.txnJobPosting.JobLocation,  dbo.txnUserAppliedJob.JobID AS Candidates FROM dbo.txnJobPosting LEFT OUTER JOIN dbo.txnUserAppliedJob ON dbo.txnJobPosting.JobID = dbo.txnUserAppliedJob.JobID  where  dbo.txnJobPosting.Title='" + objsh.Title + "' and dbo.txnJobPosting.PostingDate>='" + objsh.From + "'  and dbo.txnJobPosting.ExpirationDate<= '" + objsh.To + "' GROUP BY dbo.txnJobPosting.JobID, dbo.txnJobPosting.Title, dbo.txnJobPosting.ExpirationDate, dbo.txnUserAppliedJob.JobID,dbo.txnJobPosting.Skills,dbo.txnJobPosting.JobDescription,dbo.txnJobPosting.Education,dbo.txnJobPosting.JobType,dbo.txnJobPosting.JobLocation ";
            //return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
         
        }

        public static DataTable GetDataDefault()
        {
            int UserID = SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT COUNT(dbo.txnUserAppliedJob.JobID) AS Candidates,dbo.txnJobPosting.Sponser, dbo.txnJobPosting.JobID, dbo.txnJobPosting.Title, dbo.txnJobPosting.ExpirationDate,dbo.txnJobPosting.Skills,dbo.txnJobPosting.JobDescription,dbo.txnJobPosting.Education,dbo.txnJobPosting.JobType,dbo.txnJobPosting.JobLocation,  dbo.txnUserAppliedJob.JobID AS Candidates FROM dbo.txnJobPosting LEFT OUTER JOIN dbo.txnUserAppliedJob ON dbo.txnJobPosting.JobID = dbo.txnUserAppliedJob.JobID  where txnJobPosting.UserID='" + UserID + "'and txnJobPosting.Deleted='False' GROUP BY dbo.txnJobPosting.JobID, dbo.txnJobPosting.Title, dbo.txnJobPosting.ExpirationDate, dbo.txnUserAppliedJob.JobID,dbo.txnJobPosting.Skills,dbo.txnJobPosting.JobDescription,dbo.txnJobPosting.Education,dbo.txnJobPosting.JobType,dbo.txnJobPosting.JobLocation,dbo.txnJobPosting.Sponser  ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }


        public static void GetDeleteData(int JobID)
        {  
      
            int UserID = SessionInfo.UserId;

            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Update txnJobPosting set Deleted='True' from  txnJobPosting where JobID='" + JobID + "'";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
     
        }
    }
}
