﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class MyJobAgentBL
    {
        string UserID;

        //To get Agent Count
        public static int getAgentCount(int Uid,string cultID)
        {
            string ErrMsg = "Error";
            int count=0;
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select count(*) from [txnUserJobAgent] where UserID='" + Uid + "' and deleted='false' and CultureID='"+cultID+"'";
            count = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrMsg));
            return count;
            
         }

        //To retrieve Job Family Data
        public static DataTable GetJobFamilyData()
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "sp_RetrieveJobFamilyData";
            IConnection = objDataAccessLayer.GetConnection();
            //SqlParameter[] Parameters =
            //    {
                 
            //     new SqlParameter("@UserID", SqlDbType.Int),
            //     new SqlParameter("@Flag",SqlDbType.Int)
                             
            //    };
            //Parameters[0].Value = UserID;
            //Parameters[1].Value = flag;
            //cmd.Parameters.AddRange(Parameters);
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;
        }

        //To retrieve Job Family ID from Job Family Name
        public static string getJobFamilyID(string jobFamily)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  JobFamilyId FROM lkpJobFamily WHERE JobFamilyName='" + jobFamily + "'";
            string id= Convert.ToString(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return id;       
        }

        //To retrieve Occupation ID from Occupation Name
        public static string getOccupationID(string occ)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  ONETSOCCode FROM lkpOccupationData WHERE Title='" + occ + "'";
            DataTable dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            String id = dt.Rows[0]["ONETSOCCode"].ToString();
            return id;
        } 

        //To insert Job Agent Data
        public static void insertJobAgentData(MyJobAgentSH objsh,string cultID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_MyJobAgent";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
            {
                    
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@AgentName",SqlDbType.NVarChar,50),
            new SqlParameter("@KeyWord",SqlDbType.NVarChar,50),
            new SqlParameter("@Location",SqlDbType.Bit),
            new SqlParameter("@Country",SqlDbType.NVarChar,20),
            new SqlParameter("@City",SqlDbType.NVarChar,20),
            new SqlParameter("@YearsExperience",SqlDbType.Int),
            new SqlParameter("@JobFamilyID",SqlDbType.Char,2),
            new SqlParameter("@JobType",SqlDbType.VarChar,20),
            new SqlParameter("@OccupationID",SqlDbType.VarChar,20),
            new SqlParameter("@UpdateOnMobile",SqlDbType.Bit),
            new SqlParameter("@UpdateOnEmail",SqlDbType.Bit),
            new SqlParameter("@JobAlertNoMobile",SqlDbType.Int),
            new SqlParameter("@JobAlertNoEmail",SqlDbType.Int),
            new SqlParameter("@FrequencyEmail",SqlDbType.VarChar,50),
            new SqlParameter("@FrequencyMobile",SqlDbType.VarChar,50),
            new SqlParameter("@PostedEmail",SqlDbType.VarChar,50),
            new SqlParameter("@PostedMobile",SqlDbType.VarChar,50),
            new SqlParameter("@PayCurrency",SqlDbType.NChar,10),
            new SqlParameter("@PreferredSalary",SqlDbType.Money),
            new SqlParameter("@AvailabilityFrom",SqlDbType.VarChar,50),
            new SqlParameter("@AvailabilityTo",SqlDbType.VarChar,50),
            new SqlParameter("@Deleted",SqlDbType.Bit),
            new SqlParameter("@CreateDate",SqlDbType.NVarChar,50),
            new SqlParameter("@JobLocation",SqlDbType.NVarChar,150),
            new SqlParameter("@CultureID",SqlDbType.Char,2)
            };
            Parameters[0].Value = objsh.UserID ;
            Parameters[1].Value = objsh.AgentName;
            Parameters[2].Value = objsh.KeyWord;
            Parameters[3].Value = objsh.Location;
            Parameters[4].Value = objsh.Country;
            Parameters[5].Value = objsh.City;
            Parameters[6].Value = objsh.Experience;
            Parameters[7].Value = objsh.JobFamilyID;
            Parameters[8].Value = objsh.JobType;
            Parameters[9].Value = objsh.OccupationID;
            Parameters[10].Value = objsh.UpdateOnMobile;
            Parameters[11].Value = objsh.UpdateOnEmail;
            Parameters[12].Value = objsh.JobAlertNoMobile;
            Parameters[13].Value = objsh.JobAlertNoEmail;
            Parameters[14].Value = objsh.FrequencyEmail;
            Parameters[15].Value = objsh.FrequencyMobile;
            Parameters[16].Value = objsh.PostedEmail;
            Parameters[17].Value = objsh.PostedMobile;
            Parameters[18].Value = objsh.PayCurrency;
            Parameters[19].Value = objsh.PreferredSalary;
            Parameters[20].Value = objsh.AvailabilityFrom;
            Parameters[21].Value = objsh.AvailabilityTo;
            Parameters[22].Value = false;
            Parameters[23].Value = objsh.CreateDate;
            Parameters[24].Value = (objsh.City + "," + objsh.Country);
            Parameters[25].Value = cultID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);

        }

        /*To retrieve the occupation list corresponding to Job Family*/
        public static DataTable getOccupationData(string JobFamily)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  JobFamilyID FROM lkpJobFamily where JobFamilyName='" + JobFamily + "' ";
            int JobFamilyID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return MyJobAgentBL.getOccupations(JobFamilyID);
            //string query1 = "SELECT  Title FROM lkpOccupationData where ONETSOCCode like '" + JobFamilyID + "'+'%' ";
            //return objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);

        }

        protected static DataTable getOccupations(int JFID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "sp_RetrieveOccupationData";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {

                 new SqlParameter("@JobFamilyID", SqlDbType.Char,2)
                };
            Parameters[0].Value = JFID;
            cmd.Parameters.AddRange(Parameters);
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;
        }

        //To retrieve the table of all the agents associated with the particular User
        public static DataTable getAgentDataTable(int UserID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT AgentName,CreateDate FROM [txnUserJobAgent] WHERE UserID='" + UserID + "' and CultureID='"+cultID+"' and deleted='false' ORDER BY CreateDate";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        //To retrieve all details of a particular agent
        public static MyJobAgentSH retrieveAgent(string agentName,int UserID,string cultID)
        {
            MyJobAgentSH resultSH=new MyJobAgentSH();
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT * FROM [txnUserJobAgent] WHERE UserID='" + UserID + "' and deleted='false' and AgentName='" + agentName + "' and CultureID='"+cultID+"'";
            DataTable dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            try
            {
                //storing all the values from table to the object of Shared class
                resultSH.AgentName = dt.Rows[0]["AgentName"].ToString();
                resultSH.KeyWord = dt.Rows[0]["KeyWord"].ToString();
                resultSH.Location = Convert.ToBoolean(dt.Rows[0]["Location"]);
                resultSH.Country = dt.Rows[0]["Country"].ToString();
                resultSH.City = dt.Rows[0]["City"].ToString();
                resultSH.Experience =Convert.ToInt32(dt.Rows[0]["YearsExperience"]);
                resultSH.JobFamilyID = dt.Rows[0]["JobFamilyID"].ToString();
                resultSH.OccupationID = dt.Rows[0]["OccupationID"].ToString();
                resultSH.UpdateOnMobile = Convert.ToBoolean(dt.Rows[0]["UpdateOnMobile"]);
                resultSH.UpdateOnEmail = Convert.ToBoolean(dt.Rows[0]["UpdateOnEmail"]);
                resultSH.JobAlertNoMobile = Convert.ToInt32(dt.Rows[0]["JobAlertNoMobile"]);
                resultSH.JobAlertNoEmail = Convert.ToInt32(dt.Rows[0]["JobAlertNoEmail"]);
                resultSH.FrequencyEmail = (dt.Rows[0]["FrequencyEmail"]).ToString();
                resultSH.FrequencyMobile = (dt.Rows[0]["FrequencyMobile"]).ToString();
                resultSH.PostedEmail = (dt.Rows[0]["PostedEmail"]).ToString();
                resultSH.PostedMobile = (dt.Rows[0]["PostedMobile"]).ToString();
                resultSH.JobType = dt.Rows[0]["JobType"].ToString();
                resultSH.PayCurrency = dt.Rows[0]["PayCurrency"].ToString();
                resultSH.PreferredSalary = Convert.ToDouble(dt.Rows[0]["PreferredSalary"]);
                resultSH.AvailabilityFrom = dt.Rows[0]["AvailabilityFrom"].ToString();
                resultSH.AvailabilityTo = dt.Rows[0]["AvailabilityTo"].ToString();
                resultSH.CreateDate = dt.Rows[0]["CreateDate"].ToString();
                resultSH.UserID = UserID;
                resultSH.Deleted = Convert.ToBoolean(dt.Rows[0]["Deleted"]);
               
            }
            catch
            {
            }
            return resultSH;
        }

        //To retrieve the job family name from job family ID
        public static string getFamilyName(string familyID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  JobFamilyName FROM lkpJobFamily WHERE JobFamilyId='" + familyID + "'";
            string name = Convert.ToString(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return name;  
        }
        //To retrieve the occupation name from occupation ID
        public static string getOccupationName(string OccID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  Title FROM lkpOccupationData WHERE ONETSOCCode='" + OccID + "'";
            string name = Convert.ToString(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return name;
        }

        //To delete Job Agent
        public static void deleteAgent(string agentName, int UserID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "UPDATE txnUserJobAgent SET Deleted='true' WHERE Deleted='false' AND UserID='" + UserID + "' AND AgentName='" + agentName + "' AND CultureID='"+cultID+"'";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
            
        }
        
        //To check whether the agent exists with the same name
        public static Boolean doAgentExists(string agentName, int UserID,string cultID)
        {
            string ErrMsg = "Error";
            int count = 0;
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select count(*) from [txnUserJobAgent] where UserID='" + UserID + "' and deleted='false' and AgentName='" + agentName + "' and CultureID='"+cultID+"'";
            count = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrMsg));
            if (count >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //Search all fit Job for the candidate using job agent search criteria
        public static DataTable candidateViewJobs(string agentName, int UserID)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_JobAgentViewJobNew";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
            {
                    
            new SqlParameter("@UserID",SqlDbType.Int,50),
            new SqlParameter("@AgentName",SqlDbType.NVarChar,50),
           
            };
            Parameters[0].Value = UserID;
            Parameters[1].Value = agentName;

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }


        public static DataTable getAppliedJob(int jobID, int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_CandidateAppliedViewJob";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
            {
                    
            new SqlParameter("@UserID",SqlDbType.Int,50),
            new SqlParameter("@jobID",SqlDbType.Int,50),
            new SqlParameter("@Flag",SqlDbType.Int,50)
           
            };
            Parameters[0].Value = UserID;
            Parameters[1].Value = jobID;
            Parameters[2].Value = 2;

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }

   }
}
