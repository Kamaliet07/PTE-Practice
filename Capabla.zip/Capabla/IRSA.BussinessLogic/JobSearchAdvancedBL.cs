﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Facade;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class JobSearchAdvancedBL
   {
       public static DataTable JobData(string Keywords, JobSearchAdvancedSH objJobSearchAdvancedSH)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          // cmdProject.CommandText = "usp_JobSearchAdvanced";
           //cmdProject.CommandText = "usp_AdvancedJobSearch";
           cmdProject.CommandText = "search_job";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
                 
                 //new SqlParameter("@Industryname", SqlDbType.NVarChar,80 ),
                 //new SqlParameter("@orgCity", SqlDbType.NVarChar,50 ),
                 // new SqlParameter("@orgCountry", SqlDbType.NVarChar,50 ),
                 // new SqlParameter("@Jobfamily", SqlDbType.NVarChar,80 ),
                 new SqlParameter("@Title", SqlDbType.NVarChar,150 ),
                 new SqlParameter("@Company", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@orgCity", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@JobType", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@orgCountry", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@Industryname", SqlDbType.NVarChar,80 ),
                 //new SqlParameter("@Company", SqlDbType.NVarChar,50 ),
                 //new SqlParameter("@JobType", SqlDbType.NVarChar,50 ),
                 //new SqlParameter("@Industryname", SqlDbType.NVarChar,80 ),
                 //new SqlParameter("@Jobfamily", SqlDbType.NVarChar,80 ),
                 //new SqlParameter("@Keywords", SqlDbType.NVarChar,250 ),
                  new SqlParameter("@JobFamily", SqlDbType.NVarChar,150),
                  new SqlParameter("@ExperienceFrom", SqlDbType.Int ),
                  new SqlParameter("@ExperienceTo", SqlDbType.Int ),
                  new SqlParameter("@searchtext", SqlDbType.NVarChar,80 ),
                 
              
                 
            
                };
           Parameters[0].Value = objJobSearchAdvancedSH.Title;
           Parameters[1].Value = objJobSearchAdvancedSH.CompanyName;
           Parameters[2].Value = objJobSearchAdvancedSH.City;
           Parameters[3].Value = objJobSearchAdvancedSH.JobType;
           Parameters[4].Value = objJobSearchAdvancedSH.CountryName;
           Parameters[5].Value = objJobSearchAdvancedSH.IndustryName;
           Parameters[6].Value = objJobSearchAdvancedSH.JobFamilyName;
           Parameters[7].Value = objJobSearchAdvancedSH.ExperienceFrom;
           Parameters[8].Value = objJobSearchAdvancedSH.ExperienceTo;
           Parameters[9].Value = Keywords;

           //Parameters[9].Value = objJobSearchAdvancedSH.ExperienceTo;
           //Parameters[0].Value = objJobSearchAdvancedSH.IndustryName;
           //Parameters[1].Value = objJobSearchAdvancedSH.City;
           //Parameters[2].Value = objJobSearchAdvancedSH.CountryName;
           //Parameters[3].Value = objJobSearchAdvancedSH.JobFamilyName;
           //Parameters[4].Value = objJobSearchAdvancedSH.Title;
           //Parameters[5].Value = objJobSearchAdvancedSH.JobType;
           //Parameters[6].Value = objJobSearchAdvancedSH.CompanyName;
           //Parameters[7].Value = Keywords;
           //Parameters[8].Value = objJobSearchAdvancedSH.ExperienceFrom;
           //Parameters[9].Value = objJobSearchAdvancedSH.ExperienceTo;


           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject1);
           return rowCount;

       }
      
       public static DataTable BindFamilyData()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select JobFamilyName from lkpJobFamily;";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
    }
}
