﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class addconnectionBL
    {
       public static DataTable GetPersonDataDetails(int UserID, string FirstName)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmd = new SqlCommand();
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmd.CommandText = "sp_GetConnectionData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@UserID", SqlDbType.Int),
                 new SqlParameter("@FirstName", SqlDbType.NVarChar ,50),
            
                };
           Parameters[0].Value = UserID;
           Parameters[1].Value = FirstName;
           cmd.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public void GetviewActive(int UserID, int NetworkUserID)
       {
           string ErrorMessage = "";


           IDbCommand Command;
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
           Command = objDALFactory.CreateCommand();
           Command.CommandType = System.Data.CommandType.Text;
           IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Update  txnUserNetworkList  set  WhoCanSee='1' where UserID='" + UserID + "'and NetworkUserID='" + NetworkUserID + "'";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);



       }
    }
}
