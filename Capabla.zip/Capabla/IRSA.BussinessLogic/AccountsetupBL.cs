﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class AccountsetupBL
    {
       string UserID;
       public static DataTable RetrieveData(int UserID)
       {
           string ErrorMessage = "";


           IDbCommand Command;
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
           Command = objDALFactory.CreateCommand();
           Command.CommandType = System.Data.CommandType.Text;
           IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select * from [txnMemberAccount] where UserID='" + UserID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



       }

       //public static DataTable delcmygriddata(int UserID)
       //{
       //    string ErrorMessage = "";


       //    IDbCommand Command;
       //    string ConnectionString = GlobalMethod.GetConnectionString();
       //    string dbType = GlobalMethod.GetDbType();
       //    IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
       //    Command = objDALFactory.CreateCommand();
       //    Command.CommandType = System.Data.CommandType.Text;
       //    IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
       //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
       //    objDataAccessLayer.ConnectionString = ConnectionString;
       //    string query = "DELETE from [txnMemberCompany] where UserID='" + UserID + "'";
       //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



       //}

       public void SaveEducationData(AccountsetupSH ObjaccsetupSH, int UserID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            query = "UPDATE txnMemberAccount SET Education='" + ObjaccsetupSH.Education + "' where UserID='" + UserID + "'";
             objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
      
       public void SaveAccountSetUpData(AccountsetupSH ObjaccsetupSH, int UserID, string step, int AccountWelcome, int Experience, int PresentCompany, int PastCompany, int Acadimic, int Projects)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_AccountSetup";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
                    
            new SqlParameter("@Country",SqlDbType.NVarChar, 50),
            new SqlParameter("@PostalCode",SqlDbType.NVarChar, 20),
            new SqlParameter("@ProfessionalTitle ", SqlDbType.NVarChar, 250),
            new SqlParameter("@Sex ",SqlDbType.NVarChar, 20),
            new SqlParameter("@Phone ",SqlDbType.NVarChar, 20),
            new SqlParameter("@City ",SqlDbType.NVarChar, 50),
            new SqlParameter("@State ",SqlDbType.NVarChar, 50),
             new SqlParameter("@DateOfBirth ",SqlDbType.NVarChar, 50),
           new SqlParameter("@PhotoID ",SqlDbType.NVarChar, 50),
            
            new SqlParameter("@FirstName", SqlDbType.NChar, 15),
            new SqlParameter("@LastName", SqlDbType.NChar, 15),
            new SqlParameter("@DisplayName ", SqlDbType.NChar, 30),
            new SqlParameter("@HighestDegree",SqlDbType.NVarChar, 50),
            new SqlParameter("@PassingYear ",SqlDbType.Int),
            new SqlParameter("@University ",SqlDbType.NVarChar, 50),
            new SqlParameter("@AdditionalNotes  ",SqlDbType.NVarChar, 250),
            new SqlParameter("@Specialization  ",SqlDbType.NVarChar, 150),
            new SqlParameter("@SplPasingYear  ",SqlDbType.Int),
            new SqlParameter("@InstituteName  ",SqlDbType.NVarChar, 100),
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@Step",SqlDbType.NVarChar,20),
            new SqlParameter("@Company",SqlDbType.NVarChar, 50),
            new SqlParameter("@ONETSOCCode  ",SqlDbType.NVarChar,250), 
            new SqlParameter("@Description  ",SqlDbType.NVarChar, 1500),
            new SqlParameter("@WorkingFrom  ",SqlDbType.NVarChar, 100),
            new SqlParameter("@WorkingTo  ",SqlDbType.NVarChar, 100),
            new SqlParameter("@Countryprecmy  ",SqlDbType.NVarChar, 20),
            new SqlParameter("@Postalcodeprecmy  ",SqlDbType.NVarChar,50),
            new SqlParameter("@Designation   ",SqlDbType.NVarChar, 50),
            
            new SqlParameter("@OthersIndustry ",SqlDbType.NVarChar, 250),
            new SqlParameter("@KeySkills ",SqlDbType.NVarChar, 100),
            new SqlParameter("@AnnualSalary ",SqlDbType.Money),
            new SqlParameter("@SalaryCurrency ",SqlDbType.NVarChar, 100),
            new SqlParameter("@TotalExperience ",SqlDbType.Int),
            new SqlParameter("@ResumeID ",SqlDbType.NVarChar, 50),
            
            new SqlParameter("@ProjectName   ",SqlDbType.NVarChar, 50),
           new SqlParameter("@ClientName   ",SqlDbType.NVarChar, 50),
           new SqlParameter("@Skills   ",SqlDbType.NVarChar, 150),
           new SqlParameter("@Location   ",SqlDbType.NVarChar, 500),
           new SqlParameter("@DurationFrom   ",SqlDbType.NVarChar, 100),
           new SqlParameter("@DurationTo   ",SqlDbType.NVarChar, 100),
           new SqlParameter("@PastCompName  ",SqlDbType.NVarChar, 100),
           new SqlParameter("@Functionalarea",SqlDbType.NVarChar,100),
           new SqlParameter("@CompanyURL", SqlDbType.NVarChar,50),
           new SqlParameter("@ProfessionalExp", SqlDbType.NVarChar,1500),


                       new SqlParameter("@ProfileStatusAccount",SqlDbType.Int), 
            new SqlParameter("@ProfileStatusExp",SqlDbType.Int),

           new SqlParameter("@ProfileStatusnPresentCompany",SqlDbType.Int),
                new SqlParameter("@ProfileStatusPastCompany",SqlDbType.Int),
                  
                    new SqlParameter("@ProfileStatusAcademics",SqlDbType.Int),
                      new SqlParameter("@ProfileStatusProjects",SqlDbType.Int),
                        new SqlParameter("@MaritalStatus",SqlDbType.NVarChar,20),
                          new SqlParameter("@DrivingLicence",SqlDbType.Bit),
                          new SqlParameter("@Education",SqlDbType.NVarChar,2048),
                          new SqlParameter("@HouseNo",SqlDbType.NVarChar,50),
                           new SqlParameter("@Placeofbirth",SqlDbType.NVarChar,50),
                            new SqlParameter("@Countryofbirth",SqlDbType.NVarChar,50),
                             new SqlParameter("@Nationality",SqlDbType.NVarChar,50),
                               new SqlParameter("@SpecializationArea",SqlDbType.NVarChar,100)


            };
           Parameters[0].Value = ObjaccsetupSH.Country;
           Parameters[1].Value = ObjaccsetupSH.Postalcode;
           Parameters[2].Value = ObjaccsetupSH.Professionaltitle;
           Parameters[3].Value = ObjaccsetupSH.sex;
           Parameters[4].Value = ObjaccsetupSH.Phone;
           Parameters[5].Value = ObjaccsetupSH.City;
           Parameters[6].Value = ObjaccsetupSH.State;
           Parameters[7].Value = ObjaccsetupSH.dateofbirth;
           Parameters[8].Value = ObjaccsetupSH.Photo;
          
           Parameters[9].Value = ObjaccsetupSH.FirstName;
           Parameters[10].Value = ObjaccsetupSH.LastName;
           Parameters[11].Value = ObjaccsetupSH.DisplayName;
           Parameters[12].Value = ObjaccsetupSH.HighestDegree;
           if (ObjaccsetupSH.PassingYear != int.MinValue)
           {
               Parameters[13].Value = ObjaccsetupSH.PassingYear;
           }
           else
           {
               Parameters[13].Value = 0;
           }

           Parameters[14].Value = ObjaccsetupSH.University;
           Parameters[15].Value = ObjaccsetupSH.AdditionalNotes;
           Parameters[16].Value = ObjaccsetupSH.Specialization;
           if (ObjaccsetupSH.SplPasingYear != int.MinValue)
           {
               Parameters[17].Value = ObjaccsetupSH.SplPasingYear;
           }
           else
           {
               Parameters[17].Value = 0;
           }

           Parameters[18].Value = ObjaccsetupSH.InstituteName;
           Parameters[19].Value = UserID;
           Parameters[20].Value = step;
           Parameters[21].Value = ObjaccsetupSH.Company;
           Parameters[22].Value = ObjaccsetupSH.Occupation;
           Parameters[23].Value = ObjaccsetupSH.Description;
           Parameters[24].Value = ObjaccsetupSH.WorkingFrom;
           Parameters[25].Value = ObjaccsetupSH.WorkingTo;
           Parameters[26].Value = ObjaccsetupSH.Countryprecmy;
           Parameters[27].Value = ObjaccsetupSH.PostalCode;
           Parameters[28].Value = ObjaccsetupSH.Designation;
           Parameters[29].Value = ObjaccsetupSH.OtherIndustry;
           Parameters[30].Value = ObjaccsetupSH.KeySkills;
           Parameters[31].Value = ObjaccsetupSH.AnnualSalary;
           Parameters[32].Value = ObjaccsetupSH.SalaryCurrency;
           Parameters[33].Value = ObjaccsetupSH.TotalExperience;
           Parameters[34].Value = ObjaccsetupSH.ResumeID;


           Parameters[35].Value = ObjaccsetupSH.ProjectName;
           Parameters[36].Value = ObjaccsetupSH.ClientName;
           Parameters[37].Value = ObjaccsetupSH.Skills;
           Parameters[38].Value = ObjaccsetupSH.Location;
           Parameters[39].Value = ObjaccsetupSH.DurationFrom;
           Parameters[40].Value = ObjaccsetupSH.DurationTo;
           Parameters[41].Value = ObjaccsetupSH.pastcompnyname;
           //Parameters[42].Value = ObjaccsetupSH.IndustryName;
           Parameters[42].Value = ObjaccsetupSH.Functionalarea;
           Parameters[43].Value = ObjaccsetupSH.CompanyURL;
           Parameters[44].Value = ObjaccsetupSH.ProfessionalExp;
           Parameters[45].Value = AccountWelcome;
           Parameters[46].Value = Experience;
           Parameters[47].Value = PresentCompany;
           Parameters[48].Value = PastCompany;

           Parameters[49].Value = Acadimic;
           Parameters[50].Value = Projects;
           Parameters[51].Value =ObjaccsetupSH.MaritalStatus;
           Parameters[52].Value = ObjaccsetupSH.DrivingLicence;
           Parameters[53].Value = ObjaccsetupSH.Education;
           Parameters[54].Value = ObjaccsetupSH.HouseNo;
           Parameters[55].Value = ObjaccsetupSH.Placeofbirth;
           Parameters[56].Value = ObjaccsetupSH.Countryofbirth;
           Parameters[57].Value = ObjaccsetupSH.Nationality;
           Parameters[58].Value = ObjaccsetupSH.SpecializationArea;
           
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);





       }

        public static DataTable RetrieveAcademicGridData(int UserID, string HighestDegree)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberAcademics where UserID='" + UserID + "' and HighestDegree='" + HighestDegree + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable RetrievePastcmygrdData(int UserID, string Company)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberCompany where UserID='" + UserID + "' and Company='" + Company + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable RetrievescData(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberAccount where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable RetrieveAssoData(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberAssociations where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable RetrieveLicData(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberLicenseandCertifications where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable RetrieveVisaData(int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetAdditionalInfo";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
               new SqlParameter("@UserID", SqlDbType.Int)
           
     
                };
            Parameters[0].Value = UserID;
          

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;

        }
        public void SaveVisaData(AccountsetupSH ObjaccsetupSH, int UserID, string step, string headtext)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_Accountadditional";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                  new SqlParameter("@UserID",SqlDbType.Int),   
                  new SqlParameter("@WorkPermitName ",SqlDbType.NVarChar, 50),
                  new SqlParameter("@Country",SqlDbType.NVarChar, 50),
                  new SqlParameter("@ValidFrom",SqlDbType.NVarChar, 50),
                  new SqlParameter("@ValidTo",SqlDbType.NVarChar, 50),
                  new SqlParameter("@SCName",SqlDbType.NVarChar, 50),
                  new SqlParameter("@SCIssuingAuthority",SqlDbType.NVarChar, 100),
                  new SqlParameter("@SCDescription",SqlDbType.NVarChar, 500),
                  new SqlParameter("@SCObtained",SqlDbType.NVarChar, 50),
                  new SqlParameter("@SCVaildFrom",SqlDbType.NVarChar, 50),
                  new SqlParameter("@SCVaildTo",SqlDbType.NVarChar, 50),
                  new SqlParameter("@AwardsandAchievements",SqlDbType.NVarChar, 2000),
                  new SqlParameter("@AName",SqlDbType.NVarChar, 50),
                  new SqlParameter("@AURL",SqlDbType.NVarChar, 50),
                  new SqlParameter("@ASinceDate",SqlDbType.NVarChar, 50),
                  new SqlParameter("@AUntilDate",SqlDbType.NVarChar, 50),
                  new SqlParameter("@LCName ",SqlDbType.NVarChar, 50),
                  new SqlParameter("@LCICAndName",SqlDbType.NVarChar, 50),
                  new SqlParameter("@LCIssuedBy ",SqlDbType.NVarChar, 100),
                  new SqlParameter("@LCValidfrom ",SqlDbType.NVarChar, 50),
                  new SqlParameter("@LCValidto",SqlDbType.NVarChar, 50),
                  new SqlParameter("@PersonalInterest",SqlDbType.NVarChar, 250),
                  new SqlParameter("@LanguageSkill",SqlDbType.NVarChar, 200),
                  new SqlParameter("@ComputerSkill",SqlDbType.Bit),
                  new SqlParameter("@headText",SqlDbType.NVarChar,50),
               };
            Parameters[0].Value = UserID;
            Parameters[1].Value = ObjaccsetupSH.Workpermit;
            Parameters[2].Value = ObjaccsetupSH.VisaCountry;
            Parameters[3].Value = ObjaccsetupSH.WPvalidFrm;
            Parameters[4].Value = ObjaccsetupSH.WPValidTo;
            Parameters[5].Value = ObjaccsetupSH.SecurityClearance;
            Parameters[6].Value = ObjaccsetupSH.SCIssuingAuthority;
            Parameters[7].Value = ObjaccsetupSH.SCDescription;
            Parameters[8].Value = ObjaccsetupSH.SCObtained;
            Parameters[9].Value = ObjaccsetupSH.SCValidfrm;
            Parameters[10].Value = ObjaccsetupSH.SCValidto;
            Parameters[11].Value = ObjaccsetupSH.Awards;
            Parameters[12].Value = ObjaccsetupSH.AssociationName;
            Parameters[13].Value = ObjaccsetupSH.AssociationURL;
            Parameters[14].Value = ObjaccsetupSH.AssoSince;
            Parameters[15].Value = ObjaccsetupSH.AssoUntil;
            Parameters[16].Value = ObjaccsetupSH.Licensename;
            Parameters[17].Value = ObjaccsetupSH.LicenseID;
            Parameters[18].Value = ObjaccsetupSH.LicenseIssuedby;
            Parameters[19].Value = ObjaccsetupSH.LicenseValidfrm;
            Parameters[20].Value = ObjaccsetupSH.LicenseValidTo;
            Parameters[21].Value = ObjaccsetupSH.PersonalInterest;
            Parameters[22].Value = ObjaccsetupSH.LangSkill;
            Parameters[23].Value = ObjaccsetupSH.CompSkill;
            Parameters[24].Value = headtext;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);





        }

       public static DataTable RetrieveVisaGridData(int UserID, string WorkPermitName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberVisaInformation where UserID='" + UserID + "' and WorkPermitName='" + WorkPermitName + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
       public static DataTable RetrieveAssoGridData(int UserID, string AName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberAssociations where UserID='" + UserID + "' and AName='" + AName + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
       public void SavePhoto(string photo, int UserID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string Query = "Select UserID from txnMemberAccount where UserID='" + UserID + "'";
            DataTable dt = new DataTable();
            dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                query = "UPDATE txnMemberAccount SET PhotoID='" + photo + "' where UserID='" + UserID + "'";
            }
            else
            {
                query = "Insert into txnMemberAccount (PhotoID) values  ('" + photo + "')";
            }
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

       public void removePhoto(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string Query = "Select UserID from txnMemberAccount where UserID='" + UserID + "'";
            DataTable dt = new DataTable();
            dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                query = "UPDATE txnMemberAccount SET PhotoID='0.png' where UserID='" + UserID + "'";
            }
            else
            {
                query = "Insert into txnMemberAccount (PhotoID) values  ('0.png')";
            }
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
       public static DataTable RetrievelicGridData(int UserID, string LCName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberLicenseandCertifications where UserID='" + UserID + "' and LCName='" + LCName + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
       public void delvisagridData(int UserID, string WorkPermitName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Delete From txnMemberVisaInformation where UserID='" + UserID + "' and WorkPermitName='" + WorkPermitName + "' ";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
       public void delassogridData(int UserID, string AName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Delete From txnMemberAssociations where UserID='" + UserID + "' and AName='" + AName + "' ";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
       public void dellicgridData(int UserID, string LCName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Delete From txnMemberLicenseandCertifications where UserID='" + UserID + "' and LCName='" + LCName + "' ";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
       public void delcmygridData(int UserID, string Company)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Delete From txnMemberCompany where UserID='" + UserID + "' and Company='" + Company + "' ";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

       public void delacadgridData(int UserID, string HighestDegree)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Delete From txnMemberAcademics where UserID='" + UserID + "' and HighestDegree='" + HighestDegree + "' ";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

       public void delprojgridData(int UserID, string ProjectName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Delete From txnProjectDetails where UserID='" + UserID + "' and ProjectName='" + ProjectName + "' ";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

       public static DataTable RetrieveProjectGridData(int UserID, string ProjectName)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnProjectDetails where UserID='" + UserID + "' and ProjectName='" + ProjectName + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
       
        public static DataTable RetrieveCompanyGridData(int UserID, string Company)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * From txnMemberCompany where UserID='" + UserID + "' and Company='" + Company + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public DataTable RetrieveAccountData(int UserID,string step)
       {
          IDbConnection IConnection = null;
                string ErrorMessage = "Question Answers  Is not Added";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand cmdProject = new SqlCommand();
                cmdProject.CommandType = CommandType.StoredProcedure;
                cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                cmdProject.CommandText = "sp_GetAccountSetup";
                IConnection = objDataAccessLayer.GetConnection();
                SqlParameter[] Parameters =
                {
               new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@step", SqlDbType.NVarChar, 20)
     
                };
                Parameters[0].Value = UserID;
                Parameters[1].Value = step;
       
               cmdProject.Parameters.AddRange(Parameters);
                SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(drProject);
                return rowCount;

       }

        public static DataTable BindoccupationData()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select Title From lkpOccupationData ORDER BY Title ASC";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }

        public static DataTable BindIndustryData()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select IndustryID, IndustryName from lkpIndustry;";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
     

     
      }
    }

