﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class CandidateSearchBL
    {
        public static DataTable GetDataBoxTitle()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnJobPosting where UserID='" + SessionInfo.UserId + "' and Sponser='" + true + "' and Deleted='" + false + "'";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        public static DataTable GetDataFirstGrid(CandidateSearchSH sh)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_RecruiterCandidateSearch";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
          

            new SqlParameter("@Title", SqlDbType.Int, 4),
            new SqlParameter("@RangeFrom", SqlDbType.Int, 4),
            new SqlParameter("@RangeTo",SqlDbType.Int, 4),
            new SqlParameter("@Status", SqlDbType.NVarChar, 20),
           
          
                };
            Parameters[0].Value = sh.Title;
            Parameters[1].Value = sh.@RangeFrom;
            Parameters[2].Value = sh.@RangeTo;
            Parameters[3].Value = sh.@Status;
           


            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          


        }

        public static DataTable GetTitleID(string tlt)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select JobID from txnJobPosting where Title='"+tlt+"'";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        public static DataTable GetDataFirstGridNotApplied(CandidateSearchSH sh)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_RecruiterCandidateSearchNotApplied";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
          

            new SqlParameter("@Title", SqlDbType.Int, 4),
            new SqlParameter("@RangeFrom", SqlDbType.Int, 4),
            new SqlParameter("@RangeTo",SqlDbType.Int, 4),
            new SqlParameter("@Status", SqlDbType.NVarChar, 20),
           
          
                };
            Parameters[0].Value = sh.Title;
            Parameters[1].Value = sh.@RangeFrom;
            Parameters[2].Value = sh.@RangeTo;
            Parameters[3].Value = sh.@Status;



            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          

        }

        public void GetResume(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select ResumeID from txnMemberAccount where UserID='" + UserID + "'";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
        }
    }
}
