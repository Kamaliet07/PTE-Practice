﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;

namespace IRSA.BussinessLogic
{
    public class Assessment360ReportBL
    {
        public static DataTable Get360AssessmentAbilityReportData(int UserID,string SP,int AttemptID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = SP;
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            
           
             new SqlParameter("@UserID", SqlDbType.Int),
             new SqlParameter("@AttmtID", SqlDbType.Int),
          
                };


            Parameters[0].Value = UserID;
            Parameters[1].Value = AttemptID;
           
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }
    }
}
