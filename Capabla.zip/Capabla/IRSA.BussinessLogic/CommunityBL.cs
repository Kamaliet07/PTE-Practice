﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using System.Data.SqlClient;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic.Community
{
    public class CommunityBL
    {

        public static DataTable GetCommunityData()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetCommunityType]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetCommunityMember(int CommunityID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select distinct UserId  From txnCommunity where communityID=" + CommunityID + "";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }


        public static DataTable GetCommunityMember(int UserId, string CultureId, string CommunityName, string CommunityType, string ShortDescription)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetCommunityMember]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserId", UserId);
            SqlCmd.Parameters.AddWithValue("@CultureId", CultureId);
            SqlCmd.Parameters.AddWithValue("@CommunityName", CommunityName);
            SqlCmd.Parameters.AddWithValue("@CommunityType", CommunityType);
            SqlCmd.Parameters.AddWithValue("@ShortDescription", ShortDescription);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetUserID(string Email, string CultureId)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetUserID]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@Email", Email);
            SqlCmd.Parameters.AddWithValue("@CultureId", CultureId);

            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }



        public static DataTable GetCommunityMemberInvitation(String CommunityName, string UserId, string CultureId)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetUserIDFromCommunity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@CommunityName", CommunityName);
            SqlCmd.Parameters.AddWithValue("@UserId", UserId);
            SqlCmd.Parameters.AddWithValue("@CultureId", CultureId);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public static DataTable GetCommunityDirectory(int UserId, string CultureId, string FunctionalDomain)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetCommunityDirectory]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", UserId);
            SqlCmd.Parameters.AddWithValue("@CultureId", CultureId);
            SqlCmd.Parameters.AddWithValue("@FunctionalDomain", FunctionalDomain);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetCommunityDirectoryWithoutFunctionalDomain(int UserId, string CultureId, string ShortDescription, String CommunityType)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetCommunityDirectoryWithoutFunctionalDomain]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", UserId);
            SqlCmd.Parameters.AddWithValue("@CultureId", CultureId);
            SqlCmd.Parameters.AddWithValue("@ShortDescription", ShortDescription);
            SqlCmd.Parameters.AddWithValue("@CommunityType", CommunityType);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public static DataTable GetCommunityDetails(int UserId, string CultureId, string CommunityType, string ShortDecription)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "sp_GetCommunity";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", UserId);
            SqlCmd.Parameters.AddWithValue("@CultureId", CultureId);
            SqlCmd.Parameters.AddWithValue("@CommunityType", CommunityType);
            SqlCmd.Parameters.AddWithValue("@ShortDescription", ShortDecription);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetIndustryId(string IndustryName)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "Sp_GetIndustryId";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@IndustryName", IndustryName);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public static DataTable GetFunctionalDomain()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "sp_GetFunctionalDomain";
            IConnection = objDataAccessLayer.GetConnection();
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }



        public static DataTable SaveCommunityMember(int UserID, int CommunityID, bool Deleted, string CommandOption)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "Sp_Insert_CommunityMember";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", UserID);
            SqlCmd.Parameters.AddWithValue("@CommunityID", CommunityID);
            SqlCmd.Parameters.AddWithValue("@Deleted", Deleted);
            SqlCmd.Parameters.AddWithValue("@CommandOption", CommandOption);
            SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(dr);
            return rowCount;
        }

        public static DataTable SaveCOMMUNITY(int UserID, string CommunityName, string CommunityLogo, string CommunityType, string FunctionalDomain, string ShortDescription, string DetailedDescription, string WebsiteUrl, string CommunityOwnerName, string CommunityOwnerEmail, bool Directory, bool Logo, bool Approval, bool Status, string CultureID, string CreateDate, string ModifyDate, bool Deleted)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "Sp_Insert_Community";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", UserID);
            SqlCmd.Parameters.AddWithValue("@CommunityName", CommunityName);
            SqlCmd.Parameters.AddWithValue("@CommunityLogo", CommunityLogo);
            SqlCmd.Parameters.AddWithValue("@CommunityType", CommunityType);
            SqlCmd.Parameters.AddWithValue("@FunctionalDomain", FunctionalDomain);
            SqlCmd.Parameters.AddWithValue("@ShortDescription", FunctionalDomain);
            SqlCmd.Parameters.AddWithValue("@DetailedDescription", DetailedDescription);
            SqlCmd.Parameters.AddWithValue("@WebsiteUrl", WebsiteUrl);
            SqlCmd.Parameters.AddWithValue("@CommunityOwnerName", CommunityOwnerName);
            SqlCmd.Parameters.AddWithValue("@CommunityOwnerEmail", CommunityOwnerEmail);
            SqlCmd.Parameters.AddWithValue("@Directory", Directory);
            SqlCmd.Parameters.AddWithValue("@Logo", Logo);
            SqlCmd.Parameters.AddWithValue("@Approval", Approval);
            SqlCmd.Parameters.AddWithValue("@Status", Status);
            SqlCmd.Parameters.AddWithValue("@CultureID", CultureID);
            SqlCmd.Parameters.AddWithValue("@CreateDate", CreateDate);
            SqlCmd.Parameters.AddWithValue("@ModifyDate", ModifyDate);
            SqlCmd.Parameters.AddWithValue("@Deleted", Deleted);

            SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(dr);
            return rowCount;
        }

        # region Decleration of StoreProcedure by kamal

        public static void SaveNewCommunityDetail(string FunctDomain, IRSA.Shared.NewCommunityInfo objcommunitysave)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_Insert_Community]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", SessionInfo.UserId);
            SqlCmd.Parameters.AddWithValue("@CommunityName", objcommunitysave.CommunityName);
            SqlCmd.Parameters.AddWithValue("@CommunityLogo", objcommunitysave.CommunityLogo);
            SqlCmd.Parameters.AddWithValue("@CommunityType", objcommunitysave.CommunityType);
            SqlCmd.Parameters.AddWithValue("@FunctionalDomain", objcommunitysave.FunctionalDomain);
            SqlCmd.Parameters.AddWithValue("@ShortDescription", objcommunitysave.ShortDescription);
            SqlCmd.Parameters.AddWithValue("@DetailedDescription", objcommunitysave.DetailDescription);
            SqlCmd.Parameters.AddWithValue("@WebsiteUrl", objcommunitysave.WebSiteURL);
            SqlCmd.Parameters.AddWithValue("@CommunityOwnerName", objcommunitysave.CommunityOwnerName);
            SqlCmd.Parameters.AddWithValue("@CommunityOwnerEmail", objcommunitysave.CommunityOwnerEmail);
            SqlCmd.Parameters.AddWithValue("@Directory", objcommunitysave.CommunityDirectoryDisplay);
            SqlCmd.Parameters.AddWithValue("@Logo", objcommunitysave.CommunityLogoDisplay);
            SqlCmd.Parameters.AddWithValue("@Approval", objcommunitysave.CommunityOwnerApproval);
            SqlCmd.Parameters.AddWithValue("@Status", objcommunitysave.Status);
            SqlCmd.Parameters.AddWithValue("@CultureID", "EN");

            SqlDataReader Sqldrr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable tempskll = new DataTable();
            tempskll.Load(Sqldrr);

        }

        public static DataTable GetMaxCommunityID()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select CommunityID  From txnCommunity order by CommunityID desc";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable GetCommunityEntireDetail(int communityid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetCommunityName]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@CommunityID", communityid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static int GetCommunityMembers(int communityid)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select COUNT(1) UserID from txnCommunityMember where CommunityID = " + communityid + "";
            return Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
        }
        public static DataTable GetAllMyCommunity()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetMyCommunityDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", SessionInfo.UserId);
            SqlCmd.Parameters.AddWithValue("@CultureId", "EN");
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetCommunityUserDetail(int communityid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetCommunityUserDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@CommunityID", communityid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public static DataTable GetInvitedUserDetail(int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetInvitedUserDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", userid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetInvitedByUserStatus(int invitedby, int invitedto)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetInvitationAcceptStatus]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@InvitedByUserID", invitedby);
            SqlCmd.Parameters.AddWithValue("@InvitedToUserID", invitedto);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable UpdateInvitedUserAcceptance(int invitedby, int invitedto)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_UpdateAcceptStatus]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@InvitedByUserID", invitedby);
            SqlCmd.Parameters.AddWithValue("@InvitedToUserID", invitedto);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;

        }
        public static void InsertUserInvitationDetail(int userid, int inviteduserid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_InsertInvitation]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@InvitedByUserID", userid);
            SqlCmd.Parameters.AddWithValue("@InvitedToUserID", inviteduserid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
        }

        public static int JoinCommunity(int userid, int communityid)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "INSERT INTO [txnCommunityMember] (CommunityID,UserID) VALUES(" + communityid + "," + userid + ") ";
            return objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
        }
        public static int CheckUserThisCommunityInfo(int userid, int communityid)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select COUNT(1) from txnCommunityMember Where CommunityID = " + communityid + " and UserID = " + userid + " ";
            return Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage).ToString());
        }

        public static DataTable GetUserExistanceInNet(int userid, int loginuser)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_AddedInvitationStatus]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", userid);
            SqlCmd.Parameters.AddWithValue("@LoginUserID", loginuser);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;

        }
        public static void RemoveFromUserList(int CommID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_RemoveCommunity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@CommunityID", CommID);
            SqlCmd.Parameters.AddWithValue("@UserID", SessionInfo.UserId);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
        }


        public static DataTable GetMyContactMember(int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_MyContactMember]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", userid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetMyContactMember(string communityname, string Communitytype)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_GetSearchCommunity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@CommunityName", communityname);
            SqlCmd.Parameters.AddWithValue("@Communitytype", Communitytype);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public static DataTable DeteateCommunity(int communityid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_DeleteCommunity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@CommunityID", communityid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;

        }
        # endregion



          public static DataTable GetContactList(int UserID, string Name)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * from (SELECT dbo.txnMemberAccount.UserID,dbo.txnMemberAccount.FirstName, dbo.txnMemberAccount.LastName,(RTrim(dbo.txnMemberAccount.FirstName)+' '+RTrim(dbo.txnMemberAccount.LastName)) as FullName ,dbo.txnMemberAccount.ProfessionalTitle,dbo.txnMemberAccount.EmailID,dbo.txnMemberAccount.Phone,dbo.txnMemberAccount.PhotoID,(RTrim(dbo.txnMemberAccount.FirstName)+RTrim(dbo.txnMemberAccount.LastName)) as Name FROM dbo.txnMemberAccount INNER JOIN dbo.txnUserNetworkList ON dbo.txnMemberAccount.UserID = dbo.txnUserNetworkList.NetworkUserID where Accepted='True' and txnUserNetworkList.UserID='" + UserID + "')Table1 where Table1.FirstName='" + Name + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

          public static DataTable GetCommunitySearch(string search)
          {
              IDbConnection IConnection = null;
              string ErrorMessage = "No Data Found";
              string ConnectionString = GlobalMethod.GetConnectionString();
              string dbType = GlobalMethod.GetDbType();
              Factory objFactory = new IRSA.DALFactory.Factory(dbType);
              IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
              objDataAccessLayer.ConnectionString = ConnectionString;
              SqlCommand SqlCmd = new SqlCommand();
              SqlCmd.CommandType = CommandType.StoredProcedure;
              SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
              SqlCmd.CommandText = "sp_CommunitySearch";
              IConnection = objDataAccessLayer.GetConnection();
              SqlParameter[] Parameters =
                {
            new SqlParameter("@Keyword", SqlDbType.NVarChar, 150),
               };
              Parameters[0].Value = search;
              SqlCmd.Parameters.AddRange(Parameters);
              SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
              DataTable rowCount = new DataTable();
              rowCount.Load(drProject);
              return rowCount;
          }

          public static DataTable GetCommunityList()
          {
              IDbConnection IConnection = null;
              string ErrorMessage = "No Data Found";
              string ConnectionString = GlobalMethod.GetConnectionString();
              string dbType = GlobalMethod.GetDbType();
              Factory objFactory = new IRSA.DALFactory.Factory(dbType);
              IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
              objDataAccessLayer.ConnectionString = ConnectionString;
              SqlCommand SqlCmd = new SqlCommand();
              SqlCmd.CommandType = CommandType.StoredProcedure;
              SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
              SqlCmd.CommandText = "sp_CommunitySearchBasic";
              IConnection = objDataAccessLayer.GetConnection();
              SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
              DataTable rowCount = new DataTable();
              rowCount.Load(drProject);
              return rowCount;
          }



          public static DataTable GetUserLoginDetail(int userid)
          {
              string ErrorMessage = "No Data Found";
              string ConnectionString = GlobalMethod.GetConnectionString();
              string dbType = GlobalMethod.GetDbType();
              Factory objFactory = new IRSA.DALFactory.Factory(dbType);
              IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
              objDataAccessLayer.ConnectionString = ConnectionString;
              string query = "Select EmailID, RTrim(FirstName)+' '+ RTrim(LastName) as UserName from  txnMemberAccount where UserID = '" + userid + "'";
              return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
          }
    }


}

