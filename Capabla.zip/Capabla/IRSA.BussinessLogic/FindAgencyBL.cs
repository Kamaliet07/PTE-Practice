﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class FindAgencyBL
    {
       public static DataTable getAgency()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM lkpIndustry ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

       public static DataTable getResult(string ag ,string loc,string name,string spe)
       {
            
            int UserID = SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select IndustryID from lkpIndustry where IndustryName='" + ag + "' ";
            int IndustryID  =Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            string query1 = "select * from lkpOrganisation where IndustryID='" + IndustryID + "' ";
            string query2 = "select * from lkpOrganisation where IndustryID='" + IndustryID + "' and Country='" + loc + "'and Name like'%" + name + "%' and Specilaties  like '%" + spe + "%' ";
            return objDataAccessLayer.GetDataTable(query2, CommandType.Text, ref ErrorMessage);
           
        
       }

       public static DataTable getAgencyCon()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM lkpOrganisation ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable getResultfirst(string keyword)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select IndustryID from lkpIndustry where IndustryName='" + keyword + "' ";
           int IndustryID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
           string query1 = "select * from lkpOrganisation where IndustryID='" + IndustryID + "' ";
          
           return objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetCompanyPopUpControl(int OrganisationID)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM lkpOrganisation where OrganisationID='" + OrganisationID + "' ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
    }
}
