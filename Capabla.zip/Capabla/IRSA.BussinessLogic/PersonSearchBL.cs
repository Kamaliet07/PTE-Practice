﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class PersonSearchBL
    {

        public static DataTable GetUserData(string str4, PersonSearchSH objpersonserachSH)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_PersonSearch";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@searchtext", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@fname", SqlDbType.NVarChar,15 ),
                 new SqlParameter("@lname", SqlDbType.NVarChar,15 ),
                 new SqlParameter("@PTitle", SqlDbType.NVarChar,250 ),
                // new SqlParameter("@Company", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@City", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@Country", SqlDbType.NVarChar,50 ),
                    };
            Parameters[0].Value = str4;
            Parameters[1].Value = objpersonserachSH.FirstName;
            Parameters[2].Value = objpersonserachSH.LastName;
            Parameters[3].Value = objpersonserachSH.ProfessionalTitle;
            //Parameters[4].Value = objpersonserachSH.Company;
            Parameters[4].Value = objpersonserachSH.City;
            Parameters[5].Value = objpersonserachSH.Country;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        //public static DataTable GetPersonData(string str4, PersonSearchSH objpersonserachSH)
        //{
        //    IDbConnection IConnection = null;
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    SqlCommand cmdProject = new SqlCommand();
        //    cmdProject.CommandType = CommandType.StoredProcedure;
        //    cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
        //    cmdProject.CommandText = "usp_PersonSearch";
        //    IConnection = objDataAccessLayer.GetConnection();
        //    SqlParameter[] Parameters =
        //        {
                 
        //         new SqlParameter("@searchtext", SqlDbType.NVarChar,50 ),
                 
        //            };
        //    Parameters[0].Value = str4;
        //    cmdProject.Parameters.AddRange(Parameters);
        //    SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
        //    DataTable rowCount = new DataTable();
        //    rowCount.Load(drProject1);
        //    return rowCount;

        //}
        public static DataTable GetUserList()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_PersonSearchBasic";
            IConnection = objDataAccessLayer.GetConnection();
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        public static DataTable GetUserID(string EmailID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select UserID from txnMemberaccount where EmailID='" + EmailID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable GetUserExistanceInNet(int userid, int loginuser)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_AddedInvitationStatus]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", userid);
            SqlCmd.Parameters.AddWithValue("@LoginUserID", loginuser);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;

        }
        public static DataTable GetPersonData(string str4)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_PeopleSearch";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@searchtext", SqlDbType.NVarChar,50 ),
                 
                    };
            Parameters[0].Value = str4;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        public static DataTable GetEducationSearch(string str4)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_EducationSearch";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                    new SqlParameter("@Keyword", SqlDbType.NVarChar,50 ),
                 };
            Parameters[0].Value = str4;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        public static DataTable GetEducationList()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_EducationSearchBasic";
            IConnection = objDataAccessLayer.GetConnection();
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
    }
}
