﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
   public class EventFinalBL
    {
       public static DataTable GetUSerDocumentsEventLst()
       {
           //string ErrorMessage = "No Data Found";
           //string ConnectionString = GlobalMethod.GetConnectionString();
           //string dbType = GlobalMethod.GetDbType();
           //Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           //IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           //objDataAccessLayer.ConnectionString = ConnectionString;
           //string query = "SELECT  * FROM txnEvent ";

           //return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
           int UserID = SessionInfo.UserId;
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "Event";
            IConnection = objDataAccessLayer.GetConnection();
            //SqlParameter[] Parameters =
            //    {
          

           
            //new SqlParameter("@Title", SqlDbType.NVarChar, 50),
            //new SqlParameter("@Postingdate",SqlDbType.NVarChar, 15),
            //new SqlParameter("@Expirationdate",SqlDbType.NVarChar, 15),
            // new SqlParameter("@UserID",SqlDbType.Int),
           
          
            //    };

            //Parameters[0].Value = objsh.Title;
            //Parameters[1].Value = objsh.From;
            //Parameters[2].Value = objsh.To;
            //Parameters[3].Value = UserID;



           // cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          
        }

       
       public static DataTable GetUSerDocumentsEventMonth(string Month)
       {
           //string ErrorMessage = "No Data Found";
           //string ConnectionString = GlobalMethod.GetConnectionString();
           //string dbType = GlobalMethod.GetDbType();
           //Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           //IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           //objDataAccessLayer.ConnectionString = ConnectionString;
           //string query = "select * from txnEvent where EventMonth='" + Month + "' ";

           //return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
           int UserID = SessionInfo.UserId;
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "Event";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
               {



           new SqlParameter("@Month", SqlDbType.VarChar, 20),
      


               };

           Parameters[0].Value = Month;
          



           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public static DataTable GetUSerDocumentsEventLst1(int Event)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM txnEvent where EventID='" + Event + "'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
    }


    }
