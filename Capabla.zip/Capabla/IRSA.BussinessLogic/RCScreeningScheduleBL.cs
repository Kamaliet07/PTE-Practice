﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class RCScreeningScheduleBL
   {
       public static DataTable GetJobTitle(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select Distinct txnJobPosting.JobID,txnJobPosting.Title from txnJobPosting,txnScreeningSchedule where txnJobPosting.JobID=txnScreeningSchedule.JobID and  txnScreeningSchedule.RecuriterID='"+UserID+"'";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }
       public static DataTable getCandidate(int UserID,int jobid)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Select * from (SELECT     dbo.txnMemberAccount.UserID,dbo.txnScreeningSchedule.JobID,dbo.txnMemberAccount.EmailID ,(Rtrim(txnMemberAccount.FirstName)+' '+Rtrim(txnMemberAccount.LastName)) as Name,txnScreeningSchedule.Venue FROM         dbo.txnMemberAccount INNER JOIN dbo.txnScreeningSchedule ON dbo.txnMemberAccount.UserID = dbo.txnScreeningSchedule.UserID where dbo.txnScreeningSchedule.RecuriterID='" + UserID + "' and dbo.txnScreeningSchedule.JobID='" + jobid + "')Table1";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public static DataTable GetCandidateschedule(int UserID,string JobTitle)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT    dbo.txnScreeningSchedule.ID, dbo.txnScreeningSchedule.JobID, dbo.txnScreeningSchedule.RecuriterID,dbo.txnScreeningSchedule.UserID ,(Rtrim(txnMemberAccount.FirstName)+' '+Rtrim(txnMemberAccount.LastName)) as Name ,txnScreeningSchedule.Venue dbo.txnJobPosting.Title,dbo.txnScreeningSchedule.StartDate,dbo.txnScreeningSchedule.EndDate,  dbo.txnScreeningSchedule.Subject FROM         dbo.txnScreeningSchedule INNER JOIN dbo.txnJobPosting ON dbo.txnScreeningSchedule.JobID = dbo.txnJobPosting.JobID , txnMemberAccount  where txnMemberAccount.UserID = txnScreeningSchedule.UserID and  RecuriterID='28' and Title='asp'";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public void InsertSchedule(RecruiterSchedulerSH objRcSch, int UserID)
       {
          
           string query;
           DataTable dt = new DataTable();
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string Query1 = "select ID from txnScreeningSchedule where txnScreeningSchedule.ID='" + objRcSch.ID + "' ";
           dt=objDataAccessLayer.GetDataTable(Query1, CommandType.Text, ref ErrorMessage);
           if (dt.Rows.Count > 0)
           {
               query = "UPDATE txnScreeningSchedule SET Time='" + objRcSch .Time + "' , Status='" + objRcSch.Status + "', Date='" + objRcSch.Date + "' , Venue='" + objRcSch.Vennue + "', TypeofWork='" + objRcSch.TypeOfWork + "', Subject='" + objRcSch.Subject + "',StartDate='" + objRcSch.Start + "',EndDate='" + objRcSch.End + "' where txnScreeningSchedule.ID='" + objRcSch.ID + "'";
           }
           else
           {
               query = "insert into  txnScreeningSchedule (Venue,TypeofWork,Subject,StartDate,EndDate,JobID,UserID,RecuriterID) values ('" + objRcSch.Vennue + "','" + objRcSch.TypeOfWork + "','" + objRcSch.Subject + "','" + objRcSch.Start + "','" + objRcSch.End + "','" + UserID + "','" + UserID + "','" + UserID + "')";

           }
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable Getschedule(int UserID)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Select * from (SELECT    dbo.txnScreeningSchedule.ID, dbo.txnScreeningSchedule.JobID, dbo.txnScreeningSchedule.RecuriterID,dbo.txnScreeningSchedule.UserID ,(Rtrim(txnMemberAccount.FirstName)+' '+Rtrim(txnMemberAccount.LastName)) as Name , dbo.txnJobPosting.Title,dbo.txnScreeningSchedule.StartDate,dbo.txnScreeningSchedule.EndDate,  dbo.txnScreeningSchedule.Subject,txnScreeningSchedule.Venue FROM         dbo.txnScreeningSchedule Left Outer JOIN dbo.txnJobPosting ON dbo.txnScreeningSchedule.JobID = dbo.txnJobPosting.JobID , txnMemberAccount  where txnMemberAccount.UserID = txnScreeningSchedule.UserID and  RecuriterID='" + UserID + "')Table1";

          // string query = "SELECT   * from  txnScreeningSchedule where RecuriterID='" + UserID + "'";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public void DeleteSchedule(int ID)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Delete from txnScreeningSchedule where ID='" + ID + "'";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetSaveData(int UserID,RecruiterSchedulerSH ObjRcSH)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select * from txnScreeningSchedule where RecuriterID='" + UserID + "' and JobID='" + ObjRcSH.JobID + "'";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public static DataTable Getscheduleaccordingwork(int UserID,RecruiterSchedulerSH ObjRcSH)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT * from (SELECT    dbo.txnScreeningSchedule.ID, dbo.txnScreeningSchedule.JobID, dbo.txnScreeningSchedule.RecuriterID,dbo.txnScreeningSchedule.UserID ,(Rtrim(txnMemberAccount.FirstName)+' '+Rtrim(txnMemberAccount.LastName)) as Name ,dbo.txnScreeningSchedule.StartDate,dbo.txnScreeningSchedule.EndDate,  dbo.txnScreeningSchedule.Subject,txnScreeningSchedule.Venue FROM         dbo.txnScreeningSchedule ,txnMemberAccount  where txnMemberAccount.UserID = txnScreeningSchedule.UserID and  RecuriterID='" + UserID + "' and TypeofWork='" + ObjRcSH.TypeOfWork + "')Table1 ";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public static DataTable GetscheduleaccordingJob(int UserID, RecruiterSchedulerSH ObjRcSH)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Select * from (SELECT    dbo.txnScreeningSchedule.ID, dbo.txnScreeningSchedule.JobID, dbo.txnScreeningSchedule.RecuriterID,dbo.txnScreeningSchedule.UserID ,(Rtrim(txnMemberAccount.FirstName)+' '+Rtrim(txnMemberAccount.LastName)) as Name , dbo.txnJobPosting.Title,dbo.txnScreeningSchedule.StartDate,dbo.txnScreeningSchedule.EndDate,  dbo.txnScreeningSchedule.Subject,txnScreeningSchedule.Venue FROM         dbo.txnScreeningSchedule Left Outer JOIN dbo.txnJobPosting ON dbo.txnScreeningSchedule.JobID = dbo.txnJobPosting.JobID , txnMemberAccount  where txnMemberAccount.UserID = txnScreeningSchedule.UserID and  RecuriterID='" + UserID + "' and txnScreeningSchedule.JobID='" + ObjRcSH.JobID + "')Table1";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
       public static DataTable GetCandidateData(int UserID, RecruiterSchedulerSH ObjRcSH)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT    dbo.txnMemberAccount.UserID, (Rtrim(txnMemberAccount.FirstName)+' '+Rtrim(txnMemberAccount.LastName)) as Name, dbo.txnMemberAccount.EmailID FROM         dbo.txnMemberAccount INNER JOIN dbo.txnScreeningSchedule ON dbo.txnMemberAccount.UserID = dbo.txnScreeningSchedule.UserID where dbo.txnScreeningSchedule.ID = '" + ObjRcSH.ID + "' and dbo.txnScreeningSchedule.RecuriterID='" + UserID + "'";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
   }
}
