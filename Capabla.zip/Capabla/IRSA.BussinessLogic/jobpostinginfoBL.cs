﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
    public class jobpostinginfoBL
    {
        public static DataTable RetrivemoduleData()
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnIrsaModule ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
        public static DataTable Retrivemodules( int ModuleID)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from txnIrsaModule where ModuleID='" + ModuleID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



        }
    }
}
