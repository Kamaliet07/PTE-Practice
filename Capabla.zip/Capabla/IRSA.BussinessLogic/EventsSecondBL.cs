﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
   public class EventsSecondBL
    {
       public static DataTable GetUSerDocumentsEventSecond(string controlname)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select * from txnEvent where EventMonth='"+controlname+"' ";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
    }
}
