﻿using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Common.GlobalFunction;
using IRSA.Shared;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace IRSA.BussinessLogic
{
    public class ApprovalCenterBL
    {
        //Get the data for the grid
        public static DataTable getGridData(int Flag, int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Error in database connection";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetListForApproval";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = 
                                        {
                                            new SqlParameter("@Flag", SqlDbType.Int),
                                            new SqlParameter("@UserID", SqlDbType.Int)
                                        };
            Parameters[0].Value = Flag;
            Parameters[1].Value = UserID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }


        //
    }
}
