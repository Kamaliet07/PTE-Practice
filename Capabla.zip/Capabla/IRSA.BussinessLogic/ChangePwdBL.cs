﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
   public class ChangePwdBL
    {
       string UserID;
       string newpwd;
       public static DataTable RetrievePwd(string password)
       {
           string ErrorMessage = "";


           IDbCommand Command;
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
           Command = objDALFactory.CreateCommand();
           Command.CommandType = System.Data.CommandType.Text;
           IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select UserID from [txnMemberAccount] where Password='" + password + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);



       }
       public void ChangePwd(int UserID,string newpwd)
       {
           string ErrorMessage = "";


           IDbCommand Command;
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
           Command = objDALFactory.CreateCommand();
           Command.CommandType = System.Data.CommandType.Text;
           IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Update txnMemberAccount set  Password ='" + newpwd + "' where UserID='" + UserID + "'";
          objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);



       }
    }
}
