﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{

    
  public class TrainingPostBL
  {
      int UserID;
      public DataTable GetTraining(TrainingPostSH tpSH)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_GetAdvanceTraining";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@Keyword", SqlDbType.NVarChar, 50),
             new SqlParameter("@title",SqlDbType.NVarChar, 50),
            ////new SqlParameter("@Key", SqlDbType.NVarChar, 50),
            ////new SqlParameter("@Key2", SqlDbType.NVarChar, 50),
            
            new SqlParameter("@FormatID", SqlDbType.VarChar, 100),
            new SqlParameter("@JobFamilyName", SqlDbType.VarChar, 50),
            new SqlParameter("@Location",SqlDbType.NVarChar, 50),
             
          
                };

          Parameters[0].Value = tpSH.Keyword;
          Parameters[1].Value = tpSH.Keyword;
          ////Parameters[1].Value = tpSH.Keyword1;
          ////Parameters[2].Value = tpSH.Keyword2;
          Parameters[2].Value = tpSH.FormatID;
          Parameters[3].Value = tpSH.JobFamilyName;
          Parameters[4].Value = tpSH.Location;
          
        
          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;
          
      }
      public DataTable PostTraining(TrainingPostSH tpSH, int PostTrainingID)
      {
          UserID = SessionInfo.UserId;
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_PostTraining";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@Title", SqlDbType.NVarChar, 50),
            new SqlParameter("@Description",SqlDbType.NVarChar, 250),
            new SqlParameter("@StartDate",SqlDbType.VarChar, 20),
            new SqlParameter("@EndDate",SqlDbType.VarChar, 20),
            new SqlParameter("@FormatID", SqlDbType.VarChar, 100),
            new SqlParameter("@UserID", SqlDbType.Int, 4),
            new SqlParameter("@Action", SqlDbType.NVarChar, 50),
            new SqlParameter("@TrainingContactsID", SqlDbType.Int, 4),
            new SqlParameter("@Cost", SqlDbType.Money),
            new SqlParameter("@CostCurrency", SqlDbType.NChar, 10),
            new SqlParameter("@DurationDays", SqlDbType.SmallInt),
            new SqlParameter("@DurationHours", SqlDbType.SmallInt),
            new SqlParameter("@DurationMinute", SqlDbType.SmallInt),
            new SqlParameter("@JobFamilyName", SqlDbType.VarChar, 50),
            new SqlParameter("@Location",SqlDbType.NVarChar, 50),
            new SqlParameter("@UploadTraining", SqlDbType.VarChar, 50),
            new SqlParameter("@TrainingURL",SqlDbType.NVarChar, 50),
            new SqlParameter("@Availability",SqlDbType.NVarChar, 50),
            new SqlParameter("@Capacity",SqlDbType.Int,4),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
             new SqlParameter("@Paid",SqlDbType.VarChar, 10),
              new SqlParameter("@PostTrainingID1", SqlDbType.Int, 4),


                };

          Parameters[0].Value = tpSH.Title;
          Parameters[1].Value = tpSH.Description;
          Parameters[2].Value = tpSH.StartDate;
          Parameters[3].Value = tpSH.EndDate;
          Parameters[4].Value = tpSH.FormatID;
          Parameters[5].Value = UserID;
          Parameters[6].Value = tpSH.Action;
          Parameters[7].Value = 1;
          Parameters[8].Value = tpSH.Cost;
          Parameters[9].Value = tpSH.CostCurrency;
          Parameters[10].Value = tpSH.DurationDays;
          Parameters[11].Value = tpSH.DurationHours;
          Parameters[12].Value = tpSH.DurationMinute;
          Parameters[13].Value = tpSH.JobFamilyName;
          Parameters[14].Value = tpSH.Location;
          Parameters[15].Value = tpSH.UploadTraining;
          Parameters[16].Value = tpSH.TrainingURL;
          Parameters[17].Value = tpSH.Availability;
          Parameters[18].Value = tpSH.Capacity;
          Parameters[19].Value = "EN";
          Parameters[20].Value = tpSH.Paid;
          Parameters[21].Value = PostTrainingID;

          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;
      }
      public DataTable selectTraining(int PostTrainingID)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_SelectTraining";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@PostTrainingID", SqlDbType.Int, 4),
           
                };

          Parameters[0].Value = PostTrainingID;
         
          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }
      public DataTable selectTrainingContact(int PostTrainingID)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_SelectTrainingContact";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@PostTrainingID", SqlDbType.NVarChar, 50),
           
                };

          Parameters[0].Value = PostTrainingID;

          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }
      public DataTable selectTrainingUserInfo(int UserID)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_SelectUserInformation";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int, 4),
           
                };

          Parameters[0].Value = UserID;

          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }
      public DataTable selectTrainingInfo(int UserID, int PostTrainingID)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_GetTraininginfo";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int, 4),
            new SqlParameter("@PostTrainingID", SqlDbType.Int, 4),
           
                };

          Parameters[0].Value = UserID;
          Parameters[1].Value = PostTrainingID;

          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }
     public DataTable GetBasicTraining(TrainingPostSH tpSH)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_GetTraining";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
            new SqlParameter("@Keyword", SqlDbType.NVarChar, 50),
            ////new SqlParameter("@Key", SqlDbType.NVarChar, 50),
            new SqlParameter("@Title", SqlDbType.NVarChar, 50),
            //new SqlParameter("@FormatID", SqlDbType.VarChar, 100),
            //new SqlParameter("@JobFamilyName", SqlDbType.VarChar, 50),
            new SqlParameter("@Location",SqlDbType.NVarChar, 50),
          
                };

          Parameters[0].Value = tpSH.Keyword;
          ////Parameters[1].Value = tpSH.Keyword1;
          Parameters[1].Value = tpSH.Title;
          Parameters[2].Value = tpSH.Location;
          //Parameters[3].Value = tpSH.JobFamilyName;
          //Parameters[4].Value = tpSH.Location;
        
          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;
          
      }
  public static DataTable GetTrainingList()
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "usp_TrainingSearchBasic";
          IConnection = objDataAccessLayer.GetConnection();
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }
      
    }
}
