﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class JobWatchBL
    {
       public static DataTable GetJob(JobWatchSH job)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           //string query = "select JobTYpe,Title,JobCity,ExpirationDate,JobLocation,CONVERT(nvarchar(10),Experiencefrom) + '-' + CONVERT(nvarchar(10),ExperienceTo)+' yrs' as ExperienceLevel from txnJobPosting where  JobCountry like '%" + job.Country + "%' and Title like '%" + job.Keyword + "%' and JobLocation like '%" + job.City + "%'";
           string query = " select JobTYpe,Title,substring (keyword,0,100)as keywordTrim,JobCity,ExpirationDate,JobLocation,CONVERT(nvarchar(10),Experiencefrom) + '-' + CONVERT(nvarchar(10),ExperienceTo)+' yrs' as ExperienceLevel from txnJobPosting where  JobCountry like '" + job.Country + "' and FREETEXT(Title ,'" + job.Keyword + "') and JobCity   like '" + job.City + "' and Sponser='true' and deleted='false'order by  JobID desc";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

       public static DataTable GetJob1()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select top(10) JobID, JobTYpe,Title,substring (keyword,0,100)as keywordTrim,JobCity,ExpirationDate,JobLocation,CONVERT(nvarchar(10),Experiencefrom) + '-' + CONVERT(nvarchar(10),ExperienceTo)+' yrs' as ExperienceLevel from txnJobPosting  where Sponser='true' and deleted='false' order by  JobID desc";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
    }
}
