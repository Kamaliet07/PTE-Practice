﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class DigitalAdvisorBL
    {
              
        public DataTable getComCategory()
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string cateQuery = "select CatagoryID,CatagoryName from [lkpDACatagory]";
            return objDataAccessLayer.GetDataTable(cateQuery, CommandType.Text, ref ErrorMessage);
        }

       
        public DataTable GetPreviousSaveAdvise()
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string topQuery = "select DAdviceID,AdviceName,Rating from [txnDigitalAdvice] where UserID='" + SessionInfo.UserId + "'";
            return objDataAccessLayer.GetDataTable(topQuery, CommandType.Text, ref ErrorMessage);
        }

        public DataTable getComTopic(int top)
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string topQuery = "select DATopicID,DaTopicName from [lkpDATopic] where CategoryID='" + top + "'";
            return objDataAccessLayer.GetDataTable(topQuery, CommandType.Text, ref ErrorMessage);
        }

        public DataTable GetSituationTopic(int topcID)
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string SitQuery = "select What,How from [lkpDATopic] where DATopicID ='" + topcID + "'";
            return objDataAccessLayer.GetDataTable(SitQuery, CommandType.Text, ref ErrorMessage);
        }

        public DataTable GetUserQuickTips(int TopicId, string TopicName, string Situation, string Status)
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string TipsQuery = "select DAQuickTipsID,DAQuickTipsName from [lkpDAQuickTips] where (Situation = '" + TopicName + "' or Situation = '" + Situation + "'or Situation = '" + Status + "') and DATopicID = '" + TopicId + "'";
            return objDataAccessLayer.GetDataTable(TipsQuery, CommandType.Text, ref ErrorMessage);
        }

       
        public void SavedUserDataUserID(DigitalAdvisorSH objdigSH, DataTable objsit, int userID)
        {
           foreach (DataRow dr in objsit.Rows)
            {
            IDbConnection IConnection = null;
            string ErrorMessage = "Resule not saved";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_DigitalAdviseSaved";
            IConnection = objDataAccessLayer.GetConnection();
            

                SqlParameter[] Parameters =
                {
                    
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@CategoryID",SqlDbType.Int),
            new SqlParameter("@TopicID", SqlDbType.Int),
            new SqlParameter("@CultureID ",SqlDbType.Char, 2),
            new SqlParameter("@AdviseName ",SqlDbType.NVarChar, 50),
            new SqlParameter("@Rating ",SqlDbType.Int), 
            new SqlParameter("@Situation ",SqlDbType.NVarChar, 50),
            
           
            };
                Parameters[0].Value = userID;
                Parameters[1].Value = objdigSH.CategoryID;
                Parameters[2].Value = objdigSH.TopicID;
                Parameters[3].Value = '1';
                Parameters[4].Value = objdigSH.AdviseName;
                Parameters[5].Value = objdigSH.AdviseRate;
                Parameters[6].Value = dr["Situation"].ToString();
                

                cmdProject.Parameters.AddRange(Parameters);
                SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            }

                        
        }

        public DataTable GetUserSavedQuickTipsAccrAdviceID(int DAdviceID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = "sp_GetUserSavedQuickTips";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            
            new SqlParameter("@AdviceID", SqlDbType.Int),
            new SqlParameter("@UserID", SqlDbType.Int),
           
                };


            Parameters[0].Value = DAdviceID;
            Parameters[1].Value = SessionInfo.UserId;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable DataFind = new DataTable();
            DataFind.Load(drProject);
            return DataFind;
        }

        public DataTable GetUserSavedDataAccrAdviceIDAccrAdviceID(int DAdviceID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = "sp_UserSavedDataAccrAdviceID";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            
             new SqlParameter("@AdviceID", SqlDbType.Int),
             new SqlParameter("@UserID", SqlDbType.Int),
           
                };

            Parameters[0].Value = DAdviceID;
            Parameters[1].Value = SessionInfo.UserId;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable AdDataFind = new DataTable();
            AdDataFind.Load(drProject);
            return AdDataFind;
        }

        public DataTable GetUserSavedUserSitAccrAdviceID(int DAdviceID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = "sp_GetUserSavedSituationAccrAdviceID";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            
             new SqlParameter("@AdviceID", SqlDbType.Int),
             new SqlParameter("@UserID", SqlDbType.Int),
           
                };

            Parameters[0].Value = DAdviceID;
            Parameters[1].Value = SessionInfo.UserId;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable AdDataFind = new DataTable();
            AdDataFind.Load(drProject);
            return AdDataFind;
        }

        public DataTable GetUserSavedQuickTipsAccrAdviceID(int topicid, DataTable objdtsituation)
        {
            DataTable DataFind = new DataTable();
            foreach (DataRow ndr in objdtsituation.Rows)
            {
                IDbConnection IConnection = null;
                string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand cmdProject = new SqlCommand();
                cmdProject.CommandType = CommandType.StoredProcedure;
                cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

                cmdProject.CommandText = "sp_GetUserSavedQuickTips";
                IConnection = objDataAccessLayer.GetConnection();
                SqlParameter[] Parameters =
                {
            
            new SqlParameter("@TopicID", SqlDbType.Int),
            new SqlParameter("@Situation",SqlDbType.NChar, 10),
           
                };


                Parameters[0].Value = topicid;
                Parameters[1].Value = ndr["DASituation"].ToString().Trim();
                cmdProject.Parameters.AddRange(Parameters);
                SqlDataReader drTips = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                DataTable temp = new DataTable();
                temp.Load(drTips);
                if (DataFind.Rows.Count == 0)
                {
                    DataFind = temp;
                }
                else
                {
                    foreach (DataRow newdr in temp.Rows)
                    {
                        DataRow Extnewdr = DataFind.NewRow();
                        Extnewdr["DAQuickTipsID"] = Convert.ToInt32(newdr["DAQuickTipsID"].ToString());
                        Extnewdr["DAQuickTipsName"] = newdr["DAQuickTipsName"].ToString();
                        DataFind.Rows.InsertAt(Extnewdr, 0);
                    }
                }
                
            }
            return DataFind;
        }

        public DataTable getUserAuthencation(string emailid)
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string SitQuery = "Select ID,UserID from txnSalesOrder where EmailID = '" + emailid + "' ";
            return objDataAccessLayer.GetDataTable(SitQuery, CommandType.Text, ref ErrorMessage); 
        }

        public bool GetEvaluateProductKeyAuthenct(string productkey, int Productid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetEvaluateProductKeyAuthencation]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@ProductKey", productkey);
            SqlCmd.Parameters.AddWithValue("@ProductId", Productid);            
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            if (rowCount.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        public void ActivateUserProduct(string emailid, int ProdID, string productkey, string ipadress, string cultureid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_ActivateUserprodectKey]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@ProductID", ProdID);
            SqlCmd.Parameters.AddWithValue("@EmailId", emailid);
            SqlCmd.Parameters.AddWithValue("@ProductKey", productkey);
            SqlCmd.Parameters.AddWithValue("@IpAdress", ipadress);
            SqlCmd.Parameters.AddWithValue("@CultureID", cultureid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            
        }

        public void InsertUserPurchgEntry(string useremail,int productid, int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_TempUserEntryProductn]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserEmail", useremail);
            SqlCmd.Parameters.AddWithValue("@ProductID", productid);            
            SqlCmd.Parameters.AddWithValue("@UserId", userid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
        }

        public DataTable GetProductDetail(int productid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetProductDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@ProductID", productid);            
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public DataTable GetAmountPurchageAndUsed(int userid, int pageid)
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string chkQuery = "Select Quantity,UsedQuantity,(Quantity - UsedQuantity) as Difference,Active from txnSalesOrder where ID='" + pageid + "' and UserID='" + userid + "'";
            return objDataAccessLayer.GetDataTable(chkQuery, CommandType.Text, ref ErrorMessage); 
        }

        public void UpdateUserPurchageDetail(int userID, int pageid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_UpdatePuchageAmount]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserId", userID);
            SqlCmd.Parameters.AddWithValue("@PageID", pageid);            
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
        }



        public DataTable GewtPurchageProductDetail(int userID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetUserPurchageProductDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@UserID", userID);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
               
        public DataTable GetCareerToolDigAdInfo(int userID)
        {
            string ErrorMessage = "";
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string topQuery = "select DAdviceID as AdviceID,AdviceName as Name,Convert(Date,CreateDate,103)as CreateDate from [txnDigitalAdvice] where UserID='" + SessionInfo.UserId + "'";
            return objDataAccessLayer.GetDataTable(topQuery, CommandType.Text, ref ErrorMessage);
        }
    }
}
