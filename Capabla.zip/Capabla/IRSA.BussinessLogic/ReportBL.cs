﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;

namespace IRSA.BussinessLogic
{
   public class ReportBL
   {
       public static DataTable GetReportData(string eid,string EID,string Questemplate)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ElementID", SqlDbType.VarChar, 50),
            new SqlParameter("@ElID", SqlDbType.VarChar, 50),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
             new SqlParameter("@UserID", SqlDbType.Int),
           new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
            new SqlParameter("@AttmtID", SqlDbType.Int),
                };


           Parameters[0].Value = eid;
           Parameters[1].Value = EID;
           Parameters[2].Value = "EN";
           Parameters[3].Value = SessionInfo.UserId;
           Parameters[4].Value = Questemplate;
           Parameters[5].Value = SessionInfo.AttemptID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }

         public static DataTable GetOrgReportData(string eid,string EID,string Questemplate)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetOrgReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ElementID", SqlDbType.VarChar, 50),
            new SqlParameter("@ElID", SqlDbType.VarChar, 50),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
             new SqlParameter("@UserID", SqlDbType.Int),
           new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
            new SqlParameter("@AttmtID", SqlDbType.Int),
                };


           Parameters[0].Value = eid;
           Parameters[1].Value = EID;
           Parameters[2].Value = "EN";
           Parameters[3].Value = SessionInfo.UserId;
           Parameters[4].Value = Questemplate;
           Parameters[5].Value = SessionInfo.AttemptID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetCombinedReportData()
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetCombinedReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
             new SqlParameter("@UserID", SqlDbType.Int)
           
                };


           Parameters[0].Value = "EN";
           Parameters[1].Value = SessionInfo.UserId;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetCheckCombinedReportData()
       {

           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select * from txnQuestionaireResult where UserID ='"+ SessionInfo.UserId +"' and Deleted='0'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetAbilityReportData(string strfamily,string occuption)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetAbilityReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@JobFamilyName", SqlDbType.NVarChar , 250),
             new SqlParameter("@Title", SqlDbType.NVarChar , 250),
             new SqlParameter("@ElementID", SqlDbType.VarChar, 50),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
             new SqlParameter("@UserID", SqlDbType.Int)
                };


           Parameters[0].Value = strfamily;
           Parameters[1].Value = occuption;
           Parameters[2].Value = "1.A.[1-9].[a-z].[1-9]";
           Parameters[3].Value = "EN";
           Parameters[4].Value = SessionInfo.UserId;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetIndividualGraphReportData(string EID, string eid, string Questemplate)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetIndividualGraphReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ElementID", SqlDbType.VarChar, 50),
            new SqlParameter("@ElID", SqlDbType.VarChar , 40),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
             new SqlParameter("@UserID", SqlDbType.Int),
             new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
              new SqlParameter("@AttmtID", SqlDbType.Int),
                };


           Parameters[0].Value = EID;
           Parameters[1].Value = eid;
           Parameters[2].Value = "EN";
           Parameters[3].Value = SessionInfo.UserId;
           Parameters[4].Value = Questemplate;
           Parameters[5].Value = SessionInfo.AttemptID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetOrgIndividualGraphReportData(string EID, string eid, string Questemplate)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetOrgIndividualGraphReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ElementID", SqlDbType.VarChar, 50),
            new SqlParameter("@ElID", SqlDbType.VarChar , 40),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
             new SqlParameter("@UserID", SqlDbType.Int),
             new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
              new SqlParameter("@AttmtID", SqlDbType.Int),
                };


           Parameters[0].Value = EID;
           Parameters[1].Value = eid;
           Parameters[2].Value = "EN";
           Parameters[3].Value = SessionInfo.UserId;
           Parameters[4].Value = Questemplate;
           Parameters[5].Value = SessionInfo.AttemptID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetUserQuestionnaireStatus(string Name)
       {
           int UserID = SessionInfo.UserId;// SessionInfo.UserId;
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_GetUserQuestionnaireStatus";
           IConnection = objDataAccessLayer.GetConnection();
           cmdProject.Parameters.AddWithValue("@UserID", UserID);
           cmdProject.Parameters.AddWithValue("@QuestionaireTemplateName", Name);
           SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(dr);
           return rowCount;  
           //string query = "select * from txnQuestionnaireSubmissionList where UserID ='" + UserID + "' and QuestionaireTemplateName='" + Name + "' and Deleted='0' AttemptID='"++"'";
          // return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

       public static DataTable Get360AssessmentReportData(int UserID,string WhoIs,int AttemptID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_Get360AssessmentReportData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
           
             new SqlParameter("@UserID", SqlDbType.Int),
             new SqlParameter("@WhoIs", SqlDbType.Char,1),
             new SqlParameter("@AttmtID",  SqlDbType.Int),
          
                };


           Parameters[0].Value = UserID;
           Parameters[1].Value = WhoIs;
           Parameters[2].Value = AttemptID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetMemberData(int UserID,int AttemptID,string templateName)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetMemberData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            
             new SqlParameter("@UserID", SqlDbType.Int),
             new SqlParameter("@AttmtID", SqlDbType.Int),
             new SqlParameter("@QuestionnairTemplate", SqlDbType.NVarChar,50),
           
                };



           Parameters[0].Value = UserID;
           Parameters[1].Value = AttemptID;
           Parameters[2].Value = templateName;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }

       public static DataTable GetReportsStatus(int UserID,int ToolID)
       {

           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT * FROM [dbo].[txnQuestionnaireSubmissionList] where txnQuestionnaireSubmissionList.ToolID='" + ToolID + "' and txnQuestionnaireSubmissionList.UserID ='" + UserID + "' and txnQuestionnaireSubmissionList.Status = 'Submit'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable Get360ReportsStatus(int UserID, int ToolID)
       {

           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  txnQuestionnaireSubmissionList.AttemptID , txnQuestionnaireSubmissionList.DateSubmitted , txnQuestionnaireSubmissionList.QuestionaireTemplateName FROM         dbo.txnInvitationRecommAssessment INNER JOIN dbo.txnQuestionnaireSubmissionList ON dbo.txnInvitationRecommAssessment.ToolID = dbo.txnQuestionnaireSubmissionList.ToolID AND  dbo.txnInvitationRecommAssessment.QuestionnaireTemplateName = dbo.txnQuestionnaireSubmissionList.QuestionaireTemplateName  AND dbo.txnInvitationRecommAssessment.UserID = dbo.txnQuestionnaireSubmissionList.UserID AND txnQuestionnaireSubmissionList.UserID='" + UserID + "' and txnQuestionnaireSubmissionList.Status='Submit' and txnInvitationRecommAssessment.InvitationStatus='Submit' and txnQuestionnaireSubmissionList.ToolID='" + ToolID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
  }
}
