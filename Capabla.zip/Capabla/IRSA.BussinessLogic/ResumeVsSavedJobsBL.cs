﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class ResumeVsSavedJobsBL
    {

        //to retrieve the data table for TitleBox
        public static DataTable getTitleBoxData(string DateFrom, string DateTo,int UserID,int flag,string cultID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_ResumeVsSavedJobs";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 new SqlParameter("@DateFrom", SqlDbType.VarChar,50),
                 new SqlParameter("@DateTo", SqlDbType.VarChar,50),
                 new SqlParameter("@UserID", SqlDbType.Int),
                 new SqlParameter("@Flag",SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)
                             
                };
            Parameters[0].Value = DateFrom;
            Parameters[1].Value = DateTo;
            Parameters[2].Value = UserID;
            Parameters[3].Value = flag;
            Parameters[4].Value = cultID;
            cmd.Parameters.AddRange(Parameters);
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;
        }


        ////to retrieve the data table for Jobs Grid
        //public static DataTable getJobs(int UserID, string title)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    string query = "SELECT  JobID,Title FROM txnJobPosting where Title='" + title + "'AND UserID='"+UserID+"'";
        //    return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        //}

        //to retreive the candidate list automatically


        //to retreive the candidate list automatically
        public static DataTable getCandidateList(int JobID, int FilterFlag, int flag, int UserID,string cultID)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            if (flag == 1)
            {
                cmd.CommandText = "usp_CandidateMatch";
            }
            else if(flag==2)
            {
                cmd.CommandText = "usp_AppliedCandidateMatch";
            }
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {

                 new SqlParameter("@JobID",SqlDbType.Int),
                 new SqlParameter("@FilterFlag",SqlDbType.Int),
                 new SqlParameter("@userID",SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)
                 
                };

            Parameters[0].Value = JobID;
            Parameters[1].Value=FilterFlag;
            Parameters[2].Value = UserID;
            Parameters[3].Value = cultID;
           
            cmd.Parameters.AddRange(Parameters);
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;

        }


        //to retreive the candidate list Manually
        public static DataTable getCandidateListManually(int JobID, ResumeVsSavedJobsSH dataSH, int flag, int FilterFlag, int UserID,string cultID)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            if (flag == 1)
            {
                cmd.CommandText = "usp_CandidateManualMatch";
            }
            else if (flag == 2)
            {
                cmd.CommandText = "usp_AppliedCandidateManualMatch";
            }
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                
                 new SqlParameter("@JobID",SqlDbType.Int),
                 new SqlParameter("@ExperienceFrom",SqlDbType.Int),
                 new SqlParameter("@ExperienceTo",SqlDbType.Int),
                 new SqlParameter("@Degree",SqlDbType.NVarChar,100),
                 new SqlParameter("@CandidateSkills",SqlDbType.NVarChar,4000),
                 new SqlParameter("@JobFamilyID",SqlDbType.Char,2),
                 new SqlParameter("@FilterFlag",SqlDbType.Int),
                 new SqlParameter("@userID",SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)
                                             
                };

                Parameters[0].Value = JobID;
                Parameters[1].Value = dataSH.ExperienceFrom;
                Parameters[2].Value = dataSH.ExperienceTo;
                Parameters[3].Value = dataSH.Degree;
                Parameters[4].Value = dataSH.Skills;
                Parameters[5].Value = dataSH.JobFamilyID;
                Parameters[6].Value = FilterFlag;
                Parameters[7].Value = UserID;
                Parameters[8].Value = cultID;
                cmd.Parameters.AddRange(Parameters);
                DataTable dt = new DataTable();
                SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
                dt.Load(drProject);
                return dt;
          
        }

        //to insert the list of selected candidates in the table
        public static void insertCandidateList(ResumeVsSavedJobsSH saveSH, int flag, string cultID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_InsertSelectedCandidates";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
            {
            new SqlParameter("@RecruiterID",SqlDbType.Int),   
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@JobID",SqlDbType.Int),
            new SqlParameter("@Deleted",SqlDbType.Bit),
            new SqlParameter("@Flag",SqlDbType.Int),
            new SqlParameter("@CultureID",SqlDbType.Char,2)
            };
            Parameters[0].Value = saveSH.UserID;
            Parameters[1].Value = saveSH.CandidateID;
            Parameters[2].Value = saveSH.JobID;
            Parameters[3].Value = saveSH.Deleted;
            Parameters[4].Value = flag;
            Parameters[5].Value = cultID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);

        }

        //to retreve the resume ID
        public static string getResumeID(int userID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  ResumeID FROM txnMemberAccount WHERE UserID='" + userID + "' and CultureID='" + cultID + "' and (Who='ST' OR Who='JS')";
            string id = Convert.ToString(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return id; 
        }

        //to retreve the Video resume ID
        public static string getVideoResumeID(int userID,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  VideoResumeID FROM txnMemberAccount WHERE UserID='" + userID + "' and CultureID='" + cultID + "' and (Who='ST' OR Who='JS')";
            string id = Convert.ToString(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return id;
        }

        //to retrieve the list of all Job Family Names
        public static DataTable getJobFamilyNames()
        {         

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "sp_RetrieveJobFamilyData";
            IConnection = objDataAccessLayer.GetConnection();
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;
        
        }

        //To retrieve Job Family ID from Job Family Name
        public static string getJobFamilyID(string jobFamily)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  JobFamilyId FROM lkpJobFamily WHERE JobFamilyName='" + jobFamily + "'";
            string id = Convert.ToString(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            return id;
        }

        //to retrieve the approval status of the candidate
        public static DataTable isVodeoAvailable(int candID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  VideoApproved,VideoResumeID FROM txnMemberAccount WHERE UserID='" + candID + "' AND Deleted='False'and CultureID='" + cultID + "' and (Who='ST' OR Who='JS')";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        //to check whether CV/Video is hidden or not
        public static DataTable isCVsHidden(int UserID, int flag, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query=string.Empty;
            if (flag == 1)
            {
                 query = "SELECT  EveryOne FROM txnAccountSettings where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and Settingtype='Resume_Text'";
            }
            else if (flag == 2)
            {
                 query = "SELECT  EveryOne FROM txnAccountSettings where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and Settingtype='Resume_Both'";
            }
            else if (flag == 3)
            {
                query = "SELECT  EveryOne FROM txnAccountSettings where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and Settingtype='Resume_Video'";

            }
            else
            {
                return null;
            }
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
    }
}
