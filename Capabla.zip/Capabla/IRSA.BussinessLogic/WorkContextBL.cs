﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;


namespace IRSA.BussinessLogic
{
    public class WorkContextBL
    {
        public static DataTable GetWorkContextData(string eid)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = "sp_WorkContextQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                       
             new SqlParameter("@ElementID", SqlDbType.VarChar, 50),

             new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };


            Parameters[0].Value = eid;
            Parameters[1].Value = "EN";

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }
        public static DataTable GetWorkStyleData()
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = "sp_WorkStyleQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                       
            

             new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };


          
            Parameters[0].Value = "EN";

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }
        public static DataTable GetToolsTechnologyData(string occuptiontilte)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

            cmdProject.CommandText = "sp_Tools&technology";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                       
            
              new SqlParameter("@OccuptionTitle", SqlDbType.NVarChar, 250),
             new SqlParameter("@CultureID", SqlDbType.Char, 4)
           
                };


             Parameters[0].Value = occuptiontilte;
            Parameters[1].Value = "EN";

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }
        public static DataTable GetToolsName()
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT     dbo.lkpProduct.ID as ToolID, dbo.lkpProduct.Name, dbo.lkpProduct.Rate FROM dbo.lkpProduct INNER JOIN dbo.lkpTool ON dbo.lkpProduct.CultureID = dbo.lkpTool.CultureID AND dbo.lkpProduct.ID = dbo.lkpTool.ToolID";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
    }
}
