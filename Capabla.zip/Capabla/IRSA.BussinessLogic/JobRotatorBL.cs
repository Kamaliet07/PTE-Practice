﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
    public class JobRotatorBL
    {
        public static DataTable GetData()
        {
            int UserID = SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select  substring(Jobdescription,0,140),substring(title,0,50)as title,JobLocation  from txnjobposting";

            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
    }
}
