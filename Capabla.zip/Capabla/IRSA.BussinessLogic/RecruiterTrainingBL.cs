﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
   public class RecruiterTrainingBL
    {
        public static DataTable GetData()
        {
            int UserID = SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT * from txnTrainingPosting where UserID='" + UserID + "'and Deleted='false'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        public static void GetDeleteData(int PostTrainingID)
        {
            int UserID = SessionInfo.UserId;

            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Update txnTrainingPosting set Deleted='True' from  txnTrainingPosting where PostTrainingID='" + PostTrainingID + "'";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
        }



        public static DataTable GetDataSearch(RecruiterTrainingSH objsh)
        {
            int UserID = SessionInfo.UserId;
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_RecuiterTraining";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
          

           
            new SqlParameter("@Title", SqlDbType.NVarChar, 50),
            new SqlParameter("@Postingdate",SqlDbType.NVarChar, 15),
            new SqlParameter("@Expirationdate",SqlDbType.NVarChar, 15),
             new SqlParameter("@UserID",SqlDbType.Int),
           
          
                };

            Parameters[0].Value = objsh.Title;
            Parameters[1].Value = objsh.From;
            Parameters[2].Value = objsh.To;
            Parameters[3].Value = UserID;



            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          
        }
    }
}
