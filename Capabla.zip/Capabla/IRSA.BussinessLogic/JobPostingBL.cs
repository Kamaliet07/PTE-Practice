﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class JobPostingBL
    {
       int UserID;
       public void InsertJobQues(DataTable dataTable, int JobID)
       {
           foreach (DataRow ndr in dataTable.Rows)
           {
               UserID =SessionInfo.UserId;
               IDbConnection IConnection = null;
               
               SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
               string ErrorMessage = "No Data Found";
               string ConnectionString = GlobalMethod.GetConnectionString();
               string dbType = GlobalMethod.GetDbType();
               Factory objFactory = new IRSA.DALFactory.Factory(dbType);
               IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
               objDataAccessLayer.ConnectionString = ConnectionString;
               SqlCommand cmdProject = new SqlCommand();
               cmdProject.CommandType = CommandType.StoredProcedure;
               cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
               cmdProject.CommandText = "sp_InsertJobQuestionnaire";
               IConnection = objDataAccessLayer.GetConnection();
               cmdProject.Parameters.AddWithValue("@UserID", UserID);
               cmdProject.Parameters.AddWithValue("@JobID", JobID);
               cmdProject.Parameters.AddWithValue("@ElementID", ndr["ElementID"].ToString().Trim());
               cmdProject.Parameters.AddWithValue("@SkillName", ndr["SkillName"].ToString().Trim());
               cmdProject.Parameters.AddWithValue("@DataValue","1.0");
               cmdProject.Parameters.AddWithValue("@CultureID", "EN");
            //   SqlParameter[] Parameters =
            //    {
            //new SqlParameter("@JobID", SqlDbType.Int),
            //new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            // new SqlParameter("@DataValue", SqlDbType.Float , 50),
            //new SqlParameter("@CultureID", SqlDbType.Char, 2),
            
            //    };

            //   Parameters[0].Value = JobID;
            //   Parameters[1].Value = objskill.ElementID;
            //   Parameters[2].Value = objskill.DataValue;
            //   Parameters[3].Value = "EN";

               SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
               DataTable rowCount = new DataTable();
               rowCount.Load(dr);
           }
       }
      
       public void InsertJobSkillQues(SkillQuestionnaireSH objskill, int JobID)
       {
           IDbConnection IConnection = null;
           UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_InsertJobQuestionnaire";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
             new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@UserID", SqlDbType.Int),
                };

           Parameters[0].Value = JobID;
           Parameters[1].Value = objskill.ElementID;
           Parameters[2].Value = objskill.DataValue;
           Parameters[3].Value = "EN";
           Parameters[4].Value = UserID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

       }
       public static DataTable GetJobQuestionnaireData(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_SelectQuestionnaire";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
           
                };


           Parameters[0].Value = JobID;
           Parameters[1].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public static DataTable GetJobToolandtechQuestionnaireData(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_SelectToolandtechQuestionnaire";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
           
                };


           Parameters[0].Value = JobID;
           Parameters[1].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public DataTable InsertRCOrg(JobPostingSH jobpSH)
       {
           int UserID = SessionInfo.UserId;
           string RoleID = SessionInfo.RoleID;
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_InsertJobOrganisation";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                { 
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@Name", SqlDbType.NVarChar, 150),
             new SqlParameter("@IndustryID", SqlDbType.Int),
            new SqlParameter("@Description",SqlDbType.NVarChar,1100), 
             new SqlParameter("@Website", SqlDbType.NVarChar, 100),
              new SqlParameter("@OrgStatus", SqlDbType.Char, 2),
             new SqlParameter("@CultureID", SqlDbType.Char, 2),
             };

           Parameters[0].Value = UserID;
           Parameters[1].Value = jobpSH.OrgName;
           Parameters[2].Value = jobpSH.IndustryID;
           Parameters[3].Value = jobpSH.ComanyDescription;
           Parameters[4].Value = jobpSH.ComanyUrl;
           Parameters[5].Value = RoleID;
           Parameters[6].Value = "EN";
      
          

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public DataTable GetCompany(JobPostingSH jobpSH, string step, int JobID, string idCollection)
       {
           UserID = SessionInfo.UserId;
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_JobPosting";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
           new SqlParameter("@CompanyName", SqlDbType.NVarChar, 50),
           new SqlParameter("@CultureID", SqlDbType.Char, 2),
           new SqlParameter("@step", SqlDbType.NVarChar, 20),
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@JobTitle",SqlDbType.NVarChar, 50),
            new SqlParameter("@JobCodeReference",SqlDbType.NChar, 15),
            new SqlParameter("@Openings",SqlDbType.SmallInt),
            new SqlParameter("@PayRangeFrom", SqlDbType.Money),
            new SqlParameter("@PayRangeTo", SqlDbType.Money),
            new SqlParameter("@PayDescription",SqlDbType.NChar, 10),
            new SqlParameter("@PayCurrency",SqlDbType.NChar, 20),
            new SqlParameter("@ExperienceLevel",SqlDbType.NChar, 20),
            new SqlParameter("@JobFamilyName", SqlDbType.VarChar, 50),
            new SqlParameter("@ONETSOCTitle", SqlDbType.NVarChar, 150),
            new SqlParameter("@JobType", SqlDbType.NVarChar, 100),
            new SqlParameter("@JobDescription", SqlDbType.NVarChar, 4000),
            new SqlParameter("@Skills", SqlDbType.NVarChar, 4000),
            new SqlParameter("@YearExperience",SqlDbType.SmallInt),
            new SqlParameter("@Age",SqlDbType.SmallInt),
            new SqlParameter("@Education", SqlDbType.NVarChar, 50),
            new SqlParameter("@CurrentJobFamily", SqlDbType.VarChar, 50),
            new SqlParameter("@CurrentJobRoleType", SqlDbType.NVarChar, 350),
            new SqlParameter("@DrivingLicense", SqlDbType.Bit),
            new SqlParameter("@Distance", SqlDbType.NVarChar, 50),
            new SqlParameter("@AvailabilityFrom ", SqlDbType.VarChar,50),
            new SqlParameter("@AvailabilityTo", SqlDbType.VarChar,50),
            new SqlParameter("@Keywords", SqlDbType.NVarChar, 250),
            new SqlParameter("@JobLocation",SqlDbType.NVarChar, 100),
            new SqlParameter("@JobCountry", SqlDbType.NVarChar, 50),
            new SqlParameter("@JobPostalCode",SqlDbType.NVarChar, 20),
            new SqlParameter("@PostingDate",SqlDbType.VarChar, 50),
            new SqlParameter("@ExpirationDate",SqlDbType.VarChar, 50),
            new SqlParameter("@ToWhom",SqlDbType.NVarChar, 50),
            new SqlParameter("@ReferralBonusAmount", SqlDbType.Money),
            new SqlParameter("@ReferralBonusCurrency",SqlDbType.NChar, 20),
            new SqlParameter("@Sponser", SqlDbType.Bit),
            new SqlParameter("@Experiencefrom", SqlDbType.Int),
            new SqlParameter("@ExperienceTo", SqlDbType.Int),
            new SqlParameter("@AgeFrom", SqlDbType.Int),
            new SqlParameter("@AgeTo", SqlDbType.Int),
            new SqlParameter("@Gender", SqlDbType.NVarChar,20),
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@Paynote",SqlDbType.NVarChar,100), 
             new SqlParameter("@JobCity", SqlDbType.NVarChar, 50),
             new SqlParameter("@CompanyDescription",SqlDbType.NVarChar,1100), 
             new SqlParameter("@CompanyURL", SqlDbType.NVarChar, 50),
             new SqlParameter("@HoursPerweek", SqlDbType.Int),
             new SqlParameter("@CompanyID", SqlDbType.Int),
              new SqlParameter("@IndustryID", SqlDbType.NVarChar, 50),
                };


           Parameters[0].Value = jobpSH.ComanyName;
           Parameters[1].Value = "EN";
           Parameters[2].Value = step;
           Parameters[3].Value = JobID;
           Parameters[4].Value = jobpSH.JobTitle;
           Parameters[5].Value = jobpSH.JobCodeReference;
           Parameters[6].Value = jobpSH.Openings;
           Parameters[7].Value = jobpSH.PayRangeFrom;
           Parameters[8].Value = jobpSH.PayRangeTo;
           Parameters[9].Value = jobpSH.PayDescription;
           Parameters[10].Value = jobpSH.PayCurrency;
           Parameters[11].Value = jobpSH.ExperienceLevel;
           Parameters[12].Value = jobpSH.JobFamilyName;
           Parameters[13].Value = jobpSH.ONETSOCTitle;
           Parameters[14].Value = jobpSH.JobType;
           Parameters[15].Value = jobpSH.JobDescription;
           Parameters[16].Value = jobpSH.Skills;
           Parameters[17].Value = jobpSH.YearExperince;
           Parameters[18].Value = jobpSH.Age;
           Parameters[19].Value = jobpSH.Education;
           Parameters[20].Value = jobpSH.CurrentJobFamily;
           Parameters[21].Value = idCollection;
           Parameters[22].Value = jobpSH.DrivingLicence;
           Parameters[23].Value = jobpSH.Distance;
           Parameters[24].Value = jobpSH.AvailabilityFrom;
           Parameters[25].Value = jobpSH.AvailabilityTo;
           Parameters[26].Value = jobpSH.Keyword;
           Parameters[27].Value = jobpSH.JobLocation;
           Parameters[28].Value = jobpSH.JobCountry;
           Parameters[29].Value = jobpSH.JobPotalCode;
           Parameters[30].Value = jobpSH.PostingDate;
           Parameters[31].Value = jobpSH.ExpirationDate;
           Parameters[32].Value = jobpSH.ToWhom;
           Parameters[33].Value = jobpSH.ReferralBonusAmount;
           Parameters[34].Value = jobpSH.ReferralBonusCurrency;
           Parameters[35].Value = jobpSH.Sponser;
           Parameters[36].Value = jobpSH.ExperinceFrom;
           Parameters[37].Value = jobpSH.ExperinceTo;
           Parameters[38].Value = jobpSH.AgeFrom;
           Parameters[39].Value = jobpSH.AgeTo;
           Parameters[40].Value = jobpSH.Gender;
           Parameters[41].Value = UserID;
           Parameters[42].Value = jobpSH.PayNote;
           Parameters[43].Value = jobpSH.JobCity;
           Parameters[44].Value = jobpSH.ComanyDescription;
           Parameters[45].Value = jobpSH.ComanyUrl;
           Parameters[46].Value = jobpSH.Workperweek;
           Parameters[47].Value = jobpSH.CompanyID;
           Parameters[48].Value = jobpSH.IndustryID;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public static DataTable GetJobFamilyData()
       {

           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  JobFamilyName FROM lkpJobFamily order by JobFamilyName asc ";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


       }
       public DataTable GetSourceData(string JobFamily)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  JobFamilyID FROM lkpJobFamily where JobFamilyName='" + JobFamily + "' ";
           int JobFamilyID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
           string query1 = "SELECT  Title FROM lkpOccupationData where ONETSOCCode like '" + JobFamilyID + "'+'%'order by Title asc ";
           return objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);

       }
       public DataTable GetSourceDataID(string ONETSOCCodeData)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;

           string query = "SELECT  * FROM lkpOccupationData where Title = '" + ONETSOCCodeData + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public DataTable selectJOB(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_SelectJob";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int, 4),
           
                };

           Parameters[0].Value = JobID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public DataTable selectJOBInfo(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_SelectJobInfo";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int, 4),
           
                };

           Parameters[0].Value = JobID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public DataTable selectJOBProfile(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_SelectJobProfile";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int, 4),
           
                };

           Parameters[0].Value = JobID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public DataTable selectJobToolsAndTech(int JobID, string T2Type)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_SelectJobToolsandTechnology";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int, 4),
            new SqlParameter("@T2Type", SqlDbType.NVarChar, 15),
                };

           Parameters[0].Value = JobID;
           Parameters[1].Value = T2Type;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public void InsertJobToolsandtech(JobPostingSH jobpSH, string DescribeValue, int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_InsertJobToolsandTechnology";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@T2Example", SqlDbType.NVarChar, 150),
             new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            
                };

           Parameters[0].Value = JobID;
           Parameters[1].Value = DescribeValue;
           Parameters[2].Value = jobpSH.DataValue;
           Parameters[3].Value = "EN";

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

       }
       public static DataTable GetSubmitJobQuestions(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_GetJobQuestionnaireStatus";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@Culture", SqlDbType.Char , 2),
            ////new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };

           Parameters[0].Value = JobID;
           Parameters[1].Value = 1;
           Parameters[2].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetJobSkillsJobQuestionnaire(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand SqlCmd = new SqlCommand();
           SqlCmd.CommandType = CommandType.StoredProcedure;
           SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           SqlCmd.CommandText = "[sp_JobSkillQuestionnaire]";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {            
                  new SqlParameter("@JobID", SqlDbType.Int),                   
           
                };
           Parameters[0].Value = JobID;

           SqlCmd.Parameters.AddRange(Parameters);
           SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
           DataTable tempskl = new DataTable();
           tempskl.Load(Sqldr);
           return tempskl;

       }
       public DataTable selectOccupationName(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_OccupationName";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int, 4),
           
                };

           Parameters[0].Value = JobID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }

       public DataTable GetSourceDataTitle(string ONETSOCCodeData)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;

           string query = "SELECT  * FROM lkpOccupationData where ONETSOCCode = '" + ONETSOCCodeData + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetJobQuestionnaire(int JobID)
       {

           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  * FROM txnJobQuestionnaire where JobID='"+JobID+"' ";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


       }



       public static DataTable RecruiterJobs(int OrgID, int UserID, int Flag)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_GetRecruiterPostedJobs";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                                        {            
                                            new SqlParameter("@OrgID", SqlDbType.Int),
                                            new SqlParameter("@UserID", SqlDbType.Int),
                                            new SqlParameter("@Flag", SqlDbType.Int)
                                        };
           Parameters[0].Value = OrgID;
           Parameters[1].Value = UserID;
           Parameters[2].Value = Flag;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }


       //Return the name of the organisation for a given organisationID
       public static string GetOrgName(int OrgID, int UserID, int Flag)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_GetRecruiterPostedJobs";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                                        {            
                                            new SqlParameter("@OrgID", SqlDbType.Int),
                                            new SqlParameter("@UserID", SqlDbType.Int),
                                            new SqlParameter("@Flag", SqlDbType.Bit)
                                        };
           Parameters[0].Value = OrgID;
           Parameters[1].Value = UserID;
           Parameters[2].Value = Flag;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           if (rowCount.Rows.Count > 0)
               return (rowCount.Rows[0]["Name"]).ToString();
           else
               return string.Empty;
       }
       public  DataTable GetCompanyName()
       {
           UserID = SessionInfo.UserId;
           IDbConnection IConnection = null;

           SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_RetrieveOrganisationData";
           IConnection = objDataAccessLayer.GetConnection();
           cmdProject.Parameters.AddWithValue("@UserID", UserID);
           SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(dr);
           return rowCount;
           //string ErrorMessage = "No Data Found";
           //string ConnectionString = GlobalMethod.GetConnectionString();
           //string dbType = GlobalMethod.GetDbType();
           //Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           //IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           //objDataAccessLayer.ConnectionString = ConnectionString;
           //string query = "SELECT   OrganisationID,  Name FROM  dbo.lkpOrganisation ";
           //return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


       }
       public DataTable GetCompanyNameDes(string Name)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;


           string query1 = "SELECT  Description,Website FROM lkpOrganisation where OrganisationID='" + Name + "'  ";
           return objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);

       }
       public DataTable DeletaSkillQuest(int JobID)
       {
              UserID =SessionInfo.UserId;
               IDbConnection IConnection = null;
               
               SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
               string ErrorMessage = "No Data Found";
               string ConnectionString = GlobalMethod.GetConnectionString();
               string dbType = GlobalMethod.GetDbType();
               Factory objFactory = new IRSA.DALFactory.Factory(dbType);
               IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
               objDataAccessLayer.ConnectionString = ConnectionString;
               SqlCommand cmdProject = new SqlCommand();
               cmdProject.CommandType = CommandType.StoredProcedure;
               cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
               cmdProject.CommandText = "sp_DeleteJobSkillQuestionnaire";
               IConnection = objDataAccessLayer.GetConnection();
               cmdProject.Parameters.AddWithValue("@UserID", UserID);
               cmdProject.Parameters.AddWithValue("@JobID", JobID);
             
               cmdProject.Parameters.AddWithValue("@CultureID", "EN");
           

               SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
               DataTable rowCount = new DataTable();
               rowCount.Load(dr);
               return rowCount;

       }
       public DataTable selectJOBProfile44(int JobID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_CapablaJobQuestionnaire";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@JobID", SqlDbType.Int),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
           
                };

           Parameters[0].Value = JobID;
           Parameters[1].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }
       public  DataTable GetIndustryName()
       {

           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT IndustryID, IndustryName FROM dbo.lkpIndustry";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


       }
   }

}
