﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class LearningManagement
    {

        public static DataTable GetLearningManagement()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  top(8) *  FROM txnTrainingPosting  order by  PostTrainingID desc";

            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        //public static DataTable GetTraining(LearningManagementSH trng)
        //{
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //   // string query = "select JobTYpe,Title,JobLocation,YearsExperience from txnJobPosting where  JobCountry='" + job.Country + "' and Title like '%" + job.Keyword + "%' and JobLocation like '%" + job.City + "%'";
        //    //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
        //    //return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        //}

        public static DataTable GetTraining(LearningManagementSH trng)
             
        {
          
            string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
               objDataAccessLayer.ConnectionString = ConnectionString;
           
                   //string  query = "select Title,Location,DurationDays,DurationHours,DurationMinute,FormatID from txnTrainingPosting where  Location like '%" + trng.Country + "%' and Title like '%" + trng.Keyword + "%' ";
                   string query = " SELECT * FROM txnTrainingPosting WHERE FREETEXT(Title ,'" + trng.Keyword + "') and FREETEXT (Location    ,'" + trng.Country + "' )";
                  
              
               return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }
    }
}