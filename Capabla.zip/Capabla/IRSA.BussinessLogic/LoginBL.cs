﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class LoginBL
    {


        int rowcount;
        public bool GetValidateUser(LoginSH objlogin)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_login";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@EmailID", SqlDbType.NVarChar, 50),
                 new SqlParameter("@Password", SqlDbType.NVarChar, 50),
            
                };
            Parameters[0].Value = objlogin.EmailID;
            Parameters[1].Value = objlogin.Password;
            cmd.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            DataTable dt = new DataTable();
            dt.Load(drProject);
            if (dt.Rows.Count > 0)
            {
                int loginid = Convert.ToInt32(dt.Rows[0]["UserID"].ToString());
                string RoleID = dt.Rows[0]["Who"].ToString();
                //SessionInfo.Username = dt.Rows[0]["FirstName"].ToString();
                SessionInfo.UserId = loginid;
                SessionInfo.RoleID = RoleID;
                
                return true;

            }
            else
            {
                return false;
            }
        }
        public bool GetValidateRecruiter(LoginSH objlogin)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_Reclogin";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@EmailID", SqlDbType.NVarChar, 50),
                 new SqlParameter("@Password", SqlDbType.NVarChar, 50),
            
                };
            Parameters[0].Value = objlogin.EmailID;
            Parameters[1].Value = objlogin.Password;
            cmd.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            DataTable dt = new DataTable();
            dt.Load(drProject);
            if (dt.Rows.Count > 0)
            {
                int loginid = Convert.ToInt32(dt.Rows[0]["UserID"].ToString());
                SessionInfo.UserId = loginid;
                SessionInfo.RoleID=dt.Rows[0]["Who"].ToString();
                SessionInfo.Username = dt.Rows[0]["FirstName"].ToString();
                return true;

            }
            else
            {
                return false;
            }
        }
        public static DataTable GetOrgID()
        {

            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  * FROM lkpOrganisation where UserID='" + SessionInfo.UserId + "' and OrgStatus='" + SessionInfo.RoleID + "' ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        }
    }
}





































