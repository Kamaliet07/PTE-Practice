﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class JobSearchBL
   {
       public static DataTable GetjobDataDetails(string str)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmd = new SqlCommand();
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmd.CommandText = "usp_JobSearch1";
           //cmd.CommandText = "usp_jobsearching";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@search", SqlDbType.NVarChar ,150),
                 //new SqlParameter("@Titlejob", SqlDbType.NVarChar ,150),
                 //new SqlParameter("@Industryname", SqlDbType.NVarChar ,150),
                 //new SqlParameter("@orgCity", SqlDbType.NVarChar ,150),
                 //new SqlParameter("@orgCountry", SqlDbType.NVarChar ,150),
            
                };
           Parameters[0].Value = str;
           //Parameters[1].Value = objJobSearchSH.Title;
           //Parameters[2].Value = objJobSearchSH.IndustryName;
           //Parameters[3].Value = objJobSearchSH.City;
           //Parameters[4].Value = objJobSearchSH.CountryName;

           cmd.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetJobData(string Keywords, JobSearchSH objJobSearchSH)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           //cmdProject.CommandText = "usp_JobSearch1";
           cmdProject.CommandText = "usp_jobsearching";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@search", SqlDbType.NVarChar,150 ),
                 new SqlParameter("@Titlejob", SqlDbType.NVarChar ,150),
                 //new SqlParameter("@Industryname", SqlDbType.NVarChar ,150),
                 new SqlParameter("@orgCity", SqlDbType.NVarChar ,150),
                 new SqlParameter("@orgCountry", SqlDbType.NVarChar ,150),
            
              
                 
            
                };
           Parameters[0].Value = Keywords;
           Parameters[1].Value = objJobSearchSH.Title;
           //Parameters[2].Value = objJobSearchSH.IndustryName;
           Parameters[2].Value = objJobSearchSH.City;
           Parameters[3].Value = objJobSearchSH.CountryName;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject1);
           return rowCount;

       }
       public static DataTable JobList()
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_JobSearchBasic";
           IConnection = objDataAccessLayer.GetConnection();
           SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject1);
           return rowCount;

       }
       public static DataTable BindIndustryData()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select IndustryName from lkpIndustry;";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GridData(string Industry, string Specialities, string Country, string City, string CompanyName)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_RecruiterSearch";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                                        {
                                            new SqlParameter("@Industry", SqlDbType.NChar,50),
                                            new SqlParameter("@Specialities", SqlDbType.NVarChar,100),
                                            new SqlParameter("@Country", SqlDbType.NVarChar,50),
                                            new SqlParameter("@City", SqlDbType.NVarChar,50),
                                            new SqlParameter("@CompanyName", SqlDbType.NVarChar,150)
                                        };
           Parameters[0].Value = Industry;
           Parameters[1].Value = Specialities;
           Parameters[2].Value = Country;
           Parameters[3].Value = City;
           Parameters[4].Value = CompanyName;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject1);
           return rowCount;

       }
    }
}
