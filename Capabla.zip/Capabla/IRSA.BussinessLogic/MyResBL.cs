﻿using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Common.GlobalFunction;
using IRSA.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.BussinessLogic
{
    public class MyResBL
    {

        //Function to upload word/pdf resume path

        public void svResume(MyResSH objMyResSH, int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Upload Resume";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_ResumeUpld";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@ResumeID", SqlDbType.NVarChar, 50)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = objMyResSH.ResumeID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
        }


        //Function to upload text resume path
        public void svTxtResume(MyResSH objMyResSH, int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Upload Resume";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_TextResumeUpld";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@TextResume", SqlDbType.NVarChar, 3500)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = objMyResSH.TxtResume;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
        }

        //Function to upload video resume path
        public void svVidResume(MyResSH objMyResSH, int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Paste Resume";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_VideoResumeUpld";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@VideoResumeID", SqlDbType.NVarChar, 50)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = objMyResSH.VidResumeID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
        }


        //This function returns a table containing the blocked companies
        //or unblocked companies search list for a candidate

        public static DataTable blockedList(int UserID, int flag, string queryArgument, string subQueryArgument)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_HandleBlockedOrganisations";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@flag", SqlDbType.Int),
                                            new SqlParameter("@queryArgument", SqlDbType.NVarChar, 200),
                                            new SqlParameter("@subqueryArgument", SqlDbType.NVarChar, 100)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = flag;
            Parameters[2].Value = queryArgument;
            Parameters[3].Value = subQueryArgument;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }


        //This function updates the list of companies in the grid based on the search criteria in the searchbox

        public static DataTable updateGrid(string queryArgument, string subQueryArgument)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string subQuery = " (select * from lkpOrganisation where ((Name like '%" + subQueryArgument + "%') AND ((Status = 'S') OR (Status = 's')))) as temp "; 
            string query = "select Name from" + subQuery + "where " + queryArgument;
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }


        //This function fires a stored procedure which unblocks all
        //the organisations for a user before the blockOrganisation
        //function is called

        public static void unblockOrganisations(int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Cannot Unblock Organisation";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_UnblockOrganisations";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter Parameter = new SqlParameter("@UserID", SqlDbType.Int);
            Parameter.Value = UserID;
            cmdProject.Parameters.Add(Parameter);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
        }


        //This function fires a stored procedure which blocks or
        //unblocks an organisation for a user depending on the flag

        public static void blockOrganisation(int UserID, int OrganisationID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Block Organisation";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_BlockOrganisation";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@OrganisationID", SqlDbType.Int)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = OrganisationID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
        }



        //Check whether the pdf or doc resume is uploaded or not

        public static string ResumeFileName(int UserID, int flag)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Resume Not Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetResumeName";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@Flag",SqlDbType.Bit)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = flag;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            if ((flag == 0) && (rowCount.Rows[0]["ResumeID"]).ToString() != "")
                return rowCount.Rows[0]["ResumeID"].ToString();
            else if ((flag == 1) && (rowCount.Rows[0]["VideoResumeID"]).ToString() != "")
                return rowCount.Rows[0]["VideoResumeID"].ToString();
            else
                return string.Empty;
        }


        //Save or update the privacy settings for the uploaded resume(s)
        //I have not made this method static, unlike the above methods to 
        //facilitate multithreading at a later stage. If need be felt then
        //the same approach may be applied to the above methods with minimal changes
        //in the corresponding FACADE and aspx.cs files.

        public void savResumePrivSettings(int UserID, string SettingType, bool EveryOne, bool MyContacts, bool MyCommunities)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Error Updating Table";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_SavePrivacySettings";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@UserID",SqlDbType.Int),
                                            new SqlParameter("@SettingType",SqlDbType.NVarChar, 100),
                                            new SqlParameter("@EveryOne",SqlDbType.Int),
                                            new SqlParameter("@MyContacts",SqlDbType.Int),
                                            new SqlParameter("@MyCommunities",SqlDbType.Int)
                                        };
            Parameters[0].Value = UserID;
            Parameters[1].Value = SettingType;
            if (EveryOne)
                Parameters[2].Value = 1;
            else
                Parameters[2].Value = 0;
            if (MyContacts)
                Parameters[3].Value = 1;
            else
                Parameters[3].Value = 0;
            if (MyCommunities)
                Parameters[4].Value = 1;
            else
                Parameters[4].Value = 0;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
        }


        //Check whether the video resume has been approved or not

        public int vidApprStatus(int Flag, int UserID)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "Error retreiving video approval status";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetListForApproval";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters = {
                                            new SqlParameter("@Flag",SqlDbType.Int),
                                            new SqlParameter("@UserID",SqlDbType.Int)
                                        };
            Parameters[0].Value = Flag;
            Parameters[1].Value = UserID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            int x;
            x = -1;
            if (rowCount.Rows.Count > 0)
            {
                x = Convert.ToInt32(Convert.ToString(rowCount.Rows[0]["VideoApproved"]));
                if ((x != 0) && (x != 1) && (x != 2))
                    x = -1;

            }
            return x;
        }
    }
}
