﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;

namespace IRSA.BussinessLogic
{
  public  class SkillProfilerBL
    {
      
        public static DataTable InsertSPSkillQuestionaireResult(string QuestionaireTemplateName,int UserID ,string  SkillID,string ScaleID,float DataValue ,string CultureID ,Boolean Deleted,string Option)
        {
           
                IDbConnection IConnection = null;
                string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                SqlCmd.CommandText = "[Sp_SPSkillQuestionaireResult]";
                IConnection = objDataAccessLayer.GetConnection();
                SqlCmd.Parameters.AddWithValue("@QuestionaireTemplateName", QuestionaireTemplateName);
                SqlCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlCmd.Parameters.AddWithValue("@SkillID", SkillID);
                SqlCmd.Parameters.AddWithValue("@ScaleID", ScaleID);
                SqlCmd.Parameters.AddWithValue("@DataValue", DataValue);
                SqlCmd.Parameters.AddWithValue("@CultureID", CultureID);
                SqlCmd.Parameters.AddWithValue("@Deleted", Deleted);
                SqlCmd.Parameters.AddWithValue("@Option", Option);
                SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(dr);
                return rowCount;
        }
        public static DataTable InsertSPWorkActivityQuestionaireResult(string QuestionaireTemplateName,int UserID, string ElementID, string CultureID,Boolean Deleted,string Option)
        {
           
                IDbConnection IConnection = null;
                string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                SqlCmd.CommandText = "[Sp_SPWorkActivityQuestionaireResult]";
                IConnection = objDataAccessLayer.GetConnection();
                SqlCmd.Parameters.AddWithValue("@QuestionaireTemplateName", QuestionaireTemplateName);
                SqlCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlCmd.Parameters.AddWithValue("@ElementID", ElementID);
                SqlCmd.Parameters.AddWithValue("@CultureID", CultureID);
                SqlCmd.Parameters.AddWithValue("@Deleted", Deleted);
                SqlCmd.Parameters.AddWithValue("@Option", Option);
                SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(dr);
                return rowCount;           
        }

        public static DataTable GetSkillProfilerData(int SkillProfileID,int UserID,string CultureID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetSkillProfilerData]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@SkillProfileID", SkillProfileID);
            SqlCmd.Parameters.AddWithValue("@UserID", UserID);
            SqlCmd.Parameters.AddWithValue("@CultureID", CultureID);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public static DataTable GetWorkActivityGraph(string jobfamilyId, string ONETSOCCode)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GraphDetailWorkActivity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@jobfamilyId", jobfamilyId);
            SqlCmd.Parameters.AddWithValue("@ONETSOCCode", ONETSOCCode);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
      //For Edit WorkAct

        public static DataTable GetWorkActivity(int SkillProfileID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetEditWorkAct]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@SkillProfileID", SkillProfileID);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        //For Edit Skill Questionaire
        public static DataTable GetWorkSkillQuestionaire(int SkillProfileID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetSkillQuestionaireResult]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@SkillProfileID", SkillProfileID);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

      //For rateskill
        

        public static DataTable GetSkillsTemp(string ONETSOCCode, string ScaleID,int DataValue,int SkillProfileID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            //string query = "select ElementID,ElementName,DataValue from  domSkills where ONETSOCCode='" + ONETSOCCode + "' and ScaleID='" + ScaleID + "'and DataValue<" + DataValue + "";
          //  string query="SELECT dbo.txnSPSkillQuestionaireResult.DataValue, dbo.domSkills.DataValue AS Expr1, dbo.domSkills.ElementID, dbo.txnSPSkillQuestionaireResult.SkillID FROM dbo.domSkills Left JOIN dbo.txnSPSkillQuestionaireResult on domSkills.ElementID= dbo.txnSPSkillQuestionaireResult.SkillID" ;
            string query = "SELECT dbo.domSkills.DataValue, dbo.txnSPSkillQuestionaireResult.SkillID, dbo.txnSPSkillQuestionaireResult.DataValue AS Expr1, dbo.domSkills.ElementID,dbo.domSkills.ONETSOCCode FROM dbo.domSkills INNER JOIN dbo.txnSPSkillQuestionaireResult ON dbo.domSkills.ElementID = dbo.txnSPSkillQuestionaireResult.SkillID WHERE dbo.domSkills.ONETSOCCode LIKE '" + ONETSOCCode + "' AND dbo.domSkills.ScaleID = '" + ScaleID + "'and  dbo.txnSPSkillQuestionaireResult.SkillProfileID=" + SkillProfileID + " ";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }
         // For Choose skill   
        

        #region Bl and Storeprocedure for Skill Profiler Information by Kamal

        public static DataTable GetSkillTree()
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetJobFamily]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;

        }
                    
        public static DataTable GetSkillTreeOcupation(string childnode)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetSkillTreeOcupation]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {            
                  new SqlParameter("@JobFamilyID", SqlDbType.Char, 2),            
           
                };
            Parameters[0].Value = childnode;
            SqlCmd.Parameters.AddRange(Parameters);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable temp = new DataTable();
            temp.Load(Sqldr);
            return temp;
        }
        public static DataTable GetSkillWorkActivity(string ONETSOCCode, string ScaleID)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetSkillWorkActivity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@ONETSOCCode", ONETSOCCode);
            SqlCmd.Parameters.AddWithValue("@ScaleID", ScaleID);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
        public static DataTable GetSkills(string ONETSOCCode)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetSkillDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {            
                  new SqlParameter("@ONETSOCCode", SqlDbType.Char, 10),                   
           
                };
            Parameters[0].Value = ONETSOCCode;
            
            SqlCmd.Parameters.AddRange(Parameters);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable tempskl = new DataTable();
            tempskl.Load(Sqldr);
            return tempskl;

        }

        public static DataTable OccupationData(string p, DataTable dataTable)
        {
            DataTable DataFind = new DataTable();
            foreach (DataRow ndr in dataTable.Rows)
            {
                IDbConnection IConnection = null;
                string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand cmdProject = new SqlCommand();
                cmdProject.CommandType = CommandType.StoredProcedure;
                cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

                cmdProject.CommandText = "sp_GetSkillProfileQuestionnarieList";
                IConnection = objDataAccessLayer.GetConnection();
                SqlParameter[] Parameters =
                {            
                   new SqlParameter("@ONETSOCCode", SqlDbType.Char, 10),
                   new SqlParameter("@ElementID",SqlDbType.VarChar, 20),           
                };

                Parameters[0].Value = p;
                Parameters[1].Value = ndr["ElementID"].ToString().Trim();
                cmdProject.Parameters.AddRange(Parameters);
                SqlDataReader drTips = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                DataTable temp = new DataTable();
                temp.Load(drTips);
                if (DataFind.Rows.Count == 0)
                {
                    DataFind = temp;
                }
                else
                {
                    foreach (DataRow newdr in temp.Rows)
                    {
                        DataRow Extnewdr = DataFind.NewRow();
                        Extnewdr["ElementID"] = newdr["ElementID"].ToString();
                        Extnewdr["ElementName"] = newdr["ElementName"].ToString();
                        DataFind.Rows.InsertAt(Extnewdr, 0);
                    }
                }

            }
            return DataFind;
        }
        public static DataTable OccupationData(string ONETSOCCode, string ElementId, string ScaleID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select ElementID,ElementName from  domSkills where ONETSOCCode='" + ONETSOCCode + "' and ScaleID='" + ScaleID + "' and  ElementID in('" + ElementId + "')";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        public static DataTable GetAllDomSkillWorkActivity(string OnetSocCode, string ScaleID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetAllDomSkillDetail]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {            
                  new SqlParameter("@ONETSOCCode", SqlDbType.Char, 10),
                  new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),            
                };
            Parameters[0].Value = OnetSocCode;
            Parameters[1].Value = ScaleID;
            SqlCmd.Parameters.AddRange(Parameters);
            SqlDataReader Sqldrr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable tempskll = new DataTable();
            tempskll.Load(Sqldrr);
            return tempskll;
        }

        public static DataTable GetWorkActivityChartData(string seletedfamly, string UserseletedOcc)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GraphDetailWorkActivity]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@jobfamilyId", seletedfamly);
            SqlCmd.Parameters.AddWithValue("@Onetsoccode", UserseletedOcc);
           
            SqlDataReader Sqldrr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable tempskll = new DataTable();
            tempskll.Load(Sqldrr);
            return tempskll;
        }

        public static object InsertSkillProfiler(SkillProfiler SkProfiler)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_Insert_SkillProfiler]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@SkillProfileName", SkProfiler.SkillProfileName);
            SqlCmd.Parameters.AddWithValue("@UserID", SkProfiler.UserID);
            SqlCmd.Parameters.AddWithValue("@ONETSOCCode", SkProfiler.ONETSOCCode);
            SqlCmd.Parameters.AddWithValue("@CultureID", SkProfiler.CultureID);
            SqlCmd.Parameters.AddWithValue("@Option", SkProfiler.Option);
            SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(dr);
            return rowCount;
        }

        public static void InsertSPSkillQuestionaireResult(SkillProfiler SkProfiler, DataTable dataTable)
        {
            foreach (DataRow ndr in dataTable.Rows)
            {
                IDbConnection IConnection = null;
                string ErrorMessage = "No Data Found";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                SqlCmd.CommandText = "[Sp_SPSkillQuestionaireResult]";
                IConnection = objDataAccessLayer.GetConnection();
                SqlCmd.Parameters.AddWithValue("@QuestionaireTemplateName", SkProfiler.QuestionaireTemplateName);
                SqlCmd.Parameters.AddWithValue("@UserID", SkProfiler.UserID);
                SqlCmd.Parameters.AddWithValue("@SkillID", ndr["ElementID"].ToString().Trim());
                SqlCmd.Parameters.AddWithValue("@ScaleID", "IM");
                SqlCmd.Parameters.AddWithValue("@DataValue", ndr["Value"].ToString().Trim());
                SqlCmd.Parameters.AddWithValue("@CultureID", SkProfiler.CultureID);
                SqlCmd.Parameters.AddWithValue("@Option", SkProfiler.Option);
                SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(dr);
            }
            
        }
        public static DataTable EvaluateMatchedSkillDetail(string UserSeletednode, int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetEvaluateSkillMatched]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {            
                  new SqlParameter("@ONETSOCCode", SqlDbType.Char, 10),
                  new SqlParameter("@UserID", SqlDbType.Int),            
                };
            Parameters[0].Value = UserSeletednode;
            Parameters[1].Value = userid;
            SqlCmd.Parameters.AddRange(Parameters);
            SqlDataReader Sqldrr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable tempskll = new DataTable();
            tempskll.Load(Sqldrr);
            return tempskll;
        }

        public static DataTable GetEvaluateSkillPieGrapfDetail(string seletednode, string UserSeletednode, int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetEvaluateSkillPieChartMatched]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                  new SqlParameter("@NodeCode", SqlDbType.Char, 2),
                  new SqlParameter("@ONETSOCCode", SqlDbType.Char, 10),
                  new SqlParameter("@UserID", SqlDbType.Int),            
                };
            Parameters[0].Value = seletednode;
            Parameters[1].Value = UserSeletednode;
            Parameters[2].Value = userid;
            SqlCmd.Parameters.AddRange(Parameters);
            SqlDataReader Sqldrr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable tempskll = new DataTable();
            tempskll.Load(Sqldrr);
            return tempskll;
        }
        public static DataTable GetUserExistance(int UserID, string ONESID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select distinct txnSkillProfiler.SkillProfileID,txnSkillProfiler.SkillProfileName from txnSkillProfiler join txnSPSkillQuestionaireResult on txnSkillProfiler.SkillProfileID = txnSPSkillQuestionaireResult.SkillProfileID where txnSPSkillQuestionaireResult.UserID ='" + UserID + "' and txnSkillProfiler.ONETSOCCode = '" + ONESID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            
        
        }
        public static DataTable GetUserPrevRecords(int UserID, string ONESID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select txnSkillProfiler.ONETSOCCode from txnSkillProfiler  where UserID ='" + UserID + "' and ONETSOCCode = '" + ONESID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);   
        }

        public static DataTable GetUserPrevSavedSkil(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select ONETSOCCode,SkillProfileName,CONVERT(DATE, CreateDate, 103) AS CreateDate from txnSkillProfiler where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);   
        }

        public static DataTable GetCareerToolSkillProfDt(int UserID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select ONETSOCCode as AdviceID,SkillProfileName as Name,CONVERT(DATE, CreateDate, 103) AS CreateDate from txnSkillProfiler where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);   
        }
#   endregion







       
    }
 
}
