﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
   public  class UserInboxBL
    {
       public static DataTable GetData()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  SenderName,Subject , SUBSTRING(Subject, 1, 20)as Sub,Status,SentDate,SUBSTRING(SentDate, 1, 6) as SubDate,SUBSTRING(SentDate, 1, 11) as SentDate,InboxID,MailBoxStatus FROM txnInbox where  UserID='"+UserID+"' and MailBoxStatus='Inbox'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       
       }

       public static DataTable GetSubject(string obj)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  Description FROM txnInbox where  Subject='" + obj + "' and UserID='" + UserID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetSubject(int InboxID)
       {
          
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT dbo.txnMemberAccount.UserID, dbo.txnInbox.UserID AS Expr1, dbo.txnMemberAccount.EmailID, dbo.txnInbox.Description,dbo.txnInbox.Subject,dbo.txnInbox.SenderName FROM dbo.txnInbox INNER JOIN dbo.txnMemberAccount ON dbo.txnInbox.UserID = dbo.txnMemberAccount.UserID where InboxID='" + InboxID + "' ";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetDataOutBox()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  ReceiverName,Subject , SUBSTRING(Subject, 1, 20)as Sub,Status,SentDate, SUBSTRING(SentDate, 1, 6) as SubDate,SUBSTRING(SentDate, 1, 11) as SentDate,InboxID,MailBoxStatus FROM txnInbox where  UserID='" + UserID + "' and MailBoxStatus='Outbox'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

       public static DataTable GetStatus(EmailSendingInterfaceSH obj)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  Status FROM txnInbox where  InboxID='" + obj + "' and UserID='" + UserID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable InsertArchived(string str)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Update  txnInbox set MailBoxStatus='" + str + "' where UserID='" + UserID + "' and MailBoxStatus='Inbox'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetDataArchived()
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT  ReceiverName,Subject , SUBSTRING(Subject, 1, 20)as Sub,Status,SentDate, SUBSTRING(SentDate, 1, 6) as SubDate,SUBSTRING(SentDate, 1, 11) as SentDate,InboxID,MailBoxStatus FROM txnInbox where  UserID='" + UserID + "' and MailBoxStatus='Archived'";

           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

       public void SetArchivedStatus(int keyword)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Update  txnInbox set MailBoxStatus='Archived' where UserID='" + UserID + "' and InboxID='" + keyword + "'";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
       }

       public void  SetMarkRead(int keyword)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Update  txnInbox set Status='Viewed' where UserID='" + UserID + "' and InboxID='" + keyword + "'";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
       }

       public void SetMarkUnread(int keyword)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "Update  txnInbox set Status='Pending' where UserID='" + UserID + "' and InboxID='" + keyword + "'";
           objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetSearchData(string str)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "  select* from txnInbox  where Freetext(SenderName ,'" + str + "')  and MailBoxStatus='Inbox'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
          
       }

     

       public static DataTable GetSearchDataOutbox(string str)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "  select* from txnInbox  where Freetext(ReceiverName ,'" + str + "')  and MailBoxStatus='Outbox'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetSearchDataArchived(string str)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "  select* from txnInbox  where Freetext(* ,'" + str + "')  and MailBoxStatus='Archived'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }

       public static DataTable GetPendingSubjectData(int InboxID)
       {
           int UserID = SessionInfo.UserId;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "  select* from txnInbox where InboxID='" + InboxID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
       }
    }
}
