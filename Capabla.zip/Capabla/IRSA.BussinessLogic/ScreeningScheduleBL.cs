﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
  public class ScreeningScheduleBL
    {
        public static DataTable getJobTitle(string JobPostedFrom, string JobPostedTo, int userID,string cultID)
        {
            int flag = 1;
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_ResumeVsSavedJobs";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@DateFrom", SqlDbType.VarChar,50),
                 new SqlParameter("@DateTo", SqlDbType.VarChar,50),
                 new SqlParameter("@UserID", SqlDbType.Int),
                 new SqlParameter("@flag", SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)
                };
            Parameters[0].Value = JobPostedFrom;
            Parameters[1].Value = JobPostedTo;
            Parameters[2].Value = userID;
            Parameters[3].Value = flag;
            Parameters[4].Value = cultID;

            cmd.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }


        public static DataTable getShortlistCandidates(string JobLocation, int SearchfitFrom, int SearchfitTo, int ProfileFitFrom, int ProfileFitTo, int userID, int jobID, int expFrom, int expTo, int AssessFitFrom, int AssessFitTo, string cultID)
        {
            
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_ScreeningSchedule";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@JobLocation", SqlDbType.NVarChar,100),
                 new SqlParameter("@SearchfitFrom", SqlDbType.Int),
                 new SqlParameter("@SearchfitTo", SqlDbType.Int),
                 new SqlParameter("@ProfileFitFrom", SqlDbType.Int),
                 new SqlParameter("@ProfileFitTo", SqlDbType.Int),
                 new SqlParameter("@RecruiterID", SqlDbType.Int),
                 new SqlParameter("@JobID", SqlDbType.Int),
                 new SqlParameter("@ExperienceFrom", SqlDbType.Int),
                 new SqlParameter("@ExperienceTo", SqlDbType.Int),
                 new SqlParameter("@AssessFitFrom", SqlDbType.Int),
                 new SqlParameter("@AssessFitTo", SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)

                };
            Parameters[0].Value = JobLocation;
            Parameters[1].Value = SearchfitFrom;
            Parameters[2].Value = SearchfitTo;
            Parameters[3].Value = ProfileFitFrom;
            Parameters[4].Value = ProfileFitTo;
            Parameters[5].Value = userID;
            Parameters[6].Value = jobID;
            Parameters[7].Value = expFrom;
            Parameters[8].Value = expTo;
            Parameters[9].Value = AssessFitFrom;
            Parameters[10].Value =AssessFitTo;
            Parameters[11].Value = cultID;
            cmd.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }

        //public static DataTable getShortlistCandidates(int userID, int jobID)
        //{
        //    IDbConnection IConnection = null;
        //    string ErrorMessage = "No Data Found";
        //    string ConnectionString = GlobalMethod.GetConnectionString();
        //    string dbType = GlobalMethod.GetDbType();
        //    Factory objFactory = new IRSA.DALFactory.Factory(dbType);
        //    IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
        //    objDataAccessLayer.ConnectionString = ConnectionString;
        //    SqlCommand cmd = new SqlCommand();
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
        //    cmd.CommandText = "usp_ScreeningScheduleDateAndTime";
        //    IConnection = objDataAccessLayer.GetConnection();
        //    SqlParameter[] Parameters =
        //        {f
        //         new SqlParameter("@RecruiterID", SqlDbType.Int),
        //         new SqlParameter("@JobID", SqlDbType.Int)
        //        };
            
        //    Parameters[0].Value = userID;
        //    Parameters[1].Value = jobID;

        //    cmd.Parameters.AddRange(Parameters);
        //    SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
        //    DataTable rowCount = new DataTable();
        //    rowCount.Load(drProject);
        //    return rowCount;
        //}


        //to insert the list of selected candidates in the table
        public static void insertCandidateList(ScreeingScheduleSH saveSH, int flag,string CultID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_InsertScreeningCandidates";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
            {
            new SqlParameter("@RecruiterID",SqlDbType.Int), 
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@JobID",SqlDbType.Int),
            new SqlParameter("@Deleted",SqlDbType.Bit),
            new SqlParameter("@Date",SqlDbType.VarChar,50),
            new SqlParameter("@Time",SqlDbType.VarChar,50),
            new SqlParameter("@flag",SqlDbType.Int),
            new SqlParameter("@venue",SqlDbType.NVarChar,50),
             new SqlParameter("@CultureID",SqlDbType.Char,2)
            };
            Parameters[0].Value = saveSH.UserID;
            Parameters[1].Value = saveSH.CandidateID;
            Parameters[2].Value = saveSH.JobID;
            Parameters[3].Value = saveSH.Deleted;
            Parameters[4].Value = saveSH.Date;
            Parameters[5].Value = saveSH.Time;
            Parameters[6].Value = flag;
            Parameters[7].Value = saveSH.Venue;
            Parameters[8].Value = CultID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);

        }

        public static DataTable getCandidateData(int jobID, int userID, string CultID)
        {
            int flag = 1;
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_ScreeningScheduleDateAndTime";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@RecruiterID", SqlDbType.Int),
                 new SqlParameter("@JobID", SqlDbType.Int),
                 new SqlParameter("@flag", SqlDbType.Int),
                  new SqlParameter("@CultureID", SqlDbType.Char,2)
                };


            Parameters[0].Value = userID;
            Parameters[1].Value = jobID;
            Parameters[2].Value = flag;
            Parameters[3].Value = CultID;

            cmd.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount; 
        }
        public static DataTable getShortlistCandidates(int userID, int jobID, string cultID)
        {
            int flag = 0;
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_ScreeningScheduleDateAndTime";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 new SqlParameter("@RecruiterID", SqlDbType.Int),
                 new SqlParameter("@JobID", SqlDbType.Int),
                 new SqlParameter("@flag", SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)
                };
            
            Parameters[0].Value = userID;
            Parameters[1].Value = jobID;
            Parameters[2].Value = flag;

            Parameters[3].Value = cultID;
            cmd.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }
        public static void insertInboxcand(ScreeingScheduleSH saveSH, string setEmailID, string CultureID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_Inboxcandidate";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
            {
            new SqlParameter("@RecruiterID",SqlDbType.Int), 
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@JobID",SqlDbType.Int),
            new SqlParameter("@emailID",SqlDbType.NVarChar,50),
            new SqlParameter("@CultureID",SqlDbType.Char,2),
            
            };
            Parameters[0].Value = saveSH.UserID;
            Parameters[1].Value = saveSH.CandidateID;
            Parameters[2].Value = saveSH.JobID;
            Parameters[3].Value = setEmailID;
            Parameters[4].Value = SessionInfo.CultureID;
            //Parameters[4].Value = saveSH.Date;
            //Parameters[5].Value = saveSH.Time;
            //Parameters[6].Value = flag;
            //Parameters[7].Value = saveSH.Venue;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);

        }
    }
}
