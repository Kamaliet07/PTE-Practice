﻿using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class CloseAccountBL
    {
        public void DeleteAccount(int UserID)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Update  txnMemberAccount  set  Deleted='1' where UserID='" + UserID + "'";
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);



        }
    }
}
