﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
  public class PersonSearchAdvancedBL
    {
      public static DataTable GetUserData(string Keywords, PersonSearchSH objpersonserachSH)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            //cmdProject.CommandText = "usp_PersonSearchAdvanced";
            cmdProject.CommandText = "search_person";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                
                 new SqlParameter("@fname", SqlDbType.NVarChar,15 ),
                 new SqlParameter("@lname", SqlDbType.NVarChar,15 ),
                 new SqlParameter("@PTitle", SqlDbType.NVarChar,250 ),
                 new SqlParameter("@Company", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@City", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@Country", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@HighestDegree", SqlDbType.NVarChar,100 ),
                 new SqlParameter("@University", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@keyWord", SqlDbType.NVarChar,250 ),
                
                
                 
                };
           
            Parameters[0].Value = objpersonserachSH.FirstName;
            Parameters[1].Value = objpersonserachSH.LastName;
            Parameters[2].Value = objpersonserachSH.ProfessionalTitle;
            Parameters[3].Value = objpersonserachSH.Company;
            Parameters[4].Value = objpersonserachSH.City;
            Parameters[5].Value = objpersonserachSH.Country;
            Parameters[6].Value = objpersonserachSH.HighestEducation;
            Parameters[7].Value = objpersonserachSH.University;
            Parameters[8].Value = Keywords;
            //cmdProject.Parameters["@fname"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@lname"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@PTitle"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@Company"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@City"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@Country"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@HighestDegree"].Direction = ParameterDirection.Output;
            //cmdProject.Parameters["@keyWord"].Direction = ParameterDirection.Output;
            
           cmdProject.Parameters.AddRange(Parameters);
           //cmdProject.Parameters["@fname"].Direction = ParameterDirection.Output;

            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        public static DataTable GetPhotostatus(int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_profilestatusphoto";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@userID", SqlDbType.Int ),
                 
                };
            Parameters[0].Value = userid;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;
        }
             public static DataTable GetContactstatus(int userid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_ContactSettingsstatus";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@userID", SqlDbType.Int ),
                 
                };
            Parameters[0].Value = userid;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

     }
             public static DataTable Getlinkstatusadvanced(int userid)
             {
                 IDbConnection IConnection = null;
                 string ErrorMessage = "No Data Found";
                 string ConnectionString = GlobalMethod.GetConnectionString();
                 string dbType = GlobalMethod.GetDbType();
                 Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                 IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                 objDataAccessLayer.ConnectionString = ConnectionString;
                 SqlCommand cmdProject = new SqlCommand();
                 cmdProject.CommandType = CommandType.StoredProcedure;
                 cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                 cmdProject.CommandText = "usp_advancedlinkstatus";
                 IConnection = objDataAccessLayer.GetConnection();
                 SqlParameter[] Parameters =
                { new SqlParameter("@userID", SqlDbType.Int ),
                 
                };
                 Parameters[0].Value = userid;
                 cmdProject.Parameters.AddRange(Parameters);
                 SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                 DataTable rowCount = new DataTable();
                 rowCount.Load(drProject1);
                 return rowCount;

             }
             public static DataTable Getphotostatusadvanced(int userid)
             {
                 IDbConnection IConnection = null;
                 string ErrorMessage = "No Data Found";
                 string ConnectionString = GlobalMethod.GetConnectionString();
                 string dbType = GlobalMethod.GetDbType();
                 Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                 IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                 objDataAccessLayer.ConnectionString = ConnectionString;
                 SqlCommand cmdProject = new SqlCommand();
                 cmdProject.CommandType = CommandType.StoredProcedure;
                 cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                 cmdProject.CommandText = "usp_advancedphotostatus";
                 IConnection = objDataAccessLayer.GetConnection();
                 SqlParameter[] Parameters =
                { new SqlParameter("@userID", SqlDbType.Int ),
                 
                };
                 Parameters[0].Value = userid;
                 cmdProject.Parameters.AddRange(Parameters);
                 SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                 DataTable rowCount = new DataTable();
                 rowCount.Load(drProject1);
                 return rowCount;

             }
             public bool  GetStatus(int userid)
             {
                 IDbConnection IConnection = null;
                 string ErrorMessage = "No Data Found";
                 string ConnectionString = GlobalMethod.GetConnectionString();
                 string dbType = GlobalMethod.GetDbType();
                 Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                 IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                 objDataAccessLayer.ConnectionString = ConnectionString;
                 SqlCommand cmdProject = new SqlCommand();
                 cmdProject.CommandType = CommandType.StoredProcedure;
                 cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                 cmdProject.CommandText = "usp_GetVisibleStatus";
                 IConnection = objDataAccessLayer.GetConnection();
                 SqlParameter[] Parameters =
                { new SqlParameter("@userID", SqlDbType.Int ),
                 
                };
                 Parameters[0].Value = userid;
                 cmdProject.Parameters.AddRange(Parameters);
                 SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                 DataTable dt = new DataTable();
                 dt.Load(drProject1);
                 if (dt.Rows.Count > 0)
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }

             }
             public bool GetMyContact(int UserID,int uid)
             {
                 IDbConnection IConnection = null;
                 string ErrorMessage = "No Data Found";
                 string ConnectionString = GlobalMethod.GetConnectionString();
                 string dbType = GlobalMethod.GetDbType();
                 Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                 IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                 objDataAccessLayer.ConnectionString = ConnectionString;
                 SqlCommand cmdProject = new SqlCommand();
                 cmdProject.CommandType = CommandType.StoredProcedure;
                 cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                 cmdProject.CommandText = "usp_GetNetworkStatus";
                 IConnection = objDataAccessLayer.GetConnection();
                 SqlParameter[] Parameters =
                { new SqlParameter("@userID", SqlDbType.Int ),
                    new SqlParameter("@uid", SqlDbType.Int ),
                 
                };
                 Parameters[0].Value = UserID;
                 Parameters[1].Value = uid;
                 cmdProject.Parameters.AddRange(Parameters);
                 SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                 DataTable dt = new DataTable();
                 dt.Load(drProject1);
                 if (dt.Rows.Count > 0)
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             public bool GetOrgStatus(int UserID, int uid)
             {
                 IDbConnection IConnection = null;
                 string ErrorMessage = "No Data Found";
                 string ConnectionString = GlobalMethod.GetConnectionString();
                 string dbType = GlobalMethod.GetDbType();
                 Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                 IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                 objDataAccessLayer.ConnectionString = ConnectionString;
                 SqlCommand cmdProject = new SqlCommand();
                 cmdProject.CommandType = CommandType.StoredProcedure;
                 cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                 cmdProject.CommandText = "usp_GetOrgStatus";
                 IConnection = objDataAccessLayer.GetConnection();
                 SqlParameter[] Parameters =
                { new SqlParameter("@userID", SqlDbType.Int ),
                    new SqlParameter("@uid", SqlDbType.Int ),
                 
                };
                 Parameters[0].Value = UserID;
                 Parameters[1].Value = uid;
                 cmdProject.Parameters.AddRange(Parameters);
                 SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                 DataTable dt = new DataTable();
                 dt.Load(drProject1);
                 if (dt.Rows.Count > 0)
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }

             }
    }
}
