﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class QuestionLibraryBL
    {
        public System.Data.DataTable GetCategoryCollectionAccID(string OccID)
        {
            throw new NotImplementedException();
        }

        public void InsertUserQuestionnatie(DataTable dataTable, string QuestName)
        {
            foreach (DataRow dr in dataTable.Rows)
            {
                IDbConnection IConnection = null;
                string ErrorMessage = "Resule not saved";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                SqlCmd.CommandText = "sp_OrgQuestionnarieInsert";
                IConnection = objDataAccessLayer.GetConnection();
                SqlCmd.Parameters.AddWithValue("@OrgID", 26);
                SqlCmd.Parameters.AddWithValue("@QuestionType", QuestName);                
                SqlCmd.Parameters.AddWithValue("@QuestionName", dr["QuestionName"].ToString());
                SqlCmd.Parameters.AddWithValue("@QuestionDefinition", dr["QuestionDefinition"].ToString());
                SqlCmd.Parameters.AddWithValue("@DataValue", dr["DataValue"].ToString());
                SqlCmd.Parameters.AddWithValue("@Active", dr["Active"].ToString());
                SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            }
        }

        public DataTable GetSavedQuestionnarie()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetPevOrgSavedQuestion]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@OrgID", 26);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }

        public DataTable GetQuestionnarieAccId(int Qid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[Sp_GetPevQuestionCollectionAccID]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@QuestionTypeID", Qid);
            SqlDataReader Sqldr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(Sqldr);
            return rowCount;
        }
    }
}
