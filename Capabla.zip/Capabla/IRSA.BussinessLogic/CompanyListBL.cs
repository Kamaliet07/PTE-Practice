﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
   public class CompanyListBL
    {
       public static DataTable GetData()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           //string query = "select JobTYpe,Title,JobCity,ExpirationDate,JobLocation,CONVERT(nvarchar(10),Experiencefrom) + '-' + CONVERT(nvarchar(10),ExperienceTo)+' yrs' as ExperienceLevel from txnJobPosting where  JobCountry like '%" + job.Country + "%' and Title like '%" + job.Keyword + "%' and JobLocation like '%" + job.City + "%'";
           string query = " select * from lkpCompany ";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

    }
}
