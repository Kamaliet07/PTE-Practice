﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;

namespace IRSA.BussinessLogic
{
   public class Job_domainBL
   {
       public static DataTable GetJobdomainQuestionnaireData(string eid)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_CapablaQuestionnaire";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ElementID", SqlDbType.VarChar, 100),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };


           Parameters[0].Value = eid;
           Parameters[1].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }

       public static DataTable GetJobDomainReportData(string eid, string onet, string Questemplate,string CultureID,int UserID,int AttemptID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetCapablaBarandRadarGraphReportdata";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
           
            new SqlParameter("@EID", SqlDbType.VarChar, 6),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
            new SqlParameter("@AttmtID", SqlDbType.Int),
            new SqlParameter("@JobOccupation", SqlDbType.NVarChar, 200),
                };


           Parameters[0].Value = eid;
           Parameters[1].Value = CultureID;
           Parameters[2].Value = UserID;
           Parameters[3].Value = Questemplate;
           Parameters[4].Value = AttemptID;
           Parameters[5].Value = onet;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }
       public static DataTable GetJobDomainRoleMatchReportData(string JobFamily, string onet, string Questemplate, string CultureID, int UserID, int AttemptID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "Sp_GetCapbalaRoleMatchData";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
           
            new SqlParameter("@JobFamily", SqlDbType.VarChar, 6),
            new SqlParameter("@JobOccuptaion", SqlDbType.NVarChar, 200),
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
            new SqlParameter("@AttmtID", SqlDbType.Int),
           
                };


           Parameters[0].Value = JobFamily;
           Parameters[1].Value = onet;
           Parameters[2].Value = UserID;
           Parameters[3].Value = Questemplate;
           Parameters[4].Value = CultureID;
           Parameters[5].Value = AttemptID;
           
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }

       public static DataTable GetJobFamilyID(int AttemptID,int UserID,string templateName)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select Top (1) * from txnQuestionaireResult where AttemptID='"+ AttemptID +"' and QuestionaireTemplateName= '" + templateName + "' and UserID = '" + UserID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetJobDomainPieGraphReportdata(string CultureID, int UserID,string Questemplate, int AttemptID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_GetCapablaPieGraphReportdata";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
           
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.Char,40),
            
            new SqlParameter("@AttmtID", SqlDbType.Int),
           
                };


           Parameters[0].Value = CultureID;
           Parameters[1].Value = UserID;
           Parameters[2].Value = Questemplate;
        
           Parameters[3].Value = AttemptID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }


   }
}
