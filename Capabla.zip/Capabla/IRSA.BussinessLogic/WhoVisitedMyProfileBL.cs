﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.Common.GlobalFunction;
using IRSA.DALInterface;
using IRSA.DALFactory;

namespace IRSA.BussinessLogic
{
   public class WhoVisitedMyProfileBL
   {
       public static DataTable profile(int UserID, int combovalue)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmd = new SqlCommand();
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmd.CommandText = "sp_whoVisited";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
                 
                    new SqlParameter("@UserID", SqlDbType.Int),
                    new SqlParameter("@combovalue", SqlDbType.Int)
                              
                };
           Parameters[0].Value = UserID;
           Parameters[1].Value = combovalue;
           cmd.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;  

       }      
    }
}
