﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using System.Data.SqlClient;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
    public class MyAppliedJobBL
   {
        //To see Applied job by Candidate
        public static DataTable MyAppliedJob(int UserID, int flag)
       {
           //int flag = 0;
           int Jobid = 1;
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_CandidateAppliedViewJob";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
            {
                    
            new SqlParameter("@userID",SqlDbType.Int,50),
            new SqlParameter("@flag",SqlDbType.Int,50),
            new SqlParameter("@JobID",SqlDbType.Int,50)
           
            };
           Parameters[0].Value = UserID;
           Parameters[1].Value = flag;
           Parameters[2].Value = Jobid;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }

       public static DataTable MatchedJob()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select JobTitle, Industry,Company, Location,ProfileFit,SearchFit from txnjobCentre;";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }

       //To insert Applied job of Candidate
       public static void candidateApplyJob(int UserID, int jobID)
       {
           int Deleted = 0;
           int Status = 1;
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_CandidateAppliedJob";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
             {

             new SqlParameter("@UserID",SqlDbType.Int,50),
             new SqlParameter("@JobID",SqlDbType.Int,50),
             new SqlParameter("@Deleted",SqlDbType.Bit),
             new SqlParameter("@Status",SqlDbType.Bit)
             };
           Parameters[0].Value = UserID;
           Parameters[1].Value = jobID;
           Parameters[2].Value = Deleted;
           Parameters[3].Value = Status;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);

       }
    //To Get the skill questionnaire status of candaidate for questionnaire
       public static DataTable getStatus(int UserID, int jobID)
       {
           int flag = 1;
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_QuestionnaireStatus";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
             {

             new SqlParameter("@UserID",SqlDbType.Int,50),
             new SqlParameter("@jobID",SqlDbType.Int,50),
             new SqlParameter("@flag",SqlDbType.Int,50)
             };
           Parameters[0].Value = UserID;
           Parameters[1].Value = jobID;
           Parameters[2].Value = flag;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }

       //To Get the Tools and technology questionnaire status of candaidate for questionnaire
       public static DataTable getStatusTools(int UserID, int jobID)
       {
           int flag = 0;
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_QuestionnaireStatus";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
             {

             new SqlParameter("@UserID",SqlDbType.Int,50),
             new SqlParameter("@jobID",SqlDbType.Int,50),
             new SqlParameter("@flag",SqlDbType.Int,50)
             };
           Parameters[0].Value = UserID;
           Parameters[1].Value = jobID;
           Parameters[2].Value = flag;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }

        //
       public static void DeleteAppliedJob(int UserID,int jobID,int flag)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "Question Answers  Is not Added";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "usp_CandidateAppliedViewJob";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
             {
              new SqlParameter("@userID",SqlDbType.Int,50),
              new SqlParameter("@JobID",SqlDbType.Int,50),
              new SqlParameter("@flag",SqlDbType.Int,50)
             };


           Parameters[0].Value = UserID;
           Parameters[1].Value = jobID;
           Parameters[2].Value = flag;
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);

           
       }
    }
}
