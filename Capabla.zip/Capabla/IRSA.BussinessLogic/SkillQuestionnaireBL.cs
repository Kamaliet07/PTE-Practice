﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;

namespace IRSA.BussinessLogic
{
    public class SkillQuestionnaireBL
    {
        public static DataTable GetSkillQuestionnaireData(string eid)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            
            cmdProject.CommandText = "sp_SkillQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ElementID", SqlDbType.VarChar, 100),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };


            Parameters[0].Value = eid;
            Parameters[1].Value = "EN";
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;

        }

        public void InsertskillQues(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_InsertQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar,50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
             new SqlParameter("@AttemptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = objskill.ElementID;
            Parameters[2].Value = objskill.QuestionnaireTemplate;
            Parameters[3].Value = objskill.DateofSubmit;
            Parameters[4].Value = objskill.DataValue;
            Parameters[5].Value = objskill.ScaleID;
            Parameters[6].Value = "EN";
            Parameters[7].Value = objskill.AttemptID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }

        public void InsertOrgskillQues(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_InsertOrgQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
             new SqlParameter("@OrganisationID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar,50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
             new SqlParameter("@AttemptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = SessionInfo.OrganisationID;
            Parameters[2].Value = objskill.ElementID;
            Parameters[3].Value = objskill.QuestionnaireTemplate;
            Parameters[4].Value = objskill.DateofSubmit;
            Parameters[5].Value = objskill.DataValue;
            Parameters[6].Value = objskill.ScaleID;
            Parameters[7].Value = "EN";
            Parameters[8].Value = objskill.AttemptID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }

        public void InsertQuesSubmissionList(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_InsertQuestionnaireSubmitStatus";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@Status", SqlDbType.Char ,10),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateSubmitted",SqlDbType.NVarChar,50),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@AttemptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;// SessionInfo.UserId;
            Parameters[1].Value = objskill.Status;
            Parameters[2].Value = objskill.QuestionnaireTemplate;
            Parameters[3].Value = objskill.DateSubmitted;
            Parameters[4].Value = "EN";
            Parameters[5].Value = objskill.AttemptID;

            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }
        public static DataTable GetSubmitQuestions(string questemplate,int AttemptID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetSubmitStatus";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            ////new SqlParameter("@CultureID", SqlDbType.Char, 4),
           new SqlParameter("@AttemptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = questemplate;
            Parameters[2].Value = AttemptID;
            ////Parameters[2].Value = "EN";
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }

        public static DataTable GetOrgSubmitQuestions(string questemplate, int AttemptID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_GetOrgSubmitStatus";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            ////new SqlParameter("@CultureID", SqlDbType.Char, 4),
           new SqlParameter("@AttemptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = questemplate;
            Parameters[2].Value = AttemptID;
            ////Parameters[2].Value = "EN";
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
        }
        public void DeleteskillQues(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_DeleteQuestionnaireResult";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar , 50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@AttenptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = objskill.ElementID;
            Parameters[2].Value = objskill.QuestionnaireTemplate;
            Parameters[3].Value = objskill.DateofSubmit;
            Parameters[4].Value = objskill.DataValue;
            Parameters[5].Value = objskill.ScaleID;
            Parameters[6].Value = "EN";
            Parameters[7].Value = objskill.AttemptID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }
        public void DeleteOrgskillQues(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            int OrganisationID = SessionInfo.OrganisationID;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_DeleteOrgQuestionnaireResult";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@OrganisationID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar , 50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@AttenptID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = OrganisationID;
            Parameters[2].Value = objskill.ElementID;
            Parameters[3].Value = objskill.QuestionnaireTemplate;
            Parameters[4].Value = objskill.DateofSubmit;
            Parameters[5].Value = objskill.DataValue;
            Parameters[6].Value = objskill.ScaleID;
            Parameters[7].Value = "EN";
            Parameters[8].Value = objskill.AttemptID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }

        public void InserttoolstecQues(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_InsertToolstechQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar,50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@jobID", SqlDbType.Int),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = objskill.ElementID;
            Parameters[2].Value = objskill.QuestionnaireTemplate;
            Parameters[3].Value = objskill.DateofSubmit;
            Parameters[4].Value = objskill.DataValue;
            Parameters[5].Value = objskill.ScaleID;
            Parameters[6].Value = "EN";
            Parameters[7].Value = objskill.jobID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }
        public static DataTable GetUserAttemptID(int UserID,string questemplate)
        {
           
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select Top 1 AttemptID from txnQuestionaireResult where  UserID='" + UserID + "' and QuestionaireTemplateName='" + questemplate + "' order by AttemptID Desc";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable GetOrgUserAttemptID(int UserID, string questemplate)
        {

            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select Top 1 AttemptID from txnOrgQuestionnaire where  UserID='" + UserID + "' and QuestionaireTemplateName='" + questemplate + "' order by AttemptID Desc";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable GetUserAttemptIDfromsubmissonList(int UserID, string questemplate)
        {

            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select Top 1 AttemptID from txnQuestionnaireSubmissionList where  UserID='" + UserID + "' and QuestionaireTemplateName='" + questemplate + "' order by AttemptID Desc";
            //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable BindJobFamilyData()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT [JobFamilyID],[JobFamilyName]FROM [dbo].[lkpJobFamily]";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable BindOccupation(int JobFamilyID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT ONETSOCCode,SUBSTRING(ONETSOCCode,0,3) as JobFamilyID,Title FROM [dbo].[lkpOccupationData] where ONETSOCCode Like '" + JobFamilyID +"'+'%'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static DataTable GetWorkActivityQuestionnaire(string Joboccupation,string CultureID)
        {

            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand SqlCmd = new SqlCommand();
            SqlCmd.CommandType = CommandType.StoredProcedure;
            SqlCmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            SqlCmd.CommandText = "[sp_WorkActivityQuestionnaire]";
            IConnection = objDataAccessLayer.GetConnection();
            SqlCmd.Parameters.AddWithValue("@JobOccupation", Joboccupation);
            SqlCmd.Parameters.AddWithValue("@CultureID", CultureID);
            SqlDataReader dr = (SqlDataReader)objDataAccessLayer.ExecuteReader(SqlCmd, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(dr);
            return rowCount;
        }
        public void InsertWorkActivityQuestionnaire(SkillQuestionnaireSH objskill)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_InsertWorkActivityQuestionnaire";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar,50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
             new SqlParameter("@AttemptID", SqlDbType.Int),
             new SqlParameter("@OccupationID", SqlDbType.Int),
             new SqlParameter("@JobOccupation", SqlDbType.NVarChar,100),
                };

            Parameters[0].Value = SessionInfo.UserId;
            Parameters[1].Value = objskill.ElementID;
            Parameters[2].Value = objskill.QuestionnaireTemplate;
            Parameters[3].Value = objskill.DateofSubmit;
            Parameters[4].Value = objskill.DataValue;
            Parameters[5].Value = objskill.ScaleID;
            Parameters[6].Value = "EN";
            Parameters[7].Value = objskill.AttemptID;
            Parameters[8].Value = objskill.jobID;
            Parameters[9].Value = objskill.OccupationID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }

        public void InboxcandidateAssessmentCompleted(int UserID,int RecuriterID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "sp_InboxcandidateAssessmentCompleted";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
            new SqlParameter("@RecruiterID", SqlDbType.Int),
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@CultureID", SqlDbType.Char,2),
                };

            Parameters[0].Value = UserID;
            Parameters[1].Value = RecuriterID;
            Parameters[2].Value = SessionInfo.CultureID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

        }

    }
}
