﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Facade;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
  public class OrgAccountBL
    {
      int UserID;
      public static DataTable SaveOrganisationData(OrgAccountSH objoraccSH, int UserID, int OrganisationID)
      {
                IDbConnection IConnection = null;
                string ErrorMessage = "Question Answers  Is not Added";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand cmdProject = new SqlCommand();
                cmdProject.CommandType = CommandType.StoredProcedure;
                cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                cmdProject.CommandText = "sp_OrganisationAccount";
                IConnection = objDataAccessLayer.GetConnection();
                SqlParameter[] Parameters =
                {


                    
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@OrganisationID",SqlDbType.Int),
            new SqlParameter("@Name ", SqlDbType.NVarChar, 150),
            new SqlParameter("@HeadQuarterAddress  ",SqlDbType.NVarChar,200),
            new SqlParameter("@City ",SqlDbType.NVarChar, 50),
            new SqlParameter("@Country",SqlDbType.NVarChar, 50),
            new SqlParameter("@IndustryName",SqlDbType.NVarChar, 50),
            //new SqlParameter("@Status ",SqlDbType.NVarChar, 50),
            new SqlParameter("@Size", SqlDbType.NChar, 50),
            new SqlParameter("@Founded", SqlDbType.Char, 4),
            new SqlParameter("@Website ", SqlDbType.NVarChar, 100),
            new SqlParameter("@StockSymbol ",SqlDbType.NChar, 10),
            new SqlParameter("@Description ",SqlDbType.NVarChar, 1100),
            new SqlParameter("@GoalsAndValues",SqlDbType.NVarChar, 2500),
            new SqlParameter("@OrgStatus",SqlDbType.Char, 2),
             new SqlParameter("@Type ",SqlDbType.NChar, 10),
            new SqlParameter("@LogoPath",SqlDbType.NVarChar, 50),
           new SqlParameter("@Specilaties ", SqlDbType.NVarChar, 100),
            };
                Parameters[0].Value = UserID;
                Parameters[1].Value = OrganisationID;
                Parameters[2].Value = objoraccSH.Name;
                Parameters[3].Value = objoraccSH.HeadQuarterAddress;
                Parameters[4].Value = objoraccSH.City;
                Parameters[5].Value = objoraccSH.Country;
                Parameters[6].Value = objoraccSH.IndustryName;
                //Parameters[7].Value = objoraccSH.Status;
                Parameters[7].Value = objoraccSH.Size;
                Parameters[8].Value = objoraccSH.Founded;
                Parameters[9].Value = objoraccSH.Website;
                Parameters[10].Value = objoraccSH.StockSymbol;
                Parameters[11].Value = objoraccSH.Description;
                Parameters[12].Value = objoraccSH.GoalsAndValues;
                Parameters[13].Value = objoraccSH.OrgStatus;
                Parameters[14].Value = objoraccSH.Type;
                Parameters[15].Value = objoraccSH.LogoPath;
                Parameters[16].Value = objoraccSH.Specilaties;
                
                cmdProject.Parameters.AddRange(Parameters);
                SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(drProject);

                return rowCount;
            


        }
     
      public DataTable GetOrganisationData(int UserID, int OrganisationID)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_GetOrganisationData";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
               new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@OrganisationID", SqlDbType.Int),
                };
          Parameters[0].Value = UserID;
           Parameters[1].Value = OrganisationID;

          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }

      public DataTable GetPriContactData(int UserID, int OrganisationID,bool flag)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_GetprimaryContact";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
               new SqlParameter("@UserID", SqlDbType.Int),
               new SqlParameter("@OrgID", SqlDbType.Int),
           new SqlParameter("@Flag", SqlDbType.Bit),
                };
          Parameters[0].Value = UserID;
          Parameters[1].Value = OrganisationID;
          Parameters[2].Value = flag;
          cmdProject.Parameters.AddRange(Parameters);
          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);
          return rowCount;

      }
      public static DataTable SavePricontactData(OrgAccountSH objoraccSH, int UserID, int OrganisationID)
      {
          IDbConnection IConnection = null;
          string ErrorMessage = "Question Answers  Is not Added";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          SqlCommand cmdProject = new SqlCommand();
          cmdProject.CommandType = CommandType.StoredProcedure;
          cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
          cmdProject.CommandText = "sp_InsertprimaryContact";
          IConnection = objDataAccessLayer.GetConnection();
          SqlParameter[] Parameters =
                {
       
            new SqlParameter("@UserID",SqlDbType.Int),
            new SqlParameter("@OrganisationID",SqlDbType.Int),
            new SqlParameter("@JobTitle ", SqlDbType.NVarChar, 100),
            new SqlParameter("@Email",SqlDbType.NVarChar,100),
            new SqlParameter("@PhBusiness ",SqlDbType.NVarChar, 50),
            new SqlParameter("@PhMobile",SqlDbType.NVarChar, 50),
            new SqlParameter("@PhFax",SqlDbType.NVarChar, 50),
            new SqlParameter("@Zip ",SqlDbType.Int),
            new SqlParameter("@Country", SqlDbType.NVarChar, 100),
            //new SqlParameter("@OrgID",SqlDbType.Int),
            new SqlParameter("@Flag",SqlDbType.Char,5),
            new SqlParameter("@FullName",SqlDbType.NVarChar, 100),
            new SqlParameter("@DisplayAs",SqlDbType.NVarChar, 100),
            new SqlParameter("@Photo",SqlDbType.NVarChar,50),
           
            };
          Parameters[0].Value = UserID;
          Parameters[1].Value = OrganisationID;
          Parameters[2].Value = objoraccSH.JobTitle;
          Parameters[3].Value = objoraccSH.Email;
          Parameters[4].Value = objoraccSH.PhBusiness;
          Parameters[5].Value = objoraccSH.PhMobile;
          Parameters[6].Value = objoraccSH.PhFax;
          Parameters[7].Value = objoraccSH.Zip;
          Parameters[8].Value = objoraccSH.Country;
          //Parameters[9].Value = objoraccSH.OrgID;
          Parameters[9].Value = objoraccSH.Flag;
          Parameters[10].Value = objoraccSH.FullName;
          Parameters[11].Value = objoraccSH.DisplayAs;
          Parameters[12].Value = objoraccSH.Photo;
  
          cmdProject.Parameters.AddRange(Parameters);

          SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
          DataTable rowCount = new DataTable();
          rowCount.Load(drProject);

          return rowCount;



      }

      public void SaveLogo(string Logopath,int OrganisationID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string Query = "Select OrganisationID from lkpOrganisation where OrganisationID='" + OrganisationID + "'";
            DataTable dt = new DataTable();
            dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                query = "UPDATE lkpOrganisation SET LogoPath='" + Logopath + "' where OrganisationID='" + OrganisationID + "'";
            }
            else
            {
                query = "Insert into lkpOrganisation (LogoPath) values  ('" + Logopath + "')";
            }
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

      public void Removepripic(int UserID, int OrgID,bool flag)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string Query = "Select OrgID from txnContactPerson where OrgID='" + OrgID + "'and UserID='" + UserID + "'  and flag='" + flag + "'";
            DataTable dt = new DataTable();
            dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                query = "UPDATE txnContactPerson SET Photo='0.png' where OrgID='" + OrgID + "'and UserID='" + UserID + "'  and flag='"+ flag +"'";
            }
            else
            {
                query = "Insert into txnContactPerson (Photo) values  ('0.png') where OrgID='" + OrgID + "'and UserID='" + UserID + "' and flag='" + flag + "'";
            }
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

      public void Removericlogo(int UserID, int OrganisationID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string Query = "Select OrganisationID from lkpOrganisation where OrganisationID='" + OrganisationID + "'";
            DataTable dt = new DataTable();
            dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
                query = "UPDATE lkpOrganisation SET LogoPath='0.png' where OrganisationID='" + OrganisationID + "'" ;
            }
            else
            {
                query = "Insert into lkpOrganisation (LogoPath) values  ('0.png') ";
            }
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
      public void Savepriphoto(string Photo, int OrganisationID, int UserID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            //string Query = "Select OrgID from txnContactPerson where OrgID='" + OrganisationID + "'and UserID='"+UserID+"' and Flag='1' ";

            ////string Query = "Select Photo from txnContactPerson where OrgID='" + OrganisationID + "' and UserID='" + UserID + "'and Flag='1' ";
            //DataTable dt = new DataTable();
            //dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            //if (dt.Rows.Count > 0)
            //{
               query = "UPDATE txnContactPerson SET Photo='" + Photo + "' where OrgID='" + OrganisationID + "'and UserID='" + UserID + "' and Flag='1' ";
            //}
            ////else
            //{
            //  //query ="  Insert into txnContactPerson (Photo) values  ('" + Photo + "')";
            //    query = "Insert into txnContactPerson (Photo) values  ('" + Photo + "') Where OrganisationID='" + OrganisationID + "'and UserID='" + UserID + "' and Flag='1' ";
            //}
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }

      public void Savesecphoto(string Photo, int OrganisationID, int UserID)
        {
            string ErrorMessage = "No Data Found";
            string query;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string Query = "Select OrgID from txnContactPerson where OrgID='" + OrganisationID + "'and UserID='"+UserID+"' and Flag='0' ";

            //string Query = "Select Photo from txnContactPerson where OrgID='" + OrganisationID + "' and UserID='" + UserID + "'and Flag='1' ";
            DataTable dt = new DataTable();
            dt=objDataAccessLayer.GetDataTable(Query, CommandType.Text, ref ErrorMessage);
            if (dt.Rows.Count > 0)
            {
               query = "UPDATE txnContactPerson SET Photo='" + Photo + "' where OrgID='" + OrganisationID + "'and UserID='" + UserID + "' and Flag='0' ";
            }
            else
            {
                //query ="  Insert into txnContactPerson (Photo) values  ('" + Photo + "')";
                query = "Insert into txnContactPerson (OrgID,UserID,Flag,Photo) values  ('" + OrganisationID + "','" + UserID + "','0','" + Photo + "')";
            }
            objDataAccessLayer.ExecuteNonQuery(query, CommandType.Text, ref ErrorMessage);

        }
}
}
