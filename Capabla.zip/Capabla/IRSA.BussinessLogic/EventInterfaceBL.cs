﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
   public class EventInterfaceBL
    {

        public static DataTable InsertData(EventInterfaceSH sh,int UserID)
        {
           // int UserID = SessionInfo.UserId;
            //string query;
            //string ErrorMessage = "No Data Found";
            //string ConnectionString = GlobalMethod.GetConnectionString();
            //string dbType = GlobalMethod.GetDbType();
            //Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            //IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            //objDataAccessLayer.ConnectionString = ConnectionString;
            //string query1 = "SELECT EventID from  txnEvent where UserID='" + UserID + "'and EventDescription='" + sh.Title + "'";
            //DataTable temp = objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);

            //if (temp.Rows.Count == 0)
            //{
            //    query = "insert into  txnEvent (UserID,EventDescription,Summary,DateTo,LastDate,ContactMailID) values ( '" + UserID + "'  ,'" + sh.Title + "','" + sh.Description + "','" + sh.StartDate + "','" + sh.EndDate + "','" + sh.Url + "')";
            //}
            //else
            //{
            //    query = "Update  txnEvent set EventDescription='" + sh.Title + "',Summary='" + sh.Description + "',DateTo='" + sh.StartDate + "',LastDate='" + sh.EndDate + "',ContactMailID='" + sh.Url + "' where  UserID='" + UserID + "'and EventDescription='" + sh.Title + "'";
            //}
          
        
            //objDataAccessLayer.ExecuteNonQuery
            //    (query, CommandType.Text, ref ErrorMessage);
            //int UserID = SessionInfo.UserId;
            IDbConnection IConnection = null;
            string ErrorMessage = "Question Answers  Is not Added";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "EventInsert";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
          

            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@Title",SqlDbType.NVarChar, 80),
            new SqlParameter("@Description",SqlDbType.NVarChar, 3000),
            new SqlParameter("@StartDate",SqlDbType.NVarChar, 20),
            new SqlParameter("@EndDate",SqlDbType.NVarChar, 20),
            new SqlParameter("@Url", SqlDbType.NVarChar, 80),
            new SqlParameter("@City", SqlDbType.NVarChar, 50),
            new SqlParameter("@Country", SqlDbType.NVarChar, 50)
        
          
                };
            Parameters[0].Value = UserID ;
            Parameters[1].Value = sh.Title;
            Parameters[2].Value = sh.Description ;
            Parameters[3].Value = sh.StartDate;
            Parameters[4].Value = sh.EndDate;
            Parameters[5].Value = sh.Url;
            Parameters[6].Value = sh.City;
            Parameters[7].Value = sh.Country;
          


            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject);
            return rowCount;
          


        }

        public static DataTable GetData()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  * FROM txnEvent ";

            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }
        public static DataTable GetDataPopUp(int EventID,string Title)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  * FROM txnEvent where UserID='" + EventID + "'and EventDescription='" + Title + "'";

            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }
    }
}
