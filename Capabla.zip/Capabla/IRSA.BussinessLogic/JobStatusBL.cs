﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
   public class JobStatusBL
    {


        public void InsertData(JobStatusSH jbsh)
        {
            int UserID = SessionInfo.UserId;
            string query;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;


            query = "Update   txnMemberAccount set EmploymentStatus='" + jbsh.RadComboBox2 + "',AvailibiltyFrom='" + jbsh.RadDatePicker2 + "',AvailibiltyTo='" + jbsh.RadComboBox3 + "',JobTypes='" + jbsh.RadComboBox4 + "',PreferredCurrency='" + jbsh.RadComboBox5 + "',PreferredSalaryAmount='" + jbsh.info + "',PayDuration='" + jbsh.RadComboBox6 + "',HoursPerweek='" + jbsh.TextBox1 + "' ,Relocation='" + jbsh.radio + "' where  UserID='" + UserID + "'";


            
            objDataAccessLayer.ExecuteNonQuery
                (query, CommandType.Text, ref ErrorMessage);

        }

        public static DataTable Getdata()
        {
            int UserID = SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  * FROM  txnMemberAccount where UserID='" + UserID + "'";

            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
    }
}
