﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA.BussinessLogic
{
    public class CompanySearchBL
    {

        public static DataTable GetCompany(string Keywords, CompanySearchSH objCompanySearchSH)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           // cmdProject.CommandText = "usp_CompanySearch2";
            cmdProject.CommandText = "search_Company";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 //new SqlParameter("@beta", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@CompanyName", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@Industryname", SqlDbType.NVarChar,80 ),
                  new SqlParameter("@Type", SqlDbType.NVarChar,80 ),
                 new SqlParameter("@CompanyURL", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@CountryName ", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@City", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@keyWord", SqlDbType.NVarChar,50 ),
                 
               };
            Parameters[0].Value = objCompanySearchSH.CompanyName;
            Parameters[1].Value = objCompanySearchSH.IndustryName;
            Parameters[2].Value = objCompanySearchSH.Type;
            Parameters[3].Value = objCompanySearchSH.CompanyURL;
            Parameters[4].Value = objCompanySearchSH.CountryName;
            Parameters[5].Value = objCompanySearchSH.City;
            Parameters[6].Value = Keywords;
            //Parameters[0].Value = Keywords;


            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        public static DataTable GetUserData(string Keywords, CompanySearchSH objCompanySearchSH)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
             cmdProject.CommandText = "usp_CompanySearch2";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@beta", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@CompanyName", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@Industryname", SqlDbType.NVarChar,80 ),
                 new SqlParameter("@CompanyURL", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@CountryName ", SqlDbType.NVarChar,50 ),
                 new SqlParameter("@City", SqlDbType.NVarChar,50 ),
                 
               };
          
            Parameters[0].Value = Keywords;
            Parameters[1].Value = objCompanySearchSH.CompanyName;
            Parameters[2].Value = objCompanySearchSH.IndustryName;
            Parameters[3].Value = objCompanySearchSH.CompanyURL;
            Parameters[4].Value = objCompanySearchSH.CountryName;
            Parameters[5].Value = objCompanySearchSH.City;


            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;
        }

        public static DataTable GetCompanyList()
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_CompanySearchBasic";
            IConnection = objDataAccessLayer.GetConnection();

            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
        public static DataTable getUser(int UserID)
        {
           
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT EmailID FROM txnMemberAccount where UserID='" + UserID + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        }
        public static DataTable GetCompanyAsses(int UserID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmdProject = new SqlCommand();
            cmdProject.CommandType = CommandType.StoredProcedure;
            cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmdProject.CommandText = "usp_CompanyAssessmentFit";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@UserID", SqlDbType.Int ),
                };
            Parameters[0].Value = UserID;
            cmdProject.Parameters.AddRange(Parameters);
            SqlDataReader drProject1 = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
            DataTable rowCount = new DataTable();
            rowCount.Load(drProject1);
            return rowCount;

        }
    }
}
