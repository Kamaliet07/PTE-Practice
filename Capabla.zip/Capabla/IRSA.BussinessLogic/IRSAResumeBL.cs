﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA
{
    public class IRSAResumeBL
    {

        //to retrieve contact details from [txnMemberAccount] table
        public static DataTable getData(int UserID,int flag,string cultID)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_IRSAResume";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@UserID", SqlDbType.Int),
                 new SqlParameter("@Flag",SqlDbType.Int),
                 new SqlParameter("@CultureID",SqlDbType.Char,2)
                             
                };
            Parameters[0].Value = UserID;
            Parameters[1].Value = flag;
            Parameters[2].Value = cultID;
            cmd.Parameters.AddRange(Parameters);
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;
        }
        //To retrieve Industry Name
        public static string getIndustryName(int UserID, string cultID)    
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  IndustryID FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            int indID = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage));
            //return MyJobAgentBL.getOccupations(JobFamilyID);
            string query1 = "SELECT  IndustryName FROM lkpIndustry where IndustryID ='" + indID + "' and CultureID='"+cultID+"'";
            return (objDataAccessLayer.ExecuteScalar(query1, CommandType.Text, ref ErrorMessage)).ToString(); 
        }

        //To retrieve Industry Experience and Goals
        public static string getExpNGoals(int UserID,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  ProfessionalExperinceandGoals FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and (Who='ST' OR Who='JS')";
            return (objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage)).ToString();
        }

         //To retrieve the list of Clients for which projects have been done
        public static DataTable getProjetcts(int UserID,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT ProjectName,ClientName,DurationFrom,DurationTo,Description,Skills FROM [txnProjectDetails] WHERE UserID='" + UserID + "' and Deleted='false' and CultureID='"+cultID+"' ORDER BY DurationTo DESC";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

       

        //to check whether the candidate entry exists in various tables
        public static Boolean isExists(int UserID,int flg,string cultID)
        {
            string ErrMsg = "Error";
            int count = 0;
            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = string.Empty;
            if (flg == 0)
            {
                query = "select count(UserID) from [txnMemberAcademics] where UserID='" + UserID + "' and deleted='0' and HighestDegree<>'' and CultureID='"+cultID+"' and HighestDegree IS NOT NULL";
            }
            else if(flg == 1)
            {
                query = "select count(*) from [txnProjectDetails] where UserID='" + UserID + "' and deleted='False' and CultureID='"+cultID+"'";
            }
            else if (flg == 2)
            {

                query = "select count(*) from [txnMemberLicenseandCertifications] where UserID='" + UserID + "' and deleted='False' and CultureID='" + cultID + "'";
            }
            else if (flg == 3)
            {
                query = "select count(UserID) from [txnMemberAcademics] where UserID='" + UserID + "' and deleted='0' and Specialization<>'' and Specialization IS NOT NULL and CultureID='" + cultID + "'";
            }
            else if (flg == 4)
            {
                query = "select count(UserID) from [txnMemberVisaInformation] where UserID='" + UserID + "' and deleted='0' and Country<>'' and Country IS NOT NULL and CultureID='" + cultID + "'";
            }
            else if (flg == 5)
            {
                query = "select count(UserID) from [txnMemberAssociations] where UserID='" + UserID + "' and deleted='0' and AName<>'' and AName IS NOT NULL and CultureID='" + cultID + "'";
            }
            else if (flg == 6)
            {
                query = "select count(UserID) from [txnMemberAccount] where UserID='" + UserID + "' and deleted='0' and SCName<>'' and SCName IS NOT NULL and CultureID='" + cultID + "' and (Who='ST' OR Who='JS')";
            }
            else if (flg == 7)
            {
                query = "select count(UserID) from [txnMemberCompany] where UserID='" + UserID + "' and deleted='False' and PresentCompany='True' and CultureID='" + cultID + "'";
            }
            else if (flg == 8)
            {
                query = "select count(UserID) from [txnMemberCompany] where UserID='" + UserID + "' and deleted='False' and PresentCompany='False' and CultureID='" + cultID + "'";
            }
            else if (flg == 9)
            {
                query = "select count(UserID) from [txnAccountSettings] where UserID='" + UserID + "' and deleted='False' and CultureID='" + cultID + "'and Settingtype='Hide Identity'";
            }
            else if (flg == 10)
            {
                query = "select count(UserID) from [txnAccountSettings] where UserID='" + UserID + "' and deleted='False' and CultureID='" + cultID + "' and (Settingtype='Resume_Video' or Settingtype='Resume_Both'  or Settingtype='Resume_Text')";
            }
            else if (flg == 11)
            {
                query = "select count(UserID) from [txnAccountSettings] where UserID='" + UserID + "' and deleted='False' and CultureID='" + cultID + "' and Settingtype='My Profile Photo'";
            }
            else if (flg == 12)
            {
                query = "select count(UserID) from [txnAccountSettings] where UserID='" + UserID + "' and deleted='False' and CultureID='" + cultID + "' and Settingtype='PreferedIndustry'";
            }
            count = Convert.ToInt32(objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrMsg));
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        //To retrieve skills from txnMemberAccounts
        public static string getSkills(int UserID,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  KeySkills FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            return (objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage)).ToString();
        }

         //to retrieve degrees of a candidate
        public static DataTable getAca(int UserID,int flag,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = string.Empty;
            if (flag == 1) //to obtain university degrees
            {
                query = "SELECT HighestDegree,University,PassingYear FROM [txnMemberAcademics] WHERE UserID='" + UserID + "' and Deleted='0' and CultureID='"+cultID+"' ORDER BY PassingYear DESC";
            }
            else if(flag==2)
            {
                query = "SELECT Specialization,InstituteName,SplPasingYear FROM [txnMemberAcademics] WHERE UserID='" + UserID + "' and Deleted='0' and CultureID='"+cultID+"' ORDER BY SplPasingYear DESC";
            }
            
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);


        }

          //to retrieve personal information of the candidate
        public static string getPersonalInfo(int UserID, int flag,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query=string.Empty;
            if (flag == 1)
            {
                query = "SELECT  PersonalInterest FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            }
            else if (flag == 2)
            {
                query = "SELECT  LanguageSkill FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            }
            else if (flag == 3)
            {
                query = "SELECT  DateOfBirth FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            }
            else if (flag == 4)
            {
                query = "SELECT  Sex FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            }
            else if (flag == 5)
            {
                query = "SELECT  Nationality FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            }
          
            return (objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage)).ToString();
      
        }

        //to retreive the approval code and ID of photo
        public static DataTable getPhoto(int UserID,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT PhotoID,PhotoApproved FROM [txnMemberAccount] WHERE UserID='" + UserID + "' and Deleted='false' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

        //To retrieve the list of Clients for which projects have been done
        public static DataTable getAddress(int UserID,string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT HouseNo,City,State,Country FROM [txnMemberAccount] WHERE UserID='" + UserID + "' and Deleted='false' and CultureID='" + cultID + "'and (Who='ST' OR Who='JS')";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
        }

         //to retrieve the duration i.e. difference between two dates
        public static DataTable getDuration(DateTime dtFrom, DateTime dtTo)
        {
            IDbConnection IConnection = null;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
            cmd.CommandText = "usp_Duration";
            IConnection = objDataAccessLayer.GetConnection();
            SqlParameter[] Parameters =
                {
                 
                 new SqlParameter("@From", SqlDbType.DateTime),
                 new SqlParameter("@To",SqlDbType.DateTime)
                             
                };
            Parameters[0].Value = dtFrom;
            Parameters[1].Value = dtTo;
            cmd.Parameters.AddRange(Parameters);
            DataTable dt = new DataTable();
            SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmd, ref ErrorMessage, ref IConnection);
            dt.Load(drProject);
            return dt;
        }

        //to retrieve the display name of the candidate
        public static string getDisplayName(int UserID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  DisplayName FROM txnMemberAccount where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and (Who='ST' OR Who='JS')";
            return (objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage)).ToString();
        }

        //to check whether name is hidden or not
        public static DataTable isNameHidden(int UserID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  HideName FROM txnAccountSettings where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and Settingtype='Hide Identity'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }

        //to check whether Photo is hidden or not
        public static DataTable isPhotoHidden(int UserID, string cultID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  EveryOne FROM txnAccountSettings where UserID='" + UserID + "'and Deleted='False' and CultureID='" + cultID + "' and Settingtype='My Profile Photo'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }

        
        //to get the Industry Preferences of the candidate
        public static string getIndPreferences(int UserID, string CultureID)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "SELECT  IndustryPreference FROM txnAccountSettings where UserID='" + UserID + "'and Deleted='False' and CultureID='" + CultureID + "' and Settingtype='PreferedIndustry'";
            return (objDataAccessLayer.ExecuteScalar(query, CommandType.Text, ref ErrorMessage)).ToString();

        }

        


       
    }
}
