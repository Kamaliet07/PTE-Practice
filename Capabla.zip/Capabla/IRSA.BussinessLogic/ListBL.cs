﻿using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA.BussinessLogic
{
  public class ListBL
    {
      public static DataTable GetTask()
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "SELECT  * FROM txnToDoList where UserID='" + UserID + "'";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public static DataTable GetTaskFinal()
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "SELECT  StartDate,EndDate,TaskID FROM txnToDoList where UserID='" + UserID + "' ";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public static DataTable GetTaskDay()
      {   
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "SELECT  DaysLeft FROM txnToDoList where UserID='"+UserID+"'";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public void InsertList(ListSh listinsert)
      {
          int UserID = SessionInfo.UserId;
          string query;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
             string  query1 = "SELECT TaskID from  txnToDoList where txnToDoList.TaskID='" + listinsert.TaskID  + "'";
            DataTable temp = objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);
            if (temp.Rows.Count == 0)
            {
                query = "insert into  txnToDoList (UserID,Task,EndDate,DaysLeft,Time,StartDate,FinalDate,Description) values ('" + UserID + "','" + listinsert.Task + "','" + listinsert.Date + "','" + listinsert.Days + "','" + listinsert.Time + "','" + listinsert.Stampdate + "','" + listinsert.Final + "','" + listinsert.Description + "')";
                
            }
            else
            {
                query = "Update  txnToDoList set Task='" + listinsert.Task + "',EndDate='" + listinsert.Date + "',DaysLeft='" + listinsert.Days + "',Time='" + listinsert.Time + "',Description='" + listinsert.Description + "',StartDate='" + listinsert.Stampdate + "' where TaskID='" + listinsert.TaskID + "'and UserID='" + UserID + "'";
          
              
            }
            objDataAccessLayer.ExecuteNonQuery
                (query, CommandType.Text, ref ErrorMessage);
         

      }

      public void InsertListEdit(ListSh listinsert22)
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "Update   txnToDoList set(Task,EndDate,StartDate)=  ('" + listinsert22.Task + "','" + listinsert22.Date + "','" + listinsert22.Stampdate + "')where UserID='" + UserID + "'";
          objDataAccessLayer.ExecuteNonQuery
              (query, CommandType.Text, ref ErrorMessage);

      }
      public void UpdateList(ListSh listinsert)
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          //string query1 = "SELECT  EndDate FROM txnToDoList ";

          //return objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);
          string query = "Update  txnToDoList set daysLeft='" + listinsert.Days + "'where TaskID='" + listinsert.TaskID + "'and UserID='" + UserID + "'";
          objDataAccessLayer.ExecuteNonQuery
              (query, CommandType.Text, ref ErrorMessage);

      }

      public static DataTable GetTaskDays()
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "SELECT  EndDate,TaskID FROM txnToDoList where UserID='" + UserID + "'";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public void UpdateListTime(ListSh listinsert1)
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "Update  txnToDoList set Time='" + listinsert1.Time + "'where TaskID='" + listinsert1.TaskID + "'and UserID='" + UserID + "'";
          objDataAccessLayer.ExecuteNonQuery
              (query, CommandType.Text, ref ErrorMessage);

      }
      public static DataTable GetTaskTime()
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "SELECT  StartDate,TaskID FROM txnToDoList where UserID='" + UserID + "' ";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public void DeleteList(ListSh listinsert22)
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "Delete from txnToDoList where TaskID='" + listinsert22.TaskID + "' and UserID='" + UserID + "'";
     
          objDataAccessLayer.ExecuteNonQuery
              (query, CommandType.Text, ref ErrorMessage);

      }
      public  static DataTable GetTaskEdit(ListSh listinsert22)
      {

          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "Select * from txnToDoList where TaskID='" + listinsert22.TaskID + "' and UserID='" + UserID + "'";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public static DataTable GetTaskList()
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "SELECT  TaskID FROM txnToDoList where UserID='" + UserID + "' ";

          return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

      }
      public void Final(ListSh listinsert44)
      {
          int UserID = SessionInfo.UserId;
          string ErrorMessage = "No Data Found";
          string ConnectionString = GlobalMethod.GetConnectionString();
          string dbType = GlobalMethod.GetDbType();
          Factory objFactory = new IRSA.DALFactory.Factory(dbType);
          IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
          objDataAccessLayer.ConnectionString = ConnectionString;
          string query = "Update  txnToDoList set FinalDate='" + listinsert44.Final + "'where TaskID='" + listinsert44.TaskID + "'and UserID='" + UserID + "'";
          objDataAccessLayer.ExecuteNonQuery
              (query, CommandType.Text, ref ErrorMessage);

      }

    }
}
