﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;


namespace IRSA.BussinessLogic
{
    public class RegistrationBL
    {
        public void SaveRegistrationData(RegistrationSH objRegistrationSH)
        {
         
                IDbConnection IConnection = null;
                string ErrorMessage = "Question Answers  Is not Added";
                string ConnectionString = GlobalMethod.GetConnectionString();
                string dbType = GlobalMethod.GetDbType();
                Factory objFactory = new IRSA.DALFactory.Factory(dbType);
                IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
                objDataAccessLayer.ConnectionString = ConnectionString;
                SqlCommand cmdProject = new SqlCommand();
                cmdProject.CommandType = CommandType.StoredProcedure;
                cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
                cmdProject.CommandText = "sp_RegistrationInfo";
                IConnection = objDataAccessLayer.GetConnection();
                SqlParameter[] Parameters =
                {
            new SqlParameter("@FirstName", SqlDbType.NVarChar, 15),
            new SqlParameter("@LastName", SqlDbType.NVarChar, 15),
            new SqlParameter("@EmailID", SqlDbType.NVarChar, 50),
            new SqlParameter("@Country",SqlDbType.NVarChar, 50),
            new SqlParameter("@Who",SqlDbType.Char, 2),
            new SqlParameter("@Password",SqlDbType.NVarChar, 50),
            new SqlParameter("@IndustryName",SqlDbType.NVarChar, 50),
            new SqlParameter("@PostalCode",SqlDbType.NVarChar, 50),
            new SqlParameter("@Company",SqlDbType.NVarChar, 50),
            new SqlParameter("@HighestDegree",SqlDbType.NVarChar, 50),
            new SqlParameter("@Institute",SqlDbType.NVarChar, 150),
             new SqlParameter("@CapchaCode",SqlDbType.NVarChar, 10)
                };

                Parameters[0].Value = objRegistrationSH.FirstName;
                Parameters[1].Value = objRegistrationSH.LastName;
                Parameters[2].Value = objRegistrationSH.EmailID;
                Parameters[3].Value = objRegistrationSH.Country;
                Parameters[4].Value = objRegistrationSH.Who;
                Parameters[5].Value = objRegistrationSH.Password;
                Parameters[6].Value = objRegistrationSH.Industry;
                Parameters[7].Value = objRegistrationSH.Postalcode;
                Parameters[8].Value = objRegistrationSH.Company;
                Parameters[9].Value = objRegistrationSH.Education;
                Parameters[10].Value = objRegistrationSH.Institute;
                Parameters[11].Value = objRegistrationSH.CapchaCode;
                cmdProject.Parameters.AddRange(Parameters);
                SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
                DataTable rowCount = new DataTable();
                rowCount.Load(drProject);

    
        


        }

        public static DataTable GetValidateUser(string EmailId)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from [txnMemberAccount] where EmailID='" + EmailId + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
                       

            
        }
        public static DataTable GetValidcmy(RegistrationSH objRegistrationSH)
        {
            string ErrorMessage = "";


            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from [lkpOrganisation] where Name='" + objRegistrationSH.Company + "' OR Name='" + objRegistrationSH.Institute + "'";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
                       

            
        }
       
        public static DataTable BindIndustryData()
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select IndustryName from lkpIndustry;";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }

        public static DataTable GetUserID(string EmailId, string Password)
        {
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from [txnMemberAccount] where EmailID='" + EmailId + "' ;";
            return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

        }
        public static bool GetValidateUserMail(string EmailId)
        {
            string ErrorMessage = "";
            int count = 0;

            IDbCommand Command;
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            IRSA.DALFactory.AbstractDALFactory objDALFactory = IRSA.DALFactory.AbstractDALFactory.CreateDBObject(dbType);
            Command = objDALFactory.CreateCommand();
            Command.CommandType = System.Data.CommandType.Text;
            IRSA.DALFactory.Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "select * from [txnMemberAccount] where EmailID='" + EmailId + "'";
            DataTable dtvalidate = new DataTable();
            dtvalidate = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            count = dtvalidate.Rows.Count;
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }



        }
    }

    }




