﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System.Data.SqlClient;

namespace IRSA.BussinessLogic
{
   public class Assessment360BL
   {
       public static DataTable BindIndustryData()
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select * from lkpIndustry;";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable BindOccupation(int IndustryID)
       {
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "SELECT     dbo.lkpIndustry.IndustryID, dbo.lkpIndustry.IndustryName, dbo.othIndustryOccupation.ONETSOCCode, dbo.lkpOccupationData.Title FROM         dbo.lkpIndustry INNER JOIN dbo.othIndustryOccupation ON dbo.lkpIndustry.IndustryID = dbo.othIndustryOccupation.IndustryID INNER JOIN dbo.lkpOccupationData ON dbo.othIndustryOccupation.ONETSOCCode = dbo.lkpOccupationData.ONETSOCCode WHERE  (dbo.lkpIndustry.IndustryID = '" + IndustryID + "')";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable Get360AssessmentData(string Title)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_360DegreeAssessment";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@Title", SqlDbType.VarChar, 100),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };


           Parameters[0].Value = Title;
           Parameters[1].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }

       public void Insert360Assessment(Assessment360SH objAssessment,int UserID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_Insert360DegreeAssessmentResult";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.NVarChar,50),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@WhoIs", SqlDbType.NChar , 10),
             new SqlParameter("@IndustryID", SqlDbType.Int),
               new SqlParameter("@OccupationID", SqlDbType.NVarChar,150),
                new SqlParameter("@AttemptID", SqlDbType.Int),
                };

           Parameters[0].Value =  UserID;
           Parameters[1].Value = objAssessment.ElementID;
           Parameters[2].Value = objAssessment.QuestionnaireTemplate;
           Parameters[3].Value = objAssessment.DateofSubmit;
           Parameters[4].Value = objAssessment.DataValue;
           Parameters[5].Value = objAssessment.ScaleID;
           Parameters[6].Value = "EN";
           Parameters[7].Value = objAssessment.WhoIs;
           Parameters[8].Value = objAssessment.IndustryID;

           Parameters[9].Value = objAssessment.OccupationID;
           Parameters[10].Value = objAssessment.AttemptID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

       }

       public static DataTable Get360AssessmentSubmitQuestions(string questemplate,Assessment360SH objAssessment,int UserID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_Get360AssessmentSubmitStatus";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@WhoIs", SqlDbType.Char , 1),
            new SqlParameter("@AttemptID", SqlDbType.Int),
            ////new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };

           Parameters[0].Value =  UserID;
           Parameters[1].Value = questemplate;
           Parameters[2].Value = objAssessment.WhoIs;
           Parameters[3].Value = objAssessment.AttemptID;
           ////Parameters[2].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;
       }

       public void Delete360AssessmentSubmitQuestions(Assessment360SH objAssessment,int UserID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_Delete360DegreeAssessmentResult";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@ElementID", SqlDbType.VarChar, 20),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.VarChar , 40),
            new SqlParameter("@DateOfSubmit",SqlDbType.DateTime),
            new SqlParameter("@DataValue", SqlDbType.Float , 50),
            new SqlParameter("@ScaleID", SqlDbType.VarChar, 3),
            new SqlParameter("@CultureID", SqlDbType.Char, 2),
            new SqlParameter("@Status", SqlDbType.Char, 10),
            new SqlParameter("@IndustryID", SqlDbType.Int),
               new SqlParameter("@OccupationID", SqlDbType.NVarChar,150),
                new SqlParameter("@WhoIs", SqlDbType.Char , 1),
                new SqlParameter("@SubmitStatus", SqlDbType.NChar, 10),
                  new SqlParameter("@DateofAcceptingInvitation", SqlDbType.NVarChar , 50),
            new SqlParameter("@InvitationStatus", SqlDbType.NChar, 10),
            new SqlParameter("@AttemptID", SqlDbType.Int),
                };

           Parameters[0].Value =  UserID;
           Parameters[1].Value = objAssessment.ElementID;
           Parameters[2].Value = objAssessment.QuestionnaireTemplate;
           Parameters[3].Value = objAssessment.DateofSubmit;
           Parameters[4].Value = objAssessment.DataValue;
           Parameters[5].Value = objAssessment.ScaleID;
           Parameters[6].Value = "EN";
           Parameters[7].Value = objAssessment.Status;
           Parameters[8].Value = objAssessment.IndustryID;

           Parameters[9].Value = objAssessment.OccupationID;
           Parameters[10].Value = objAssessment.WhoIs;
           Parameters[11].Value = objAssessment.SubmitStatus;
           Parameters[12].Value = objAssessment.DateofAcceptingInvitation;

           Parameters[13].Value = objAssessment.InvitationStatus;
           Parameters[14].Value = objAssessment.AttemptID;

           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

       }

       public void Insert360AssessmentInviteStatus(Assessment360SH objAssessment,int UserID)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();
           cmdProject.CommandText = "sp_Insert360DegreeAssessmentInvitationStatus";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            new SqlParameter("@UserID", SqlDbType.Int),
            new SqlParameter("@SubmitStatus", SqlDbType.NChar, 10),
            new SqlParameter("@QuestionaireTemplateName", SqlDbType.NVarChar , 50),
            new SqlParameter("@DateofSendingInvitation",SqlDbType.NVarChar,50),
            new SqlParameter("@DateofAcceptingInvitation", SqlDbType.NVarChar , 50),
            new SqlParameter("@InvitationStatus", SqlDbType.NChar, 10),
            new SqlParameter("@Name", SqlDbType.NVarChar, 100),
            new SqlParameter("@WhoIs", SqlDbType.Char , 1),
             new SqlParameter("@EmailID", SqlDbType.NVarChar,150),
             new SqlParameter("@Message", SqlDbType.NVarChar,2500),
             new SqlParameter("@AttemptID", SqlDbType.Int),
                };

           Parameters[0].Value = UserID;
           Parameters[1].Value = objAssessment.SubmitStatus;
           Parameters[2].Value = objAssessment.QuestionnaireTemplate;
           Parameters[3].Value = objAssessment.DateofSendingInvitation;
           Parameters[4].Value = objAssessment.DateofAcceptingInvitation;
           Parameters[5].Value = objAssessment.InvitationStatus;
           Parameters[6].Value = objAssessment.Name;
           Parameters[7].Value = objAssessment.WhoIs;
           Parameters[8].Value = objAssessment.EmailID;
           Parameters[9].Value = objAssessment.Message;
           Parameters[10].Value = objAssessment.AttemptID;
          


           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);

       }
       public static DataTable GetInvitationStatus(Assessment360SH objAssessment,int UserID)
       {
           string query;
          
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           if (objAssessment.WhoIs != "")
           {
               query = "select * from txnInvitationRecommAssessment where UserID='" + UserID + "' and QuestionnaireTemplateName='" + objAssessment.QuestionnaireTemplate + "' and WhoIs='" + objAssessment.WhoIs + "' and AttemptID='" + objAssessment.AttemptID + "';";
           }
           else
           {
               query = "select * from txnInvitationRecommAssessment where UserID='" + UserID + "' and QuestionnaireTemplateName='" + objAssessment.QuestionnaireTemplate + "' and AttemptID='" + objAssessment.AttemptID + "';";

           }
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable Get360AssessmentDataForInvitie(string Title)
       {
           IDbConnection IConnection = null;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           SqlCommand cmdProject = new SqlCommand();
           cmdProject.CommandType = CommandType.StoredProcedure;
           cmdProject.Connection = (SqlConnection)objDataAccessLayer.GetConnection();

           cmdProject.CommandText = "sp_360DegreeAssessmentForInvitie";
           IConnection = objDataAccessLayer.GetConnection();
           SqlParameter[] Parameters =
                {
            
            new SqlParameter("@ONETSOCCode", SqlDbType.NVarChar, 50),
            new SqlParameter("@CultureID", SqlDbType.Char, 4),
           
                };


           Parameters[0].Value = Title;
           Parameters[1].Value = "EN";
           cmdProject.Parameters.AddRange(Parameters);
           SqlDataReader drProject = (SqlDataReader)objDataAccessLayer.ExecuteReader(cmdProject, ref ErrorMessage, ref IConnection);
           DataTable rowCount = new DataTable();
           rowCount.Load(drProject);
           return rowCount;

       }

       public static DataTable GetSubmitionStatusofuser(int UserID)
       {
           string query="";
           int AttemptID;
           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query1 = "select Top 1 AttemptID from txnRecommendationAssessmentResult where  UserID='" + UserID + "' order by AttemptID Desc";
           DataTable dtnew = new DataTable();
           dtnew=objDataAccessLayer.GetDataTable(query1, CommandType.Text, ref ErrorMessage);
           if (dtnew.Rows.Count > 0)
           {
               AttemptID = Convert.ToInt32(dtnew.Rows[0]["AttemptID"].ToString());

               query = "SELECT  dbo.txnInvitationRecommAssessment.InvitationStatus, dbo.txnInvitationRecommAssessment.WhoIs, dbo.txnInvitationRecommAssessment.UserID,dbo.txnQuestionnaireSubmissionList.QuestionaireTemplateName, dbo.txnQuestionnaireSubmissionList.Status FROM   dbo.txnInvitationRecommAssessment INNER JOIN dbo.txnQuestionnaireSubmissionList ON dbo.txnInvitationRecommAssessment.UserID = dbo.txnQuestionnaireSubmissionList.UserID and dbo.txnInvitationRecommAssessment.AttemptID = dbo.txnQuestionnaireSubmissionList.AttemptID AND dbo.txnInvitationRecommAssessment.QuestionnaireTemplateName = dbo.txnQuestionnaireSubmissionList.QuestionaireTemplateName where txnQuestionnaireSubmissionList.UserID='" + UserID + "' and txnQuestionnaireSubmissionList.Status='Submit' and txnInvitationRecommAssessment.InvitationStatus='Submit' and txnInvitationRecommAssessment.AttemptID='" + AttemptID + "'";
           }
           else
           {
               AttemptID = 0;
               query = "SELECT  dbo.txnInvitationRecommAssessment.InvitationStatus, dbo.txnInvitationRecommAssessment.WhoIs, dbo.txnInvitationRecommAssessment.UserID,dbo.txnQuestionnaireSubmissionList.QuestionaireTemplateName, dbo.txnQuestionnaireSubmissionList.Status FROM   dbo.txnInvitationRecommAssessment INNER JOIN dbo.txnQuestionnaireSubmissionList ON dbo.txnInvitationRecommAssessment.UserID = dbo.txnQuestionnaireSubmissionList.UserID and dbo.txnInvitationRecommAssessment.AttemptID = dbo.txnQuestionnaireSubmissionList.AttemptID AND dbo.txnInvitationRecommAssessment.QuestionnaireTemplateName = dbo.txnQuestionnaireSubmissionList.QuestionaireTemplateName where txnQuestionnaireSubmissionList.UserID='" + UserID + "' and txnQuestionnaireSubmissionList.Status='Submit' and txnInvitationRecommAssessment.InvitationStatus='Submit' and txnInvitationRecommAssessment.AttemptID='" + AttemptID + "'";

           }
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable GetInvitationStatusofuser(int UserID,int AttemptID)
       {
           string query;

           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           query = "SELECT  dbo.txnInvitationRecommAssessment.InvitationStatus,dbo.txnInvitationRecommAssessment.UserID,dbo.txnInvitationRecommAssessment.QuestionnaireTemplateName FROM   dbo.txnInvitationRecommAssessment where dbo.txnInvitationRecommAssessment.AttemptID='" + AttemptID + "' and dbo.txnInvitationRecommAssessment.InvitationStatus='Submit' and dbo.txnInvitationRecommAssessment.UserID='" + UserID + "'";
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable Get360UserAttemptID(int UserID, string questemplate)
       {

           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select Top 1 AttemptID from txnRecommendationAssessmentResult where  UserID='" + UserID + "' and QuestionnaireTemplateName='" + questemplate + "' order by AttemptID Desc";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
       public static DataTable Get360UserAttemptIDforInvitie(int UserID, Assessment360SH objAssessment)
       {

           string ErrorMessage = "No Data Found";
           string ConnectionString = GlobalMethod.GetConnectionString();
           string dbType = GlobalMethod.GetDbType();
           Factory objFactory = new IRSA.DALFactory.Factory(dbType);
           IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
           objDataAccessLayer.ConnectionString = ConnectionString;
           string query = "select Top 1 AttemptID from txnRecommendationAssessmentResult where  UserID='" + UserID + "' and QuestionnaireTemplateName='" + objAssessment.QuestionnaireTemplate  + "' and WhoIs='"+objAssessment.WhoIs +"' order by AttemptID Desc";
           //string query = "SELECT CONVERT(CHAR(10),GETDATE(),103)"; 
           return objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);

       }
   }
}
