﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Principal;
using System.Security.Permissions;
using System.Diagnostics;
using System.Threading;


namespace IRSA.Exception
{
    [Serializable]
    public class BaseClassException:System.Exception
    {
        #region Declare Member Variables
        // Member variable declarations
        private string i_ErrorCode;
        private string i_MachineName;
        private string i_AppDomainName;
        private string i_ThreadIdentity;
        private string i_WindowsIdentity;
        private DateTime i_CreatedDateTime = DateTime.Now;

        #endregion


        #region Public Properties
        public string ErrorCode
        {
            get
            {
                return i_ErrorCode; 
            }
            set
            {
                i_ErrorCode = value;
            }
        }

       
        /// Machine name where the exception occurred.
       
        public string MachineName
        {
            get
            {
                return i_MachineName;
            }
        }

     
        /// Date and Time the exception was created.
       
        public DateTime CreatedDateTime
        {
            get
            {
                return i_CreatedDateTime;
            }
        }

    
        /// AppDomain name where the exception occurred.
       
        public string AppDomainName
        {
            get
            {
                return i_AppDomainName;
            }
        }

       
        /// Identity of the executing thread on which the exception was created.
       
        public string ThreadIdName
        {
            get
            {
                return i_ThreadIdentity;
            }
        }

      
        /// Windows identity under which the code was running.
       
        public string WindowsIdName
        {
            get
            {
                return i_WindowsIdentity;
            }
        }

        #endregion

          #region Constructors
       
        /// Constructor with no params.
       
        public BaseClassException()
            : base()
        {
            InitializeEnvironmentInformation();            
        }
        
       
        /// Constructor allowing the InnerException property to be set.
       
       /// String setting the message of the exception.
       /// Sets a reference to the InnerException.
        public BaseClassException(System.Exception inner)
            : base(inner.Message)
        {
            InitializeEnvironmentInformation();
        }

       
        /// Constructor allowing the Message property to be set.
     /// String setting the message of the exception.
        public BaseClassException(string message)
            : base(message)
        {
            InitializeEnvironmentInformation();
        }
      
        /// Constructor allowing the Message and InnerException property to be set.
      /// String setting the message of the exception.
      /// Sets a reference to the InnerException.
        public BaseClassException(string message, System.Exception inner)
            : base(message, inner)
        {
            InitializeEnvironmentInformation();
        }

      
        /// Constructor used for deserialization of the exception class.
        ///Represents the SerializationInfo of the exception.
       ///Represents the context information of the exception.
        protected BaseClassException(SerializationInfo info, StreamingContext context)
            : base(info, context) 
        {
            i_MachineName = info.GetString("MachineName");
            i_CreatedDateTime = info.GetDateTime("CreatedDateTime");
            i_AppDomainName = info.GetString("ApplicationDomainName");
            i_ThreadIdentity = info.GetString("ThreadIdentity");
            i_WindowsIdentity = info.GetString("WindowsIdentity");
           
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Initialization function that gathers environment information safely.
        /// </summary>
        private void InitializeEnvironmentInformation()
        {
            i_MachineName = Environment.MachineName;
            i_ThreadIdentity = Thread.CurrentPrincipal.Identity.Name;
            i_WindowsIdentity = WindowsIdentity.GetCurrent().Name;
            i_AppDomainName = AppDomain.CurrentDomain.FriendlyName;
        }

        #endregion


        #region Public Methods
       
        /// Override the GetObjectData method to serialize custom values.
       
       /// Represents the SerializationInfo of the exception.
       /// Represents the context information of the exception.
       
        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("MachineName", i_MachineName, typeof(string));
            info.AddValue("CreatedDateTime", i_CreatedDateTime);
            info.AddValue("ApplicationDomainName", i_AppDomainName, typeof(string));
            info.AddValue("ThreadIdentity", i_ThreadIdentity, typeof(string));
            info.AddValue("WindowsIdentity", i_WindowsIdentity, typeof(string));  
            base.GetObjectData(info, context);
        }
        #endregion


    }
}
