﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Exception
{
   public class BusinessLogicException:MyException,ExceptionLogg
    {
        public BusinessLogicException() : base()
        {
           
        }
        public BusinessLogicException(string ErrorMessage) :base(ErrorMessage)
        {
            this.ErrorMessage = ErrorMessage;
            
        }
        public BusinessLogicException(string ErrorMessage, System.Exception Ex)
            : base(ErrorMessage, Ex)
        {
            this.ErrorMessage = ErrorMessage;
        }

        public BusinessLogicException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
            : base(info, context)
           
        {
            //this.Message = ErrorCode;            
        }

        #region ExceptionLogg Members

        public void LogMessage(System.Exception Ex)
        {
            ErrorLog.Logging(Ex);
        }

        #endregion
    }
}
