﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace IRSA.Exception
{
   public class DataAccessException:MyException,ExceptionLogg
    {
        public DataAccessException()
            : base()
        {
        }
        public DataAccessException(string ErrorMessage)
            : base(ErrorMessage)
        {
            this.ErrorMessage = ErrorMessage;

        }

        public DataAccessException(string ErrorMessage, System.Exception Ex)
            : base(ErrorMessage, Ex)
        {
            this.ErrorMessage = ErrorMessage;
        }

        public DataAccessException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
            : base(info, context)
        {
            this.ErrorMessage = ErrorMessage;
        }

        #region ExceptionLogg Members

        public void LogMessage(System.Exception Ex)
        {
            ErrorLog.Logging(Ex);
        }

        #endregion
    }
}
