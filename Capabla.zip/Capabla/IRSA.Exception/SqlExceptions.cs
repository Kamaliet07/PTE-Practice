﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace IRSA.Exception
{
   public class SqlExceptions:BaseClassException 
    {
// Default constructor
		public SqlExceptions() : base()
		{
		}

        // Constructor with inner exception
        public SqlExceptions(System.Exception inner)
            : base(inner)
        {
        }

		// Constructor with exception message
		public SqlExceptions(string message) : base(message)
		{
		}
		// Constructor with message and inner exception
        public SqlExceptions(string message, System.Exception inner)
            : base(message, inner)
		{
		}
		// Protected constructor to de-serialize data
        protected SqlExceptions(SerializationInfo info, StreamingContext context)
            : base(info, context)
		{
		}

         // Constructor with message, error code and inner exception
        public SqlExceptions(string message, string errorCode, System.Exception inner)
            : base(message, inner)
        {
            base.ErrorCode = errorCode;
        }
    }
}
