﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace IRSA.Exception
{
   [Serializable]
   public class AppException:BaseClassException 
    {
       // Default constructor
		public AppException() : base()
		{
		}

        // Constructor with inner exception
        public AppException(System.Exception inner)
            : base(inner)
        {
        }

		// Constructor with exception message
		public AppException(string message) : base(message)
		{
		}
		// Constructor with message and inner exception
        public AppException(string message, System.Exception inner)
            : base(message, inner)
		{
		}
		// Protected constructor to de-serialize data
        protected AppException(SerializationInfo info, StreamingContext context)
            : base(info, context)
		{
		}

         // Constructor with message, error code and inner exception
        public AppException(string message, string errorCode, System.Exception inner)
            : base(message, inner)
        {
            base.ErrorCode = errorCode;
        }  
    }
}
