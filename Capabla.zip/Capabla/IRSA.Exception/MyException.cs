﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Exception
{
   public class MyException:System.Exception 
    {
        public MyException()
            : base()
        {

        }
        public MyException(string message)
            : base(message)
        {

        }
        public MyException(string message, System.Exception Ex)
            : base(message, Ex)
        {

        }
        public MyException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
            : base(info, context)
        {

        }
        string StrErrorMessage = "";
        public string ErrorMessage
        {
            get
            {
                return StrErrorMessage;
            }
            set
            {
                StrErrorMessage = value;
            }

        }
    }
}
