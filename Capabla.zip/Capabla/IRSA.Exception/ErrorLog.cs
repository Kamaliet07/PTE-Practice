﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Net.Mail;
using System.Xml;

namespace IRSA.Exception
{
    public class ErrorLog
    {
        /* ErrorLog Constructor */
        public ErrorLog()
        {

        }

        public static void Logging(System.Exception ErrorMessage)
        {

            CreateErrorLog(ErrorMessage);
        }

        public static void Logging(System.Exception ErrorMessage, bool IERSASentMail)
        {

            CreateErrorLog(ErrorMessage, IERSASentMail);
        }

        /**************************************************************************************************
        METHOD NAME : CreateErrorLog
        PARAMETERS  : Ex
        RETURN TYPE : Returns true i.e Log is created
        CREATE DATE : 23-APRIL-2009
        MODIFY DATE :  
        **************************************************************************************************/

        private static bool CreateErrorLog(System.Exception Ex)
        {
            string sErrorDirectoryPath, sErrorFileName, sErrorCompletePath; //sErrorLogFilePath;
            try
            {
                sErrorDirectoryPath = ConfigurationSettings.AppSettings["LogDirectoryPath"];
                sErrorFileName = ConfigurationSettings.AppSettings["LogFilePath"];
                sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
                if (GetExitandMakeNewDirectory(sErrorDirectoryPath))
                {
                    if (GetExitandMakeNewFile(sErrorCompletePath, Ex))
                    {

                    }
                }
            }
            finally
            {
                sErrorDirectoryPath = null;
                sErrorFileName = null;
                sErrorCompletePath = null;
                //sErrorLogFilePath = null;
            }
            return true;
        }

      /**************************************************************************************************
       METHOD NAME : CreateErrorLog
       PARAMETERS  : Ex,SysSentMail
       RETURN TYPE : Returns true i.e Log is created and send a mail to application administrator
       CREATE DATE : 23-APRIL-2009
       MODIFY DATE :  
      **************************************************************************************************/
        private static bool CreateErrorLog(System.Exception Ex, bool SysSentMail)
        {
            string sErrorDirectoryPath, sErrorFileName, sErrorCompletePath; //sErrorLogFilePath;
            try
            {
                sErrorDirectoryPath = ConfigurationSettings.AppSettings["LogDirectoryPath"];
                sErrorFileName = ConfigurationSettings.AppSettings["LogFilePath"];
                sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;

                if (GetExitandMakeNewDirectory(sErrorDirectoryPath))
                {
                    if (GetExitandMakeNewFile(sErrorCompletePath, Ex))
                    {
                        SentMailInfo(Ex);
                    }
                }
            }
            finally
            {
                sErrorDirectoryPath = null;
                sErrorFileName = null;
                sErrorCompletePath = null;
            }
            return true;
        }

        /**************************************************************************************************
         METHOD NAME : GetExitandMakeNewDirectory
         PARAMETERS  : DirectoryPath
         RETURN TYPE : Returns true i.e Directory is created or get a directory if exits
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/
        private static bool GetExitandMakeNewDirectory(string DirectoryPath)
        {
            DirectoryInfo objDir;
            try
            {
                objDir = new DirectoryInfo(DirectoryPath);
                if (!objDir.Exists)
                {
                    objDir.Create();
                    objDir.SetAccessControl(new System.Security.AccessControl.DirectorySecurity(DirectoryPath, System.Security.AccessControl.AccessControlSections.All));
                }

                objDir = null;
            }
            finally
            {
                objDir = null;
            }
            return true;
        }

        /**************************************************************************************************
         METHOD NAME : GetExitandMakeNewFile
         PARAMETERS  : FilePath, Ex
         RETURN TYPE : Returns true i.e file is created or get a File if exits
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/

        private static bool GetExitandMakeNewFile(string FilePath, System.Exception Ex)
        {
            FileInfo objFile;
            try
            {
                objFile = new FileInfo(FilePath);
                if (!objFile.Exists)
                {
                    MakeErrorLog(ref objFile, Ex);
                }
                else
                {
                    MakeErrorLog(FilePath, Ex);
                }

                objFile.Refresh();
                objFile = null;
            }
            finally
            {
                objFile = null;
            }
            return true;
        }

        /**************************************************************************************************
         METHOD NAME : MakeErrorLog
         PARAMETERS  : FilePath, Ex
         RETURN TYPE : Returns true i.e file is created and file is wrriten
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/
        private static bool MakeErrorLog(string FilePath, System.Exception Ex)
        {
            StreamWriter strmLogFile;
            try
            {
                strmLogFile = new StreamWriter(FilePath, true);
                strmLogFile.WriteLine(DateTime.Now.ToString());
                strmLogFile.WriteLine("User Message: " + Ex.Message);
                strmLogFile.WriteLine("System Message: " + Ex.InnerException);
                strmLogFile.WriteLine("Source: " + Ex.Source);
                strmLogFile.WriteLine("Stack Trace: " + Ex.StackTrace);
                strmLogFile.Close();
            }
            finally
            {
                strmLogFile = null;
            }
            return true;
        }

        /**************************************************************************************************
        METHOD NAME : MakeErrorLog
        PARAMETERS  : ref File, Ex
        RETURN TYPE : Returns true i.e file is created and file is wrriten
        CREATE DATE : 23-APRIL-2009
        MODIFY DATE :  
        **************************************************************************************************/
        private static bool MakeErrorLog(ref FileInfo File, System.Exception Ex)
        {
            StreamWriter strmLogFile;
            try
            {
                strmLogFile = File.CreateText();
                strmLogFile.WriteLine(DateTime.Now.ToLongDateString());
                strmLogFile.WriteLine("User Message: " + Ex.Message);
                strmLogFile.WriteLine("System Message: " + Ex.InnerException);
                strmLogFile.WriteLine("Source: " + Ex.Source);
                strmLogFile.WriteLine("Stack Trace: " + Ex.StackTrace);
                strmLogFile.Close();
            }
            finally
            {
                strmLogFile = null;
            }
            return true;
        }

        /**************************************************************************************************
        METHOD NAME : SentMailInfo
        PARAMETERS  : Ex
        RETURN TYPE : Returns true i.e If mail is sent to application administrator
        CREATE DATE : 23-APRIL-2009
        MODIFY DATE :  
        **************************************************************************************************/
        private static bool SentMailInfo(System.Exception Ex)
        {
            string sErrorDirectoryPath, To, From, Subject, SMTP, Priority;
            XmlDocument xmlDoc = new XmlDocument();
            MailMessage mailmsg;
            System.Net.Mail.SmtpClient smtpServer;
            try
            {
                sErrorDirectoryPath = ConfigurationSettings.AppSettings["ErrorLogMail"];


                xmlDoc.Load(sErrorDirectoryPath + "EmailInfo.xml");
                To = xmlDoc.SelectSingleNode("MailSettings/Mail/To").InnerText;
                From = xmlDoc.SelectSingleNode("MailSettings/Mail/From").InnerText;
                Subject = xmlDoc.SelectSingleNode("MailSettings/Mail/Subject").InnerText;
                SMTP = xmlDoc.SelectSingleNode("MailSettings/Mail/SMTP").InnerText;
                Priority = xmlDoc.SelectSingleNode("MailSettings/Mail/Priority").InnerText;

                mailmsg = new MailMessage(From, To, Subject, Ex.ToString());
                smtpServer = new System.Net.Mail.SmtpClient(SMTP);

                mailmsg.Priority = MailPriority.High;

                smtpServer.Send(mailmsg);
            }
            finally
            {
                xmlDoc = null;
                mailmsg = null;
                smtpServer = null;
            }

            return true;

        }


       
    }

}
