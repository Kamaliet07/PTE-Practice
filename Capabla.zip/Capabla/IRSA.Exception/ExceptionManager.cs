﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace IRSA.Exception
{
   public class ExceptionManager
    {
       static public string GetErrorMessage(string errorCode, string exceptionTypeNode)
       {
          string strPath = AppDomain.CurrentDomain.BaseDirectory;

           XmlDocument xmlDoc = new XmlDocument();
           xmlDoc.Load(strPath + "ExceptionErrorMsg.xml");
           XmlNode xNode = xmlDoc.SelectSingleNode("BaseException/" + exceptionTypeNode + errorCode);
           return xNode.InnerText.Trim();
       }

       public static string GetErrorMessage(string MessageCode)
       {
           XmlTextReader nodeReader = null;
           String strSearchtext = string.Empty;
           nodeReader = new XmlTextReader(AppDomain.CurrentDomain.BaseDirectory + "ExceptionErrorMsg.xml");


           while (nodeReader.Read())
           {
               if (nodeReader.NodeType == XmlNodeType.Element)
               {
                   if (nodeReader.LocalName.Equals(MessageCode))
                   {
                       strSearchtext = nodeReader.ReadString();
                   }

               }

           }
           return strSearchtext;
       }
    }
}
