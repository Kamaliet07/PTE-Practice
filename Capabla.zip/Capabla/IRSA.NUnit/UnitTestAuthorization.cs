﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NUnit.Framework;

namespace IRSA.NUnit
{
    /*************************************************************************************
    CREATED FOR : Nunit Testing of application Business layer
    *************************************************************************************/
    [TestFixture]
    public class UnitTestAuthorization
    {
        /*********************************************************************************
         Declaration of variables of Classes
        *********************************************************************************/
       // SignInControlllerBL objSignIn;
        [SetUp]
        public void Init()
        {
          /*********************************************************************************
            instantiations of class, initialization of variables, Properties etc. are there
          *********************************************************************************/
        }

        /*******************************************************************************************
        Created for   : Nunit Testing of method created
        Created DATE  :             
        Paramter Input: Save Function Called for saving data in the database
        Return Type   : Bool Value(true or false)
        Checked For   : Checks whether tha data is saved succesfully or not depending on bool value
        ********************************************************************************************/
        [Test]
        public void TestDataAuthorization()
        {
            //Assert.IsTrue(objSignIn.SaveAuthorizationData());
        }
    }
}
