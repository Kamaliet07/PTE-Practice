﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class ProfileStatusFA
    {
        public DataTable GetStatusPersonal()
        {
            return ProfileStatusBL.GetStatusPersonal();
        }
        public DataTable GetStatusAcademic()
        {
            return ProfileStatusBL.GetStatusAcademic();
        }
        public DataTable GetStatusPastCompany()
        {
            return ProfileStatusBL.GetStatusPastCompany();
        }
        public DataTable GetStatusPresentCompany()
        {
            return ProfileStatusBL.GetStatusPresentCompany();
        }
        public DataTable GetStatusExperence()
        {
            return ProfileStatusBL.GetStatusExperence();
        }
        public DataTable GetStatusProjects()
        {
            return ProfileStatusBL.GetStatusProjects();
        }
        public DataTable GetProfileStatusIndicator()
        {
            return ProfileStatusBL.GetProfileStatusIndicator();
        }
        public DataTable GetProfileStatusIndicatorExp()
        {
            return ProfileStatusBL.GetProfileStatusIndicatorExp();
        }


        public DataTable GetProfileStatusIndicatorPastComp()
        {
            return ProfileStatusBL.GetProfileStatusIndicatorPastComp();
        
        }
        public DataTable GetProfileStatusIndicatorPreComp()
        {
            return ProfileStatusBL.GetProfileStatusIndicatorPreComp();

        }
        public DataTable GetProfileStatusIndicatorAcademic()
        {
            return ProfileStatusBL.GetProfileStatusIndicatorAcademic();

        }
        public DataTable GetProfileStatusIndicatorPersonal()
        {
            return ProfileStatusBL.GetProfileStatusIndicatorPersonal();

        }
    }
}
