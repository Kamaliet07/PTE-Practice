﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class Assessment360FA
   {
       public DataTable Get360AssessmentData(string Title)
       {

           return Assessment360BL.Get360AssessmentData(Title);
       }
       public DataTable BindIndustryData()
       {

           return Assessment360BL.BindIndustryData();
       }
       public DataTable BindOccupation(int industryid)
       {

           return Assessment360BL.BindOccupation(industryid);
       }
       public void Insert360Assessment(Assessment360SH objAssessment, int UserID)
       {
           Assessment360BL objAssessmentBL = new Assessment360BL();
           objAssessmentBL.Insert360Assessment(objAssessment, UserID);

       }
       public DataTable Get360AssessmentSubmitQuestions(string questemplate, Assessment360SH objAssessment,int UserID)
       {

           return Assessment360BL.Get360AssessmentSubmitQuestions(questemplate, objAssessment, UserID);
       }
       public void Delete360AssessmentSubmitQuestions(Assessment360SH objAssessment, int UserID)
       {
           Assessment360BL objAssessmentBL = new Assessment360BL();
           objAssessmentBL.Delete360AssessmentSubmitQuestions(objAssessment, UserID);

       }
       public void Insert360AssessmentInviteStatus(Assessment360SH objAssessment,int UserID)
       {
           Assessment360BL objAssessmentBL = new Assessment360BL();
           objAssessmentBL.Insert360AssessmentInviteStatus(objAssessment, UserID);

       }
       public DataTable GetInvitationStatus(Assessment360SH objAssessment, int UserID)
       {

           return Assessment360BL.GetInvitationStatus(objAssessment, UserID);
       }
       public DataTable Get360AssessmentDataForInvitie(string Title)
       {

           return Assessment360BL.Get360AssessmentDataForInvitie(Title);
       }
       public DataTable GetSubmitionStatusofuser(int UserID)
       {

           return Assessment360BL.GetSubmitionStatusofuser(UserID);
       }
       public DataTable GetInvitationStatusofuser(int UserID,int AttemptID)
       {

           return Assessment360BL.GetInvitationStatusofuser(UserID, AttemptID);
       }
       public DataTable Get360UserAttemptID(int UserID, string questemplate)
       {

           return Assessment360BL.Get360UserAttemptID(UserID, questemplate);
       }
       public DataTable Get360UserAttemptIDforInvitie(int UserID, Assessment360SH objAssessment)
       {

           return Assessment360BL.Get360UserAttemptIDforInvitie(UserID, objAssessment);
       }
   }
}
