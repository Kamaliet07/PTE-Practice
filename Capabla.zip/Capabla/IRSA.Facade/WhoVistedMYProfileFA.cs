﻿using System;
using System.Collections.Generic;
using System.Text;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
using IRSA.Shared;
using System.Data.SqlClient;
using System.Data;
using System.Web;

namespace IRSA.Facade
{
    public class WhoVistedMYProfileFA
    {
        public static DataTable ProfileData(int UserID, int combovalue)
        {
            return WhoVisitedMyProfileBL.profile(UserID, combovalue);
        }        
    }
}
