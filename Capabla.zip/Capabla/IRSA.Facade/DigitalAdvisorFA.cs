﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
using IRSA.Shared;

namespace IRSA.Facade
{
   public class DigitalAdvisorFA
    {
        
        public DataTable getDetCategory()
        {
            DigitalAdvisorBL objcategory = new DigitalAdvisorBL();
            return objcategory.getComCategory();
        }

       
        public DataTable GetPreviousSaveUserAdvise()
        {
            DigitalAdvisorBL objcategory = new DigitalAdvisorBL();
            return objcategory.GetPreviousSaveAdvise();
        }

        public DataTable getDetTopic(int top)
        {
            DigitalAdvisorBL objcategory = new DigitalAdvisorBL();
            return objcategory.getComTopic(top);
        }

        public DataTable getSituationSelect(int topcID)
        {
            DigitalAdvisorBL objsit = new DigitalAdvisorBL();
            return objsit.GetSituationTopic(topcID);
        }


        public DataTable GetUserQuickTipsAccordingTopicID(int TopicId, string TopicName, string Situation, string Status)
        {
            DigitalAdvisorBL objtips = new DigitalAdvisorBL();
            return objtips.GetUserQuickTips(TopicId ,TopicName, Situation, Status);
        }
               

        public void SaveUserAdviseAccUserID(DigitalAdvisorSH objdigSH, DataTable objsit, int userID)
        {
            DigitalAdvisorBL objSavedData = new DigitalAdvisorBL();
            objSavedData.SavedUserDataUserID(objdigSH, objsit, userID);
        }
             

        public DataTable GetUserSavedQuickTipsAccrAdviceID(int DAdviceID)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            return objUserSavedData.GetUserSavedQuickTipsAccrAdviceID(DAdviceID);
        }

        public DataTable GetUserSavedDataAccrAdviceIDAccrAdviceID(int DAdviceID)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            return objUserSavedData.GetUserSavedDataAccrAdviceIDAccrAdviceID(DAdviceID);
        }

        public DataTable GetUserSituationAccrAdviceID(int DAdviceID)
        {
            DigitalAdvisorBL objUserSitData = new DigitalAdvisorBL();
            return objUserSitData.GetUserSavedUserSitAccrAdviceID(DAdviceID);
        }

        public DataTable GetUserSavedQuickTipsAccrAdviceID(int topicid, DataTable objdtsituation)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            return objUserSavedData.GetUserSavedQuickTipsAccrAdviceID(topicid, objdtsituation);
        }

        public DataTable getUserAuthentaction(string emailid)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            return objUserSavedData.getUserAuthencation(emailid);
        }

        public bool GetEvaluateProductKeyAuthenct(string productkey, int productid)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            return objUserSavedData.GetEvaluateProductKeyAuthenct(productkey, productid);
        }

        public void ActivateUserProduct(string emailid, int ProdID, string productkey, string ipadress, string cultureid)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            objUserSavedData.ActivateUserProduct(emailid, ProdID, productkey, ipadress, cultureid);
        }

        public void InserUserPurchageIntery(string useremail,int productid, int userid)
        {
            DigitalAdvisorBL objUserSavedData = new DigitalAdvisorBL();
            objUserSavedData.InsertUserPurchgEntry(useremail,productid,userid);
        }

        public DataTable GetProductDetail(int productid)
        {
            DigitalAdvisorBL objproductData = new DigitalAdvisorBL();
            return objproductData.GetProductDetail(productid);
        }

        public DataTable GetAmountPurchageAndUsed(int userid,int pageid)
        {
            DigitalAdvisorBL objproductData = new DigitalAdvisorBL();
            return objproductData.GetAmountPurchageAndUsed(userid,pageid);
        }

        public void UpdateUserPurchageDetail(int userID, int pageid)
        {
            DigitalAdvisorBL objproductpurchUpdt = new DigitalAdvisorBL();
            objproductpurchUpdt.UpdateUserPurchageDetail(userID, pageid);
        }

        public DataTable GewtPurchageProductDetail(int userID)
        {
            DigitalAdvisorBL objCareer = new DigitalAdvisorBL();
            return objCareer.GewtPurchageProductDetail(userID);
        }

        public DataTable GetCareerToolDigAdInfo(int userID)
        {
            DigitalAdvisorBL objCareer = new DigitalAdvisorBL();
            return objCareer.GetCareerToolDigAdInfo(userID);
        }
    }
}
