﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;


namespace IRSA.Facade
{
   public class JobPostingFA
    {
       //public DataTable JobPosting(JobPostingSH jobpSH)
       //{
       //    JobPostingBL JobPostBL = new JobPostingBL();

       //    return JobPostBL.JobPosting(jobpSH);
       //}
       public void InsertJobQues(DataTable dataTable, int JobID)
       {
           JobPostingBL objJobBL = new JobPostingBL();
           objJobBL.InsertJobQues(dataTable, JobID);

       }
       public void InsertJobSkillQues(SkillQuestionnaireSH objskill, int JobID)
       {
           JobPostingBL objJobBL = new JobPostingBL();
           objJobBL.InsertJobSkillQues(objskill, JobID);

       }
       public DataTable GetJobQuestionnaireData(int JobID)
       {

           return JobPostingBL.GetJobQuestionnaireData(JobID);
       }
       public DataTable GetJobToolandtechQuestionnaireData(int JobID)
       {

           return JobPostingBL.GetJobToolandtechQuestionnaireData(JobID);
       }
       public DataTable GetCompany(JobPostingSH jobpSH, string step, int JobID, string idCollection)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.GetCompany(jobpSH, step, JobID, idCollection);
       }
       public DataTable GetJobFamilyData() //get JobFamily
       {

           return JobPostingBL.GetJobFamilyData();  
       }
       public DataTable GetSourceData(string JobFamily)
       {
           JobPostingBL JobPostBL = new JobPostingBL();
           return JobPostBL.GetSourceData(JobFamily);
       }
       public DataTable SelectJob(int JobID)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.selectJOB(JobID);
       }
       public DataTable SelectJobInfo(int JobID)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.selectJOBInfo(JobID);
       }
       public DataTable SelectJobProfile(int JobID)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.selectJOBProfile(JobID);
       }
       public DataTable selectJobToolsAndTech(int JobID, string T2Type)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.selectJobToolsAndTech(JobID, T2Type);
       }
       public void InsertJobToolsandtech(JobPostingSH jobpSH,string DescribeValue, int JobID)
       {
           JobPostingBL objJobBL = new JobPostingBL();
           objJobBL.InsertJobToolsandtech(jobpSH,DescribeValue, JobID);

       }
       public DataTable GetSubmitJobQuestionsStatus(int JobID)
       {

           return JobPostingBL.GetSubmitJobQuestions(JobID);
       }
       public DataTable GetSourceDataID(string ONETSOCCodeData)
       {
           JobPostingBL JobPostBL = new JobPostingBL();
           return JobPostBL.GetSourceDataID(ONETSOCCodeData);
       }
       public DataTable GetSourceTitle(string ONETSOCCodeData)
       {
           JobPostingBL JobPostBL = new JobPostingBL();
           return JobPostBL.GetSourceDataTitle(ONETSOCCodeData);
       }
       public DataTable GetSkills(int JobID)
       {
           return JobPostingBL.GetJobSkillsJobQuestionnaire(JobID);
       }
       public DataTable selectOccupationName(int JobID)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.selectOccupationName(JobID);
       }
       public DataTable GetJobQuestionnaire(int JobID)
       {
         

           return JobPostingBL.GetJobQuestionnaire(JobID);
       }
       public string GetOrgName(int OrgID, int UserID)
       {
           return JobPostingBL.GetOrgName(OrgID, UserID, 1);
       }
       public DataTable AppliedJobs(int OrgID, int UserID)
       {
           //Add a parameter called "Flag" that tells the stored procedure what to return
           return JobPostingBL.RecruiterJobs(OrgID, UserID, 2);
       }
       public DataTable RecruiterJobs(int OrgID, int UserID)
       {
           //Add a parameter called "Flag" that tells the stored procedure what to return
           return JobPostingBL.RecruiterJobs(OrgID, UserID, 0);
       }
       public DataTable GetCompanyName()
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.GetCompanyName();
       }
       public DataTable GetCompanyNameDes(string Name)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.GetCompanyNameDes(Name);
       }
       public DataTable SelectJobProfile44(int JobID)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.selectJOBProfile44(JobID);
       }
       public DataTable GetIndustryName()
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.GetIndustryName();
       }
       public DataTable InsertRCOrg(JobPostingSH jobpSH)
       {
           JobPostingBL JobPostBL = new JobPostingBL();

           return JobPostBL.InsertRCOrg(jobpSH);
       }
   }
}
