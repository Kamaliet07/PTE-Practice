﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
    public class ViewAccountFA
    {

        public DataTable GetViewAccountData(int UserID)
        {
            //ViewAccountBL objviewaccuntBL = new ViewAccountBL();
           return ViewAccountBL.RetrieveViewData(UserID);       
        }

        public DataTable GetpastcompanyData(int UserID,string Addmore)
        {
            return IRSA.BussinessLogic.ViewAccountBL.RetrievecompData(UserID, Addmore);
        }
       
        //public DataTable GetFirstpastcompanyData(int UserID)
        //{
        //    return IRSA.BussinessLogic.ViewAccountBL.RetrievefirstcompData(UserID);
        //}
        public DataTable GetacademicsData(int UserID, string Addmore)
        {
            return IRSA.BussinessLogic.ViewAccountBL.RetrieveacademicsData(UserID, Addmore);
        }
        //public DataTable GetfirstacademicsData(int UserID)
        //{
        //    return IRSA.BussinessLogic.ViewAccountBL.RetrievefirstacademicsData(UserID);
        //}
        public DataTable GetprojectsData(int UserID, string Addmore)
        {
            return IRSA.BussinessLogic.ViewAccountBL.RetrieveprojectsData(UserID, Addmore);
        }

    //public DataTable GetFirstprojectsData(int UserID)
    //    {
    //        return IRSA.BussinessLogic.ViewAccountBL.RetrieveprojectsData(UserID, moreproj);
    //    }
        


    }
}