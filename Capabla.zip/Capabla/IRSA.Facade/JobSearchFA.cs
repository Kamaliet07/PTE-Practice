﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
   public class JobSearchFA
   {
       public DataTable GetJobData(string str)
       {
           return JobSearchBL.GetjobDataDetails(str);
       }
       public DataTable GetJob(string Keywords, JobSearchSH objJobSearchSH)
       {
           return JobSearchBL.GetJobData(Keywords, objJobSearchSH);
       }
       public DataTable GetIndustryData()
       {
           return JobSearchBL.BindIndustryData();
       }
       public DataTable GetJobList()
       {
           return JobSearchBL.JobList();
       }
       public DataTable GridData(string Industry, string Specialities, string Country, string City, string CompanyName)
       {
           return JobSearchBL.GridData(Industry, Specialities, Country, City, CompanyName);
       }
    }
}
