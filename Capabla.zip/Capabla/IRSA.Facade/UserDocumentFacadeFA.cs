﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class UserDocumentFacadeFA
    {
        public DataTable GetUSerDocumentsList()
        {
            return UserDocumentBL.GetUSerDocumentsList();
        }
        public void GetUSerDocumentsListInsert(UserDocumentSH objUserDocumentInsert)
        {
            UserDocumentBL objudocbl = new UserDocumentBL();
            objudocbl.GetUSerDocumentsListInsert(objUserDocumentInsert);
        }
        public DataTable GetUSerDocuments(string DocumentID)
        {
            return UserDocumentBL.GetUSerDocuments(DocumentID);
        }
    }
}
    

