﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class RegistrationFA
    {
        public void InsertRegistrationData(RegistrationSH objReg)
        {
            RegistrationBL objRegistrationBL = new RegistrationBL();
            objRegistrationBL.SaveRegistrationData(objReg);
        }

        public DataTable Chkvalidcmy(RegistrationSH objReg)
        {
            return RegistrationBL.GetValidcmy(objReg);
                
              
        }
        public DataTable GetValidateEmail(string email)
        {
          return  RegistrationBL.GetValidateUser(email);
                
              
        }
        public DataTable GetIndustryData()
        {
            return IRSA.BussinessLogic.RegistrationBL.BindIndustryData();

        }
        public DataTable RetrieveUserID( string EmailID,string Password)
        {
            return IRSA.BussinessLogic.RegistrationBL.GetUserID(EmailID,Password);

        }
        public bool GetValidateUserMail(string email)
        {
            return RegistrationBL.GetValidateUserMail(email);


        }
    }
}
