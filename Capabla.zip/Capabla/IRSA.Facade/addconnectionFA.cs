﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class addconnectionFA
    {
       public DataTable GetPersonData(int UserID, string FirstName)
        {
            return addconnectionBL.GetPersonDataDetails(UserID,FirstName);



        }
       public void activatecansee(int UserID, int NetworkUserID)
       {

           addconnectionBL objaddconnection = new addconnectionBL();
           objaddconnection.GetviewActive(UserID, NetworkUserID);

       }
    }
}
