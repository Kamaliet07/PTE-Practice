﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class OrganisationLicenseFA
    {
     

       public DataTable BindComboIndustryData()
       {
           return OrganisationLicenseBL.BindComboIndustryData();
       }

       

       public void InsertLicenseKey(string sSecretKey)
       {
           OrganisationLicenseBL bl = new OrganisationLicenseBL();
           bl.InsertLicenseKey(sSecretKey);
       }

       public DataTable GetData()
       {
           return  OrganisationLicenseBL.GetData();
       }

       public DataTable GetUserCount()
       {
          return OrganisationLicenseBL.GetUserCount();
       }
    }
}
