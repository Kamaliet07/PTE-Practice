﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class AccountSettingFA
    {
        public DataTable GetUserRole(int UserID)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrieveRole(UserID);

            //AccountsetupBL objaca = new AccountsetupBL();
            //return objaca.RetrieveAcademicGridData(UserID,HighestDegree);
            //return AccountsetupBL.RetrieveAccountData(UserID, step);
        }
        public void Insertaccessroles(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.SaveWhocanaccessData(UserID, objaccsettSH);
        }
        public void Insertprofileviewer(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Saveproviewer(UserID, objaccsettSH);
        }
        public void InsertContactSettings(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Savecontsett(UserID, objaccsettSH);
        }
        public void Insertnotify(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Savenotify(UserID, objaccsettSH);
        }

        public void InsertShowName(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.SaveShowName(UserID, objaccsettSH);
        }
        public void Insertrecallow(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Saverecallow(UserID, objaccsettSH);
        }
        public void InsertProflephoto(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.SaveProflephoto(UserID, objaccsettSH);
        }
        public void InsertPref(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.SavePrefInd(UserID, objaccsettSH);
        }
        public void Insertvisibility(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Savevisible(UserID, objaccsettSH);
        }
        public void InsertAcademicsroles(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Saveacad(UserID, objaccsettSH);
        }
        public void Insertprojects(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Saveprojects(UserID, objaccsettSH);
        }
        public void Insertprecmy(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Saveprecmy(UserID, objaccsettSH);
        }
        public void InsertPostcmy(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Savepastcmy(UserID, objaccsettSH);
        }
        public void Insertsalarydetails(int UserID, AccountSettingSH objaccsettSH)
        {
            AccountSettingBL objAccountSettingBL = new AccountSettingBL();
            objAccountSettingBL.Savesalarydetails(UserID, objaccsettSH);
        }
        public DataTable GetContactbrowseData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrieveContactbrowse(UserID, objaccsettSH);

        }
        public DataTable GetconsettData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrieveconsettdata(UserID, objaccsettSH);
;
        }
        public DataTable GetpropicData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrievepropicdata(UserID, objaccsettSH);

        }
        public DataTable GetvisibleData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrievenisibledata(UserID, objaccsettSH);

        }

        public DataTable GetacadData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrieveacaddata(UserID, objaccsettSH);

        }

        public DataTable GetpstcmyData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrievepstcmydata(UserID, objaccsettSH);

        }
        public DataTable GetPrescmyData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrievePrescmydata(UserID, objaccsettSH);

        }
        public DataTable GetProjectsData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrieveProjectsdata(UserID, objaccsettSH);

        }
        public DataTable GetirsaData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrieveirsadata(UserID, objaccsettSH);

        }
        public DataTable GetRAData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrieveRAdata(UserID, objaccsettSH);

        }

        public DataTable GetNamestatus(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrieveNamests(UserID, objaccsettSH);

        }
        public DataTable GetPindData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.RetrievePindData(UserID, objaccsettSH);

        }
        public DataTable RetrieveUserID(int UserID)
        {
            return IRSA.BussinessLogic.AccountSettingBL.GetUserdata(UserID);

        }
        public DataTable GetsalaryData(int UserID, AccountSettingSH objaccsettSH)
        {
            return IRSA.BussinessLogic.AccountSettingBL.Retrievesalarydata(UserID, objaccsettSH);

        }
        
    }

}
