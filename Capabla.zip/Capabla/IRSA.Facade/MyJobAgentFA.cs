﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.BussinessLogic;
using IRSA.Shared;

namespace IRSA.Facade
{
   public class MyJobAgentFA
    {

       /*This method gives the number of Agents for a particularly Candidtae*/
       public int getAgentCount(int UserId,string cultID)
       {
           int agentcount = 0;
           agentcount = MyJobAgentBL.getAgentCount(UserId,cultID);

           return agentcount;
       }
       /*To get the data for drop down list of Job Family*/
       public DataTable GetJobFamilyData() 
       {

           return MyJobAgentBL.GetJobFamilyData();
       }

       /*This function returns the Job Family ID after taking Job Family name as argument*/
       public string getJobFamilyID(String jobfamilyName)
       {
           return MyJobAgentBL.getJobFamilyID(jobfamilyName);
       }

       /*To Insert Job Agent Data into the database*/
       public void insertJobAgentData(MyJobAgentSH objSh,string cultID)
       {
           MyJobAgentBL.insertJobAgentData(objSh, cultID);
       }

       /*This function returns the Occupation ID after taking Occupation name as argument*/
       public string getOccupationID(String occ)
       {
           return MyJobAgentBL.getOccupationID(occ);
       }

       /*To retrieve the occupation list corresponding to Job Family*/
       public DataTable getOccupationData(string JobFamily)
       {
         
           return MyJobAgentBL.getOccupationData(JobFamily);
       }

       /*To retrieve agentnames and create dates for a particular user*/
       public DataTable getAgentDataTable(int UserID,string cultID)
       {
           return MyJobAgentBL.getAgentDataTable(UserID,cultID);
       }

       /*To retrieve all agent details for a particular Agent Name*/
       public MyJobAgentSH retrieveAgent(string agentName, int UserID,string cultID)
       {
           return MyJobAgentBL.retrieveAgent(agentName, UserID, cultID);
       }

       /*To retrieve the job family name for a particular family ID*/
       public string getFamilyName(string familyID)
       {
           return MyJobAgentBL.getFamilyName(familyID);
       }

       /*To retrieve the occupation name for a particular Occupation ID*/
       public string getOccupationName(string OccID)
       {
           return MyJobAgentBL.getOccupationName(OccID);
       }

       /*To delete the Job Agent*/
       public static void deleteAgent(string agentName, int UserID,string cultID)
       {
           MyJobAgentBL.deleteAgent(agentName, UserID, cultID);         
       }
       public DataTable GetAssessmentFitDetails(int UserID, int combovalue)
       {
           return JobMatchedCandidateBL.GetAssesmentFit(UserID, combovalue);
       }
       ///* To get assessment details of candidate*/
       //public DataTable GetAssessmentDetails()
       //{
       //    return JobMatchedCandidateBL.GetAssessmentDetails();
       //}
       ///*To insert Applied job of Candidate*/
       public void candidateApplyJob(int UserID, int jobID)
       {
           MyAppliedJobBL.candidateApplyJob(UserID, jobID);
       }

       /*To Get the status of candaidate for questionnaire*/
       public DataTable getStatus(int UserID, int jobID)
       {
           return MyAppliedJobBL.getStatus(UserID, jobID);
       }
       /*To Get the status of candaidate for questionnaire*/
       public DataTable getStatusTools(int UserID, int jobID)
       {
           return MyAppliedJobBL.getStatusTools(UserID, jobID);
       }
       /*To check whether the agent already exists or not*/
       public Boolean doAgentExists(string agentName, int UserID, string cultID)
       {
           return MyJobAgentBL.doAgentExists(agentName, UserID,cultID);
       }
       /*Search all Job for the candidate*/
       public DataTable candidateViewJobs(string agentName, int UserID)
       {
           return MyJobAgentBL.candidateViewJobs(agentName, UserID);
       }
       public DataTable getAppliedJob(int jobID, int UserID)
       {
           return MyJobAgentBL.getAppliedJob(jobID, UserID);
       }

    }
}
