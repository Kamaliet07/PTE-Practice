﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class AccountsetupFA
   {
       public DataTable GetAccountSetUpData(int UserID, string step)
       {
           AccountsetupBL OBJGET = new AccountsetupBL();
           return OBJGET.RetrieveAccountData(UserID, step);
          
       }

       public DataTable GetVisaData(int UserID)
       {
         
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveVisaData(UserID);
           
       }
       public DataTable GetSCData(int UserID)
       {
          
           return IRSA.BussinessLogic.AccountsetupBL.RetrievescData(UserID);
           
       }
     public DataTable GetAssoData(int UserID)
       {
           
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveAssoData(UserID);
           
       }
        public DataTable GetLicData(int UserID)
       {
         
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveLicData(UserID);
           
       }
       public DataTable GetAcademicGridData(int UserID, string HighestDegree)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveAcademicGridData(UserID,HighestDegree);

       }
       public DataTable GetPastcmygrdData(int UserID, string Company)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrievePastcmygrdData(UserID, Company);

       }
       public DataTable GetCompanyGridData(int UserID, string Company)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveCompanyGridData(UserID, Company);

       }
       public DataTable GetvisaGridData(int UserID, string WorkPermitName)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveVisaGridData(UserID, WorkPermitName);

          
       }
       public DataTable GetAssoGridData(int UserID, string AName)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveAssoGridData(UserID, AName);

          
       }
       public void updatephoto(int UserID)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.removePhoto(UserID);
       }
       public DataTable GetlicGridData(int UserID, string LCName)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrievelicGridData(UserID, LCName);

          
       }
       public DataTable GetProjectGridData(int UserID, string ProjectName)
       {
           return IRSA.BussinessLogic.AccountsetupBL.RetrieveProjectGridData(UserID, ProjectName);

       }
       public void InsertAccountSetUpData(AccountsetupSH ObjaccsetupSH, int UserID, string step, int AccountWelcome, int Experience, int PresentCompany, int PastCompany, int Acadimic, int Projects)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.SaveAccountSetUpData(ObjaccsetupSH, UserID, step, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
       }
       public void InserteducationData(AccountsetupSH ObjaccsetupSH, int UserID)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.SaveEducationData(ObjaccsetupSH, UserID);
       }

       public void insertphoto(string photo, int UserID)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.SavePhoto(photo, UserID);
       }
       public void deletevisaGridData(int UserID, string WorkPermitName)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.delvisagridData(UserID, WorkPermitName);
          

       }
       public void deletecmyGridData(int UserID, string Company)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.delcmygridData(UserID, Company);
           

       }
       public void deleteAssoGridData(int UserID, string AName)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.delassogridData(UserID, AName);
           
       }
       public void deletelicGridData(int UserID, string LCName)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.dellicgridData(UserID, LCName);
           

       }
       public void deleteacadGridData(int UserID, string HighestDegree)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.delacadgridData(UserID, HighestDegree);
          

       }
       public void deleteprojGridData(int UserID, string ProjectName)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.delprojgridData(UserID, ProjectName);
          
       }


       public void InsertVisaData(AccountsetupSH ObjaccsetupSH, int UserID, string step, string headtext)
       {
           AccountsetupBL objAccountsetupBL = new AccountsetupBL();
           objAccountsetupBL.SaveVisaData(ObjaccsetupSH, UserID, step, headtext);
       }
    
      
       public DataTable GetoccupationData()
       {
           return IRSA.BussinessLogic.AccountsetupBL.BindoccupationData();

       }
      
    
       public DataTable GetIndustryData()
       {
           return IRSA.BussinessLogic.AccountsetupBL.BindIndustryData();

       }
               
      

       public DataTable GetaccountData(int UserID)
       {
           return AccountsetupBL.RetrieveData(UserID);
       }
      
    }
}
