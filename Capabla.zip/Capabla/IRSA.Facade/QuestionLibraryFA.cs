﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
using IRSA.Shared;

namespace IRSA.Facade
{
   public class QuestionLibraryFA
    {

        public DataTable GetCategorryColl(string OccID)
        {
            QuestionLibraryBL objBL = new QuestionLibraryBL();
            return objBL.GetCategoryCollectionAccID(OccID);
        }

        public void InsertUserQuestionnatie(DataTable dataTable, string QuestName)
        {
            QuestionLibraryBL objBL = new QuestionLibraryBL();
            objBL.InsertUserQuestionnatie(dataTable, QuestName);
        }

        public DataTable GetSavedQuestionnarie()
        {
            QuestionLibraryBL objBL = new QuestionLibraryBL();
            return objBL.GetSavedQuestionnarie();
        }

        public DataTable GetQuestionnarieAccId(int Qid)
        {
            QuestionLibraryBL objBL = new QuestionLibraryBL();
            return objBL.GetQuestionnarieAccId(Qid);
        }
    }
}
