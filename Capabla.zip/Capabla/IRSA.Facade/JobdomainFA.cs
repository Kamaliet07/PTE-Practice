﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.BussinessLogic;
using System.Data;

namespace IRSA.Facade
{
   public class JobdomainFA
   {
       public DataTable GetJobdomainQuestionnaireData(string eid)
       {

           return Job_domainBL.GetJobdomainQuestionnaireData(eid);
       }
       public DataTable GetJobDomainReportData(string eid, string onet, string Questemplate, string CultureID, int UserID, int AttemptID)
       {

           return Job_domainBL.GetJobDomainReportData(eid, onet, Questemplate, CultureID, UserID, AttemptID);
       }
       public DataTable GetJobDomainRoleMatchReportData(string eid, string onet, string Questemplate, string CultureID, int UserID, int AttemptID)
       {

           return Job_domainBL.GetJobDomainRoleMatchReportData(eid, onet, Questemplate, CultureID, UserID, AttemptID);
       }
       public DataTable GetJobFamilyID(int AttemptID, int UserID, string templateName)
       {

           return Job_domainBL.GetJobFamilyID(AttemptID, UserID, templateName);
       }
   }
}
