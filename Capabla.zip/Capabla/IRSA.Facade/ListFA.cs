﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
  public  class ListFA
    {
      public void InsertList(ListSh listinsert)
      {
          ListBL bl = new ListBL();
           bl.InsertList(listinsert);
      }
      public void InsertListEdit(ListSh listinsert22)
      {
          ListBL bl = new ListBL();
          bl.InsertListEdit(listinsert22);
      }
      public void UpdateList(ListSh listinsert)
      {
          ListBL bl = new ListBL();
          bl.UpdateList(listinsert);
      }
      public void DeleteList(ListSh listinsert22)
      {
          ListBL bl = new ListBL();
          bl.DeleteList(listinsert22);
      }
      public DataTable GetTaskEdit(ListSh listinsert)
      {
          return ListBL.GetTaskEdit(listinsert);
      }
      public void UpdateListTime(ListSh listinsert1)
      {
          ListBL bl = new ListBL();
          bl.UpdateListTime(listinsert1);
      }
      public void Final(ListSh listinsert44)
      {
          ListBL bl = new ListBL();
          bl.Final(listinsert44);
      }

      public DataTable GetTask()
      {
          return ListBL.GetTask();
      }
      public DataTable GetTaskDays()
      {
          return ListBL.GetTaskDays();
      }
      public DataTable GetTaskTime()
      {
          return ListBL.GetTaskTime();
      }
      public DataTable GetTaskList()
      {
          return ListBL.GetTaskList();
      }
      public DataTable GetTaskFinal()
      {
          return ListBL.GetTaskFinal();
      }
      public DataTable GetTaskDay()
      {
          return ListBL.GetTaskDay();
      }
    }
}
