﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.Shared;
using IRSA.BussinessLogic;
using System.Data;

namespace IRSA.Facade
{
   public class MyDashBoardFA
    {
        public DataTable GetSavedUserControlAccUserId(int UserID)
        {
            MyDashBoardBL objmydashboard = new MyDashBoardBL();
            return objmydashboard.GetSavedUserControlAccUserId(UserID);
        }

        public void saveUserControl(int userid, string controlname)
        {
            MyDashBoardBL objmydashboard = new MyDashBoardBL();
            objmydashboard.InsertControlAccorUser(userid, controlname);
        }

        public DataTable GetDefaultWebPArt()
        {
            MyDashBoardBL objmydashboard = new MyDashBoardBL();
            return objmydashboard.GetUserDefaultWebPart();
        }
    }
}
