﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;



namespace IRSA.Facade
{
    public class PersonSearchFA
    {

        public DataTable GetData1(string str4, PersonSearchSH objpersonserachSH)
        {
            return PersonSearchBL.GetUserData(str4, objpersonserachSH);
        }
        public DataTable GetDataList()
        {
            return PersonSearchBL.GetUserList();
        }
        public DataTable GetUser(string EmailID)
        {
            return PersonSearchBL.GetUserID(EmailID);
        }
        public DataTable GetUserExistanceInNet(int inviteuserid, int loginuser)
        {
            return PersonSearchBL.GetUserExistanceInNet(inviteuserid, loginuser);
        }

        public DataTable GetEducationSearch(string str4)
        {
            return PersonSearchBL.GetEducationSearch(str4);
        }
        public DataTable GetEducationList()
        {
            return PersonSearchBL.GetEducationList();
        }
    }
}


