﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class MyAppliedJobFA
   {
        public DataTable MyAppliedJob(int UserID, int flag)
       {
           return MyAppliedJobBL.MyAppliedJob(UserID, flag);
       }

       public DataTable MatchedJob()
       {
           return MyAppliedJobBL.MatchedJob();
       }
       public DataTable GetAssessmentFitDetails(int UserID, int combovalue)
       {
           return JobMatchedCandidateBL.GetAssesmentFit(UserID, combovalue);
       }
       //public DataTable GetAssessmentDetails()
       //{
       //    return JobMatchedCandidateBL.GetAssessmentDetails();
       //}
       public void DeleteAppliedJob(int UserID,int jobID, int flag)
       {
           MyAppliedJobBL.DeleteAppliedJob(UserID,jobID, flag);
       }
       public DataTable GetJobMatchedDetails(int UserID, int combovalue)
       {
           return JobMatchedCandidateBL.GetJobMatchedDetails(UserID, combovalue);
       }
       //public DataTable GetAssessmentFitDetails(int UserID, int combovalue)
       //{
       //    return JobMatchedCandidateBL.GetAssesmentFit(UserID, combovalue);
       //}
       
    }
}
