﻿using IRSA.BussinessLogic;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IRSA.Facade
{
    public class ApprovalCenterFA
    {
        public DataTable getGridData(int Flag, int UserID)
        {
            return ApprovalCenterBL.getGridData(Flag, UserID);
        }
    }
}
