﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;


namespace IRSA.Facade
{
   public class CandidateSearchFA
    {
        public DataTable GetDataFirstGrid(CandidateSearchSH sh)
        {
            return CandidateSearchBL.GetDataFirstGrid(sh);
        }

        public DataTable GetDataBoxTitlte()
        {
           return CandidateSearchBL.GetDataBoxTitle();
        }

        public DataTable GetTitleID(string tlt)
        {
            return CandidateSearchBL.GetTitleID(tlt);
        }

        public DataTable GetDataFirstGridNotApplied(CandidateSearchSH sh)
        {
            return CandidateSearchBL.GetDataFirstGridNotApplied(sh);
        }

        public void GetResume(int UserID)
        {
            CandidateSearchBL bl = new CandidateSearchBL();
            bl.GetResume(UserID);
        }

    }
}
