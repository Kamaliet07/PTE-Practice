﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.BussinessLogic;
using IRSA.Shared;


namespace IRSA.Facade
{
    public class ResumeVsSavedJobsFA
    {
     
        //to retrieve the data table for TitleBox
        public DataTable getTitleBoxData(string DateFrom, string DateTo, int UserID, int flag,string cultID)
        {
            return ResumeVsSavedJobsBL.getTitleBoxData(DateFrom,DateTo,UserID,flag,cultID);
        }

        //
        //public DataTable getJobs(int UserID, string title)
        //{

        //    return ResumeVsSavedJobsBL.getJobs(UserID,title);
        //}

        //to retriev the list of candidates for a particular job
        public DataTable getCandidateListManually(int JobID, ResumeVsSavedJobsSH dataSH, int flag, int FilterFlag, int UserID,string cultID)
        {
            return ResumeVsSavedJobsBL.getCandidateListManually(JobID, dataSH, flag, FilterFlag, UserID,cultID);
        }

        //to retriev the list of candidates for a particular job
        public DataTable getCandidateList(int JobID, int FilterFlag, int flag, int UserID,string cultID)
        {
            return ResumeVsSavedJobsBL.getCandidateList(JobID, FilterFlag, flag, UserID,cultID);
        }

        //To insert the list of selected candidates
        public void insertCandidateList(ResumeVsSavedJobsSH saveSH,int flag,string cultID)
        {
            ResumeVsSavedJobsBL.insertCandidateList(saveSH,flag,cultID);
        }

        //To retrieve the Resume ID of a particular candidate
        public static string getResumeID(int userID,string cultID)
        {
           return ResumeVsSavedJobsBL.getResumeID(userID,cultID);
        }

        //To retrieve the Video Resume ID of a particular candidate
        public static string getVideoResumeID(int userID,string cultID)
        {
            return ResumeVsSavedJobsBL.getVideoResumeID(userID,cultID);
        }

       //to retrieve the list of JobFamily Names
        public DataTable getJobFamilyNames()
        {
            return ResumeVsSavedJobsBL.getJobFamilyNames();
        }

        //to retrieve the Job Family ID from Job Family name
        public static string getJobFamilyID(string jobName)
        {
            return ResumeVsSavedJobsBL.getJobFamilyID(jobName);
        }

        //to check the approval status
        public static DataTable isVodeoAvailable(int candID,string cultID)
        {
            return ResumeVsSavedJobsBL.isVodeoAvailable(candID,cultID);
        }

        //to check whether CV/Video is hidden or not
        public DataTable isCVsHidden(int UserID, int flag, string cultID)
        {
            return ResumeVsSavedJobsBL.isCVsHidden(UserID, flag, cultID);
        }
    }
}
