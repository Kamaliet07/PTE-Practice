﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.Shared;
using IRSA.BussinessLogic;
using System.Data;
namespace IRSA.Facade
{
   public class EmailSendingInterfaceFA
    {

        public DataTable InsertData(EmailSendingInterfaceSH obj)
        {
            EmailSendingInterfaceBL objbl = new EmailSendingInterfaceBL();
           return objbl.InserData(obj);
        }

        public DataTable GetComboBoxData()
        {
           return EmailSendingInterfaceBL.GetComboBoxData();
        }
    }
}
