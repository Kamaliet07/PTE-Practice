﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
  public class TrainingPostFA
    {
      public DataTable GetTraining(TrainingPostSH trpsh)
      {
          TrainingPostBL trpBL = new TrainingPostBL();

        return  trpBL.GetTraining(trpsh);
      }
      public DataTable PostTraining(TrainingPostSH trpsh, int PostTrainingID)
      {
          TrainingPostBL trpBL = new TrainingPostBL();

          return trpBL.PostTraining(trpsh, PostTrainingID);
      }
      public DataTable SelectTraining(int PostTrainingID)
      {
          TrainingPostBL trpBL = new TrainingPostBL();

          return trpBL.selectTraining(PostTrainingID);
      }
      public DataTable selectTrainingContact(int PostTrainingID)
      {
          TrainingPostBL trpBL = new TrainingPostBL();

          return trpBL.selectTrainingContact(PostTrainingID);
      }
      public DataTable selectTrainingUserInfo(int UserID)
      {
          TrainingPostBL trpBL = new TrainingPostBL();

          return trpBL.selectTrainingUserInfo(UserID);
      }
      public DataTable GetBasicTraining(TrainingPostSH trpsh)
      {
          TrainingPostBL trpBL = new TrainingPostBL();

          return trpBL.GetBasicTraining(trpsh);
      }
      public DataTable GetTrainingList()
      {
          return TrainingPostBL.GetTrainingList();
      }
      public DataTable selectTrainingInfo(int UserID, int PostTrainingID)
      {
          TrainingPostBL trpBL = new TrainingPostBL();
          return trpBL.selectTrainingInfo(UserID, PostTrainingID);
      }
    }
}
