﻿using IRSA.BussinessLogic;
using IRSA.Shared;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace IRSA.Facade
{
    public class MyResFA
    {
        //Based on the parameter yx_vid_flag this method calls the business logic 
        //function that saves the file path of the saved file (the text or the video resume),
        //as the case may be,to the database.

        public void UpldRes(MyResSH objMyResSH, int userID, int txt_vid_flag)
        {
            MyResBL objMyResBL = new MyResBL();
            if (txt_vid_flag == 1)
                objMyResBL.svResume(objMyResSH, userID);
            else if (txt_vid_flag == 2)
                objMyResBL.svVidResume(objMyResSH, userID);
            else if (txt_vid_flag == 3)
                objMyResBL.svTxtResume(objMyResSH, userID);
        }

        //Function to call the business logic function that will update the
        //radgrid control when a user enters some text into the search box

        public DataTable updtGrid(string queryArgument, string subQueryArgument)
        {
            return MyResBL.updateGrid(queryArgument, subQueryArgument);
        }


        public static DataTable blockedList(int UserID, int flag, string queryArgument, string subQueryArgument)
        {
            return MyResBL.blockedList(UserID, flag, queryArgument, subQueryArgument);
        }


        //Unblock all organisations before blocking them

        public void unblockOrganisations(int UserID)
        {
            MyResBL.unblockOrganisations(UserID);
        }


        //Block an organisation for a user

        public static void blockOrganisation(int flag, int UserID, int OrganisationID)
        {
            MyResBL.blockOrganisation(UserID, OrganisationID);
        }


        //Return the resume file name of a particular user

        public static string ResumeFileName(int UserID, int flag)
        {
            return MyResBL.ResumeFileName(UserID, flag);
        }


        //Save user privacy settings for the uploaded resumes

        public void savResumePrivSettings(int UserID, string SettingType, bool EveryOne, bool MyContacts, bool MyCommunities)
        {
            MyResBL objMyResBL = new MyResBL();
            objMyResBL.savResumePrivSettings(UserID, SettingType, EveryOne, MyContacts, MyCommunities);
        }


        //Return video resume approval status

        public int vidApprStatus(int Flag, int UserID)
        {
            MyResBL objMyResBL = new MyResBL();
            return objMyResBL.vidApprStatus(Flag, UserID);
        }
    }
}
