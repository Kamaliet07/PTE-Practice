﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
   public class EventInterfaceFA
    {
        public void InsertData(EventInterfaceSH sh,int UserID)
        {
            EventInterfaceBL.InsertData(sh,UserID);
        }

        public DataTable GetData()
        {
            return EventInterfaceBL.GetData();
        }
        public DataTable GetDataPopUp(int EventID,string Title)
        {
            return EventInterfaceBL.GetDataPopUp(EventID, Title);
        }
    }
}
