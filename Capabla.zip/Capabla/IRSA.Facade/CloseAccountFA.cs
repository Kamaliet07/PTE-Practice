﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
  public  class CloseAccountFA
    {
      public void Closeconn(int UserID)
      {

          CloseAccountBL objcloseconnection = new CloseAccountBL();
          objcloseconnection.DeleteAccount(UserID);

      }
    }
}
