﻿using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
   public class MContactListFA
    {

        public DataTable GetData1(string str4, MContactListSH objcontlistSH, int UserID)
        {
            return MContactListBL.GetUserData(str4, objcontlistSH, UserID);
        }
        public DataTable GetUserSearch(string str, int UserID)
        {
            //return IRSA.BussinessLogic.Community.CommunityBL.GetContactList(UserID, Name);
            return MContactListBL.GetUserDetails(str, UserID);
        }

    }
}
