﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.Shared;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class RecruiterJobPostingFA
    {
        public DataTable GetData(RecruiterJobPostingSh objsh)
        {
          return  RecruiterJobPostingBL.GetData(objsh);
        }

        public DataTable GetDataDefault()
        {
            return RecruiterJobPostingBL.GetDataDefault();
        }


        public void GetDeleteData(int JobID)
        {
            RecruiterJobPostingBL.GetDeleteData(JobID);
        }
    }
}
