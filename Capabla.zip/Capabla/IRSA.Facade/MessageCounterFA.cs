﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class MessageCounterFA
    {
       public DataTable GetData()
       {
           return MessageCounterBL.GetData();
       }
    }
}
