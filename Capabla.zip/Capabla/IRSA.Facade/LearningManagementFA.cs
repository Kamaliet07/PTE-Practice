﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class LearningManagementFA
    {
       public DataTable GetLearningManagement()
       {
           return LearningManagement.GetLearningManagement();
       }
       //public DataTable GetTraining(LearningManagementSH trng)
       //{
       //    return LearningManagement.GetTraining(trng);
       //}

       public DataTable GetTraining(LearningManagementSH trng)
       {
           return LearningManagement.GetTraining(trng);
       }
    }
}
