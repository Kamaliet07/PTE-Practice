﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
   public class CompanySearchFA
   {

       public DataTable GetData1(string Keywords, CompanySearchSH objCompanySearchSH)
       {
           return CompanySearchBL.GetUserData(Keywords, objCompanySearchSH);
       }
       public DataTable GetCompanyData()
       {
           return CompanySearchBL.GetCompanyList();
       }
       public DataTable GetCompany(string Keywords, CompanySearchSH objCompanySearchSH)
       {
           return CompanySearchBL.GetCompany(Keywords, objCompanySearchSH);
       }
       public DataTable getUser(int UserID)
       {
           return CompanySearchBL.getUser(UserID);
       }
       public DataTable GetCompanyAsses(int UserID)
       {
           return CompanySearchBL.GetCompanyAsses(UserID);
       }
    }
}
