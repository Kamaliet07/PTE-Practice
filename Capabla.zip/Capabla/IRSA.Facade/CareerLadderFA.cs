﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

using System.Web;
using System.Data;

using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class CarrerLadderFA
    {
        public DataTable GetJobFamilyData() //get JobFamily
        {

            return CareerLadderBL.GetJobFamilyData();    //this.UserID);
        }

        public DataTable GetSourceData(string JobFamily)
        {
            CareerLadderBL objcareer = new CareerLadderBL();
            return objcareer.GetSourceData(JobFamily);
        }



        public DataTable GetDetailSourceData(string JobFamily, string SourceValue, string TargeValue, int i)
        {
            CareerLadderBL objSourceData = new CareerLadderBL();
            return objSourceData.GetDetailSourceData(JobFamily, SourceValue, TargeValue, i);
        }

        public DataTable GetOccupationCount(string JobFamily, string SourceValue, string TargeValue, int i)
        {
            CareerLadderBL objSourceData = new CareerLadderBL();
            return objSourceData.GetOccupationCount(JobFamily, SourceValue, TargeValue, i);
        }
        public DataTable GetTargetData(string JobFamily, string SourceValue, string TargeValue, int i)
        {
            CareerLadderBL GetTargetData = new CareerLadderBL();
            return GetTargetData.GetTargetData(JobFamily, SourceValue, TargeValue, i);
        }
        public DataTable GetSourceZone(string Source)
        {
            CareerLadderBL objcareer = new CareerLadderBL();
            return objcareer.GetSourceZone(Source);
        }

        public DataTable GetDetailCLTask(string Onsetcode,int flag)
        {
            CareerLadderBL objcareer = new CareerLadderBL();
            return objcareer.GetDetailCLTask(Onsetcode, flag);
        }
        public DataTable GetDetailCLKnowlwdge(string Onsetcode, int flag)
       {
           CareerLadderBL objcareer = new CareerLadderBL();
           return objcareer.GetDetailCLKnowlwdge(Onsetcode, flag);
       }

        public DataTable GetDetailCLAbility(string Onsetcode, int flag)
       {
           CareerLadderBL objcareer = new CareerLadderBL();
           return objcareer.GetDetailCLAbility(Onsetcode, flag);
       }

        public DataTable GetDetailCLSkills(string Onsetcode, int flag)
       {
           CareerLadderBL objcareer = new CareerLadderBL();
           return objcareer.GetDetailCLSkills(Onsetcode, flag);
       }
        public DataTable GetDetailCLWorkActivities(string Onsetcode, int flag)
       {
           CareerLadderBL objcareer = new CareerLadderBL();
           return objcareer.GetDetailCLWorkActivities(Onsetcode, flag);
       }     

    }
}