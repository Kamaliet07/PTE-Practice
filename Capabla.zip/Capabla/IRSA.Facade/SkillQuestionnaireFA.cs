﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class SkillQuestionnaireFA
    {
       public DataTable GetSkillQuestionnaireData(string eid) 
       {

           return SkillQuestionnaireBL.GetSkillQuestionnaireData(eid);    
       }
       public void InsertskillQues(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.InsertskillQues(objskill);

       }
       public void InsertOrgskillQues(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.InsertOrgskillQues(objskill);

       }
       public DataTable GetSubmitStatus(string questemplate,int AttemptID)
       {

           return SkillQuestionnaireBL.GetSubmitQuestions(questemplate, AttemptID);
       }
       public DataTable GetOrgSubmitStatus(string questemplate, int AttemptID)
       {

           return SkillQuestionnaireBL.GetOrgSubmitQuestions(questemplate, AttemptID);
       }
       public void DeleteskillQues(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.DeleteskillQues(objskill);

       }
       public void DeleteOrgskillQues(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.DeleteOrgskillQues(objskill);

       }
       public DataTable GetWorkContextData(string eid)
       {

           return WorkContextBL.GetWorkContextData(eid);
       }
       public DataTable GetWorkStyleData()
       {

           return WorkContextBL.GetWorkStyleData();
       }
       public DataTable GetToolsTechnologyData(string occuptiontilte)
       {

           return WorkContextBL.GetToolsTechnologyData(occuptiontilte);
       }

       public void InsertToolstechskillQues(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.InserttoolstecQues(objskill);

       }
       public void InsertQuesSubmissionList(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.InsertQuesSubmissionList(objskill);

       }
       public DataTable GetAttemptID(int UserID, string questemplate)
       {

           return SkillQuestionnaireBL.GetUserAttemptID(UserID, questemplate);
       }
       public DataTable GetOrgAttemptID(int UserID, string questemplate)
       {

           return SkillQuestionnaireBL.GetOrgUserAttemptID(UserID, questemplate);
       }
       public DataTable GetUserAttemptIDfromsubmissonList(int UserID, string questemplate)
       {

           return SkillQuestionnaireBL.GetUserAttemptIDfromsubmissonList(UserID, questemplate);
       }
       public DataTable BindJobFamilyData()
       {

           return SkillQuestionnaireBL.BindJobFamilyData();
       }
       public DataTable BindOccupation(int JobFamilyID)
       {

           return SkillQuestionnaireBL.BindOccupation(JobFamilyID);
       }
       public DataTable GetWorkActivityQuestionnaireData(string Joboccupation,string CultureID)
       {

           return SkillQuestionnaireBL.GetWorkActivityQuestionnaire(Joboccupation, CultureID);
       }
       public void InsertWorkActivityQuestionnaire(SkillQuestionnaireSH objskill)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.InsertWorkActivityQuestionnaire(objskill);

       }
       public void InboxcandidateAssessmentCompleted(int UserID, int RecuriterID)
       {
           SkillQuestionnaireBL objskillBL = new SkillQuestionnaireBL();
           objskillBL.InboxcandidateAssessmentCompleted(UserID, RecuriterID);

       }
    }
}
