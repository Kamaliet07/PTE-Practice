﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
   public class UserInboxFA
    {
       public DataTable GetData()
       { 
         return UserInboxBL.GetData();
       
       }



       public DataTable GetSubject(string obj)
       {
           return UserInboxBL.GetSubject( obj);
       }

       public DataTable InboxPopUp(int UserID)
       {
           return UserInboxBL.GetSubject(UserID);
       }



       public DataTable GetDataOutBox()
       {
           return UserInboxBL.GetDataOutBox();
       }

       public DataTable GetStatus(EmailSendingInterfaceSH obj)
       {
           return UserInboxBL.GetStatus(obj);
       }

       public DataTable InsertArchive(string str)
       {
           return UserInboxBL.InsertArchived(str); 
       }

       public DataTable GetDataArchived()
       {
           return UserInboxBL.GetDataArchived();
       }

       public void SetArchivedStatus(int keyword)
       {
           UserInboxBL sas = new UserInboxBL();
           sas.SetArchivedStatus(keyword); 
       }

       public void SetMarkRead(int keyword)
       {
           UserInboxBL smr = new UserInboxBL();
           smr.SetMarkRead(keyword); 
       }

       public void SetMarkUnread(int keyword)
       {
           UserInboxBL smu = new UserInboxBL();
           smu.SetMarkUnread(keyword); 
       }

       public DataTable GetSearchData(string str)
       {
           return UserInboxBL.GetSearchData(str); 
       }



       public DataTable GetSearchDataOutbox(string str)
       {
           return UserInboxBL.GetSearchDataOutbox(str); 
       }

       public DataTable GetSearchDataArchived(string str)
       {
           return UserInboxBL.GetSearchDataArchived(str); 
       }

       public DataTable GetPendingSubjectData(int InboxID)
       {
           return UserInboxBL.GetPendingSubjectData(InboxID); 
       }
    }
}
