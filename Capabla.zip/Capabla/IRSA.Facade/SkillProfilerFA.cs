﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;


namespace IRSA.Facade
{
    public class SkillProfilerFA
    {
        public DataTable GetSkillTreeFamily()
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetSkillTree();
        }
        
        public DataTable GetSkillWorkActivity(string ONETSOCCode, string ScaleID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetSkillWorkActivity(ONETSOCCode, ScaleID);
        }
        //For Edit WorkActivity
        public DataTable GetWorkActivity(int SkillProfileID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetWorkActivity(SkillProfileID);
        }

        public DataTable GetSkillQuestionaire(int SkillProfileID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetWorkSkillQuestionaire(SkillProfileID);
        }
        public DataTable GetWorkActivityGraph(string jobfamilyId, string ONETSOCCode)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetWorkActivityGraph(jobfamilyId, ONETSOCCode);
        }
        public DataTable GetSkills(string ONETSOCCode)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetSkills(ONETSOCCode);
        }
        public DataTable GetSkillsTemp(string ONETSOCCode, string ScaleID, int DataValue,int SkillProfileID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetSkillsTemp(ONETSOCCode, ScaleID, DataValue,SkillProfileID);
        }
        public DataTable GetSkillProfilerData(int SkillProfileID, int UserID, string CultureID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetSkillProfilerData(SkillProfileID, UserID, CultureID);
        }
        
        public DataTable SaveSkillQuestionaireResult(string QuestionaireTemplateName,int UserID, string SkillID, string ScaleID, float DataValue, string CultureID,Boolean Deleted,string Option)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.InsertSPSkillQuestionaireResult(QuestionaireTemplateName,UserID, SkillID,ScaleID, DataValue, CultureID,Deleted,Option);
        }

        public DataTable SaveWorkActivityQuestionaireResult(string QuestionaireTemplateName,int UserID, string ElementID, string CultureID,Boolean Deleted,string Option)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.InsertSPWorkActivityQuestionaireResult(QuestionaireTemplateName,UserID,ElementID, CultureID,Deleted,Option);
        }
        // for Rate Skill
        public DataTable OccupationData(string ONETSOCODE, string ElementID, string ScaleID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.OccupationData(ONETSOCODE, ElementID, ScaleID);
        }
              

        public DataTable GetSkillTreeOcupation(string childnode)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetSkillTreeOcupation(childnode);
            
        }

        public DataTable OccupationData(string p, DataTable dataTable)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.OccupationData(p, dataTable);
        }

        public DataTable GetAllDomSkillWorkActivity(string OnetSocCode, string ScaleID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetAllDomSkillWorkActivity(OnetSocCode, ScaleID);
        }



        public DataTable GetEvaluateWorkActChart(string seletedfamly, string UserseletedOcc)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetWorkActivityChartData(seletedfamly, UserseletedOcc);
        }

        public void SaveSkillProfilerData(IRSA.Shared.SkillProfiler SkProfiler)
        {
           IRSA.BussinessLogic.SkillProfilerBL.InsertSkillProfiler(SkProfiler);
        }

        public void SaveSkillQuestionaireResult(IRSA.Shared.SkillProfiler SkProfiler, DataTable dataTable)
        {
            IRSA.BussinessLogic.SkillProfilerBL.InsertSPSkillQuestionaireResult(SkProfiler, dataTable);
        }

        public DataTable EvaluateMatchSkillProf(string UserSeletednode, int userid)
        {
           return IRSA.BussinessLogic.SkillProfilerBL.EvaluateMatchedSkillDetail(UserSeletednode, userid);
        }

        public DataTable GetEvaluateSkillPieGrapfDet(string seletednode, string UserSeletednode, int userid)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetEvaluateSkillPieGrapfDetail(seletednode,UserSeletednode, userid);
        }

        public DataTable getuserExistance(int userid, string ONESID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetUserExistance(userid, ONESID);
        }

        public DataTable GetUserPrevRecords(int UserID, string ONESID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetUserPrevRecords(UserID, ONESID);
        }

        public DataTable GetUserPrevSavedSkill(int UserID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetUserPrevSavedSkil(UserID);
        }

        public DataTable GetCareerToolSkillProfDt(int UserID)
        {
            return IRSA.BussinessLogic.SkillProfilerBL.GetCareerToolSkillProfDt(UserID);
        }
    }
}



