﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;


namespace IRSA.Facade
{
   public class EventsSecondFA
    {
       public DataTable GetUSerDocumentsEventSecond(string controlname)
       {
           return EventsSecondBL.GetUSerDocumentsEventSecond(controlname);
       }

    }
}
