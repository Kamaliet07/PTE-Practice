﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class ChangePasswordFA
    {
       public DataTable GetPassword(string password)
       {
           return IRSA.BussinessLogic.ChangePwdBL.RetrievePwd(password);

           //AccountsetupBL objaca = new AccountsetupBL();
           //return objaca.RetrieveAcademicGridData(UserID,HighestDegree);
           //return AccountsetupBL.RetrieveAccountData(UserID, step);
       }
       public void UpdatePassword(int UserID, string newpwd)
       {
           ChangePwdBL objchnbl=new ChangePwdBL();
           objchnbl.ChangePwd(UserID, newpwd);

           //AccountsetupBL objaca = new AccountsetupBL();
           //return objaca.RetrieveAcademicGridData(UserID,HighestDegree);
           //return AccountsetupBL.RetrieveAccountData(UserID, step);
       }
    }
}
