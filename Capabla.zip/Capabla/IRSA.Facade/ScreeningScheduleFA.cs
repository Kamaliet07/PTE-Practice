﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class ScreeningScheduleFA
    {
       public DataTable getJobTitle(string JobPostedFrom,string JobPostedTo,int userID,string cultID)
        {
           
            return ScreeningScheduleBL.getJobTitle(JobPostedFrom, JobPostedTo, userID,cultID);
        }

       

       public  DataTable getShortlistCandidates(string JobLocation, int SearchfitFrom, int SearchfitTo, int ProfileFitFrom, int ProfileFitTo, int userID, int jobID,int expFrom,int expTo,int AssessFitFrom,int AssessFitTo,string cultID)
       {
           return ScreeningScheduleBL.getShortlistCandidates(JobLocation, SearchfitFrom, SearchfitTo, ProfileFitFrom, ProfileFitTo, userID, jobID, expFrom, expTo, AssessFitFrom, AssessFitTo, cultID);
       }

       public DataTable getShortlistCandidates(int userID, int jobID, string cultID)
      {
          return ScreeningScheduleBL.getShortlistCandidates(userID, jobID, cultID);
      }
      //To insert the list of selected candidates
     public void insertCandidateList(ScreeingScheduleSH saveSH, int flag, string CultureID)
      {
          ScreeningScheduleBL.insertCandidateList(saveSH, flag,CultureID);
      }
     public DataTable getCandidateData(int jobID, int userID, string CultureID)
      {
          return ScreeningScheduleBL.getCandidateData(jobID, userID, CultureID);
      }
     public void insertInboxcand(ScreeingScheduleSH saveSH, string setEmailID, string CultureID)
     {
         ScreeningScheduleBL.insertInboxcand(saveSH, setEmailID, CultureID);
     }
    }
}
