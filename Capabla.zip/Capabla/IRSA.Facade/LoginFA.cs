﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

using System.Web;
using System.Data;

using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class LoginFA
    {
        //public DataTable GetPassword(LoginSH objsh) //get User Profile Data by User Login Id
        //{
        //    LoginBL objlogin = new LoginBL();
        //    return objlogin.GetForgetPassword(objsh); //this.UserID);


        //}
        public bool GetValidate(LoginSH objsh)
        {
            LoginBL objlogin = new LoginBL();
            return objlogin.GetValidateUser(objsh);
        }
        public bool GetValidateRec(LoginSH objsh)
        {
            LoginBL objlogin = new LoginBL();
            return objlogin.GetValidateRecruiter(objsh);
        }
        public DataTable GetOrgID()
        {
            return LoginBL.GetOrgID();
        }
    }
}

