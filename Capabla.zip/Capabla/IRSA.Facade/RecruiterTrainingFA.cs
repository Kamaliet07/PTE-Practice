﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.Shared;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class RecruiterTrainingFA
    {
        public DataTable GetData()
        {
            return RecruiterTrainingBL.GetData();
        }

        public void GetDeleteData(int PostTrainingID)
        {
            RecruiterTrainingBL.GetDeleteData(PostTrainingID);
        }

      

        public DataTable GetDataSearch(RecruiterTrainingSH objsh)
        {
            return RecruiterTrainingBL.GetDataSearch(objsh);
        }
    }
}
