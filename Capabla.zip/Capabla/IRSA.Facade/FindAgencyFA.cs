﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
   public  class FindAgencyFA
    {

       public DataTable getAgency()
       {
           return FindAgencyBL.getAgency();
       }
       public DataTable getResult(string ag,string loc,string name,string spe)
       {
           //FindAgencyBL bl = new FindAgencyBL();
           return FindAgencyBL.getResult(ag,loc,name,spe);
         
       }

       public DataTable getAgencyCon()
       {
           return FindAgencyBL.getAgencyCon();
       }

       public DataTable getResultfirst(string keyword)
       {
           return FindAgencyBL.getResultfirst(keyword);
       }
       public DataTable GetCompanyPopUpControl(int OrganisationID)
       {
           return FindAgencyBL.GetCompanyPopUpControl(OrganisationID);
       }
    }
}
