﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.BussinessLogic;
using IRSA.Shared;
namespace IRSA
{
    public class IRSAResumeFA
    {
        //To retrieve contact details
        public DataTable getContactandOtherDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID,flag,cultID);
        }

        //To retrieve Present Company data
        public DataTable getPresentCompanyDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID,flag,cultID);
        }

        //To retrieve Past Company data
        public DataTable getPastCompanyDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve Academics data
        public DataTable getAcademicsDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve License data
        public DataTable getLicenseDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve Association data
        public DataTable getAssociationDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve Visa data
        public DataTable getVisaDetails(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve Security Clearance data
        public DataTable getSecurityClearanceData(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve Awards and Achievements data
        public DataTable getAwardsAndAchievements(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag,cultID);
        }

        //To retrieve Industry Name
        public string getIndustryName(int UserID, string cultID)
        {
            return IRSAResumeBL.getIndustryName(UserID,cultID);
        }

        //To retrieve Industry Experience and Goals
        public string getExpNGoals(int UserID,string cultID)
        {
            return IRSAResumeBL.getExpNGoals(UserID, cultID);
        }

        //To retrieve the list of Clients for which projects have been done
        public DataTable getProjetcts(int UserID, string cultID)
        {
            return IRSAResumeBL.getProjetcts(UserID, cultID);
        }

        //to check whether the candidate entry exists in txnLicensAndCertifications
        public Boolean isCertiExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists in txnMemberAcademics
        public Boolean isAcademicsExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists in txnProjectDetails
        public Boolean isProjectExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists for Specialization in txnMemberAcademics
        public Boolean isSplExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists for Visa in txnMemberVisaInformation
        public Boolean isVisaExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists for Associations in txnMemberAssociations
        public Boolean isAssociationExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists for Security Clearance in txnMemberAccount
        public Boolean isSecurityExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists for Present Company in txnMemberCompany
        public Boolean isPresentCompExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to check whether the candidate entry exists for Past Company in txnMemberCompany
        public Boolean isPastCompExists(int UserID, int flg, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flg, cultID);
        }

        //to retrieve skills from txnMemberAccounts
        public string getSkills(int UserID, string cultID)
        {
            return IRSAResumeBL.getSkills(UserID,cultID);
        }

        //to retrieve degrees of a candidate
        public DataTable getAca(int UserID,int flag,string cultID)
        {
            return IRSAResumeBL.getAca(UserID,flag,cultID);
        }

        //to retrieve personal information of the candidate
        public string getPersonalInfo(int UserID, int flag,string cultID)
        {
            return IRSAResumeBL.getPersonalInfo(UserID, flag,cultID);
        }

        //to retrieve Address of the candidate
        public DataTable getAddress(int UserID,string cultID)
        {
            return IRSAResumeBL.getAddress(UserID,cultID);
        }

        //to retrieve the duration i.e. difference between two dates
        public static DataTable getDuration(DateTime dtFrom, DateTime dtTo)
        {
            return IRSAResumeBL.getDuration(dtFrom, dtTo);
        }

        //to retrieve the photo ID of the candidate
        public static DataTable getPhotoID(int UserID,string cultID)
        {
            return IRSAResumeBL.getPhoto(UserID,cultID);
        }
        
        //to retrieve the display name of the candidate
        public static string getDisplayName(int UserID, string CultureID)
        {
            return IRSAResumeBL.getDisplayName(UserID, CultureID);
        }

        //To retrieve Job Preference details
        public DataTable getJobPreferences(int UserID, int flag, string cultID)
        {
            return IRSAResumeBL.getData(UserID, flag, cultID);
        }

        //to retrieve whether User entry exists in txnAccountSettings
        public Boolean settingsExists(int UserID, int flag, string cultID)
        {
            return IRSAResumeBL.isExists(UserID, flag, cultID);

        }

        //to check whether name is hidden or not
        public Boolean isNameHidden(int UserID, string CultureID)
        {
            DataTable hideNameDT = new DataTable();
            hideNameDT = IRSAResumeBL.isNameHidden(UserID, CultureID);
            Boolean hide=Convert.ToBoolean(hideNameDT.Rows[0]["HideName"]);
            return hide;
        }

        //to check whether Photo is hidden or not
        public Boolean isPhotoHidden(int UserID, string CultureID)
        {
            DataTable hidePhotoDT = new DataTable();
            hidePhotoDT = IRSAResumeBL.isPhotoHidden(UserID, CultureID);
            Boolean hide = Convert.ToBoolean(hidePhotoDT.Rows[0]["EveryOne"]);
            return hide;
        }

        //to get the Industry Preferences of the candidate
        public static string getIndPreferences(int UserID, string CultureID)
        {
            return IRSAResumeBL.getIndPreferences(UserID, CultureID);
        }

       
    
}
}
