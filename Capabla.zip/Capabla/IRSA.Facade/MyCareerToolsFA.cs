﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
    public class MyCareerToolsFA
    {
        public DataTable GetProduct()
        {
            return MyCareerToolsBl.GetProduct();
        }
        public DataTable GetProductName()
        {
            return MyCareerToolsBl.GetProductName();
        }
        public DataTable GetProductNameAsses()
        {
            return MyCareerToolsBl.GetProductNameAsses();
        }
        public DataTable GetProfile(int ProfileID)
        {
            return MyCareerToolsBl.GetProfile(ProfileID);
        }

    }
}
