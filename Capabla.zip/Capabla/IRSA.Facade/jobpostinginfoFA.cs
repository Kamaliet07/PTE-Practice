﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
namespace IRSA.Facade
{
  public  class jobpostinginfoFA
    {
      public DataTable GetmoduleData()
        {
            return IRSA.BussinessLogic.jobpostinginfoBL.RetrivemoduleData();

            //AccountsetupBL objaca = new AccountsetupBL();
            //return objaca.RetrieveAcademicGridData(UserID,HighestDegree);
            //return AccountsetupBL.RetrieveAccountData(UserID, step);
        }

          public DataTable getmodules(int ModuleID)
        {
            return IRSA.BussinessLogic.jobpostinginfoBL.Retrivemodules(ModuleID);

            //AccountsetupBL objaca = new AccountsetupBL();
            //return objaca.RetrieveAcademicGridData(UserID,HighestDegree);
            //return AccountsetupBL.RetrieveAccountData(UserID, step);
        }
    }
}
