﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
   public class PersonSearchAdvancedFA
   {
       public DataTable GetData1(string Keywords, PersonSearchSH objpersonserachSH)
       {
           return PersonSearchAdvancedBL.GetUserData(Keywords, objpersonserachSH);
       }
       public DataTable Photostatus(int userid)
       {
           return PersonSearchAdvancedBL.GetPhotostatus(userid);
       }
       public DataTable contactstatus(int userid)
       {
           return PersonSearchAdvancedBL.GetContactstatus(userid);
       }
       public DataTable Getlinkstatusadvanced(int userid)
       {
           return PersonSearchAdvancedBL.Getlinkstatusadvanced(userid);
       }
       public DataTable Getphotostatusadvanced(int userid)
       {
           return PersonSearchAdvancedBL.Getphotostatusadvanced(userid);
       }
       public bool GetStatus(int userid)
       {
           PersonSearchAdvancedBL objPersonSearchAdvancedBL = new PersonSearchAdvancedBL();
           return objPersonSearchAdvancedBL.GetStatus(userid);
       }
       public bool GetMyContact(int UserID,int uid)
       {
           PersonSearchAdvancedBL objPersonSearchAdvancedBL = new PersonSearchAdvancedBL();
           return objPersonSearchAdvancedBL.GetMyContact(UserID,uid);
       }
       public bool GetOrgStatus(int UserID, int uid)
       {
           PersonSearchAdvancedBL objPersonSearchAdvancedBL = new PersonSearchAdvancedBL();
           return objPersonSearchAdvancedBL.GetOrgStatus(UserID, uid);
       }
      
    }
}
