﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade.Community
{
    public class CommunityFA
    {
        public DataTable GetData()
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetFunctionalDomain();

        }
        public DataTable GetIndustryId(string IndustryName)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetIndustryId(IndustryName);

        }
        public DataTable GetCommunityData()
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityData();

        }
        //public DataTable GetCommunityDetails()
        //{
        //    return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityDetails(1, "EN", SessionInfo.i_CategoryName, SessionInfo.i_CommSearch);

        //}
        public DataTable GetCommunityDetails(int UserId, string CultureId, string CommunityType, string ShortDecription)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityDetails(UserId, CultureId, CommunityType, ShortDecription);

        }



        public DataTable GetCommunityMemberInvitation(string CommunityName, string UserId, string CultureId)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityMemberInvitation(CommunityName, UserId, CultureId);


        }
        public DataTable GetCommunityUserId(string Email, string CultureId)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetUserID(Email, CultureId);


        }

        public DataTable GetCommunityDirectoryWithoutFunctionalDomain(int UserId, string CultureId, string CommunityName, string CommunityType)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityDirectoryWithoutFunctionalDomain(UserId, CultureId, CommunityName, CommunityType);

        }

        public DataTable GetCommunityDirectory(int UserId, string CultureId, string FunctionalDomain)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityDirectory(UserId, CultureId, FunctionalDomain);

        }
        public DataTable GetCommunityMemberDetails(int UserId, string CultureId, string CommunityName, string CommunityType, string ShortDescription)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityMember(UserId, CultureId, CommunityName, CommunityType, ShortDescription);


        }
        public DataTable SaveCommunityMember(int UserID, int CommunityID, bool Deleted, string CommandOption)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.SaveCommunityMember(UserID, CommunityID, Deleted, CommandOption);

        }

        # region Decleration of Facade Function by kamal

        public void SaveNewCommunity(string FunctDomain, IRSA.Shared.NewCommunityInfo objcommunitysave)
        {
            IRSA.BussinessLogic.Community.CommunityBL.SaveNewCommunityDetail(FunctDomain, objcommunitysave);
        }
        public DataTable GetMaxCommunityID()
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetMaxCommunityID();

        }
        public DataTable getCommunityIntireDetail(int communityid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityEntireDetail(communityid);
        }
        public int CommunityTotalMembers(int communityid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityMembers(communityid);
        }
        public DataTable getAllMyCommunityDetail()
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetAllMyCommunity();
        }
        public DataTable GetCommunityUserDetail(int communityid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityUserDetail(communityid);
        }
        public DataTable GetInvitedUserDetail(int userid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetInvitedUserDetail(userid);
        }
        public DataTable GetLoginUserDetail()
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetInvitedUserDetail(SessionInfo.UserId);
        }
        public DataTable GetStatusOFInvitedByUser(int invitedby, int invitedto)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetInvitedByUserStatus(invitedby, invitedto);
        }
        public DataTable UpdateInvitedUserAcceptance(int invitedby, int invitedto)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.UpdateInvitedUserAcceptance(invitedby, invitedto);
        }

        public void InsertUserInvitationDetail(int userid, int inviteduserid)
        {
            IRSA.BussinessLogic.Community.CommunityBL.InsertUserInvitationDetail(userid, inviteduserid);
        }

        public int JoinCommunity(int userid, int communityid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.JoinCommunity(userid, communityid);
        }
        public int CheckUserThisCommunityInfo(int userid, int communityid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.CheckUserThisCommunityInfo(userid, communityid);
        }
        //public void GetUserExistanceInNet(int userid, int loginuser)
        //{
        //    return IRSA.BussinessLogic.Community.CommunityBL.CheckUserThisCommunityInfo(userid, loginuser);
        //}
        public DataTable GetUserExistanceInNet(int userid, int loginuser)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetUserExistanceInNet(userid, loginuser);
        }
        public void RemoveFromUserList(int CommID)
        {
            IRSA.BussinessLogic.Community.CommunityBL.RemoveFromUserList(CommID);
        }
        public DataTable GetMyContactMember(int userid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetMyContactMember(userid);
        }
        public DataTable GetSearchCommunity(string communityname, string Communitytype)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetMyContactMember(communityname, Communitytype);
        }

        public DataTable DeteateCommunity(int communityid)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.DeteateCommunity(communityid);
        }
        # endregion












       public DataTable GetContactList(int UserID, string Name)
        {
            return IRSA.BussinessLogic.Community.CommunityBL.GetContactList(UserID, Name);

        }



       public DataTable GetCommunitySearch(string search)
       {
           return IRSA.BussinessLogic.Community.CommunityBL.GetCommunitySearch(search);

       }
       public DataTable GetCommunityList()
       {
           return IRSA.BussinessLogic.Community.CommunityBL.GetCommunityList();

       }

       public DataTable GetUserLoginDetail(int userid)
       {
           return IRSA.BussinessLogic.Community.CommunityBL.GetUserLoginDetail(userid);
       }
    }
}
