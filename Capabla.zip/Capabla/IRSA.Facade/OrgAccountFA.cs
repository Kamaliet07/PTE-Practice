﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.BussinessLogic;
using IRSA.Common.GlobalFunction;


namespace IRSA.Facade
{
  public  class OrgAccountFA
    {
      //public void InsertOrganisationData(OrgAccountSH objoraccSH, int UserID)
      //{
      //    OrgAccountBL objOrgAccountBL = new OrgAccountBL();
      //    objOrgAccountBL.SaveOrganisationData(objoraccSH,UserID);
      //}
      public void InsertOrganisationData(OrgAccountSH objoraccSH, int UserID, int OrganisationID)
      {
          //OrgAccountBL objorgBL = new OrgAccountBL();
          OrgAccountBL.SaveOrganisationData(objoraccSH, UserID,OrganisationID);
         
          
      }

      public void insertLogo(string Logopath,int OrganisationID)
      {
          OrgAccountBL objorgBL = new OrgAccountBL();
          objorgBL.SaveLogo(Logopath, OrganisationID);
         
          
      }

      public void updatephoto(int UserID, int OrgID, bool flag)
      {
          OrgAccountBL objorgBL = new OrgAccountBL();
          objorgBL.Removepripic(UserID, OrgID, flag);
         
          
      }
      public void removelogo(int UserID, int OrganisationID)
      {
          OrgAccountBL objorgBL = new OrgAccountBL();
          objorgBL.Removericlogo(UserID, OrganisationID);
         
          
      }
      public DataTable RetrieveOrganisationData(int UserID, int OrganisationID)
      {
          OrgAccountBL OBJGET = new OrgAccountBL();
          return OBJGET.GetOrganisationData(UserID, OrganisationID);
          //return AccountsetupBL.RetrieveAccountData(UserID, step);
      }

      public DataTable RetrievePriContactData(int UserID, int OrganisationID,bool flag)
      {
          OrgAccountBL OBJGET = new OrgAccountBL();
          return OBJGET.GetPriContactData(UserID, OrganisationID,flag);
          //return AccountsetupBL.RetrieveAccountData(UserID, step);
      }

      public void InsertPriContactData(OrgAccountSH objoraccSH, int UserID, int OrganisationID)
      {
          //OrgAccountBL objorgBL = new OrgAccountBL();
          OrgAccountBL.SavePricontactData(objoraccSH, UserID, OrganisationID);
         
          
      }

      public void insertpriphoto(string Photo, int UserID, int OrganisationID)
      {
          OrgAccountBL objorgBL = new OrgAccountBL();
          objorgBL.Savepriphoto(Photo, UserID, OrganisationID);
         
          
      }

      public void insertsecphoto(string Photo, int UserID, int OrganisationID)
      {
          OrgAccountBL objorgBL = new OrgAccountBL();
          objorgBL.Savesecphoto(Photo, UserID, OrganisationID);
         
          
      }
    }
}
