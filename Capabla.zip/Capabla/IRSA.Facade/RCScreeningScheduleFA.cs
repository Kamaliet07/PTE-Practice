﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.BussinessLogic;
using IRSA.Shared;

namespace IRSA.Facade
{
    public class RCScreeningScheduleFA
    {
        public DataTable getJobtitle(int UserID)
        {
            return RCScreeningScheduleBL.GetJobTitle(UserID);
        }
        public DataTable GetCandidateschedule(int UserID,string JobTitle)
        {
            return RCScreeningScheduleBL.GetCandidateschedule(UserID,JobTitle);
        }
        public void Insert(RecruiterSchedulerSH objRcSch,int UserID)
        {
            RCScreeningScheduleBL objschedulerBL = new RCScreeningScheduleBL();
            objschedulerBL.InsertSchedule(objRcSch,UserID);
        }
        public DataTable Getschedule(int UserID)
        {
            return RCScreeningScheduleBL.Getschedule(UserID);
        }
        public void Delete(int ID)
        {
            RCScreeningScheduleBL objschedulerBL = new RCScreeningScheduleBL();
            objschedulerBL.DeleteSchedule(ID);
        }
        public DataTable getCandidate(int UserID,int jobid)
        {
            return RCScreeningScheduleBL.getCandidate(UserID,jobid);
        }
        public DataTable GetSaveData(int UserID, RecruiterSchedulerSH objRcSch)
        {
            return RCScreeningScheduleBL.GetSaveData(UserID, objRcSch);
        }
        public DataTable Getscheduleaccordingwork(int UserID, RecruiterSchedulerSH objRcSch)
        {
            return RCScreeningScheduleBL.Getscheduleaccordingwork(UserID, objRcSch);
        }
        public DataTable GetscheduleaccordingJob(int UserID, RecruiterSchedulerSH objRcSch)
        {
            return RCScreeningScheduleBL.GetscheduleaccordingJob(UserID, objRcSch);
        }
        public DataTable GetCandidateData(int UserID, RecruiterSchedulerSH objRcSch)
        {
            return RCScreeningScheduleBL.GetCandidateData(UserID, objRcSch);
        }
    }
}
