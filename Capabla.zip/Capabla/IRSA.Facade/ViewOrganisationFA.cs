﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;

namespace IRSA.Facade
{
  public  class ViewOrganisationFA
    {
      public DataTable GetViewOrganisationData(int UserID, int OrganisationID)
      {
          //ViewAccountBL objviewaccuntBL = new ViewAccountBL();
          return ViewOrganisationBL.RetrieveOrgData(UserID, OrganisationID);
      }
      public DataTable GetViewContactData(int UserID, int OrgID)
      {
          //ViewAccountBL objviewaccuntBL = new ViewAccountBL();
          return ViewOrganisationBL.RetrieveContactData(UserID, OrgID);
      }
    }
}
