﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace IRSA.DALFactory
{
    /******************************************************************************************************************
          DEFINTION    : This is a abstract class where we declare different types of method
          METHOD NAMES : CreateDBObject,CreateConnection,CreateCommand,CreateAdapter,CreateParameter,GetParameterValue
          CREATE DATE  : 23-APRIL-2009
          MODIFY DATE  :  
     *******************************************************************************************************************/
    abstract public class AbstractDALFactory
    {

        /**************************************************************************************************
        METHOD NAME : CreateDBObject
        PARAMETERS  : databaseType
        RETURN TYPE : Returns type of database
        CREATE DATE : 23-APRIL-2009
        MODIFY DATE :  
        **************************************************************************************************/
        public static AbstractDALFactory CreateDBObject(string databaseType)
        {
            if (databaseType.ToUpper().Equals("SQL"))
            {
                return new SqlFactory(); 
            }
            else if (databaseType.ToUpper().Equals("ORACLE"))
            {

                return new OracleFactory();
            }
            else
            {
                return new OledbFactory();
            }
        }
        abstract public IDbConnection CreateConnection(string connectionString);
        abstract public IDbCommand CreateCommand(string commandText);
        abstract public IDbCommand CreateCommand();
        abstract public IDataAdapter CreateAdapter(string commandText);
        abstract public IDataAdapter CreateAdapter();
        abstract public IDataParameter CreateParameter();
        abstract public IDataParameter CreateParameter(string name, Object value);
        abstract public IDataParameter CreateParameter(string name, DbType type);
        abstract public IDataParameter CreateParameter(string name, DbType type,int size);
        abstract public Object GetParameterValue(Object parameter);
        abstract public string ConnectionString
        {
            get;
        }
    

    }
}
