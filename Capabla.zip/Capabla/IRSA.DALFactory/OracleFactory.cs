﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;


namespace IRSA.DALFactory
{
    /******************************************************************************************************************
         DEFINTION    : That class Contains different types of method for Oracledatabse
         METHOD NAMES : CreateDBObject,CreateConnection,CreateCommand,CreateAdapter,CreateParameter,GetParameterValue
         CREATE DATE  : 23-APRIL-2009
         MODIFY DATE  :  
    *******************************************************************************************************************/
    class OracleFactory:AbstractDALFactory
    {
        protected string _connectionString;
        public override IDbCommand CreateCommand(string commandText)
        {
            return new OracleCommand(commandText);
        }

        public override IDataAdapter CreateAdapter(string commandText)
        {
            return new OracleDataAdapter(new OracleCommand(commandText));  
        }

        public override IDataParameter CreateParameter()
        {
            return new OracleParameter();
        }

        public override IDataParameter CreateParameter(string name, object value)
        {
            return new OracleParameter(name,value);
        }

        public override IDataParameter CreateParameter(string name, DbType type, int size)
        {
            return new OracleParameter(name,(OracleType)type,size);
        }

        public override object GetParameterValue(object parameter)
        {
            if (parameter == null)
            {
                return null;
            }
            OracleParameter iOracleParameter = (OracleParameter)parameter;
            return iOracleParameter.Value;
        }

        public override string ConnectionString
        {
            get 
            {
                return _connectionString;
            }
        }

        public override IDbConnection CreateConnection(string connectionString)
        {
            return new OracleConnection(connectionString); 
        }

        public override IDbCommand CreateCommand()
        {
            return new OracleCommand();
        }

        public override IDataAdapter CreateAdapter()
        {
            return new OracleDataAdapter(new OracleCommand());
        }

        public override IDataParameter CreateParameter(string name, DbType type)
        {
            return new OracleParameter(name, (OracleType)type);
        }


    }
}
