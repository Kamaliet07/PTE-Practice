﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace IRSA.DALFactory
{
    /******************************************************************************************************************
          DEFINTION    : That class Contains different types of method for Oledbdatabse
          METHOD NAMES : CreateDBObject,CreateConnection,CreateCommand,CreateAdapter,CreateParameter,GetParameterValue
          CREATE DATE  : 23-APRIL-2009
          MODIFY DATE  :  
     *******************************************************************************************************************/
    class OledbFactory:AbstractDALFactory 
    {
        protected string _connectionString;

        public override IDbConnection CreateConnection(string connectionString)
        {
            return new OleDbConnection(connectionString);
        }

        public override IDbCommand CreateCommand(string commandText)
        {
            return new OleDbCommand(commandText);
        }

        public override IDataAdapter CreateAdapter(string commandText)
        {
            return new OleDbDataAdapter(new OleDbCommand(commandText));
        }

        public override IDataParameter CreateParameter()
        {
            return new OleDbParameter();

        }

        public override IDataParameter CreateParameter(string name, object value)
        {
            return new OleDbParameter(name, value);
        }

        public override IDataParameter CreateParameter(string name, DbType type, int size)
        {
            return new OleDbParameter(name, (OleDbType)type, size);
        }
        public override IDataParameter CreateParameter(string name, DbType type)
        {
            return new OleDbParameter(name, (OleDbType)type);
        }

        public override object GetParameterValue(object parameter)
        {
            if (parameter == null)
            {
                return null;
            }
            OleDbParameter iOleDbParameter = (OleDbParameter)parameter;
            return iOleDbParameter.Value;
        }

        public override string ConnectionString
        {
            get
            {
                return _connectionString;
            }
        }


        public override IDbCommand CreateCommand()
        {
            return new OleDbCommand();
        }

        public override IDataAdapter CreateAdapter()
        {
            return new OleDbDataAdapter(new OleDbCommand());
        }

    }
}
