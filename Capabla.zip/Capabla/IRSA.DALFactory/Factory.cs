﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IRSA.DALInterface;

namespace IRSA.DALFactory
{
    public class Factory
    {
        private string _DBType;

        public string DBType
        {
            get
            {
                return _DBType;
            }
            set
            {
                value = _DBType;
            }
        }

        public Factory(string DataBaseType)
        {
            this._DBType = DataBaseType;
        }

        /**************************************************************************************************
         METHOD NAME : GetDBProvider
         PARAMETERS  : None
         RETURN TYPE : Returns type of database method's Access 
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/
        public DataAccessInterface GetDBProvider()
        {
            if (_DBType.Equals("Sql"))
            {
                return new IRSA.DataAccess.SqlDataAccess();
            }
            else if (_DBType.Equals("Oracle"))
            {

                return new IRSA.DataAccess.OracleDataAccess();
            }
            else
            {
                return new IRSA.DataAccess.OledbDataAccess();
            }
        }

    }
}
