﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data; 

namespace IRSA.DALFactory
{
    /******************************************************************************************************************
        DEFINTION    : That class Contains different types of method for SQLdatabse
        METHOD NAMES : CreateDBObject,CreateConnection,CreateCommand,CreateAdapter,CreateParameter,GetParameterValue
        CREATE DATE  : 23-APRIL-2009
        MODIFY DATE  :  
   *******************************************************************************************************************/
    class SqlFactory:AbstractDALFactory 
    {
        protected string _connectionString;
        
        public override IDbConnection CreateConnection(string connectionString)
        {
            return new SqlConnection(connectionString); 
        }

        public override IDbCommand CreateCommand(string commandText)
        {
            return new SqlCommand(commandText); 
        }

        public override IDataAdapter CreateAdapter(string commandText)
        {
            return new SqlDataAdapter(new SqlCommand(commandText));  
        }

        public override IDataParameter CreateParameter()
        {
            return new SqlParameter(); 
        }

        public override IDataParameter CreateParameter(string name, object value)
        {
            return new SqlParameter(name, value); 
        }

        public override IDataParameter CreateParameter(string name, System.Data.DbType type, int size)
        {
            return new SqlParameter(name, (SqlDbType)type, size); 
        }

        public override object GetParameterValue(object parameter)
        {
            if (parameter == null)
            {
                return null;
            }
            SqlParameter iSqlParameter = (SqlParameter)parameter;
            return iSqlParameter.Value; 
        }

        public override string ConnectionString
        {
            get 
            {
                return _connectionString;            
            }
        }

        public override IDbCommand CreateCommand()
        {
            return new SqlCommand(); 
        }

        public override IDataAdapter CreateAdapter()
        {
            return new SqlDataAdapter(new SqlCommand());   
        }

        public override IDataParameter CreateParameter(string name, DbType type)
        {
            return new SqlParameter(name, (SqlDbType)type);
        }
    }

    
}
