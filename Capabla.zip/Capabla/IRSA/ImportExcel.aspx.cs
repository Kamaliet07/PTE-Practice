﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;
using System.Data.SqlClient;
using System.Data.OleDb;
using IRSA.Facade;
using System.IO;

namespace IRSA
{
    public partial class ImportExcel : System.Web.UI.Page
    {
        # region Decleration For View State and DataTable
        public DataTable occupation
        {
            set
            {
                ViewState["occupation"] = value;
            }
            get
            {

                return (DataTable)ViewState["occupation"];
            }
        }
        public DataTable CategoryColl
        {
            set
            {
                ViewState["CategoryColl"] = value;
            }
            get
            {

                return (DataTable)ViewState["CategoryColl"];
            }
        }
        public DataTable QuestionColl
        {
            set
            {
                ViewState["QuestionColl"] = value;
            }
            get
            {

                return (DataTable)ViewState["QuestionColl"];
            }
        }

        public string CategoryID
        {
            set
            {
                ViewState["CategoryID"] = value;
            }
            get
            {
                if (ViewState["CategoryID"] == null)
                {
                    ViewState["CategoryID"] = string.Empty;
                }
                return ViewState["CategoryID"].ToString();
            }
        }
        public string JobFamilyID
        {
            set
            {
                ViewState["JobFamilyID"] = value;
            }
            get
            {
                if (ViewState["JobFamilyID"] == null)
                {
                    ViewState["JobFamilyID"] = string.Empty;
                }
                return ViewState["JobFamilyID"].ToString();
            }
        }
        public string OccuptionID
        {
            set
            {
                ViewState["OccuptionID"] = value;
            }
            get
            {
                if (ViewState["OccuptionID"] == null)
                {
                    ViewState["OccuptionID"] = string.Empty;
                }
                return ViewState["OccuptionID"].ToString();
            }
        }
        
        public DataTable GetSkillFamily
        {
            get { return (DataTable)ViewState["GetSkillFamily"]; }
            set { ViewState["GetSkillFamily"] = value; }
        }
        # endregion 
        public SqlConnection sqlcon = new SqlConnection("Data Source = MINDS3; User ID = sa; Password = minds; Initial Catalog=simple");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                if (!Page.IsPostBack)
                {
                    this.GetSkillFamily = GetSkillFamilyDetails();
                    GetDefaultTopID();                    
                    BindComboBox();
                    BindGrids();

                }
            }

            catch
            { 
            
            
            }
            
        }

        private void GetDefaultTopID()
        {
            try
            {
                this.JobFamilyID = this.GetSkillFamily.Rows[0]["JobFamilyID"].ToString();
                GetChildNodes(this.JobFamilyID);
                this.OccuptionID = this.occupation.Rows[0]["ONETSOCCode"].ToString();
                GetCategoryDetail(this.OccuptionID);
                this.CategoryID = this.CategoryColl.Rows[0]["ONETSOCCode"].ToString();
                GetQuestionnarieDetail(this.CategoryID);
                BindGrids();
            }

            catch
            { 
            
            }

        }

        private void GetCategoryDetail(string OccID)
        {
            QuestionLibraryFA objFA = new QuestionLibraryFA();
            this.CategoryColl = objFA.GetCategorryColl(OccID);
        }

        private void GetQuestionnarieDetail(string CatID)
        {
            throw new NotImplementedException();
        }

        private void BindComboBox()
        {
            RadComboBoxJobfml.DataSource = this.GetSkillFamily;
            RadComboBoxJobfml.DataTextField = "JobFamilyName";
            RadComboBoxJobfml.DataValueField = "JobFamilyID";
            RadComboBoxJobfml.DataBind();
        }

        private void BindGrids()
        {
            this.RadGridOcc.DataSource = this.occupation;
            this.RadGridOcc.DataBind();

            this.RadGridQuestion.DataSource = this.occupation;
            this.RadGridQuestion.DataBind();

            this.RadGridCategory.DataSource = this.occupation;
            this.RadGridCategory.DataBind();
        }

        private DataTable GetSkillFamilyDetails()
        {
            SkillProfilerFA objskillfamily = new SkillProfilerFA();
            return objskillfamily.GetSkillTreeFamily();
        }

        private DataTable GetCategory()
        {
            DigitalAdvisorFA objcategory = new DigitalAdvisorFA();
            DataTable temp = objcategory.getDetCategory();

            return temp;
        }

       
        protected void RadComboBoxJobfml_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {
                this.JobFamilyID = RadComboBoxJobfml.SelectedItem.ToString();
                GetChildNodes(this.JobFamilyID);                
                BindGrids();
            }

            catch
            {


            }
        }

        private void GetChildNodes(string jobfamilyid)
        {
            SkillProfilerFA objskillfamilyOccupt = new SkillProfilerFA();
            this.occupation = objskillfamilyOccupt.GetSkillTreeOcupation(jobfamilyid);
        }

        protected void ButnDownload_Click(object sender, EventArgs e)
        {
            // Get the physical Path of the file(test.doc)
             string filepath = Server.MapPath("contatti.xls");

             // Create New instance of FileInfo class to get the properties of the file being downloaded
             FileInfo file = new FileInfo(filepath);
 
            // Checking if file exists
             if (file.Exists)
               {
                 // Clear the content of the response
                 Response.ClearContent();
   
                 // LINE1: Add the file name and attachment, which will force the open/cance/save dialog to show, to the header
                 Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
   
                 // Add the file size into the response header
                 Response.AddHeader("Content-Length", file.Length.ToString());

                 // Set the ContentType
                 Response.ContentType = ReturnExtension(file.Extension.ToLower());

                 // Write the file into the response (TransmitFile is for ASP.NET 2.0. In ASP.NET 1.1 you have to use WriteFile instead)
                 Response.Write(file.FullName);

                // End the response
                Response.End();
             
              }
         }

        private string ReturnExtension(string fileExtension)
        {
            switch (fileExtension)
            {
                case ".htm":
                case ".html":
                case ".log":
                    return "text/HTML";
                case ".txt":
                    return "text/plain";
                case ".doc":
                    return "application/ms-word";
                case ".tiff":
                case ".tif":
                    return "image/tiff";
                case ".asf":
                    return "video/x-ms-asf";
                case ".avi":
                    return "video/avi";
                case ".zip":
                    return "application/zip";
                case ".xls":
                case ".csv":
                    return "application/vnd.ms-excel";
                case ".gif":
                    return "image/gif";
                case ".jpg":
                case "jpeg":
                    return "image/jpeg";
                case ".bmp":
                    return "image/bmp";
                case ".wav":
                    return "audio/wav";
                case ".mp3":
                    return "audio/mpeg3";
                case ".mpg":
                case "mpeg":
                    return "video/mpeg";
                case ".rtf":
                    return "application/rtf";
                case ".asp":
                    return "text/asp";
                case ".pdf":
                    return "application/pdf";
                case ".fdf":
                    return "application/vnd.fdf";
                case ".ppt":
                    return "application/mspowerpoint";
                case ".dwg":
                    return "image/vnd.dwg";
                case ".msg":
                    return "application/msoutlook";
                case ".xml":
                case ".sdxl":
                    return "application/xml";
                case ".xdp":
                    return "application/vnd.adobe.xdp+xml";
                default:
                    return "application/octet-stream";
            }
        }

        //protected void BtnUpload_Click(object sender, EventArgs e)
        //{
        //    string ExcelFilename = FileUpload1.PostedFile.FileName;
        //    string ExcelFileNameonly = ExcelFilename.Substring(ExcelFilename.LastIndexOf("\\") + 1);
        //    string FileExt = ExcelFilename.Substring(ExcelFilename.LastIndexOf(".") + 1);
        //    string Filenamewithoutextn = ExcelFileNameonly.Remove(ExcelFileNameonly.LastIndexOf("."));
        //    if (FileExt.ToLower() == "xls")
        //    {
        //        try
        //        {
        //            string strInputFilePath = Server.MapPath("ProjectImage") + "\\";
        //            FileUpload1.PostedFile.SaveAs(strInputFilePath + Filenamewithoutextn + ".xls");
        //            string strConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strInputFilePath + Filenamewithoutextn + ".xls;Extended Properties=Excel 8.0;";

        //            OleDbConnection olecon = new OleDbConnection(strConnectionString);

        //            int RecordCount = 0;
        //            lblError.Visible = false;
        //            lblError.Visible = false;
        //            olecon.Open();
        //            OleDbCommand cmd = olecon.CreateCommand();
        //            cmd.CommandText = "SELECT * FROM [" + Filenamewithoutextn + "$]";
        //            DataSet ds = new DataSet();
        //            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        //            OleDbDataReader dr = cmd.ExecuteReader();
        //            sqlcon.Open();
        //            string deletestr = "delete from importdata";
        //            SqlCommand sqlcmd = new SqlCommand(deletestr, sqlcon);
        //            sqlcmd.ExecuteNonQuery();
        //            while (dr.Read())
        //            {
        //                SqlCommand cmd1 = sqlcon.CreateCommand();
        //                cmd1.CommandText = "INSERT INTO ImportData values ('" + dr[0] + "','" + dr[1] + "')";
        //                cmd1.ExecuteNonQuery();
        //                RecordCount++;
        //                lblError.Visible = true;
        //                lblError.Text = " Processed Record # " + RecordCount.ToString();
        //            }
        //            dr.Close();
        //            olecon.Close();
        //            BindGrid();
        //            sqlcon.Close();
        //        }
        //        catch
        //        {
        //            lblError.Visible = true;
        //            lblError.Text = "Upload is not valid";
        //        }
        //    }
        //}

        //private void BindGrid()
        //{
        //    try
        //    {
        //        lblError.Visible = false;
        //        SqlCommand cmd2 = sqlcon.CreateCommand();
        //        cmd2.CommandText = "SELECT * FROM ImportData";

        //        DataSet sds = new DataSet();

        //        SqlDataAdapter sda = new SqlDataAdapter(cmd2);

        //        sda.Fill(sds, "ImportData");
        //        RadGridImport.DataSource = sds.Tables["ImportData"].DefaultView;
        //        RadGridImport.DataBind();
        //    }
        //    catch
        //    {
        //        lblError.Visible = true;
        //        lblError.Text = "Unable to bind";
        //    }
        //}

       
        
    }
}
