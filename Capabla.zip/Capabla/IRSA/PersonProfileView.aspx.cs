﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class PersonProfileView : System.Web.UI.Page
    {

        int UserID, str;
        string CultureID;
        string PhotoDirectoryPath;
        string CULINFO;
        ViewAccountFA objaccFA = new ViewAccountFA();
        string MsgCandidateSearch = "TooltipMsgPersonProfileView.xml";
        public int MoreVisa
        {
            set
            {
                ViewState["MoreVisa"] = value;
            }
            get
            {
                if (ViewState["MoreVisa"] == null)
                {
                    ViewState["MoreVisa"] = 0;
                }
                return Convert.ToInt32(ViewState["MoreVisa"].ToString());
            }
        }
        public int MoreAsso
        {
            set
            {
                ViewState["MoreAsso"] = value;
            }
            get
            {
                if (ViewState["MoreAsso"] == null)
                {
                    ViewState["MoreAsso"] = 0;
                }
                return Convert.ToInt32(ViewState["MoreAsso"].ToString());
            }
        }
        public int MoreLicense
        {
            set
            {
                ViewState["MoreLicense"] = value;
            }
            get
            {
                if (ViewState["MoreLicense"] == null)
                {
                    ViewState["MoreLicense"] = 0;
                }
                return Convert.ToInt32(ViewState["MoreLicense"].ToString());
            }
        }
        public int MorePastCompany
        {
            set
            {
                ViewState["MorePastCompany"] = value;
            }
            get
            {
                if (ViewState["MorePastCompany"] == null)
                {
                    ViewState["MorePastCompany"] = 0;
                }
                return Convert.ToInt32(ViewState["MorePastCompany"].ToString());
            }
        }
        public int MoreAcademics
        {
            set
            {
                ViewState["MoreAcademics"] = value;
            }
            get
            {
                if (ViewState["MoreAcademics"] == null)
                {
                    ViewState["MoreAcademics"] = 0;
                }
                return Convert.ToInt32(ViewState["MoreAcademics"].ToString());
            }
        }
        public int MoreProjects
        {
            set
            {
                ViewState["MoreProjects"] = value;
            }
            get
            {
                if (ViewState["MoreProjects"] == null)
                {
                    ViewState["MoreProjects"] = 0;
                }
                return Convert.ToInt32(ViewState["MoreProjects"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            //MoreVisa = 0;
            PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];

            if (SessionInfo.RoleID == "RC" || SessionInfo.RoleID == "OR" || SessionInfo.RoleID == "IN")
            {
                UserID = SessionInfo.CandidateID;

            }
            else
            {
                UserID = SessionInfo.UserId;

            }

           // UserID = 67; //comment it after testing!!


            if (UserID != int.MinValue)
            {
                //AccountsetupFA objaccFA = new AccountsetupFA();
                //DataTable objdt = new DataTable();
                //objdt = objaccFA.GetaccountData(UserID);
               // Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            
            CultureID = "EN";
            if (!IsPostBack)
            {
                pnlDetailProfSummary.Visible = false;
            }
            getPageLanguageInfo();
            GettooltipMessage();
            Retrievedata();

            //RetrievefirstAcademicsdata();

            //RetrieveFirstprojdata();
            //RetrieveFirstpastcompanydata();
            AwardsNAcheievements();
            SecurityClearance();
            VisaInformation();
            Associations();
            LicenseNCertification();
            PastCompany();
            Academics();
            Projects();
            MoreProfSummary();
            displayPhoto();
            JobPreferences();



        }
        string roleind = "";
        string roleindus = "";
        string strLast = "";
        string strdes = "";
        string strcmycountry = "";
        string strworkinfrm = "";

        //To retrieve the tool tip messages
        private void GettooltipMessage()
        {
            try
            {
                imgPDF.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, MsgCandidateSearch);
                imgBtnClose.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, MsgCandidateSearch);

                imgBtnClose1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, MsgCandidateSearch);


            }
            catch { }
        }

        //to display the profile photo
        void displayPhoto()
        {
            try
            {
                string photoID = string.Empty;
                DataTable dtp = new DataTable();
                dtp = IRSA.IRSAResumeFA.getPhotoID(UserID, CultureID);
                int approved = Convert.ToInt32(dtp.Rows[0]["PhotoApproved"]);
                photoID = dtp.Rows[0]["PhotoID"].ToString().TrimEnd();
                //photoID = "";//////Do COMMENT IT AFTER TESTING!!!!
                if (photoID == null || photoID == "")
                {
                    string str = string.Empty;
                    string FileName2 = string.Empty;
                    Image1.ImageUrl = ConfigurationSettings.AppSettings["userpics"];
                }
                else
                {
                    string str = string.Empty;
                    string FileName2 = string.Empty;
                    FileName2 = ConfigurationSettings.AppSettings["userdetails"];
                    string file = FileName2 + photoID;
                    if (FileName2 != "")
                    {
                        if (approved == 1)
                        {
                            
                            Image1.Visible = true;
                            IRSAResumeFA settingsFA = new IRSAResumeFA();
                            Boolean hidePhoto;
                            Boolean hideExists = settingsFA.settingsExists(UserID, 11, CultureID); //11 is flag to identify the querry
                            if (hideExists == true)
                            {
                                hidePhoto = settingsFA.isPhotoHidden(UserID, CultureID);
                                if (hidePhoto == false)
                                {
                                    Image1.ImageUrl = ConfigurationSettings.AppSettings["userpics"];

                                }
                                else
                                {
                                    Image1.ImageUrl = file;
                                }
                            }
                            else
                            {
                                Image1.ImageUrl = file;
                            }
                           
                        }
                        else
                        {
                            Image1.Visible = true;
                            Image1.ImageUrl = ConfigurationSettings.AppSettings["userpics"];
                        }

                    }
                    else
                    {
                        Image1.Visible = true;
                        Image1.ImageUrl = ConfigurationSettings.AppSettings["userpics"];

                    }
                }
            }
            catch { }
        }
        
        public void Retrievedata()
        {
            try
            {

                ViewAccountFA objaccFA = new ViewAccountFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetViewAccountData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    lblname.Visible = true;
                
                   
                    
                   
                    Lblexp.Visible = true;
                    string strprecmy;
                    string strfirstname = string.Empty;
                    string strlastname = string.Empty;
                    IRSAResumeFA settingsFA = new IRSAResumeFA();
                    Boolean hideName;
                    Boolean hideExists = settingsFA.settingsExists(UserID, 9, CultureID); //to identify the querry
                    if (hideExists == true)
                    {
                        hideName = settingsFA.isNameHidden(UserID, CultureID);
                        if (hideName == false)
                        {
                            strfirstname = "Anonymous";
                            strlastname = string.Empty;
                        }
                        else
                        {
                            strfirstname = objdt.Rows[0]["FirstName"].ToString();
                            strlastname = objdt.Rows[0]["LastName"].ToString();
                        }
                    }
                    else
                    {
                        strfirstname = objdt.Rows[0]["FirstName"].ToString();
                        strlastname = objdt.Rows[0]["LastName"].ToString();
                    }
                    lblname.Text = strfirstname + strlastname;
                    if (objdt.Rows[0]["ProfessionalTitle"].ToString() != "")
                    {
                        Lblprotitle.Visible = true;
                        Lblprotitle.Text = objdt.Rows[0]["ProfessionalTitle"].ToString();
                    }
                    
                    //Lbldesignation.Text=objdt.Rows[0][""]
                    string strcity = objdt.Rows[0]["City"].ToString();
                    string strcountry = objdt.Rows[0]["Expr4"].ToString();
                    if (strcity!="")
                    {
                        lblloc.Visible = true;
                    lblloc.Text = strcity + "," + strcountry;
                    }
                    else if (strcity == "")
                    {
                        lblloc.Visible = true;
                        lblloc.Text = strcountry;
                    }
                    else
                    {
                        lblloc.Visible = false;
                    }
                    if (objdt.Rows[0]["IndustryID"].ToString() != "")
                    {
                        roleindus = objdt.Rows[0]["IndustryName"].ToString();
                    }
                    if (objdt.Rows[0]["OthersIndustry"].ToString() != "")
                    {
                        lblroleind.Visible = true;
                        lblroleind.Text = objdt.Rows[0]["OthersIndustry"].ToString();
                    }
                    //if(objdt.Rows[0]["ProfessionalExperinceandGoals"].ToString()!="")
                    //{
                    //    Lblsummery.Visible = true;
                    //    Lblsummery.Text = objdt.Rows[0]["ProfessionalExperinceandGoals"].ToString();
                    //}
                    //Lblsummery.Text = objdt.Rows[0]["ProfessionalExperinceandGoals"].ToString();
                    
                    if (roleindus != "")
                    {
                        roleind = roleindus;
                    }
                    string skills = objdt.Rows[0]["KeySkills"].ToString();
                    string exp = objdt.Rows[0]["TotalExperience"].ToString();
                    if (exp != "")
                    {
                        strLast = exp;
                        //int lastIndex = exp.LastIndexOf("-");
                        //strLast = exp.Substring(0, lastIndex);
                    }
                    if(objdt.Columns.Count >23)
                    {
                     strdes=objdt.Rows[0]["Designation"].ToString();
                    
                     strprecmy = objdt.Rows[0]["Company"].ToString();
                    
                   
                      strcmycountry=objdt.Rows[0]["Expr1"].ToString();
                      strworkinfrm=objdt.Rows[0]["WorkingFrom"].ToString();
                      LblPrecmy.Visible = true;
                      LblPrecmy.Text = strdes + ' ' + "At" + ' ' + strprecmy + "," + ' ' + strcmycountry + " " + "Since" + ' ' + strworkinfrm;

                    }
                     if (roleindus != "")
                     {
                         Lblexp.Text = "More Than" + ' ' + strLast + "Years Experience in" + ' ' + roleind + ' ' + "having experience & knowledge in" + ' ' + skills;
                     }
                     else
                     {
                         Lblexp.Text = "More Than" + ' ' + strLast + "Years Experience " +  "and "  + "having experience & knowledge in" + ' ' + skills;

                     }
                     //string file = objdt.Rows[0]["PhotoID"].ToString();
                     //if (file != "")
                     //{

                     //    Image1.Visible = true;
                     //    Image1.ImageUrl = "~/UserData/UserPhotos/" + file;

                     //}
                     //else
                     //{
                     //    Image1.Visible = true;
                     //    Image1.ImageUrl = "~/UserData/UserPhotos/" + "0.png";
                     //    //Image1.ImageUrl = PhotoDirectoryPath + "DefaultImage.Png";
                     //}


                }
            }
            catch { }
        }

        protected string getDisplayName()
        {
            string name = string.Empty;
            name = IRSAResumeFA.getDisplayName(UserID, CultureID);
            return name;

        }
     
        protected void BtnMoreAcad_Click(object sender, EventArgs e)
        {
            try
            {
                string str = string.Empty;
                DataTable DTd = new DataTable();
                IRSA.IRSAResumeFA acaFA = new IRSA.IRSAResumeFA();
                Boolean exists = acaFA.isAcademicsExists(UserID, 0, CultureID);
                if (exists == true)
                {

                    int count = 0;
                    DataTable tempDT = new DataTable();
                    tempDT.Columns.Add("AcadmicDetails");
                    DTd = acaFA.getAca(UserID, 1, CultureID); // flag 1 specifies that Details of university degree are extracted.
                    if (MoreAcademics == 0)
                    {
                        for (int i = 0; i < DTd.Rows.Count; i++)
                        {
                            if (DTd.Rows[i]["HighestDegree"].ToString() != null && (DTd.Rows[i]["HighestDegree"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((DTd.Rows[i]["HighestDegree"]).ToString()).TrimEnd();
                                if ((DTd.Rows[i]["University"]).ToString() != null && (DTd.Rows[i]["University"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " from " + ((DTd.Rows[i]["University"]).ToString()).TrimEnd();
                                }
                                if ((DTd.Rows[i]["PassingYear"]).ToString() != null && (DTd.Rows[i]["PassingYear"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " in " + ((DTd.Rows[i]["PassingYear"]).ToString()).TrimEnd();
                                }

                            }
                            DataRow dr2 = tempDT.NewRow();
                            dr2["AcadmicDetails"] = str;
                            tempDT.Rows.Add(dr2);
                            tempDT.AcceptChanges();
                            str = string.Empty;
                        }
                    }
                    else if (MoreAcademics == 1)
                    {
                        if (DTd.Rows.Count >= 2)
                        {
                            count = 2;
                        }
                        else
                        {
                            count = DTd.Rows.Count;
                        }
                        for (int i = 0; i < count; i++)
                        {
                            if (DTd.Rows[i]["HighestDegree"].ToString() != null && (DTd.Rows[i]["HighestDegree"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((DTd.Rows[i]["HighestDegree"]).ToString()).TrimEnd();
                                if ((DTd.Rows[i]["University"]).ToString() != null && (DTd.Rows[i]["University"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " from " + ((DTd.Rows[i]["University"]).ToString()).TrimEnd();
                                }
                                if ((DTd.Rows[i]["PassingYear"]).ToString() != null && (DTd.Rows[i]["PassingYear"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " in " + ((DTd.Rows[i]["PassingYear"]).ToString()).TrimEnd();
                                }

                            }
                            DataRow dr2 = tempDT.NewRow();
                            dr2["AcadmicDetails"] = str;
                            tempDT.Rows.Add(dr2);
                            tempDT.AcceptChanges();
                            str = string.Empty;
                        }
                    }

                    lblAcademicsErr.Visible = false;
                    RadGridAcademics.DataSource = tempDT;
                    RadGridAcademics.DataBind();
                    RadGridAcademics.Visible = true;


                }
                else
                {
                    lblAcademicsErr.Visible = true;
                    RadGridAcademics.Visible = false;

                }
                if (MoreAcademics == 0)
                {
                    MoreAcademics = 1;
                    BtnMoreAcad.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(51);
                }
                else
                {
                    MoreAcademics = 0;
                    BtnMoreAcad.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(52);
                }
            }
            catch { }
        }

        protected void Academics()
        {
            string str = string.Empty;
            DataTable DTd = new DataTable();
            IRSA.IRSAResumeFA acaFA = new IRSA.IRSAResumeFA();
            Boolean exists = acaFA.isAcademicsExists(UserID, 0, CultureID);
            try
            {
                if (exists == true)
                {
                    int count = 0;
                    DataTable tempDT = new DataTable();
                    tempDT.Columns.Add("AcadmicDetails");
                    DTd = acaFA.getAca(UserID, 1, CultureID); // flag 1 specifies that Details of university degree are extracted.
                    if (DTd.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = DTd.Rows.Count;
                    }
                    for (int i = 0; i < count; i++)
                    {
                        if (DTd.Rows[i]["HighestDegree"].ToString() != null && (DTd.Rows[i]["HighestDegree"]).ToString().TrimEnd() != "")
                        {
                            str = str + ((DTd.Rows[i]["HighestDegree"]).ToString()).TrimEnd();
                            if ((DTd.Rows[i]["University"]).ToString() != null && (DTd.Rows[i]["University"]).ToString().TrimEnd() != "")
                            {
                                str = str + " from " + ((DTd.Rows[i]["University"]).ToString()).TrimEnd();
                            }
                            if ((DTd.Rows[i]["PassingYear"]).ToString() != null && (DTd.Rows[i]["PassingYear"]).ToString().TrimEnd() != "")
                            {
                                str = str + " in " + ((DTd.Rows[i]["PassingYear"]).ToString()).TrimEnd();
                            }

                        }
                        DataRow dr2 = tempDT.NewRow();
                        dr2["AcadmicDetails"] = str;
                        tempDT.Rows.Add(dr2);
                        tempDT.AcceptChanges();
                        str = string.Empty;
                    }

                    lblAcademicsErr.Visible = false;
                    RadGridAcademics.DataSource = tempDT;
                    RadGridAcademics.DataBind();
                    RadGridAcademics.Visible = true;


                }
                else
                {
                    BtnMoreAcad.Visible = false;
                    lblAcademicsErr.Visible = true;
                    RadGridAcademics.Visible = false;
                }
            }
            catch { }
        }

        public void RetrieveFirstprojdata()
        {
            try
            {
                string Addmore = "";
                ViewAccountFA objaccFA = new ViewAccountFA();
                DataTable objprojdt = new DataTable();
                objprojdt = objaccFA.GetprojectsData(UserID, Addmore);
                if (objprojdt.Rows.Count > 0)
                {
                    RadGridProjects.DataSource = objprojdt;
                    RadGridProjects.DataBind();
                    
                   
                }

            }
            catch { }
        }

        //to retrieve the Awards and achievements details
        protected void AwardsNAcheievements()
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 9;
            try
            {
                ContactDT = ContactFA.getAwardsAndAchievements(UserID, flag, CultureID);
            }
            catch { }
            if (ContactDT.Rows[0]["AwardsandAchievements"].ToString() != null && ContactDT.Rows[0]["AwardsandAchievements"].ToString().TrimEnd() != "")
            {
                lblAwards.Text = ContactDT.Rows[0]["AwardsandAchievements"].ToString();
                lblAwards.Visible = true;
                lblAwardsErr.Visible = false;
            }
            else
            {
                //lblAwards.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                //lblAwards.Visible = true;
                lblAwards.Visible = false;
                lblAwardsErr.Visible = true;
            }
        }

        //to retrieve the security clearance details
        protected void SecurityClearance()
        {
            IRSAResumeFA secInfoFA = new IRSAResumeFA();
            Boolean exists = secInfoFA.isSecurityExists(UserID, 6, CultureID);
            DataTable DTadd = new DataTable();
            string str = string.Empty;
            try
            {
                if (exists == true)
                {
                    //pnlAddInfo.Visible = true;
                    lblSecurityErr.Visible = false;
                    //lblSecurity.Visible = true;
                    DTadd = secInfoFA.getSecurityClearanceData(UserID, 8, CultureID);//8 is the flag used to identify querry in stored procedure
                    int count = 0;
                    if (DTadd.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = DTadd.Rows.Count;
                    }

                    for (int i = 0; i < count; i++)
                    {
                        if ((DTadd.Rows[i]["SCName"]).ToString() != null && (DTadd.Rows[i]["SCName"]).ToString().TrimEnd() != "")
                        {

                            str = str + ((DTadd.Rows[i]["SCName"]).ToString()).TrimEnd();
                            if ((DTadd.Rows[i]["SCIssuingAuthority"]).ToString() != null && (DTadd.Rows[i]["SCIssuingAuthority"]).ToString().TrimEnd() != "")
                            {
                                str = str + ", " + ((DTadd.Rows[i]["SCIssuingAuthority"]).ToString()).TrimEnd();
                            }
                            if ((DTadd.Rows[i]["SCVaildFrom"]).ToString() != null && (DTadd.Rows[i]["SCVaildFrom"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["SCVaildTo"]).ToString() != null && (DTadd.Rows[i]["SCVaildTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + System.Environment.NewLine + ((DTadd.Rows[i]["SCVaildFrom"]).ToString()).TrimEnd() + " - " + ((DTadd.Rows[i]["SCVaildTo"]).ToString()).TrimEnd();
                            }
                            str = str + System.Environment.NewLine;
                        }
                    }
                    lblSecurity.Text = str;
                    lblSecurity.Visible = true;
                }
                else
                {
                    //lblSecurity.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                    //lblSecurity.Visible = true;
                    lblSecurity.Visible = false;
                    lblSecurityErr.Visible = true;
                }
            }
            catch { }
        }

        //to retrieve the Visa Information details
        protected void VisaInformation()
        {
            IRSAResumeFA addInfoFA = new IRSAResumeFA();
            string str = string.Empty;
            Boolean exists = addInfoFA.isVisaExists(UserID, 4, CultureID);
            
            if (exists == true)
            {
                try
                {
                    lblVisaInfoErr.Visible = false;
                    RadGridVisaInfo.Visible = true;
                    DataTable DTadd = addInfoFA.getVisaDetails(UserID, 7, CultureID);//7 is the flag used to identify querry in stored procedure
                    DataTable tempDT = new DataTable();
                    tempDT.Columns.Add("Visa");
                    int count = 0;
                    if (DTadd.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = DTadd.Rows.Count;
                    }

                    for (int i = 0; i < count; i++)
                    {
                        if ((DTadd.Rows[i]["Country"]).ToString() != null && (DTadd.Rows[i]["Country"]).ToString().TrimEnd() != "")
                        {

                            str = str + ((DTadd.Rows[i]["Country"]).ToString()).TrimEnd();
                            if ((DTadd.Rows[i]["ValidFrom"]).ToString() != null && (DTadd.Rows[i]["ValidFrom"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["ValidTo"]).ToString() != null && (DTadd.Rows[i]["ValidTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + " , valid from " + ((DTadd.Rows[i]["ValidFrom"]).ToString()).TrimEnd() + " to " + ((DTadd.Rows[i]["ValidTo"]).ToString()).TrimEnd();
                                DataRow dr2 = tempDT.NewRow();
                                dr2["Visa"] = str;
                                tempDT.Rows.Add(dr2);
                                tempDT.AcceptChanges();
                                str = string.Empty;
                            }

                        }
                    }

                    RadGridVisaInfo.DataSource = tempDT;
                    RadGridVisaInfo.DataBind();
                }
                catch { }
                

            }
            else
            {
                RadGridVisaInfo.Visible = false;
                lblVisaInfoErr.Visible = true;
                lnkBtnMoreVisa.Visible = false;

            }
        }

        //to retrieve the Associations information
        protected void Associations()
        {
            IRSAResumeFA addInfoFA = new IRSAResumeFA();
            Boolean exists = addInfoFA.isAssociationExists(UserID, 5, CultureID);
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("Associations");
            if (exists == true)
            {
                try
                {

                    DataTable DTadd = addInfoFA.getAssociationDetails(UserID, 6, CultureID);//6 is the flag used to identify querry in stored procedure
                    int count = 0;
                    if (DTadd.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = DTadd.Rows.Count;
                    }
                    for (int i = 0; i < count; i++)
                    {
                        str = "Associated with ";
                        if ((DTadd.Rows[i]["AName"]).ToString() != null && (DTadd.Rows[i]["AName"]).ToString().TrimEnd() != "")
                        {
                            str = str + ((DTadd.Rows[i]["AName"]).ToString()).TrimEnd();
                            if ((DTadd.Rows[i]["ASinceDate"]).ToString() != null && (DTadd.Rows[i]["ASinceDate"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["AUntilDate"]).ToString() != null && (DTadd.Rows[i]["AUntilDate"]).ToString().TrimEnd() != "")
                            {
                                str = str + " , " + ((DTadd.Rows[i]["ASinceDate"]).ToString()).TrimEnd() + " - " + ((DTadd.Rows[i]["AUntilDate"]).ToString()).TrimEnd();
                                DataRow dr2 = tempDT.NewRow();
                                dr2["Associations"] = str;
                                tempDT.Rows.Add(dr2);
                                tempDT.AcceptChanges();

                            }
                            //str = str + System.Environment.NewLine;
                        }
                        str = string.Empty;
                    }

                    RadGridAsso.Visible = true;
                    RadGridAsso.DataSource = tempDT;
                    RadGridAsso.DataBind();
                    lblAssoErr.Visible = false;
                }
                catch { }
               

            }
            else
            {
                lnkBtnMoreAsso.Visible = false;
                RadGridAsso.Visible = false;
                lblAssoErr.Visible = true;
            }

        }

        //to display the visa related details
        protected void LicenseNCertification()
        {
            IRSA.IRSAResumeFA certiFA = new IRSA.IRSAResumeFA();
            Boolean exists = certiFA.isCertiExists(UserID, 2,CultureID);
            DataTable DTc=new DataTable();
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("License");
            if (exists == true)
            {
                try
                {
                    lblLicenseErr.Visible = false;
                    DTc = certiFA.getLicenseDetails(UserID, 5, CultureID);//5 is the flag bit to be used in the stored procedure
                    //pnlCertification.Visible = true;
                    int count = 0;
                    if (DTc.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = DTc.Rows.Count;
                    }

                    for (int i = 0; i < count; i++)
                    {
                        if ((DTc.Rows[i]["LCName"]).ToString() != null && (DTc.Rows[i]["LCName"]).ToString().TrimEnd() != "")
                        {

                            str = str + ((DTc.Rows[i]["LCName"]).ToString()).TrimEnd();
                            if ((DTc.Rows[i]["LCIssuedBy"]).ToString() != null && (DTc.Rows[i]["LCIssuedBy"]).ToString().TrimEnd() != "")
                            {
                                str = str + " , " + ((DTc.Rows[i]["LCIssuedBy"]).ToString()).TrimEnd();
                                DataRow dr2 = tempDT.NewRow();
                                dr2["License"] = str;
                                tempDT.Rows.Add(dr2);
                                tempDT.AcceptChanges();
                            }
                            //str = str + System.Environment.NewLine;
                        }
                        str = string.Empty;
                    }
                    RadGridLicense.DataSource = tempDT;
                    RadGridLicense.DataBind();
                    RadGridLicense.Visible = true;

                }
                catch { }

            }
            else
            {
                lnkBtnMoreLicense.Visible = false;
                lblLicenseErr.Visible = true;
                RadGridLicense.Visible = false;
            }
        }

        protected void PastCompany()
        {
            IRSAResumeFA pastFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("PstCmyDetails");
            if (pastFA.isPastCompExists(UserID, 8, CultureID) == true)
            {
                try
                {
                    lblPastCompanyErr.Visible = false;
                    int flag = 3;
                    DataTable pastDT = new DataTable();
                    pastDT = pastFA.getPastCompanyDetails(UserID, flag, CultureID);
                    int count = 0;
                    if (pastDT.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = pastDT.Rows.Count;
                    }
                    for (int i = 0; i < count; i++)
                    {
                        if ((pastDT.Rows[i]["Designation"]).ToString() != null && (pastDT.Rows[i]["Designation"]).ToString().TrimEnd() != "")
                        {
                            str = str + ((pastDT.Rows[i]["Designation"]).ToString()).TrimEnd() + " - ";
                        }
                        if ((pastDT.Rows[i]["Company"]).ToString() != null && (pastDT.Rows[i]["Company"]).ToString().TrimEnd() != "")
                        {
                            str = str + ((pastDT.Rows[i]["Company"]).ToString()).TrimEnd();
                        }
                        if ((pastDT.Rows[i]["Country"]).ToString() != null && (pastDT.Rows[i]["Country"]).ToString().TrimEnd() != "")
                        {
                            str = str + ", " + ((pastDT.Rows[i]["Country"]).ToString()).TrimEnd();
                        }
                        if ((pastDT.Rows[i]["WorkingFrom"]).ToString() != null && (pastDT.Rows[i]["WorkingFrom"]).ToString().TrimEnd() != "" && (pastDT.Rows[i]["WorkingTo"]).ToString() != null && (pastDT.Rows[i]["WorkingTo"]).ToString().TrimEnd() != "")
                        {
                            str = str + " , from " + ((pastDT.Rows[i]["WorkingFrom"]).ToString()).TrimEnd() + " to " + ((pastDT.Rows[i]["WorkingTo"]).ToString()).TrimEnd();
                        }
                        DataRow dr2 = tempDT.NewRow();
                        dr2["PstCmyDetails"] = str;
                        tempDT.Rows.Add(dr2);
                        tempDT.AcceptChanges();


                        //str = str + System.Environment.NewLine;

                        str = string.Empty;

                    }

                    RadGridpstcmy.DataSource = tempDT;
                    RadGridpstcmy.DataBind();
                    RadGridpstcmy.Visible = true;
                }
                catch { }



            }
            else
            {
                Linkmorepstcmy.Visible = false;
                lblPastCompanyErr.Visible = true;
                //lblPastCompanyErr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                RadGridpstcmy.Visible = false;
            }
        }

        protected void Linkmorepstcmy_Click(object sender, EventArgs e)
        {
            try
            {
                IRSAResumeFA pastFA = new IRSAResumeFA();
                DataTable ContactDT = new DataTable();
                string str = string.Empty;
                DataTable tempDT = new DataTable();
                tempDT.Columns.Add("PstCmyDetails");
                if (pastFA.isPastCompExists(UserID, 8, CultureID) == true)
                {

                    lblPastCompanyErr.Visible = false;
                    int flag = 3;
                    DataTable pastDT = new DataTable();
                    pastDT = pastFA.getPastCompanyDetails(UserID, flag, CultureID);
                    if (MorePastCompany == 0)
                    {
                        for (int i = 0; i < pastDT.Rows.Count; i++)
                        {
                            if ((pastDT.Rows[i]["Designation"]).ToString() != null && (pastDT.Rows[i]["Designation"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((pastDT.Rows[i]["Designation"]).ToString()).TrimEnd() + " - ";
                            }
                            if ((pastDT.Rows[i]["Company"]).ToString() != null && (pastDT.Rows[i]["Company"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((pastDT.Rows[i]["Company"]).ToString()).TrimEnd();
                            }
                            if ((pastDT.Rows[i]["Country"]).ToString() != null && (pastDT.Rows[i]["Country"]).ToString().TrimEnd() != "")
                            {
                                str = str + ", " + ((pastDT.Rows[i]["Country"]).ToString()).TrimEnd();
                            }
                            if ((pastDT.Rows[i]["WorkingFrom"]).ToString() != null && (pastDT.Rows[i]["WorkingFrom"]).ToString().TrimEnd() != "" && (pastDT.Rows[i]["WorkingTo"]).ToString() != null && (pastDT.Rows[i]["WorkingTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + " , from " + ((pastDT.Rows[i]["WorkingFrom"]).ToString()).TrimEnd() + " to " + ((pastDT.Rows[i]["WorkingTo"]).ToString()).TrimEnd();
                                DataRow dr2 = tempDT.NewRow();
                                dr2["PstCmyDetails"] = str;
                                tempDT.Rows.Add(dr2);
                                tempDT.AcceptChanges();

                            }
                            //str = str + System.Environment.NewLine;

                            str = string.Empty;

                        }
                    }
                    else if (MorePastCompany == 1)
                    {
                        int count = 0;
                        if (pastDT.Rows.Count >= 2)
                        {
                            count = 2;
                        }
                        else
                        {
                            count = pastDT.Rows.Count;
                        }
                        for (int i = 0; i < count; i++)
                        {
                            if ((pastDT.Rows[i]["Designation"]).ToString() != null && (pastDT.Rows[i]["Designation"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((pastDT.Rows[i]["Designation"]).ToString()).TrimEnd() + " - ";
                            }
                            if ((pastDT.Rows[i]["Company"]).ToString() != null && (pastDT.Rows[i]["Company"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((pastDT.Rows[i]["Company"]).ToString()).TrimEnd();
                            }
                            if ((pastDT.Rows[i]["Country"]).ToString() != null && (pastDT.Rows[i]["Country"]).ToString().TrimEnd() != "")
                            {
                                str = str + ", " + ((pastDT.Rows[i]["Country"]).ToString()).TrimEnd();
                            }
                            if ((pastDT.Rows[i]["WorkingFrom"]).ToString() != null && (pastDT.Rows[i]["WorkingFrom"]).ToString().TrimEnd() != "" && (pastDT.Rows[i]["WorkingTo"]).ToString() != null && (pastDT.Rows[i]["WorkingTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + " , from " + ((pastDT.Rows[i]["WorkingFrom"]).ToString()).TrimEnd() + " to " + ((pastDT.Rows[i]["WorkingTo"]).ToString()).TrimEnd();
                                DataRow dr2 = tempDT.NewRow();
                                dr2["PstCmyDetails"] = str;
                                tempDT.Rows.Add(dr2);
                                tempDT.AcceptChanges();

                            }
                            //str = str + System.Environment.NewLine;

                            str = string.Empty;

                        }

                    }

                    RadGridpstcmy.DataSource = tempDT;
                    RadGridpstcmy.DataBind();
                    RadGridpstcmy.Visible = true;


                }
                else
                {
                    lblPastCompanyErr.Visible = true;
                    //lblPastCompanyErr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                    RadGridpstcmy.Visible = false;
            
                }
                if (MorePastCompany == 0)
                {
                    MorePastCompany = 1;
                    Linkmorepstcmy.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(51);
                }
                else
                {
                    MorePastCompany = 0;
                    Linkmorepstcmy.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(52);
                }
            }
            catch { }
        }

        //to retrieve the projects data
        protected void Projects()
        {
            IRSAResumeFA projFA = new IRSAResumeFA();
            DataTable projDT = new DataTable();
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("ProjectDetails");
            Boolean exists = projFA.isProjectExists(UserID,1,CultureID);
            if (exists == true)
            {
                try
                {
                    int count = 0;
                    projDT = projFA.getProjetcts(UserID, CultureID);
                    if (projDT.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = projDT.Rows.Count;
                    }

                    for (int i = 0; i < count; i++)
                    {

                        if (projDT.Rows[i]["ProjectName"].ToString() != null && (projDT.Rows[i]["ProjectName"]).ToString().TrimEnd() != "")
                        {
                            str = str + (projDT.Rows[i]["ProjectName"]).ToString().TrimEnd() + System.Environment.NewLine;
                            if (projDT.Rows[i]["ClientName"].ToString()!= null && (projDT.Rows[i]["ClientName"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["ClientName"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }

                            if (projDT.Rows[i]["Description"].ToString() != null && (projDT.Rows[i]["Description"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["Description"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }
                            if (projDT.Rows[i]["Skills"].ToString() != null && (projDT.Rows[i]["Skills"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["Skills"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }
                            if ((projDT.Rows[i]["DurationFrom"]).ToString() != null && (projDT.Rows[i]["DurationFrom"]).ToString().TrimEnd() != "" && (projDT.Rows[i]["DurationTo"]).ToString() != null && (projDT.Rows[i]["DurationTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["DurationFrom"]).ToString().TrimEnd() + " - " + (projDT.Rows[i]["DurationTo"]).ToString().TrimEnd();
                            }

                        }
                        DataRow dr2 = tempDT.NewRow();
                        dr2["ProjectDetails"] = str;
                        tempDT.Rows.Add(dr2);
                        tempDT.AcceptChanges();
                        str = string.Empty;

                    }
                    RadGridProjects.DataSource = tempDT;
                    RadGridProjects.DataBind();
                    RadGridProjects.Visible = true;
                    lblProjectsErr.Visible = false;


                }
                catch { }
                }
                else
                {
                    LinkBtnMoreProj.Visible = false;
                    RadGridProjects.Visible = false;
                    lblProjectsErr.Visible = true;
                }
                
        }

        

        protected void LinkBtnMoreProj_Click(object sender, EventArgs e)
        {
            try
            {
            IRSAResumeFA projFA = new IRSAResumeFA();
            DataTable projDT = new DataTable();
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("ProjectDetails");
            Boolean exists = projFA.isProjectExists(UserID,1,CultureID);
            if (exists == true)
            {
                projDT = projFA.getProjetcts(UserID, CultureID);
                if (MoreProjects == 0)
                {
                    for (int i = 0; i < projDT.Rows.Count; i++)
                    {

                        if (projDT.Rows[i]["ProjectName"].ToString() != null && (projDT.Rows[i]["ProjectName"]).ToString().TrimEnd() != "")
                        {
                            str = str + (projDT.Rows[i]["ProjectName"]).ToString().TrimEnd() + System.Environment.NewLine;
                            if (projDT.Rows[i]["ClientName"].ToString() != null && (projDT.Rows[i]["ClientName"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["ClientName"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }

                            if (projDT.Rows[i]["Description"].ToString() != null && (projDT.Rows[i]["Description"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["Description"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }
                            if (projDT.Rows[i]["Skills"].ToString() != null && (projDT.Rows[i]["Skills"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["Skills"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }
                            if ((projDT.Rows[i]["DurationFrom"]).ToString() != null && (projDT.Rows[i]["DurationFrom"]).ToString().TrimEnd() != "" && (projDT.Rows[i]["DurationTo"]).ToString() != null && (projDT.Rows[i]["DurationTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["DurationFrom"]).ToString().TrimEnd() + " - " + (projDT.Rows[i]["DurationTo"]).ToString().TrimEnd();
                            }

                        }
                        DataRow dr2 = tempDT.NewRow();
                        dr2["ProjectDetails"] = str;
                        tempDT.Rows.Add(dr2);
                        tempDT.AcceptChanges();
                        str = string.Empty;

                    }

                }
                else if (MoreProjects == 1)
                {
                    int count = 0;
                    if (projDT.Rows.Count >= 2)
                    {
                        count = 2;
                    }
                    else
                    {
                        count = projDT.Rows.Count;
                    }
                    for (int i = 0; i < count; i++)
                    {

                        if (projDT.Rows[i]["ProjectName"].ToString() != null && (projDT.Rows[i]["ProjectName"]).ToString().TrimEnd() != "")
                        {
                            str = str + (projDT.Rows[i]["ProjectName"]).ToString().TrimEnd() + System.Environment.NewLine;
                            if (projDT.Rows[i]["ClientName"].ToString() != null && (projDT.Rows[i]["ClientName"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["ClientName"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }

                            if (projDT.Rows[i]["Description"].ToString() != null && (projDT.Rows[i]["Description"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["Description"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }
                            if (projDT.Rows[i]["Skills"].ToString() != null && (projDT.Rows[i]["Skills"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["Skills"]).ToString().TrimEnd() + System.Environment.NewLine;
                            }
                            if ((projDT.Rows[i]["DurationFrom"]).ToString() != null && (projDT.Rows[i]["DurationFrom"]).ToString().TrimEnd() != "" && (projDT.Rows[i]["DurationTo"]).ToString() != null && (projDT.Rows[i]["DurationTo"]).ToString().TrimEnd() != "")
                            {
                                str = str + (projDT.Rows[i]["DurationFrom"]).ToString().TrimEnd() + " - " + (projDT.Rows[i]["DurationTo"]).ToString().TrimEnd();
                            }

                        }
                        DataRow dr2 = tempDT.NewRow();
                        dr2["ProjectDetails"] = str;
                        tempDT.Rows.Add(dr2);
                        tempDT.AcceptChanges();
                        str = string.Empty;

                    }

                }
                RadGridProjects.DataSource = tempDT;
                RadGridProjects.DataBind();
                RadGridProjects.Visible = true;
                lblProjectsErr.Visible = false;

            }
            else
            {
                RadGridProjects.Visible = false;
                lblProjectsErr.Visible = true;
            }
            if (MoreProjects == 0)
            {
                MoreProjects = 1;
                LinkBtnMoreProj.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(51);
            }
            else
            {
                MoreProjects = 0;
                LinkBtnMoreProj.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(52);
            }
            }
            catch { }
        }

        protected void imgPDF_Click(object sender, ImageClickEventArgs e)
        {
            openPdf();
        }
        void openPdf()
        {
            try
            {
                SessionInfo.CandidateID = UserID;
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void lnkBtnMoreVisa_Click(object sender, EventArgs e)
        {
            
            IRSAResumeFA addInfoFA = new IRSAResumeFA();
            string str = string.Empty;
            Boolean exists = addInfoFA.isVisaExists(UserID, 4, CultureID);
            if (exists == true)
            {
                try
                {
                    lblVisaInfoErr.Visible = false;
                    RadGridVisaInfo.Visible = true;
                    DataTable DTadd = addInfoFA.getVisaDetails(UserID, 7, CultureID);//7 is the flag used to identify querry in stored procedure
                    DataTable tempDT = new DataTable();
                    tempDT.Columns.Add("Visa");
                    if (MoreVisa == 0)
                    {
                        for (int i = 0; i < DTadd.Rows.Count; i++)
                        {
                            if ((DTadd.Rows[i]["Country"]).ToString() != null && (DTadd.Rows[i]["Country"]).ToString().TrimEnd() != "")
                            {

                                str = str + ((DTadd.Rows[i]["Country"]).ToString()).TrimEnd();
                                if ((DTadd.Rows[i]["ValidFrom"]).ToString() != null && (DTadd.Rows[i]["ValidFrom"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["ValidTo"]).ToString() != null && (DTadd.Rows[i]["ValidTo"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " , valid from " + ((DTadd.Rows[i]["ValidFrom"]).ToString()).TrimEnd() + " to " + ((DTadd.Rows[i]["ValidTo"]).ToString()).TrimEnd();
                                    DataRow dr2 = tempDT.NewRow();
                                    dr2["Visa"] = str;
                                    tempDT.Rows.Add(dr2);
                                    tempDT.AcceptChanges();
                                    str = string.Empty;
                                }

                            }
                        }
                    }
                    else if (MoreVisa == 1)
                    {
                        int count = 0;
                        if (DTadd.Rows.Count >= 2)
                        {
                            count = 2;
                            for (int i = 0; i < count; i++)
                            {
                                if ((DTadd.Rows[i]["Country"]).ToString() != null && (DTadd.Rows[i]["Country"]).ToString().TrimEnd() != "")
                                {

                                    str = str + ((DTadd.Rows[i]["Country"]).ToString()).TrimEnd();
                                    if ((DTadd.Rows[i]["ValidFrom"]).ToString() != null && (DTadd.Rows[i]["ValidFrom"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["ValidTo"]).ToString() != null && (DTadd.Rows[i]["ValidTo"]).ToString().TrimEnd() != "")
                                    {
                                        str = str + " , valid from " + ((DTadd.Rows[i]["ValidFrom"]).ToString()).TrimEnd() + " to " + ((DTadd.Rows[i]["ValidTo"]).ToString()).TrimEnd();
                                        DataRow dr2 = tempDT.NewRow();
                                        dr2["Visa"] = str;
                                        tempDT.Rows.Add(dr2);
                                        tempDT.AcceptChanges();
                                        str = string.Empty;
                                    }

                                }
                            }
                        }
                        else
                        {
                            count = DTadd.Rows.Count;
                            for (int i = 0; i < count; i++)
                            {
                                if ((DTadd.Rows[i]["Country"]).ToString() != null && (DTadd.Rows[i]["Country"]).ToString().TrimEnd() != "")
                                {

                                    str = str + ((DTadd.Rows[i]["Country"]).ToString()).TrimEnd();
                                    if ((DTadd.Rows[i]["ValidFrom"]).ToString() != null && (DTadd.Rows[i]["ValidFrom"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["ValidTo"]).ToString() != null && (DTadd.Rows[i]["ValidTo"]).ToString().TrimEnd() != "")
                                    {
                                        str = str + " , valid from " + ((DTadd.Rows[i]["ValidFrom"]).ToString()).TrimEnd() + " to " + ((DTadd.Rows[i]["ValidTo"]).ToString()).TrimEnd();
                                        DataRow dr2 = tempDT.NewRow();
                                        dr2["Visa"] = str;
                                        tempDT.Rows.Add(dr2);
                                        tempDT.AcceptChanges();
                                        str = string.Empty;
                                    }

                                }
                            }
                        }

                    }

                    RadGridVisaInfo.DataSource = tempDT;
                    RadGridVisaInfo.DataBind();
                    RadGridVisaInfo.Visible = true;
                    lblVisaInfoErr.Visible = false;

                }
                catch { }


            }
            else
            {
                RadGridVisaInfo.Visible = false;
                lblVisaInfoErr.Visible = true;

            }
            if (MoreVisa == 0)
            {
                MoreVisa = 1;
                lnkBtnMoreVisa.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(51);
            }
            else
            {
                MoreVisa = 0;
                lnkBtnMoreVisa.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(52);
            }
        }

        protected void lnkBtnMoreAsso_Click(object sender, EventArgs e)
        {
            IRSAResumeFA addInfoFA = new IRSAResumeFA();
            Boolean exists = addInfoFA.isAssociationExists(UserID, 5, CultureID);
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("Associations");
            if (exists == true)
            {
                try
                {

                    DataTable DTadd = addInfoFA.getAssociationDetails(UserID, 6, CultureID);//6 is the flag used to identify querry in stored procedure
                    //int count = 0;
                    if (MoreAsso == 0)
                    {
                        for (int i = 0; i < DTadd.Rows.Count; i++)
                        {
                            str = "Associated with ";
                            if ((DTadd.Rows[i]["AName"]).ToString() != null && (DTadd.Rows[i]["AName"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((DTadd.Rows[i]["AName"]).ToString()).TrimEnd();
                                if ((DTadd.Rows[i]["ASinceDate"]).ToString() != null && (DTadd.Rows[i]["ASinceDate"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["AUntilDate"]).ToString() != null && (DTadd.Rows[i]["AUntilDate"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " , " + ((DTadd.Rows[i]["ASinceDate"]).ToString()).TrimEnd() + " - " + ((DTadd.Rows[i]["AUntilDate"]).ToString()).TrimEnd();
                                    DataRow dr2 = tempDT.NewRow();
                                    dr2["Associations"] = str;
                                    tempDT.Rows.Add(dr2);
                                    tempDT.AcceptChanges();

                                }
                                //str = str + System.Environment.NewLine;
                            }
                            str = string.Empty;
                        }
                    }
                    else if (MoreAsso == 1)
                    {
                        int count = 0;
                        if (DTadd.Rows.Count >= 2)
                        {
                            count = 2;
                        }
                        else
                        {
                            count = DTadd.Rows.Count;
                        }
                        for (int i = 0; i < count; i++)
                        {
                            str = "Associated with ";
                            if ((DTadd.Rows[i]["AName"]).ToString() != null && (DTadd.Rows[i]["AName"]).ToString().TrimEnd() != "")
                            {
                                str = str + ((DTadd.Rows[i]["AName"]).ToString()).TrimEnd();
                                if ((DTadd.Rows[i]["ASinceDate"]).ToString() != null && (DTadd.Rows[i]["ASinceDate"]).ToString().TrimEnd() != "" && (DTadd.Rows[i]["AUntilDate"]).ToString() != null && (DTadd.Rows[i]["AUntilDate"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " , " + ((DTadd.Rows[i]["ASinceDate"]).ToString()).TrimEnd() + " - " + ((DTadd.Rows[i]["AUntilDate"]).ToString()).TrimEnd();
                                    DataRow dr2 = tempDT.NewRow();
                                    dr2["Associations"] = str;
                                    tempDT.Rows.Add(dr2);
                                    tempDT.AcceptChanges();

                                }
                                //str = str + System.Environment.NewLine;
                            }
                            str = string.Empty;
                        }

                    }

                    RadGridAsso.Visible = true;
                    RadGridAsso.DataSource = tempDT;
                    RadGridAsso.DataBind();
                    lblAssoErr.Visible = false;
                }
                catch { }


            }
            else
            {
                RadGridAsso.Visible = false;
                lblAssoErr.Visible = true;
            }
            if (MoreAsso == 0)
            {
                MoreAsso = 1;
                lnkBtnMoreAsso.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(51);
            }
            else
            {
                MoreAsso = 0;
                lnkBtnMoreAsso.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(52);
            }
        }

        protected void lnkBtnMoreLicense_Click(object sender, EventArgs e)
        {
            IRSA.IRSAResumeFA certiFA = new IRSA.IRSAResumeFA();
            Boolean exists = certiFA.isCertiExists(UserID, 2, CultureID);
            DataTable DTc = new DataTable();
            string str = string.Empty;
            DataTable tempDT = new DataTable();
            tempDT.Columns.Add("License");
            if (exists == true)
            {
                try
                {
                    lblLicenseErr.Visible = false;
                    DTc = certiFA.getLicenseDetails(UserID, 5, CultureID);//5 is the flag bit to be used in the stored procedure
                    //pnlCertification.Visible = true;

                    if (MoreLicense == 1)
                    {
                        int count = 0;
                        if (DTc.Rows.Count >= 2)
                        {
                            count = 2;
                        }
                        else
                        {
                            count = DTc.Rows.Count;
                        }

                        for (int i = 0; i < count; i++)
                        {
                            if ((DTc.Rows[i]["LCName"]).ToString() != null && (DTc.Rows[i]["LCName"]).ToString().TrimEnd() != "")
                            {

                                str = str + ((DTc.Rows[i]["LCName"]).ToString()).TrimEnd();
                                if ((DTc.Rows[i]["LCIssuedBy"]).ToString() != null && (DTc.Rows[i]["LCIssuedBy"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " , " + ((DTc.Rows[i]["LCIssuedBy"]).ToString()).TrimEnd();
                                    DataRow dr2 = tempDT.NewRow();
                                    dr2["License"] = str;
                                    tempDT.Rows.Add(dr2);
                                    tempDT.AcceptChanges();
                                }
                                //str = str + System.Environment.NewLine;
                            }
                            str = string.Empty;
                        }
                    }
                    else if (MoreLicense == 0)
                    {
                        for (int i = 0; i < DTc.Rows.Count; i++)
                        {
                            if ((DTc.Rows[i]["LCName"]).ToString() != null && (DTc.Rows[i]["LCName"]).ToString().TrimEnd() != "")
                            {

                                str = str + ((DTc.Rows[i]["LCName"]).ToString()).TrimEnd();
                                if ((DTc.Rows[i]["LCIssuedBy"]).ToString() != null && (DTc.Rows[i]["LCIssuedBy"]).ToString().TrimEnd() != "")
                                {
                                    str = str + " , " + ((DTc.Rows[i]["LCIssuedBy"]).ToString()).TrimEnd();
                                    DataRow dr2 = tempDT.NewRow();
                                    dr2["License"] = str;
                                    tempDT.Rows.Add(dr2);
                                    tempDT.AcceptChanges();
                                }
                                //str = str + System.Environment.NewLine;
                            }
                            str = string.Empty;
                        }
                    }
                    RadGridLicense.DataSource = tempDT;
                    RadGridLicense.DataBind();
                    RadGridLicense.Visible = true;
                }
                catch { }



            }
            else
            {
                lblLicenseErr.Visible = true;
                RadGridLicense.Visible = false;
            }
            if (MoreLicense == 0)
            {
                MoreLicense = 1;
                lnkBtnMoreLicense.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(51);
            }
            else
            {
                MoreLicense = 0;
                lnkBtnMoreLicense.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(52);
            }
        }

        protected void lnkBtnClose_Click(object sender, EventArgs e)
        {
            pnlDetailProfSummary.Visible = false;
            lnkBtnMoreProfSummary.Visible = true;
        }

        protected void MoreProfSummary()
        {
            IRSAResumeFA profFA = new IRSAResumeFA();
            string profSum = profFA.getExpNGoals(UserID, CultureID);
            string subProf = string.Empty;
            if (profSum != null && profSum != "")
            {
                if (profSum.Length >= 200)
                {
                    subProf = profSum.Substring(0, 200);
                    lnkBtnMoreProfSummary.Visible = true;
                }
                else
                {
                    subProf = profSum;
                    lnkBtnMoreProfSummary.Visible = false;
                }
                Lblsummery.Visible = true;
                Lblsummery.Text = subProf;
            }
            else
            {
                Lblsummery.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                Lblsummery.Visible = false;
                lnkBtnMoreProfSummary.Visible = false;
            }
           


        }

        protected void JobPreferences()
        {
            IRSAResumeFA JobPrefFA = new IRSAResumeFA();
            DataTable DTJobPref = new DataTable();
            string text = string.Empty;
            string text1 = string.Empty;
            string text2 = string.Empty;
            try
            {
                DTJobPref = JobPrefFA.getJobPreferences(UserID, 10, CultureID); //10 is the flag to identify querry in the stored procedure
            }
            catch { }
            if (DTJobPref != null)
            {
                text = (DTJobPref.Rows[0]["EmploymentStatus"].ToString()).Trim();
                try
                {
                    if (text != null && text != "")
                    {
                        lblEmpStatus.Font.Bold = false;
                        lblEmpStatus.Text = text;
                    }
                    else
                    {
                        lblEmpStatus.Font.Bold = true;
                        lblEmpStatus.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                    }
                }
                catch { }
                text = string.Empty;
                try
                {
                    text = (DTJobPref.Rows[0]["JobTypes"].ToString()).Trim();
                    if (text != null && text != "")
                    {
                        lblJobType.Font.Bold = false;
                        lblJobType.Text = text;
                    }
                    else
                    {
                        lblJobType.Font.Bold = true;
                        lblJobType.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                    }
                }
                catch { }
                text = string.Empty;
                try
                {
                    text = (DTJobPref.Rows[0]["AvailibiltyFrom"].ToString()).Trim();
                    text1 = (DTJobPref.Rows[0]["AvailibiltyTo"].ToString()).Trim();
                    if (text != null && text != "")
                    {
                        if (text1 != null && text1 != "")
                        {
                            text = text + " - " + text1;
                            
                        }
                        else
                        {
                            text = text + IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(98);

                        }
                        lblAvailability.Font.Bold = false;
                        lblAvailability.Text = text;
                    }
                    else
                    {
                        lblAvailability.Font.Bold = true;
                        lblAvailability.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                    }

                }
                catch { }
                text = string.Empty;
                text1 = string.Empty;
                try
                {
                    text = (DTJobPref.Rows[0]["PreferredSalaryAmount"].ToString()).Trim();
                    text1 = (DTJobPref.Rows[0]["PreferredCurrency"].ToString()).Trim();
                    text2 = (DTJobPref.Rows[0]["PayDuration"].ToString()).Trim();
                    if (text != null && text != "" && text1 != null && text1 != "")
                    {
                        text = text + " " + text1;
                        if (text2!=null && text2!="")
                        {
                            text = text + " " + text2;
                        }
                        lblPrefSal.Font.Bold = false;
                        lblPrefSal.Text = text;
                    }
                    else
                    {
                        lblPrefSal.Font.Bold = true;
                        lblPrefSal.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                    }

                }
                catch { }
                text = string.Empty;
                text1 = string.Empty;
                text2 = string.Empty;
                try
                {
                    text = (DTJobPref.Rows[0]["HoursPerweek"].ToString()).Trim();
                    if (text != null && text != "")
                    {
                        lblHrs.Font.Bold = false;
                        lblHrs.Text = text;
                    }
                    else
                    {
                        lblHrs.Font.Bold = true;
                        lblHrs.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);

                    }
                }
                catch { }
                text = string.Empty;
                try
                {
                    text = (DTJobPref.Rows[0]["Relocation"].ToString()).Trim();
                    if (text != null && text != "")
                    {
                        lblRelocation.Font.Bold = false;
                        lblRelocation.Text = text;
                    }
                    else
                    {
                        lblRelocation.Font.Bold = true;
                        lblRelocation.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);

                    }
                }
                catch { }
                text = string.Empty;
                try
                {
                    IRSAResumeFA settingsFA = new IRSAResumeFA();
                    // Boolean hidePhoto;
                    Boolean exists = settingsFA.settingsExists(UserID, 12, CultureID); //12 is flag to identify the querry
                    if (exists == true)
                    {
                        text = IRSAResumeFA.getIndPreferences(UserID,CultureID);
                        if (text != null && text != "")
                        {
                            lblPrefInd.Font.Bold = false;
                            lblPrefInd.Text = text;
                        }
                        else
                        {
                            lblPrefInd.Font.Bold = true;
                            lblPrefInd.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                        }

                    }
                    else
                    {
                        lblPrefInd.Font.Bold = true;
                        lblPrefInd.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);

                    }
                }
                catch { }
            }
        }

        protected void lnkBtnMoreProfSummary_Click(object sender, EventArgs e)
        {
            IRSAResumeFA profFA = new IRSAResumeFA();
            string profSum = profFA.getExpNGoals(UserID, CultureID);
            if (profSum != null && profSum != "")
            {
                lblMoreProfSummary.Text = profSum;
            }
            else
            {
                lblMoreProfSummary.Visible = false;
                lblMoreProfSummary.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
            }
            pnlDetailProfSummary.Visible = true;
            lnkBtnMoreProfSummary.Visible = false;
        }

        //protected void LinkButton1_Click(object sender, EventArgs e)
        //{

        //}

        protected void imgBtnClose1_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void imgBtnClose_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void getPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label74.Text = (string)GetGlobalResourceObject("PageResource", "Label74_ViewAccount");
                lnkBtnMoreProfSummary.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                Linkmorepstcmy.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                BtnMoreAcad.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                LinkBtnMoreProj.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                lnkBtnMoreVisa.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                lnkBtnMoreAsso.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                lnkBtnMoreLicense.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnMoreProfSummary_ViewAccount");
                lnkBtnClose.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnClose_ViewAccount");
                lblProfDetailHead.Text = (string)GetGlobalResourceObject("PageResource", "Label74_ViewAccount");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_ViewAccount");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_ViewAccount");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_ViewAccount");
                lblPastCompanyErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblAcademicsErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblProjectsErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblVisaInfoErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblAssoErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblLicenseErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblSecurityErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");
                lblAwardsErr.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoErr_ViewAccount");

                //Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_JobPostingProfile");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_ViewAccount");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_ViewAccount");
                Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_ViewAccount");
                lblVisaHead.Text = (string)GetGlobalResourceObject("PageResource", "lblVisaHead_ViewAccount");
                lblAssoHead.Text = (string)GetGlobalResourceObject("PageResource", "lblAssoHead_ViewAccount");
                lblLicenseHead.Text = (string)GetGlobalResourceObject("PageResource", "lblLicenseHead_ViewAccount");
                lblSecurityHead.Text = (string)GetGlobalResourceObject("PageResource", "lblSecurityHead_ViewAccount");
                lblAwardsHead.Text = (string)GetGlobalResourceObject("PageResource", "lblAwardsHead_ViewAccount");
                //LinkButton1.Text = (string)GetGlobalResourceObject("PageResource", "lnkBtnClose_ViewAccount");
            }
            catch
            {
            }
        }



        }
    }


