﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;

namespace IRSA
{
    public partial class CommunityDetail : System.Web.UI.Page
    {
        int usercommunityinfo = 0;
        public int CommunityID
        {
            set
            {
                ViewState["CommunityID"] = value;
            }
            get
            {
                if (ViewState["CommunityID"] == null)
                {
                    ViewState["CommunityID"] = 0;
                }
                return Convert.ToInt32(ViewState["CommunityID"].ToString());
            }
        }
        public int CommunityMembers
        {
            set
            {
                ViewState["CommunityMembers"] = value;
            }
            get
            {
                if (ViewState["CommunityMembers"] == null)
                {
                    ViewState["CommunityMembers"] = 0;
                }
                return Convert.ToInt32(ViewState["CommunityMembers"].ToString());
            }
        }
        public DataTable GetCommunityDetails
        {
            get { return (DataTable)ViewState["GetCommunityDetails"]; }
            set { ViewState["GetCommunityDetails"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                int UserID1 = SessionInfo.UserId;
                if (UserID1 != int.MinValue)
                {
                    Lblmember.Text = SessionInfo.FirstName + " " + "!";
                }
                else
                {
                   Response.Redirect("Login.aspx");
                }
                if (!Page.IsPostBack)
                {
                    this.CommunityID = Convert.ToInt32(Request.QueryString.Get("id"));
                    DisplayCommunityInformation();
                    usercommunityinfo = GetUserCommunityInfo();
                    if (usercommunityinfo != 0)
                    {
                        btnJoin.Enabled = false;
                        Labelmsg.Text = "You are already a Member of this community";
                    }
                    if (Convert.ToInt32(this.GetCommunityDetails.Rows[0]["UserID"].ToString()) != SessionInfo.UserId)
                    {
                        Pnlvisibilty.Visible = false;

                    }
                                    
                }                

            }
            catch
            { 
            
            }
        }

        private int GetUserCommunityInfo()
        {
            IRSA.Facade.Community.CommunityFA commDetail = new IRSA.Facade.Community.CommunityFA();
            return commDetail.CheckUserThisCommunityInfo(SessionInfo.UserId, this.CommunityID);
        }

        private void DisplayCommunityInformation()
        {
            this.GetCommunityDetails = GetCommunityInformation();
            this.CommunityMembers = GettotalMembers();
            BindInformation();
        }

        private void BindInformation()
        {
            DataTable objdetail = new DataTable();
            objdetail = this.GetCommunityDetails;
            if (objdetail.Rows.Count != 0)
            {

              Imgcommunt.ImageUrl = "~/ProjectImage/" + objdetail.Rows[0]["CommunityLogo"].ToString();

              LabelCommunityName.Text = objdetail.Rows[0]["CommunityName"].ToString();

              LabelCommunityDet.Text = objdetail.Rows[0]["DetailedDescription"].ToString();

              LblCreated.Text = objdetail.Rows[0]["CreateDate"].ToString();

              LblCategory.Text = objdetail.Rows[0]["CommunityType"].ToString();

              LCommunityMem.Text = this.CommunityMembers.ToString();

              LblCommOwner.Text = objdetail.Rows[0]["CommunityOwnerName"].ToString();

              LblEmail.Text = objdetail.Rows[0]["CommunityOwnerEmail"].ToString();

              LblOwnerweb.Text = objdetail.Rows[0]["WebsiteUrl"].ToString();

              LblCommBlog.Text = objdetail.Rows[0]["CommunityBlog"].ToString();
            
            }
        }

        private int GettotalMembers()
        {
            IRSA.Facade.Community.CommunityFA commDetail = new IRSA.Facade.Community.CommunityFA();
            return commDetail.CommunityTotalMembers(this.CommunityID);
        }

        private DataTable GetCommunityInformation()
        {
            IRSA.Facade.Community.CommunityFA commDetail = new IRSA.Facade.Community.CommunityFA();
            return commDetail.getCommunityIntireDetail(this.CommunityID);
        }

        protected void btnJoin_Click(object sender, EventArgs e)
        {
            try
            {
                IRSA.Facade.Community.CommunityFA commDetail = new IRSA.Facade.Community.CommunityFA();
                int i = commDetail.JoinCommunity(SessionInfo.UserId, this.CommunityID);
                if (i > 0)
                {
                    Labelmsg.Text = "You Have Join This Community Successfully";
                
                }
            }
            catch
            { }
        }

        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                IRSA.Facade.Community.CommunityFA commDetail = new IRSA.Facade.Community.CommunityFA();
                DataTable objdt = commDetail.DeteateCommunity(this.CommunityID);
                Labelmsg.Text = "Community Deleted Successfully";
                
            }

            catch
            { 
            
            }
        }
    }
}
