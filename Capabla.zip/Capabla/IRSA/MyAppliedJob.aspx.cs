﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;

namespace IRSA
{
    public partial class MyAppliedJob : System.Web.UI.Page
    {
        int UserID;
        int flagid;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            if (!IsPostBack)
            {
                MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();
                DataTable dt = new DataTable();

                dt = objMyAppliedJobFA.MyAppliedJob(UserID,1);

                rdCandidateAppliedJob.DataSource = dt;
                rdCandidateAppliedJob.DataBind();
            }
        }



        protected void btnMyAppliedJob_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnResumeUpload_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnWhoVisited_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnJobMatched_Click(object sender, EventArgs e)
        {
            
        }

        protected void btniRSAResume_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnJonAgent_Click(object sender, EventArgs e)
        {
           
        }

        protected void imgBtnView_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                pnlViewjobInfo.Visible = true;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                int jobID = Convert.ToInt32(rdCandidateAppliedJob.MasterTableView.DataKeyValues[gr.ItemIndex]["JobID"]);
                GetPreviewData(jobID);
                GetJobInfo(jobID);
                GetJobProfiles(jobID);
            }
            catch
            {
            }
        }

        protected void GetPreviewData(int JobID)
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJob(JobID);
                if (dt.Rows.Count > 0)
                {
                    LblCompanyName.Text = dt.Rows[0]["Name"].ToString();
                    LblTotalEmployees.Text = dt.Rows[0]["Size"].ToString();
                    //LblComapnyDescription.Text = dt.Rows[0]["Description"].ToString();
                    lnkComapnyURL.Text = dt.Rows[0]["CompanyURL"].ToString();
                    lnkComapnyURL.NavigateUrl = dt.Rows[0]["CompanyURL"].ToString();
                    LblJobLocation.Text = dt.Rows[0]["JobLocation"].ToString();
                    //LblCountry.Text = dt.Rows[0]["JobCountry"].ToString();
                    //LblPostalcode.Text = dt.Rows[0]["JobPostalCode"].ToString();
                    LblPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                    LblExperationDate.Text = dt.Rows[0]["ExpirationDate"].ToString();
                    LblpayrangeFrom.Text = dt.Rows[0]["PayRangeTo"].ToString();
                    lblPayRangeTo.Text = dt.Rows[0]["PayRangefrom"].ToString();
                    lblCurrency.Text = dt.Rows[0]["PayCurrency"].ToString();
                    //LblTowhom.Text = dt.Rows[0]["Towhom"].ToString();
                    //LblAmount.Text = dt.Rows[0]["ReferalBonusAmount"].ToString();
                    //LblCurrency.Text = dt.Rows[0]["ReferalBonusCurrency"].ToString();

                }
            }
            catch
            { }
        }

        protected void GetJobInfo(int JobID)
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobInfo(JobID);
                if (dt.Rows.Count > 0)
                {
                    LblJobtitle.Text = dt.Rows[0]["Expr1"].ToString();
                   // Lblrefcode.Text = dt.Rows[0]["JobCodeRef"].ToString();
                    //Lblnoofopening.Text = dt.Rows[0]["Openings#"].ToString();
                    //LblpayrangeFrom.Text = dt.Rows[0]["PayRangeTo"].ToString();
                    //lblPayRangeTo.Text = dt.Rows[0]["PayRangefrom"].ToString();
                    //lblCurrency.Text = dt.Rows[0]["PayCurrency"].ToString();
                    LblExperienceLevel.Text = dt.Rows[0]["ExperienceLevel"].ToString();
                    //LblPaydescripation.Text = dt.Rows[0]["PayDescription"].ToString();
                    LBlJobfamily.Text = dt.Rows[0]["JobFamilyName"].ToString();
                    LblJobType.Text = dt.Rows[0]["JobType"].ToString();
                    Lbljobdescription.Text = dt.Rows[0]["JobDescription"].ToString();
                    LblSkill.Text = dt.Rows[0]["Skills"].ToString();
                }
            }
            catch
            {
            }
        }

        protected void GetJobProfiles(int JobID)
        {
            try
            {
                
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobProfile(JobID);
                if (dt.Rows.Count > 0)
                {

                    LblEducation.Text = dt.Rows[0]["Education"].ToString();
                    LblAge.Text = dt.Rows[0]["Age"].ToString();
                    LblJobIndustry.Text = dt.Rows[0]["JobFamilyName"].ToString();
                    // RadDdRoleJobtype.SelectedValue = dt.Rows[0]["Title"].ToString();
                    //RadioBtndl.SelectedValue = dt.Rows[0]["DrivingLicense"].ToString();
                    if (dt.Rows[0]["DrivingLicense"].ToString() == "True")
                    {
                        LblDL.Text = "Required";
                    }
                    else
                    {
                        LblDL.Text = "Not Required";
                    }
                    LblDistance.Text = dt.Rows[0]["Distance"].ToString();
                    LblavailabilityFrom.Text = dt.Rows[0]["AvailabiltyFrom"].ToString();
                    LBlAvailabilityto.Text = dt.Rows[0]["AvailabiltyTo"].ToString();
                }
            }
            catch
            {
            }

        }
        //protected void imgBtnDelete_Click(object sender, ImageClickEventArgs e)
        //{
        //    try
        //    {
        //        int flag = 1;
        //        //pnlViewjobInfo.Visible = true;
        //        GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
        //        int jobID = Convert.ToInt32(rdCandidateAppliedJob.MasterTableView.DataKeyValues[gr.ItemIndex]["JobID"]);
        //        MyAppliedJobFA ObjJobDeleteFA = new MyAppliedJobFA();
        //        ObjJobDeleteFA.DeleteAppliedJob(UserID,jobID,flag);
        //        MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();
        //        DataTable dt = new DataTable();

        //        dt = objMyAppliedJobFA.MyAppliedJob(UserID);

        //        rdCandidateAppliedJob.DataSource = dt;
        //        rdCandidateAppliedJob.DataBind();
        //    }
        //    catch
        //    {
        //    }
        //}
       
        protected void rdCandidateAppliedJob_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            
            if (jobFilterBox.Text == "All Jobs")
            {
                flagid = 1;
            }
            else if (jobFilterBox.Text == "Expired Jobs")
            {
                flagid = 3;
            }
            else if (jobFilterBox.Text == "Not Expired Jobs")
            {
                flagid = 4;
            }
            MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();
            DataTable dt = new DataTable();
            dt = objMyAppliedJobFA.MyAppliedJob(UserID, flagid);
             rdCandidateAppliedJob.DataSource = dt;
            rdCandidateAppliedJob.DataBind();

        }

        protected void jobFilterBox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            if (jobFilterBox.Text == "All Jobs") 
            {
                flagid = 1;
            }
            else if (jobFilterBox.Text == "Expired Jobs")
            {
                flagid = 3;
            }
            else if (jobFilterBox.Text == "Not Expired Jobs")
            {
                flagid = 4;
            }
            pnlViewjobInfo.Visible = false;
            MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();
            DataTable dt = new DataTable();
            dt = objMyAppliedJobFA.MyAppliedJob(UserID, flagid);
            rdCandidateAppliedJob.DataSource = dt;
            rdCandidateAppliedJob.DataBind();

        }

        //protected void btnCreateCommunity_Click(object sender, EventArgs e)
        //{

        //}

        //protected void btnWhoVisited_Click(object sender, EventArgs e)
        //{

        //}
    }
}
