﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Xml.XPath;

namespace IRSA
{
    public partial class AcciRSAResume : System.Web.UI.Page
    {
        //Declaring global variables to be used throughout the class
        int UserID;
        string CultureID;

        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            CultureID = "EN";
            //UserID = 3;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["FirstName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            getContactandOtherDetails(UserID);
            getPresentCompanyDetails(UserID);
            getPastCompanyDetails(UserID);
            getAcademicsDetails(UserID);
            getLicenseDetails(UserID);
            getAssociationDetails(UserID);
            getVisaDetails(UserID);
            getSecurityClearanceData(UserID);


        }

        //Function to infer titlr from gender
        protected string getTitle(string gender)
        {
            string title = string.Empty;
            if (gender == "Male")
            {
                title = "Mr.";
                return title;
            }
            else
            {
                title = "Ms.";
                return title;
            }
        }

        //This functions fetches the contact details from [txnMemeberAccount] table and assigns to labels
        protected void getContactandOtherDetails(int UserID)
        {
            IRSAResumeSH ContactSH = new IRSAResumeSH();
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 1;
            ContactDT = ContactFA.getContactandOtherDetails(UserID, flag, CultureID);

            lblTitle.Text = getTitle(ContactDT.Rows[0]["Sex"].ToString());
            lblFirstName.Text = ContactDT.Rows[0]["FirstName"].ToString();
            lblLastName.Text = ContactDT.Rows[0]["LastName"].ToString();
            lblCity.Text = ContactDT.Rows[0]["City"].ToString();
            lblState.Text = ContactDT.Rows[0]["State"].ToString();
            lblPostalCode.Text = ContactDT.Rows[0]["PostalCode"].ToString();
            lblCountry.Text = ContactDT.Rows[0]["Country"].ToString();
            lblPhoneNo.Text = ContactDT.Rows[0]["Phone"].ToString();
            lblEmail.Text = ContactDT.Rows[0]["EmailID"].ToString();
            lblDOB.Text = ContactDT.Rows[0]["DateOfBirth"].ToString();
            lblGender.Text = ContactDT.Rows[0]["Sex"].ToString();
            lblMaritalStatus.Text = ContactDT.Rows[0]["MaritalStatus"].ToString();
            lblDL.Text = ContactDT.Rows[0]["DrivingLicence"].ToString();

        }

        //This functions fetches the Present Company details from [txnMemeberCompany] table and assigns to labels
        protected void getPresentCompanyDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 2;
            ContactDT = ContactFA.getPresentCompanyDetails(UserID, flag, CultureID);
            lblDesignation.Text = ContactDT.Rows[0]["Designation"].ToString();
            lblCompany.Text = ContactDT.Rows[0]["Company"].ToString();
            lblCountry.Text = ContactDT.Rows[0]["Country"].ToString();
            lblDesc.Text = ContactDT.Rows[0]["Description"].ToString();
            lblDateRange.Text = ContactDT.Rows[0]["WorkingFrom"].ToString();
        }

        //This functions fetches the Past Companies details from [txnMemeberCompany] table and binds to grid
        protected void getPastCompanyDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 3;
            ContactDT = ContactFA.getPastCompanyDetails(UserID, flag, CultureID);
            GridPastExp.DataSource = ContactDT;
            GridPastExp.DataBind();

        }


        //This functions fetches the Academics details from [txnMemeberAcademics] table and binds to grid
        protected void getAcademicsDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 4;
            ContactDT = ContactFA.getAcademicsDetails(UserID, flag, CultureID);
            GridAcademics.DataSource = ContactDT;
            GridAcademics.DataBind();
        }

        //to retrieve the License and certification detrails
        protected void getLicenseDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 5;
            ContactDT = ContactFA.getLicenseDetails(UserID, flag, CultureID);
            GridLicenseAndCertification.DataSource = ContactDT;
            GridLicenseAndCertification.DataBind();

        }

        //to retrieve the Association details
        protected void getAssociationDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 6;
            ContactDT = ContactFA.getAssociationDetails(UserID, flag, CultureID);
            GridAssociations.DataSource = ContactDT;
            GridAssociations.DataBind();

        }

        //to retrieve the Visa details
        protected void getVisaDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 7;
            ContactDT = ContactFA.getVisaDetails(UserID, flag, CultureID);
            GridVisaInfo.DataSource = ContactDT;
            GridVisaInfo.DataBind();

        }

        //to retrieve the security clearance data
        protected void getSecurityClearanceData(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 8;
            ContactDT = ContactFA.getSecurityClearanceData(UserID, flag, CultureID);
            lblSecurityName.Text = ContactDT.Rows[0]["SCName"].ToString();
            lblIssuerName.Text = ContactDT.Rows[0]["SCIssuingAuthority"].ToString();
            lblSecurityDescription.Text = ContactDT.Rows[0]["SCDescription"].ToString();
            lblObtainedOn.Text = ContactDT.Rows[0]["SCObtained"].ToString();
            lblSecValidityFrom.Text = ContactDT.Rows[0]["SCVaildFrom"].ToString();
            lblSecValidityTo.Text = ContactDT.Rows[0]["SCVaildTo"].ToString();

        }

        //to retrieve awards and achievements from txnMemberAccount table
        protected void getAwardsAndAchievements(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 9;
            ContactDT = ContactFA.getAwardsAndAchievements(UserID, flag, CultureID);
            lblAwards.Text = ContactDT.Rows[0]["AwardsandAchievements"].ToString();

        }

    }
}
