﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using Telerik.Web.UI;
using System.Collections;
using IRSA.Shared;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Resources;
using IRSA.BussinessLogic;
using System.Configuration;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class addconnection : System.Web.UI.Page
    {
        string str;
        string str6;
        int UserID;
        int ConnectionID;
        int NetworkUserID;
        string FirstName;
        string EID;
        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
               

            }
        }
        public void GetpersonGrid()
        {
            FirstName = TextBox1.Text;
            addconnectionFA objaddconnectionFA = new addconnectionFA();
            DataTable dt = new DataTable();
            dt = objaddconnectionFA.GetPersonData(UserID,FirstName);
            RadGrid1.Visible = true;
            RadGrid1.DataSource = dt;
            TotalCount = dt.Rows.Count;

            RadGrid1.DataBind();
            

        } 

        protected void Button2_Click(object sender, EventArgs e)
        {
            IRSA.Facade.addconnectionFA objaddconnectionFA = new IRSA.Facade.addconnectionFA();
            if (SelectedParentRecord.Count > 0)
            {

                IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                while (Enumerator.MoveNext())
                {
                    NetworkUserID = Convert.ToInt32(Enumerator.Key);
                    objaddconnectionFA.activatecansee(UserID, NetworkUserID);
                    Lblconfirm.Visible = true;
                    Lblconfirm.Text = "selected Contacts can now see you";
                }
            }
            
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GetpersonGrid();
        }

        protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = 0;
           
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);

            CheckBoxList CheckBoxList1 = (CheckBoxList)sender;

            CheckBoxList objrb2 = (CheckBoxList)CheckBoxList1.NamingContainer.FindControl("CheckBoxList1");
            i = Convert.ToInt32(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["NetworkUserID"]);
            
            if (objrb2.SelectedValue != null)
            {
                if (CRecordCount < TotalCount)
                {
                    if (SelectedParentRecord.ContainsKey(i) == true)
                    {
                        CRecordCount--;
                        RemoveRecord(i);
                    }
                    CRecordCount++;
                    SaveRecord(i, objrb2.SelectedValue);
                }
            }
            else
            {
                if (CRecordCount > 0)
                {
                    CRecordCount--;
                    RemoveRecord(i);
                }
            }

           
           

        }

      
        private void SaveRecord(int id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(int id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }
       
    }
}
