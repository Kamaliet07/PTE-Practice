﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;

namespace IRSA
{
    public partial class JobMatchedCandidate : System.Web.UI.Page
    {
        int UserID;
        public DataTable GetCompleteDetailCombined
        {
            get { return (DataTable)ViewState["GetCompleteDetailCombined"]; }
            set { ViewState["GetCompleteDetailCombined"] = value; }
        }
        public DataTable GetUserProfileFit
        {
            get { return (DataTable)ViewState["GetUserProfileFit"]; }
            set { ViewState["GetUserProfileFit"] = value; }
        }
        public DataTable GetUserAssissmentFit
        {
            get { return (DataTable)ViewState["GetUserAssissmentFit"]; }
            set { ViewState["GetUserAssissmentFit"] = value; }
        }
        public DataTable GetMatchedAssissmentFit
        {
            get { return (DataTable)ViewState["GetMatchedAssissmentFit"]; }
            set { ViewState["GetMatchedAssissmentFit"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void btnJobAgent_Click(object sender, EventArgs e)
        {
            btnJobAgent.BackColor = System.Drawing.Color.OrangeRed;
            btnJobMatched.BackColor = System.Drawing.Color.Maroon;
            btnMyAppliedJob.BackColor = System.Drawing.Color.Maroon;
            btnResumeUpload.BackColor = System.Drawing.Color.Maroon;
            //btnWhoVisited.BackColor = System.Drawing.Color.Maroon;
            //btniRSAResume.BackColor = System.Drawing.Color.Maroon;
        }

        protected void btnMyAppliedJob_Click(object sender, EventArgs e)
        {
            btnJobAgent.BackColor = System.Drawing.Color.Maroon;
            btnJobMatched.BackColor = System.Drawing.Color.Maroon;
            btnMyAppliedJob.BackColor = System.Drawing.Color.OrangeRed;
            btnResumeUpload.BackColor = System.Drawing.Color.Maroon;
            //btnWhoVisited.BackColor = System.Drawing.Color.Maroon;
            //btniRSAResume.BackColor = System.Drawing.Color.Maroon;
        }

        protected void btnResumeUpload_Click(object sender, EventArgs e)
        {
            btnJobAgent.BackColor = System.Drawing.Color.Maroon;
            btnJobMatched.BackColor = System.Drawing.Color.Maroon;
            btnMyAppliedJob.BackColor = System.Drawing.Color.Maroon;
            btnResumeUpload.BackColor = System.Drawing.Color.OrangeRed;
            //btnWhoVisited.BackColor = System.Drawing.Color.Maroon;
            //btniRSAResume.BackColor = System.Drawing.Color.Maroon;
        }

        protected void btnWhoVisited_Click(object sender, EventArgs e)
        {
            btnJobAgent.BackColor = System.Drawing.Color.Maroon;
            btnJobMatched.BackColor = System.Drawing.Color.Maroon;
            btnMyAppliedJob.BackColor = System.Drawing.Color.Maroon;
            btnResumeUpload.BackColor = System.Drawing.Color.Maroon;
            //btnWhoVisited.BackColor = System.Drawing.Color.OrangeRed;
            //btniRSAResume.BackColor = System.Drawing.Color.Maroon;
        }

        protected void btnJobMatched_Click(object sender, EventArgs e)
        {
            btnJobAgent.BackColor = System.Drawing.Color.Maroon;
            btnJobMatched.BackColor = System.Drawing.Color.Maroon;
            btnMyAppliedJob.BackColor = System.Drawing.Color.Maroon;
            btnResumeUpload.BackColor = System.Drawing.Color.Maroon;
            //btnWhoVisited.BackColor = System.Drawing.Color.Maroon;
            //btniRSAResume.BackColor = System.Drawing.Color.OrangeRed;
        }

        protected void btniRSAResume_Click(object sender, EventArgs e)
        {
            btnJobAgent.BackColor = System.Drawing.Color.Maroon;
            btnJobMatched.BackColor = System.Drawing.Color.Maroon;
            btnMyAppliedJob.BackColor = System.Drawing.Color.Maroon;
            btnResumeUpload.BackColor = System.Drawing.Color.Maroon;
            //btnWhoVisited.BackColor = System.Drawing.Color.Maroon;
            //btniRSAResume.BackColor = System.Drawing.Color.OrangeRed;
        }


        protected void RFilterBox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            
            if (RFilterBox.Text == "Last 7 days")
            {
                rdJobMatchedCandidate.Visible = true;
               int combovalue=1;
               //this.GetUserProfileFit = GetUserMatchedJob(combovalue);
               this.GetUserAssissmentFit = GetUserMatchedAssissment(combovalue);
              // this.GetMatchedAssissmentFit = GetAssesmentJob();
               this.GetMatchedAssissmentFit = GetUserMatchedJob(combovalue);
               BindProfile();
               this.GetCompleteDetailCombined = BindTableForGridEntry();
               BindGridValue();
                   
            }
            else if (RFilterBox.Text == "Last 30 days")
            {
                rdJobMatchedCandidate.Visible = true;
                int combovalue = 2;
                //this.GetUserProfileFit = GetUserMatchedJob(combovalue);
                this.GetUserAssissmentFit = GetUserMatchedAssissment(combovalue);
                this.GetMatchedAssissmentFit = GetUserMatchedJob(combovalue);
                BindProfile();
                this.GetCompleteDetailCombined = BindTableForGridEntry();
                BindGridValue();

            }
            else if (RFilterBox.Text == "Today")
            {
                rdJobMatchedCandidate.Visible = true;
                int combovalue = 3;
                //this.GetUserProfileFit = GetUserMatchedJob(combovalue);
                this.GetUserAssissmentFit = GetUserMatchedAssissment(combovalue);
                this.GetMatchedAssissmentFit = GetUserMatchedJob(combovalue);
                BindProfile();
                this.GetCompleteDetailCombined = BindTableForGridEntry();
                BindGridValue();

            }
        }
         private DataTable BindProfile()
        {

            for (int i = 0; i <= GetMatchedAssissmentFit.Rows.Count - 1; i++)
            {
                if (this.GetMatchedAssissmentFit.Rows[i]["ProfileFitpercent"].ToString().Trim() == "")
                {
                    this.GetMatchedAssissmentFit.Rows[i]["ProfileFitpercent"] = "0";
                    GetMatchedAssissmentFit.AcceptChanges();
                }

             }
                return GetMatchedAssissmentFit;
            }

           
       private void BindGridValue()
        {
           
            try
            {
                if (this.GetCompleteDetailCombined.Rows.Count != 0)
                {

                    rdJobMatchedCandidate.DataSource = this.GetCompleteDetailCombined;
                    this.GetCompleteDetailCombined.Columns.Add(new DataColumn("SkillJobID", typeof(string)));
                    for (int i = this.GetCompleteDetailCombined.Rows.Count - 1; i >= 0; i--)
                    {
                        this.GetCompleteDetailCombined.Rows[i]["SkillJobID"] = "RedirecttoTools(" + (this.GetCompleteDetailCombined.Rows[i]["JobID"]).ToString() + ")";
                    }
                    
                    rdJobMatchedCandidate.DataBind();

                }
                else
                {
                    rdJobMatchedCandidate.DataSource = this.GetCompleteDetailCombined;
                    rdJobMatchedCandidate.DataBind();
                }
            }

            catch
            {

            }
        }

        private DataTable BindTableForGridEntry()
        {
            
                this.GetMatchedAssissmentFit.Columns.Add(new DataColumn("percentAge", typeof(string)));
                foreach (DataRow ndr in this.GetMatchedAssissmentFit.Rows)
                {
                    int count = 0;
                    string value = string.Empty;
                    foreach (DataRow tdr in this.GetUserAssissmentFit.Rows)
                    {
                        if (tdr["JobID"].ToString() == ndr["JobID"].ToString())
                        {
                            value = tdr["percentAge"].ToString();
                            count = 1;
                        }

                       
                    }
                    if (count != 0)
                    {
                        ndr["percentAge"] = value;
                        this.GetMatchedAssissmentFit.AcceptChanges();
                    }
                    else
                    {
                        ndr["percentAge"] = "Assessment Not Required";
                        this.GetMatchedAssissmentFit.AcceptChanges();
                    }

                }
                return this.GetMatchedAssissmentFit;

            }
             
           

        private DataTable GetUserMatchedAssissment(int combovalue)
        {
            MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();
            return objMyAppliedJobFA.GetAssessmentFitDetails(UserID, combovalue);
        }

        //private DataTable GetUserMatchedJob(int combovalue)
        //{
        //    MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();

        //    return objMyAppliedJobFA.GetProfileFitDetails(UserID, combovalue);


        //}
        //private DataTable GetAssesmentJob()
        //{
        //    MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();

        //    return objMyAppliedJobFA.GetAssessmentDetails();


        //}
        private DataTable GetUserMatchedJob(int combovalue)
        {
            MyAppliedJobFA objMyAppliedJobFA = new MyAppliedJobFA();
            return objMyAppliedJobFA.GetJobMatchedDetails(UserID, combovalue);
        }

        protected void imgApplyNow_Click(object sender, ImageClickEventArgs e)
        {
            int jobID = 0;
            lblMsgJob.Visible = false;
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            ImageButton lnkBtnApply = (ImageButton)rdJobMatchedCandidate.Items[gr.ItemIndex].FindControl("imgApplyNow");
            LinkButton BtnAlertmsgAssessment = (LinkButton)rdJobMatchedCandidate.Items[gr.ItemIndex].FindControl("lnkAssessment");
            LinkButton lnkTools = (LinkButton)rdJobMatchedCandidate.Items[gr.ItemIndex].FindControl("lnkTools");

            jobID = Convert.ToInt32(rdJobMatchedCandidate.MasterTableView.DataKeyValues[gr.ItemIndex]["JobID"]);
            MyJobAgentFA getAppliedJob = new MyJobAgentFA();
            DataTable dtjob = getAppliedJob.getAppliedJob(jobID, UserID);
            if (dtjob.Rows.Count > 0)
            {
                lblMsgJob.Visible = true;
                lblMsgJob.Text = "You have already Applied";
            }
            else
            {
                MyJobAgentFA getStatusFA = new MyJobAgentFA();
                DataTable dtStatus = getStatusFA.getStatus(UserID, jobID);
                DataTable dtStatusTools = getStatusFA.getStatusTools(UserID, jobID);
                if (dtStatus.Rows.Count > 0 || dtStatusTools.Rows.Count > 0)
                {
                    if (dtStatus.Rows.Count > 0 && dtStatusTools.Rows.Count > 0)
                    {
                        if (dtStatus.Rows[0]["Status"].ToString().Trim() == "Submit" && dtStatusTools.Rows[0]["Status"].ToString().Trim() == "Submit")
                        {
                            BtnAlertmsgAssessment.Visible = false;
                            lnkTools.Visible = false;
                            MyJobAgentFA applyJob = new MyJobAgentFA();
                            applyJob.candidateApplyJob(UserID, jobID);
                            lblMsgJob.Visible = true;
                            lblMsgJob.Text = "You have successfully applied";
                            //lnkBtnApply.Enabled = false;
                            //lnkBtnApply.Enabled = false;
                        }
                        else
                        {

                            if (dtStatusTools.Rows[0]["Status"].ToString().Trim() == "Save")
                            {
                                lnkTools.Visible = true;
                                lblMsgJob.Visible = true;
                                lblMsgJob.Text = "Your Assessment is Pending";
                            }

                            if (dtStatus.Rows[0]["Status"].ToString().Trim() == "Save")
                            {
                                BtnAlertmsgAssessment.Visible = true;
                                lblMsgJob.Visible = true;
                                lblMsgJob.Text = "Your Assessment is Pending";
                            }
                        }
                    }

                    else if (dtStatus.Rows.Count > 0 && dtStatusTools.Rows.Count == 0)
                    {
                        if (dtStatus.Rows[0]["Status"].ToString().Trim() == "Save" || dtStatus.Rows[0]["Status"].ToString().Trim() == "")
                        {
                            BtnAlertmsgAssessment.Visible = true;
                            lblMsgJob.Visible = true;
                            lblMsgJob.Text = "Your Assessment is Pending";
                        }
                        else
                        {
                            BtnAlertmsgAssessment.Visible = false;
                            lnkTools.Visible = false;
                            MyJobAgentFA applyJob = new MyJobAgentFA();
                            applyJob.candidateApplyJob(UserID, jobID);
                            lblMsgJob.Visible = true;
                            lblMsgJob.Text = "You have successfully applied";
                            //lnkBtnApply.Enabled = false;
                            //lnkBtnApply.Enabled = false;
                        }
                    }
                    else if (dtStatus.Rows.Count == 0 && dtStatusTools.Rows.Count > 0)
                    {
                        if (dtStatusTools.Rows[0]["Status"].ToString().Trim() == "Save")
                        {
                            lnkTools.Visible = true;
                            lblMsgJob.Visible = true;
                            lblMsgJob.Text = "Your Assessment is Pending";
                        }
                        else
                        {
                            BtnAlertmsgAssessment.Visible = false;
                            lnkTools.Visible = false;
                            MyJobAgentFA applyJob = new MyJobAgentFA();
                            applyJob.candidateApplyJob(UserID, jobID);
                            //lnkBtnApply.Enabled = false;
                            //lnkBtnApply.Enabled = false;
                            lblMsgJob.Visible = true;
                            lblMsgJob.Text = "You have successfully applied";
                        }
                    }

                }
                else
                {

                    MyJobAgentFA applyJob = new MyJobAgentFA();
                    applyJob.candidateApplyJob(UserID, jobID);//To insert Applied job of Candidate
                    //lnkBtnApply.Enabled = false;
                    lblMsgJob.Visible = true;
                    lblMsgJob.Text = "You have successfully applied";
                }
            
        }
        }
            
        
        protected void lnkassesement_Click(object sender, EventArgs e)
        {
            Response.Redirect("Questionnarie.aspx?id=" + "Skill");
        }

        

        protected void rdJobMatchedCandidate_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            
            BindGridValue();
        }
    }
}


