﻿using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using Telerik.Web.UI;
using System;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;
using IRSA.Facade;
namespace IRSA
{
    public partial class Contact_Us : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserID = SessionInfo.UserId;
                regexvldtrTxtEMail.ValidationExpression = (@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember_Login.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                }
                else
                {
                    Lblmember_Login.Text = "Guest !";
                }
            }
            catch { }
        }
        public void mail()
        {
            try
            {
                string MaiAddress = ConfigurationSettings.AppSettings["SenderMailID"]; ;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowMessegeSent";
                rd.NavigateUrl = "~/MessageSentPopUp.aspx";
                rd.Width = 400;
                rd.Height = 200;
                rd.VisibleStatusbar = false;
                rd.Title = "Thank You";
                rd.VisibleOnPageLoad = true;
                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(MaiAddress);
                MailAddress fromto = new MailAddress(txtEMail.Text);
                MailMessage msg = new MailMessage(fromto, sendto);
                msg.Subject = txtSubject.Text;
                string fileName = Path.GetFileName(aspfileupldScrshot.PostedFile.FileName);
                Attachment myAttachment = new Attachment(aspfileupldScrshot.FileContent, fileName);
                msg.Attachments.Add(myAttachment);
                msg.Body = txtDetails.Text;
                msg.IsBodyHtml = false;
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
                txtName.Text = "";
                txtEMail.Text = "";
                txtMobile.Text = "";
                txtLandline.Text = "";
                txtSubject.Text = "";
                txtDetails.Text = "";
                rd.Behaviors = (Telerik.Web.UI.WindowBehaviors)Enum.Parse(typeof(Telerik.Web.UI.WindowBehaviors), "Close");
                RadWindowManager1.Windows.Add(rd);
                rd.Visible = true;
            }
            catch { }
        }

        protected void validateMaxFileSize(object source, ServerValidateEventArgs args)
        {
            try
            {
                HttpPostedFile postedfile = aspfileupldScrshot.PostedFile;
                if (postedfile.ContentLength > (1024 * 150))
                {
                    args.IsValid = false;
                    return;
                }
                args.IsValid = true;
            }
            catch { }
        }

        protected void validatePnones(object source, ServerValidateEventArgs args)
        {
            try
            {
                if (!((txtMobile.Text == "") && (txtLandline.Text == "")))
                {
                    args.IsValid = true;
                    return;
                }
                args.IsValid = false;
            }
            catch { }
        }

        protected void validateFileType(object source, ServerValidateEventArgs args)
        {
            try
            {
                string file;
                HttpPostedFile postedfile = aspfileupldScrshot.PostedFile;
                file = aspfileupldScrshot.FileName;
                string str = file.Split(new string[] { "." }, 3, StringSplitOptions.None)[1];
                if (str == "png" || str == "PNG" || str == "jpg" || str == "JPG" || str == "jpeg" || str == "JPEG")
                {
                    args.IsValid = true;
                    return;
                }
                args.IsValid = false;
            }
            catch { }
        }

        protected void imgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                cstmvldtrFileTypes.Validate();
                cstmvldtrFileUpld.Validate();
                cstmvldtrPhones.Validate();
                if (cstmvldtrFileTypes.IsValid && cstmvldtrFileUpld.IsValid && cstmvldtrPhones.IsValid)
                    mail();
            }
            catch { }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void imgbtnChat_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                RadWindow rdwndwCstmrSpprt = new RadWindow();
                rdwndwCstmrSpprt.ID = "rdwndwCustomerSupport";
                rdwndwCstmrSpprt.NavigateUrl = "~/CustomerSupportPopUp.aspx";
                rdwndwCstmrSpprt.OffsetElementID = Convert.ToString(imgbtnChat.ClientID);
                rdwndwCstmrSpprt.Top = -40;
                rdwndwCstmrSpprt.Left = -440;
                rdwndwCstmrSpprt.Width = 440;
                rdwndwCstmrSpprt.Height = 420;
                rdwndwCstmrSpprt.VisibleStatusbar = false;
                rdwndwCstmrSpprt.Title = "Customer Support";
                rdwndwCstmrSpprt.Behaviors = (Telerik.Web.UI.WindowBehaviors)Enum.Parse(typeof(Telerik.Web.UI.WindowBehaviors), "Close");
                rdwndwCstmrSpprt.VisibleStatusbar = false;
                rdwndwCstmrSpprt.VisibleOnPageLoad = true;
                RadWindowManager1.KeepInScreenBounds = true;
                RadWindowManager1.Windows.Add(rdwndwCstmrSpprt);
            }
            catch { }
        }

    }
}
