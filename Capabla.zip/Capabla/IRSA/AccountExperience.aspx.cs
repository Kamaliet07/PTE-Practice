﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class AccountExperience : System.Web.UI.Page
    {
        int UserID;
        string AppName;
        string CurrentWizardStep = "Experience";
        string Accountxml = "irsatooltipaccount.xml";
        string ResumeDirectoryPath;
        string firstdisplay;
        string strfirstname;
        string OriginalFile;
        string NewFile;
        int NewWidth;
        int MaxHeight;
        bool OnlyResizeIfWider;
        string file;
        string str1;
        string str2;
        string CULINFO;
        string CultureID1;
        string strExp;
        public string ResumeID
        {
            set
            {
                ViewState["ResumeID"] = value;
            }
            get
            {
                if (ViewState["ResumeID"] == null)
                {
                    ViewState["ResumeID"] = "";
                }
                return ViewState["ResumeID"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountExperiencePageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            Page.Form.DefaultButton = Update.UniqueID;
            UserID = SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
            if (!this.IsPostBack)
            {
                string str = Request.QueryString.Get("id");

                int id = Convert.ToInt32(str);
                if (str != null)
                {

                    str = Request.QueryString.Get("id");

                }
                FillIndustry();
                Getdata();
                Lbldatamodified.Visible = false;
            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["DisplayName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }

            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                TxtOthers.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(58, Accountxml);
                Txtkeysklills.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(59, Accountxml);
                Txtgoals.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(62, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                Txnsalary.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(60, Accountxml);
                Ddncurrency.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(68, Accountxml);
                Txnexperience.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(61, Accountxml);

            }
            catch { }
        }

        public void FillIndustry()
        {
            try
            {



                XPathNavigator nvg4;
                XPathDocument docNvg4;
                XPathNodeIterator NdIter4;
                docNvg4 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Industry.xml"));
                nvg4 = docNvg4.CreateNavigator();
                if (CultureID1 == "EN")
                {
                    strExp = "/root/English";
                }
                else if (CultureID1 == "NL")
                {
                    strExp = "/root/Dutch";
                }
                NdIter4 = nvg4.Select(strExp);
                NdIter4.MoveNext();
                DdnIndustry.LoadXml(NdIter4.Current.InnerXml);

            }


            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }

        }
        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {

                    if (objdt.Rows[0]["IndustryID"].ToString() != "")
                    {
                        DdnIndustry.SelectedIndex = (Convert.ToInt32(objdt.Rows[0]["IndustryID"].ToString()));
                        if (objdt.Rows[0]["IndustryID"].ToString() == "22")
                        {
                            Panelothers.Visible = true;

                        }
                    }
                    if (objdt.Rows[0]["OthersIndustry"].ToString() != "")
                    {
                        Panelothers.Visible = true;
                        TxtOthers.Text = objdt.Rows[0]["OthersIndustry"].ToString();
                    }
                    

                    Txtkeysklills.Text = objdt.Rows[0]["KeySkills"].ToString();
                    if (objdt.Rows[0]["AnnualSalary"].ToString() != "")
                    {
                        string sal = objdt.Rows[0]["AnnualSalary"].ToString();
                        string[] arstr = new string[2]; char[] splitterpost = { ',','.' };
                        arstr = sal.Split(splitterpost);
                        string salary = arstr[0];
                        Txnsalary.Text = salary;
                        //Txnsalary.Text = objdt.Rows[0]["AnnualSalary"].ToString();
                    }
                    if (objdt.Rows[0]["SalaryCurrency"].ToString() != "")
                    {
                        string str = objdt.Rows[0]["SalaryCurrency"].ToString();
                        Ddncurrency.SelectedValue = str;
                    }



                    if (objdt.Rows[0]["TotalExperience"].ToString() != "")
                    {
                        Txnexperience.Text = objdt.Rows[0]["TotalExperience"].ToString();
                    }
                    //Lbluserresume.Text = strfirstname;
                    Txtgoals.Text = objdt.Rows[0]["ProfessionalExperinceandGoals"].ToString();
                    // ResumeID = objdt.Rows[0]["ResumeID"].ToString();
                    //if (ResumeID != "")
                    //{
                    //    string strcv = ResumeID.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                    //    LinkBtnResume.Visible = true;
                    //    //Myimage.Visible = true;
                    //    LinkBtnResume.Text = objdt.Rows[0]["FirstName"].ToString() + "_Resume" + "." + strcv;
                    //    //MyImage.ImageUrl = "~/UserCV/" + CV;
                    //}


                }

            }
            catch { }
        }
        //protected void Txtgoals_TextChanged(object sender, EventArgs e)
        //{
        //    string str = Txtgoals.Text;

        //  //  Lblcharcount.Text = "Words Left:&nbsp;" + (Txtgoals.MaxLength - str.Length).ToString();

        //}

        protected void DdnIndustry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string Str = (DdnIndustry.Text).Trim();
                //int strln = Str.Length;
                //Str = Str.Substring(0, 6);
                if (Str == "Others")
                {
                    Panelothers.Visible = true;
                    TxtOthers.ReadOnly = false;
                }
                else
                {
                    Panelothers.Visible = false;
                }
            }
            catch { }
        }
        //protected void LinkBtnResume_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        string FlieName2;

        //        if (ResumeID != "")
        //        {

        //            FlieName2 = ResumeDirectoryPath + ResumeID;
        //            //FileName = Server.MapPath("~/UserCV/"++);


        //            FileInfo file = new FileInfo(FlieName2);
        //            if (file.Exists)
        //            {
        //                Response.ClearContent();
        //                Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
        //                Response.ContentType = "application/vnd.xls";
        //                Response.ContentType = "application/vnd.word";
        //                Response.ContentType = "application/vnd.pdf";
        //                Response.ContentType = "application/vnd.txt";
        //                Response.Flush();
        //                Response.TransmitFile(file.FullName);
        //                Response.End();
        //            }


        //        }
        //    }
        //    catch { }
        //}
        public void savedata()
        {
            try
            {
                AccountsetupSH objaccExpSH = new AccountsetupSH();

                //if (.SelectedValue == "Others")
                if ((DdnIndustry.Text).Trim() == "Others")
                {
                    Panelothers.Visible = true;
                    objaccExpSH.OtherIndustry = TxtOthers.Text;
                    objaccExpSH.Functionalarea = DdnIndustry.Text;
                }
                else
                {
                    objaccExpSH.Functionalarea = DdnIndustry.Text;
                }
                //if (DdnIndustry.SelectedValue == "Others")
                //{
                //    objaccExpSH.OtherIndustry = TxtOthers.Text;
                //    objaccExpSH.Functionalarea = DdnIndustry.SelectedValue;
                //}
                //else
                //{
                //    objaccExpSH.Functionalarea = DdnIndustry.SelectedValue;
                //}
                objaccExpSH.KeySkills = UCFirst(Txtkeysklills.Text);
                if (Txnsalary.Text != "")
                {

                    objaccExpSH.AnnualSalary = Convert.ToDouble(Txnsalary.Text);
                }
                if (Ddncurrency.SelectedValue != "Select Currency")
                {
                    objaccExpSH.SalaryCurrency = Ddncurrency.SelectedValue;
                }
                if (Txnexperience.Text != "")
                {
                    {
                        if (Convert.ToInt32(Txnexperience.Text) <= 50)
                        {
                            Lbldatamodified.Visible = false;
                            lblex.Visible = false;
                            objaccExpSH.TotalExperience = Convert.ToInt32(Txnexperience.Text);
                        }
                        else
                        {
                            Lbldatamodified.Visible = false;
                            lblex.Visible = true;
                            lblex.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(53);
                            goto Last;
                        }
                    }
                    objaccExpSH.TotalExperience = Convert.ToInt32(Txnexperience.Text);
                }

                objaccExpSH.ProfessionalExp = UCFirst(Txtgoals.Text);

                //file = FileResume.FileName;
                //if (file != "")
                //{

                //    int lastIndex = file.LastIndexOf("/");
                //    string strLast = file.Substring(0, lastIndex + 1);
                //    string str = file.Split(new string[] { "." }, 3, StringSplitOptions.None)[1];
                //    FileResume.SaveAs(ResumeDirectoryPath + UserID + "." + str);
                //    objaccExpSH.ResumeID = UserID + "." + str;

                //}


                // string path = "~/App_Themes/Site/images/";
                int i = 0;

                if (Txtkeysklills.Text != "")
                {
                    i++;
                }
                if (Txtgoals.Text != "")
                {
                    i++;
                }
                if (DdnIndustry.SelectedIndex != 0 || TxtOthers.Text != "")
                {
                    i++;
                }
                if (Ddncurrency.SelectedIndex != 0)
                {
                    i++;
                }
                if (Txnsalary.Text != "")
                {
                    i++;
                }
                if (Txnexperience.Text != "")
                {
                    i++;
                }

                int Experience = i * 100 / 6;
                int AccountWelcome = 0, Acadimic = 0, PastCompany = 0, Projects = 0, PresentCompany = 0;
                AccountsetupFA objaccExpFA = new AccountsetupFA();
                objaccExpFA.InsertAccountSetUpData(objaccExpSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                Getdata();
            Last: ;

            }
            catch { }

        }




        protected void Next_Click(object sender, EventArgs e)
        {
            savedata();
            Response.Redirect("AccountProjects.aspx");
        }


        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {

                sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);

            }
            catch { }
            return sb.ToString();
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            savedata();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            Getdata();
        }

        protected void Btnprev_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountPastCompany.aspx");
        }

        protected void Butnxt_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountProjects.aspx");
        }

        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }




        }
        protected void getAccountExperiencePageLanguageInfo()
        {
            try
            {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountExperience");
            btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountExperience");
            btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountExperience");
            Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountExperience");
            Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountExperience");
            Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccountExperience");
            Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccountExperience");
            Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccountExperience");
            Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccountExperience");
            Button7.Text = (string)GetGlobalResourceObject("PageResource", "Button7_AccountExperience");
            Button8.Text = (string)GetGlobalResourceObject("PageResource", "Button8_AccountExperience");
            Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_AccountExperience");
            Label26.Text = (string)GetGlobalResourceObject("PageResource", "Label26_AccountExperience");
            Label27.Text = (string)GetGlobalResourceObject("PageResource", "Label27_AccountExperience");
            Label28.Text = (string)GetGlobalResourceObject("PageResource", "Label28_AccountExperience");
            Label29.Text = (string)GetGlobalResourceObject("PageResource", "Label29_AccountExperience");
            Label30.Text = (string)GetGlobalResourceObject("PageResource", "Label30_AccountExperience");
            Label31.Text = (string)GetGlobalResourceObject("PageResource", "Label31_AccountExperience");
            lblgoals.Text = (string)GetGlobalResourceObject("PageResource", "lblgoals_AccountExperience");
            Btnprev.Text = (string)GetGlobalResourceObject("PageResource", "Btnprev_AccountExperience");
            Update.Text = (string)GetGlobalResourceObject("PageResource", "Update_AccountExperience");
            Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountExperience");
            Butnxt.Text = (string)GetGlobalResourceObject("PageResource", "Butnxt_AccountExperience");
            Label25.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
            }
                catch
            {
             }
        

        }
    }
    }
