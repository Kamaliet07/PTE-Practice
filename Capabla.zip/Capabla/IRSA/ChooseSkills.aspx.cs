﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.Data;
using System.Text;
using System.Xml.XPath;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using IRSA.BussinessLogic;
using System.Collections;
using IRSA.Shared;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Resources;
using System.Configuration;

namespace IRSA
{
    public partial class ChooseSkills : System.Web.UI.Page
    {
        string EID,SkillID;
        int SkilProfilerID=8;
        int UserID;
        IRSA.Shared.SkillProfiler SkProfiler = new IRSA.Shared.SkillProfiler();    
        IRSA.Facade.SkillProfilerFA comm = new IRSA.Facade.SkillProfilerFA();
        
       
        public Hashtable CountNode
        {
            set
            {
                ViewState["CountNode"] = value;
            }
            get
            {
                if (ViewState["CountNode"] == null)
                {
                    CountNode = new Hashtable();
                }
                return (Hashtable)ViewState["CountNode"];
            }
        }

         
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //EID = Request.QueryString.Get("id").ToString();

                UserID = SessionInfo.UserId;
                if (SessionInfo.SkillProfilerName != "")
                {
                    Label4.Text = SessionInfo.SkillProfilerName;
                }
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }    
            }
            catch
            {
            }
          
        }


        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    FillData();
                   
                }
               
            }
            catch
            {
            }
        }
        public void FillData()
        {
            try
            {
                DataTable temp = new DataTable();
                temp = comm.GetSkills(SessionInfo.ONETSOCCode);
                GridView1.DataSource = temp;
                GridView1.DataBind();
            }
            catch
            {
            }
        }

        private void SaveRecord(string id, string value)
        {
            try
            {
                if (!CountNode.ContainsKey(id))
                {
                    CountNode.Add(id, value);
                }
            }
            catch
            {
            }

        }
        private void RemoveRecord()
        {
            try
            {
                if (CountNode.Count > 0)
                {
                    CountNode.Clear();
                }
            }
            catch
            {
            }

        }

        public void Check()
        {
            try
            {
                CheckBox chk;
                if (CountNode.Count > 0)
                {
                    RemoveRecord();
                }

                foreach (GridViewRow rowItem in GridView1.Rows)
                {    // FindControl function gets the control placed inside the GridView control from the specified cell  
                    // FindControl fucntion accepts string id of the control that you want to access 
                    // type casting of control allows to access the properties of that particular control 
                    // here checkbox control type cast is used to access its properties
                    chk = (CheckBox)(rowItem.Cells[0].FindControl("chk1"));
                    // chk.checked will access the checkbox state value (on button click event)
                    if (chk.Checked)
                    {
                        EID = GridView1.DataKeys[rowItem.RowIndex]["ElementID"].ToString();
                        SaveRecord(EID, EID);
                    }

                }
            }
            catch
            {
            }
        }

        public void FindData()
        {
            try
            {
                string sany = "";
                // int count = CountNode.Count;
                if (CountNode.Count > 0)
                {
                    IDictionaryEnumerator Enumerator = CountNode.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        EID = Enumerator.Key.ToString();
                        sany = sany + "'" + EID + "'" + ",";

                    }
                    int s = sany.Length;
                    sany = sany.Remove(s - 2, 2);
                    sany = sany.Remove(0, 1);

                    SessionInfo.ElementID = sany;

                }
            }
            catch
            {
            }

       }      

        protected void btnRateSkills_Click(object sender, EventArgs e)
        {
            Response.Redirect("RateSkill.aspx");
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                FindData();
                Response.Redirect("RateSkill.aspx");
            }
            catch
            {
            }
        }

        protected void RadGrid1_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                Check();
            }
            catch
            {
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void chk1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                Check();
                FindData();
            }
            catch
            {
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                CheckBox chk;
                if (btnEdit.Text == "Edit")
                {
                    DataTable objdt = new DataTable();

                    objdt = comm.GetSkillQuestionaire(SkilProfilerID);

                    for (int i = 0; i < objdt.Rows.Count; i++)
                    {
                        SkillID = objdt.Rows[i]["SkillID"].ToString();

                        foreach (GridViewRow rowItem in GridView1.Rows)
                        {
                            {
                                EID = GridView1.DataKeys[rowItem.RowIndex]["ElementID"].ToString();
                                if (EID == SkillID)
                                {
                                    chk = (CheckBox)(rowItem.Cells[0].FindControl("chk1"));
                                    chk.Checked = true;

                                }
                            }
                        }

                    }

                    btnEdit.Text = "Update";
                }
                if (btnEdit.Text == "Update")
                {

                }
            }
            catch
            {
            }
            }
        }

    }

