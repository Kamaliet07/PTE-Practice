﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;


using System.Xml.XPath;

namespace IRSA
{
    public partial class PostJobCompanyInformation : System.Web.UI.Page
    {
    
        int UserID;
        string Job;
        string CULINFO;
        string step = "";
        string Collection = "";
        int OrganisationID;
        string JobPostingxml = "TooltripJobposting.xml";
   
        public int JobID
        {
            set
            {
                ViewState["JobID"] = value;
            }
            get
            {
                if (ViewState["JobID"] == null)
                {
                    ViewState["JobID"] = 0;
                }
                return Convert.ToInt32(ViewState["JobID"].ToString());
            }
        }
        public int CompanyID
        {
            set
            {
                ViewState["CompanyID"] = value;
            }
            get
            {
                if (ViewState["CompanyID"] == null)
                {
                    ViewState["CompanyID"] = 0;
                }
                return Convert.ToInt32(ViewState["CompanyID"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
          
           
            GettooltipMessage();
            if (UserID != int.MinValue)
            {
                OrganisationID = SessionInfo.OrganisationID;
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            Job = Request.QueryString.Get("ID");
            if (Job != null)
            {
                JobID = Convert.ToInt32(Job);

            }
            string Role = Convert.ToString(SessionInfo.RoleID);
            if(Role=="OR")
            {
                DdCompanyName.Enabled = false;
            }
            if (!IsPostBack)
            {
                GetIndustryName();
            }
        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                getCompanyInformationPageLanguageInfo();
                if (!Page.IsPostBack)
                {
                    if (Job == null)
                    {
                        Comboboxbind();
                        GetCompanyData();
                       // GetIndustryName();
                    }
                    else
                    {
                        Comboboxbind();
                        GetCompanyInfo();
                       // GetIndustryName();
                    }
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        public void Comboboxbind()
        {
            try
            {
                JobPostingFA Jobpostfa = new JobPostingFA();
                 JobPostingSH JobPostSH = new JobPostingSH();
                DataTable temp = new DataTable();
                temp = Jobpostfa.GetCompanyName();
               
                DdCompanyName.DataSource = temp;
                DdCompanyName.DataBind();
                Defaultseletion();
               
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }

        protected void DdCompanyName_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetCompanyData();
        }
        protected void GetCompanyData()
        {
            try
            {
                JobPostingSH JobPostSH = new JobPostingSH();
                JobPostingFA Jobpostfa = new JobPostingFA();
                JobPostSH.ComanyName = DdCompanyName.Text;
                
                DataTable temp = new DataTable();
                if (DdCompanyName.Text == "" )
                {
                    PenelComanyName.Visible = true;
                    RadEditorCompanyDesc.Content = "";
                    TxtCompanyURL.Text = "";
                }
                else
                {
                    temp = Jobpostfa.GetCompanyNameDes(DdCompanyName.SelectedValue);
                    if (temp.Rows.Count > 0)
                    {
                      
                        RadEditorCompanyDesc.Content = temp.Rows[0]["Description"].ToString();
                        TxtCompanyURL.Text = temp.Rows[0]["Website"].ToString();

                    }
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
           
            {
                datasave();
                Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
            }
        }
        protected void GetCompanyInfo()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJob(JobID);
                if (dt.Rows.Count > 0)
                {
                    DdCompanyName.SelectedValue = dt.Rows[0]["Name"].ToString();
                    RadEditorCompanyDesc.Content = dt.Rows[0]["CompanyDescription"].ToString();
                    TxtCompanyURL.Text = dt.Rows[0]["CompanyURL"].ToString();
                    DdIndustry.SelectedValue =dt.Rows[0]["IndustryID"].ToString();

                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        protected void Defaultseletion()
        {
            OrgAccountFA objorgFA = new OrgAccountFA();
            DataTable dt1 = new DataTable();
            dt1 = objorgFA.RetrieveOrganisationData(UserID, OrganisationID);
            if (dt1.Rows.Count > 0)
            {
                DdCompanyName.SelectedValue = dt1.Rows[0]["OrganisationID"].ToString();
                CompanyID =Convert.ToInt32( dt1.Rows[0]["OrganisationID"].ToString()); 

            }
        }
        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            datasave();
                Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
          
        }
        protected void GetIndustryName()
        {
            JobPostingFA objjobFA = new JobPostingFA();
            DataTable DtGetIndustryName = new DataTable();
            DtGetIndustryName = objjobFA.GetIndustryName();
            DdIndustry.DataSource = DtGetIndustryName;
            DdIndustry.DataBind();

        }

        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            datasave();
                Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
            
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            datasave();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            datasave();
                Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
          
        }

        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            datasave();
                Response.Redirect("JobPostingDescribetoolsandtech.aspx?ID=" + JobID);
          
        }

        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            datasave();
                Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
           
        }
        protected void datasave()
        {
            try
            {
                //if (fromvalidation())
                {
                    
                    JobPostingSH JobPostSH = new JobPostingSH();
                    JobPostingFA Jobpostfa = new JobPostingFA();
                    JobPostSH.ComanyName = DdCompanyName.Text;
                    JobPostSH.IndustryID = DdIndustry.Text;
                    JobPostSH.ComanyDescription = RadEditorCompanyDesc.Content;
                    JobPostSH.ComanyUrl = TxtCompanyURL.Text;
                    if (TxtnewCompany.Text != "")
                    {
                        DataTable dtOrg = new DataTable();
                       
                         JobPostingFA Jobpostorgfa = new JobPostingFA();
                        JobPostSH.OrgName = TxtnewCompany.Text;
                        dtOrg = Jobpostorgfa.InsertRCOrg(JobPostSH);
                        if(dtOrg.Rows.Count>0)
                        {
                            JobPostSH.CompanyID =Convert.ToInt32( dtOrg.Rows[0]["OrganisationID"].ToString());
                            SessionInfo.OrganisationID = Convert.ToInt32(dtOrg.Rows[0]["OrganisationID"].ToString());
                        }
                    }
                    else
                    {
                        JobPostSH.CompanyID =Convert.ToInt32(DdCompanyName.Text);
                        SessionInfo.OrganisationID = Convert.ToInt32(DdCompanyName.Text);
                    }
                    
                   
                    
                    DataTable temp = new DataTable();

                    if (JobID != 0)
                    {
                        step = "CompanyInfo";
                    }
                    else
                    {
                        step = "";
                    }
                    
                    temp = Jobpostfa.GetCompany(JobPostSH, step, JobID, Collection);
                    if (temp.Rows.Count > 0)
                    {
                        JobID = Convert.ToInt32(temp.Rows[0]["JobID"].ToString());

                    }
                    lblmassage.Visible = true;
                    lblmassage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(50);
                }
                //else
                //{
                //    lblmassage.Visible = true;
                //    lblmassage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(43);
                //}
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }

        //protected void Btnreset_Click(object sender, EventArgs e)
        //{
        //    Comboboxbind();
        //    GetCompanyData();
        //}

        protected void Btnupdate_Click(object sender, EventArgs e)
        {
            
                datasave();
            
           
        }
        private void GettooltipMessage()
        {
            try
            {
                DdCompanyName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, JobPostingxml);
                RadEditorCompanyDesc.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, JobPostingxml);
                TxtCompanyURL.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, JobPostingxml);
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        protected bool fromvalidation()
        {
            if (!Validation.IsValidInternetURL(TxtCompanyURL.Text))
            {
                Lblurlerrormessage.Visible = true;
                Lblurlerrormessage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(33);
                return false;
            }
            else
            {
                Lblurlerrormessage.Visible = false;
                Lblurlerrormessage.Text = "";

            }
            return true;
        }
        protected void getCompanyInformationPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_PostJobCompanyInformation");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_PostJobCompanyInformation");
                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label5_PostJobCompanyInformation");
                Label6.Text = (string)GetGlobalResourceObject("PageResource", "Label6_PostJobCompanyInformation");
                Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_PostJobCompanyInformation");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_PostJobCompanyInformation");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_PostJobCompanyInformation");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_PostJobCompanyInformation");
                Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_PostJobCompanyInformation");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_PostJobCompanyInformation");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_PostJobCompanyInformation");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_PostJobCompanyInformation");
                lblCharLeft.Text = (string)GetGlobalResourceObject("PageResource", "lblCharLeft_PostJobCompanyInformation");
                Btnupdate.Text = (string)GetGlobalResourceObject("PageResource", "Btnupdate_PostJobCompanyInformation");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_PostJobCompanyInformation");
            }
            catch
            {
            }
        }
    }
    
}
 