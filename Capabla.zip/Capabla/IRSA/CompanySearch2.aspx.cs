﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Net.Mail;
using IRSA.Exception;
using System.Resources;
using System.Threading;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace IRSA
{
    public partial class CompanySearch2 : System.Web.UI.Page
    {
        CompanySearchSH objCompanySearchSH = new CompanySearchSH();
        CompanySearchFA objCompanySearchFA = new CompanySearchFA();
        string PhotoDirectoryPath,PhotoPath, str;
        int UserID;
        
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        public DataTable companydetails
        {
            get { return (DataTable)ViewState["companydetails"]; }
            set { ViewState["companydetails"] = value; }
        }
        public DataTable GetCompanyAssissmentFit
        {
            get { return (DataTable)ViewState["GetCompanyAssissmentFit"]; }
            set { ViewState["GetCompanyAssissmentFit"] = value; }
        }
        public DataTable GetCompleteDetail
        {
            get { return (DataTable)ViewState["GetCompleteDetail"]; }
            set { ViewState["GetCompleteDetail"] = value; }
        }
        public DataTable GetTempCompleteDetail
        {
            get { return (DataTable)ViewState["GetTempCompleteDetail"]; }
            set { ViewState["GetTempCompleteDetail"] = value; }
        }


        string Accountxml = "irsaToolTipSearch.xml";

        string CULINFO;
        protected void Page_Load(object sender, EventArgs e)
        {
            PhotoDirectoryPath = ConfigurationSettings.AppSettings["orglogo"];
            PhotoPath = ConfigurationSettings.AppSettings["orglogodefault"];
            if (!IsPostBack)
            {
                getPageLanguageInfo();
                XmlCountry();
                FillIndustry();
                str = Request.QueryString.Get("id");
                //if (str == "")
                //{
                //    GetList();
                //}
                //else
                //{
                //    int lng = str.Length;
                //    if (lng <= 1)
                //    {
                //        GetpersonGrid();
                //    }
                //    else
                //    {
                //        GetSearchWords(str);

                //    }
                //}

                if (str != "")
                {
                    int lng = str.Length;
                    if (lng <= 1)
                    {
                        GetpersonGrid();
                    }
                    else
                    {
                        GetSearchWords(str);

                    }

                }
                else
                {
                    //lblcomp.Text = "No matching Organisation Found.Refine your search criteria";
                    lblcomp.Visible = true;
                    lblcomp.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(97);
                }
            }
            GetiRsaToolTipAccMsg();


            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";

            }
            else
            {
                Lblmember.Text = "Guest !";
            }
        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                RtxtTitle.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                RCity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                
            }
            catch { }
        }



        private void XmlCountry()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                countrybox1.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {

            }
        }
        public void GetpersonGrid()
        {
            try
            {

                CompanySearchFA objCompanySearchFA = new CompanySearchFA();
                DataTable dt = new DataTable();
                dt = objCompanySearchFA.GetData1(str, objCompanySearchSH);

                RadGrid1.DataSource = dt;
                RadGrid1.DataBind();
            }
            catch
            {
            }


        }
        //public void GetList()
        //{
        //    try
        //    {

        //        CompanySearchFA objCompanySearchFA = new CompanySearchFA();
        //        DataTable dl = new DataTable();
        //        dl = objCompanySearchFA.GetCompanyData();
        //        RadGrid1.DataSource = dl;
        //        RadGrid1.DataBind();
        //    }
        //    catch
        //    {
        //    }

        //}
       
        public void getmember(string str4)
        {
            try
            {

                DataTable dtCalc = new DataTable();
                DataTable ds = new DataTable();

                if (GetTempsearchCollection == null)
                {
                    CompanySearchFA objCompanySearchFA = new CompanySearchFA();

                    ds = objCompanySearchFA.GetData1(str4, objCompanySearchSH);
                    this.GetTempsearchCollection = ds;
                    
                }
                else
                {

                    if (GetTempsearchCollection.Rows.Count > 0)
                    {
                        if (GetTempsearchCollection.Rows[0]["details"].ToString() != "")
                        {

                            DataRow[] Result = GetTempsearchCollection.Select("details Like '%" + str4 + "%'");
                            DataTable dfg = new DataTable();
                            dfg.Columns.Add("Name", typeof(string));
                            dfg.Columns.Add("City", typeof(string));
                            dfg.Columns.Add("Country", typeof(string));
                            dfg.Columns.Add("Website", typeof(string));
                            dfg.Columns.Add("LogoPath", typeof(string)); 
                            dfg.Columns.Add("OrganisationID", typeof(int));
                            dfg.Columns.Add("UserID", typeof(int));
                            dfg.Columns.Add("EmailID", typeof(string));
                            foreach (DataRow dr in Result)
                            {
                                DataRow row;
                                row = dfg.NewRow();
                                row["Name"] = dr[0];
                                row["City"] = dr[2];
                                row["Country"] = dr[3];
                                row["Website"] = dr[4];
                                row["OrganisationID"] = dr[6];
                                row["UserID"] = dr[8];
                                row["EmailID"] = dr[9];
                                row["LogoPath"] = dr[7];

                                dfg.Rows.InsertAt(row, 0);
                            }

                            GetTempsearchCollection = dfg;
                        }
                    }


                }
            }
            catch
            {
            }

        }




        public void GetSearchWords(string str)
        {
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str4 = words[i];

                getmember(str4);
            }
            if (GetTempsearch == null)
            {
                //RadGrid1.DataSource = GetTempsearchCollection;
                this.GetTempCompleteDetail = GetTempsearchCollection;
                this.GetCompanyAssissmentFit = GetCompanyAsses(SessionInfo.UserId);
                this.GetCompleteDetail = BindTableForGridEntry();
                BindGridValue();
                //RadGrid1.DataBind();
            }
            else
            {
                this.GetTempCompleteDetail = GetTempsearchCollection;
                this.GetCompanyAssissmentFit = GetCompanyAsses(SessionInfo.UserId);
                this.GetCompleteDetail = BindTableForGridEntry();
                BindGridValue();
                //RadGrid1.DataBind();
            }

        }


        protected void Button_Click(object sender, EventArgs e)
        {
            GetTempsearchCollection = null;
            GetTempsearch = null;
            Company();

        }

        protected void countrybox1_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objCompanySearchSH.CountryName = countrybox1.SelectedItem.Text;
        }

        protected void RadGrid1_PageIndexChanged1(object source, GridPageChangedEventArgs e)
        {
            //if (str == "" || str == null)
            //{
            //    GetList();
            //}
            //else
            //{
            //    int lng = str.Length;
            //    if (lng <= 1)
            //    {
            //        GetpersonGrid();
            //    }
            //    else
            //    {
            //        GetSearchWords(str);

            //    }
            //}
            if (str != "")
            {
                int lng = str.Length;
                if (lng <= 1)
                {
                    GetpersonGrid();
                }
                else
                {
                    GetSearchWords(str);

                }
            }
            else
            {
                //lblcomp.Text = "No matching Organisation Found.Refine your search criteria";
                lblcomp.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(97);
            }
        }
       


        public void FillIndustry()
        {
            try
            {
                JobSearchFA objJobSearchFA = new JobSearchFA();
                DataTable temp = new DataTable();
                temp = objJobSearchFA.GetIndustryData();
                DataRow dr = temp.NewRow();
                dr["IndustryName"] = "Select IndustryName";
                temp.Rows.InsertAt(dr, 0);
                Industry.DataTextField = "IndustryName";
                Industry.DataSource = temp;
                Industry.DataBind();
            }
            catch
            {
            }
        }
        protected void Company()
        {
            try
            {
                string str6, str7, str8, str9, str10, str11, str12;
                str6 = RtxtTitle.Text;
                str9 = " ";
                objCompanySearchSH.CompanyName = RtxtTitle.Text; ;
                str7 = Industry.SelectedValue;
                str10 = " ";
                objCompanySearchSH.IndustryName = Industry.SelectedValue;
                str11 = countrybox1.SelectedValue;
                str12 = " ";
                objCompanySearchSH.CountryName = countrybox1.SelectedValue; ;
                str8 = RCity.Text;
                objCompanySearchSH.City = RCity.Text;

                string ab = str6 + str9 + str7 + str10 + str11 + str12 + str8;
                GetSearchWords(ab);
            }
            catch
            {
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton1");
                string OrganisationID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["OrganisationID"]);
                GridDataItem dtitem = this.RadGrid1.Items[gr.ItemIndex];
                string UseID = dtitem["UserID"].Text.ToString();
                int uid = Convert.ToInt32(UseID);
                string Message = string.Format("~/ViewOrg.aspx?param1={0}&param2={1}", uid, OrganisationID);
                if (UserID != int.MinValue)
                {

                    RadWindow rd = new RadWindow();
                    rd.ID = "RadWindowhelp";
                    rd.NavigateUrl = Message;
                    rd.VisibleOnPageLoad = true;
                    rd.Width = 600;
                    rd.Height = 500;
                    rd.Left = 400;
                    rd.Top = 150;
                    RadWindowManager1.Windows.Add(rd);
                }
                else
                {
                    lblcomp.Visible = true;
                    lblcomp.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(96);
                    //lblcomp.Text = "You must be logged in to view the company profile";
                }
            }
            catch
            {
            }
        }

        protected void RadComboBox1_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objCompanySearchSH.IndustryName = Industry.Text;
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {

            Response.Redirect("CompanySearchAdvanced.aspx");



        }

        protected void RadGrid1_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem item = e.Item as GridDataItem;
                CompanySearchFA objCompanySearchFA = new CompanySearchFA();
                string Photo = (item["LogoPath"].Text.ToString());
                string log="0.png";
                if (Photo == log)
                {
                    Image img = item["TemplateColumn"].FindControl("Image1") as Image;
                    img.ImageUrl = PhotoPath + Photo;
                }
                else
                {
                    Image img = item["TemplateColumn"].FindControl("Image1") as Image;
                    img.ImageUrl = PhotoDirectoryPath + Photo;
                }
                if (SessionInfo.RoleID == "JS" || SessionInfo.RoleID == "ST")
                {
                    LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton2") as LinkButton;
                    lnkbtn.Visible = true;
                }
                else
                {
                    LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton2") as LinkButton;
                    lnkbtn.Visible = false;
                }

            }

        }

        protected void LinkButton2_Click1(object sender, EventArgs e)
        {
            try
            {

                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton2");
                string EmailID = Convert.ToString(gr["EmailID"].Text.ToString());
                string mailform = string.Format("~/CompanySendmail.aspx?param1={0}&param2={1}", UserID, EmailID);
                if (SessionInfo.UserId != int.MinValue)
                {

                    RadWindow rdwndwCstmrSpprt = new RadWindow();
                    rdwndwCstmrSpprt.ID = "rdwndwCustomerSupport";
                    rdwndwCstmrSpprt.NavigateUrl = mailform;
                    rdwndwCstmrSpprt.OffsetElementID = Convert.ToString(LinkButton2.ClientID);

                    rdwndwCstmrSpprt.Top = -40;
                    rdwndwCstmrSpprt.Left = -440;
                    rdwndwCstmrSpprt.Width = 440;
                    rdwndwCstmrSpprt.Height = 420;
                    rdwndwCstmrSpprt.VisibleStatusbar = false;
                    rdwndwCstmrSpprt.Title = "";
                    rdwndwCstmrSpprt.Behaviors = (Telerik.Web.UI.WindowBehaviors)Enum.Parse(typeof(Telerik.Web.UI.WindowBehaviors), "Close");
                    rdwndwCstmrSpprt.VisibleStatusbar = false;
                    rdwndwCstmrSpprt.VisibleOnPageLoad = true;
                    RadWindowManager1.KeepInScreenBounds = true;
                    RadWindowManager1.Windows.Add(rdwndwCstmrSpprt);


                }
                else
                {
                    lblcomp.Visible = true;
                    //lblcomp.Text = "You must be logged in to view the company profile";
                    lblcomp.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(96);
                }
            }
            catch
            {
            }
        }
        private DataTable GetCompanyAsses(int UserID)
        {
                          CompanySearchFA objCompanySearchFA = new CompanySearchFA();
                return objCompanySearchFA.GetCompanyAsses(UserID);
           
        }
       
        private DataTable BindTableForGridEntry()
        {
            try
            {
                this.GetTempCompleteDetail.Columns.Add(new DataColumn("percentAge", typeof(string)));
                foreach (DataRow ndr in this.GetTempCompleteDetail.Rows)
                {
                    int count = 0;
                    string value = string.Empty;
                    foreach (DataRow tdr in this.GetCompanyAssissmentFit.Rows)
                    {
                        if (tdr["OrganisationID"].ToString() == ndr["OrganisationID"].ToString())
                        {
                            value = tdr["percentAge"].ToString();
                            count = 1;
                        }


                    }
                    if (count != 0)
                    {
                        ndr["percentAge"] = value;
                        this.GetTempCompleteDetail.AcceptChanges();
                    }
                    else
                    {
                        ndr["percentAge"] = "NA";
                        this.GetTempCompleteDetail.AcceptChanges();
                    }

                }
                return this.GetTempCompleteDetail;
            }

            catch 
            {
                return this.GetTempCompleteDetail;
            }
        }
        private void BindGridValue()
        {

            try
            {
                if (this.GetCompleteDetail.Rows.Count != 0)
                {

                    RadGrid1.DataSource = this.GetCompleteDetail;
                    RadGrid1.DataBind();
                   

                }
                else
                {
                    RadGrid1.DataSource = this.GetCompleteDetail;
                    RadGrid1.DataBind();
                }
            }

            catch
            {

            }
        }
        protected void getPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;

                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_CompanySearch");
                LCompanyName.Text = (string)GetGlobalResourceObject("PageResource", "Label11_PostJobCompanyInformation");
                LIndustry.Text = (string)GetGlobalResourceObject("PageResource", "LblIndustry_Registration");
                LCountry.Text = (string)GetGlobalResourceObject("PageResource", "Label10_ScreeningSchedule");
                LCity.Text = (string)GetGlobalResourceObject("PageResource", "Label11_ScreeningSchedule");
                Button1.Text = (string)GetGlobalResourceObject("PageResource", "btnFind_ResumeVsSavedJobs");
                RadGrid1.MasterTableView.NoDetailRecordsText = (string)GetGlobalResourceObject("PageResource", "RadGrid1_JobSearch");
            }
            catch
            {
            }

        }

        

    }
}

