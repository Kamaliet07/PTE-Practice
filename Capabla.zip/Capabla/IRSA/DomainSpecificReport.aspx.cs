﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
using iTextSharp.text.pdf;
using System.Configuration;
using System.IO;
using IRSA.Facade;
using Telerik.Web.UI;
using Telerik.Reporting;
using System.Reflection;
using System.ComponentModel;
using ReportLibrary;

namespace IRSA
{
    public partial class DomainSpecificReport : System.Web.UI.Page
    {
        int UserID;
        string ChartsFilePath;
        string EID="4.A.%";
        string ElID;
        string reportName;
        int AttemptID;
        string CultureID;
        string Questemplatename = "Job-domain Specific";
        public string JobOccupation
        {
            set
            {
                ViewState["JobOccupation"] = value;
            }
            get
            {
                if (ViewState["JobOccupation"] == null)
                {
                    ViewState["JobOccupation"] = "";
                }
                return ViewState["JobOccupation"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                    AttemptID = SessionInfo.AttemptID;
                    CultureID = SessionInfo.CultureID;
                    ChartsFilePath = ConfigurationSettings.AppSettings["ChartsFilePath"];
                    UserID = SessionInfo.UserId;
                    
            if (!IsPostBack)
            {

                    
                    string jobmaillyID = SessionInfo.JobfamilyIDforjobDomain;
                    ComboboxoccupationBind(Convert.ToInt32(jobmaillyID));
                    JobOccupation = DdlRole.SelectedItem.Text;
                    SessionInfo.JobOccupation = JobOccupation;
                    GetRadar(EID, Questemplatename, JobOccupation);
                    //bindchart(jobmaillyID, Questemplatename, JobOccupation);
                    getrpt();
            
                
            }
          }
        catch { }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            try
            {
                JobOccupation = DdlRole.SelectedItem.Text;
                SessionInfo.JobOccupation = JobOccupation;
                GetRadar(EID, Questemplatename, JobOccupation);
                //bindchart(EID, Questemplatename, JobOccupation);
                getrpt();
            }
            catch { }
        }
        public void ComboboxoccupationBind(int jobmaillyID)
        {
            try
            {
                SkillQuestionnaireFA objFA = new SkillQuestionnaireFA();
                DataTable temp = new DataTable();
                temp = objFA.BindOccupation(jobmaillyID);
                DdlRole.DataSource = temp;
                DdlRole.DataBind();
            }
            catch
            {
            }
        }
        private void GetRadar(string ID, string Name, string OnetTitle)
        {
            try
            {
                EID = ID;
                ElID = OnetTitle;
                double[] data = new double[4];
                double[] data1 = new double[4];
                double[] fixeddata = { 3.5, 3.5, 3.5, 3.5, 3.5 };
                double[] fixeddata1 = { 4.25, 4.25, 4.25, 4.25, 4.25 };
                // The labels for the chart
                string[] labels = new string[4];

                DataTable dtrpt = new DataTable();
                JobdomainFA objjobFA = new JobdomainFA();
                dtrpt = objjobFA.GetJobDomainReportData(EID, OnetTitle, Name, CultureID, UserID, AttemptID);
                if (dtrpt.Rows.Count > 0)
                {
                    for (int i = 0; i < dtrpt.Rows.Count; i++)
                    {

                        data[i] = Convert.ToDouble(dtrpt.Rows[i]["DataValue"].ToString());
                        data1[i] = Convert.ToDouble(dtrpt.Rows[i]["DataValueAvg"].ToString());
                        labels[i] = dtrpt.Rows[i]["ElementName"].ToString();
                    }
                }
                // Create a PolarChart object of size 450 x 350 pixels
                ChartDirector.PolarChart c = new ChartDirector.PolarChart(800, 550, ChartDirector.Chart.silverColor(), 0x000000, 1);

                // Set center of plot area at (225, 185) with radius 150 pixels
                c.setPlotArea(400, 250, 200, 0xffcccc);
                ChartDirector.PolarLineLayer pl = new ChartDirector.PolarLineLayer();
                ChartDirector.LegendBox b = c.addLegend(400, 520, false, "Arial Bold", 10);

                b.setAlignment(ChartDirector.Chart.BottomCenter);
                b.setBackground(ChartDirector.Chart.silverColor(), ChartDirector.Chart.Transparent, 1);
                // Add an area layer to the polar chart
                c.addAreaLayer(fixeddata1, 0xa0bce0, "Favoural Zone(3.5 to 4.25)");
                c.addAreaLayer(fixeddata, 0xffcccc);
                if (CultureID == "NL")
                {
                    pl = c.addLineLayer(data, 0x800000, "zelf");
                }
                else if (CultureID == "EN")
                {
                    pl = c.addLineLayer(data, 0x800000, "Self");
                }
                pl.setDataSymbol(ChartDirector.Chart.DiamondSymbol, 13);
                pl.setLineWidth(3);
                if (CultureID == "EN")
                {
                    pl = c.addLineLayer(data1, 0x008000, "Role:" + "[" + OnetTitle + "]");
                }
                else if (CultureID == "NL")
                {
                    pl = c.addLineLayer(data1, 0x008000, "Rol:" + "[" + OnetTitle + "]");
                }
                pl.setDataSymbol(ChartDirector.Chart.CircleSymbol, 12);
                pl.setLineWidth(3);
                // Set the labels to the angular axis as spokes
                c.angularAxis().setLabels(labels);
                c.radialAxis().setLinearScale(0, 6, 1);
                // Output the chart
                WebChartViewer1.Image = c.makeWebImage(ChartDirector.Chart.PNG);

                //include tool tip for the chart
                WebChartViewer1.ImageMap = c.getHTMLImageMap("", "",
                    "title='{label}: score = {value}'");
                string filename = c.makeTmpFile(ChartsFilePath);
                string filesave;
                string filee = ChartsFilePath + filename;
                filesave = ChartsFilePath + UserID + "jobdomain" + ".png";
                ResizeImage(filee, filesave, 600, 400);
            }
            catch { }
        }
        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(OriginalFile);

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                NewImage.Save(NewFile);
            }
            catch
            {
            }
        }
       
        public void getrpt()
        {
            try
            {
                foreach (Type t in ReportExplorer.GetReports())
                {
                    DescriptionAttribute description =
                        TypeDescriptor.GetAttributes(t)[typeof(DescriptionAttribute)] as DescriptionAttribute;

                    object[] values = new object[]
                {
                   reportName = t.AssemblyQualifiedName
                };
                    reportName = Server.UrlDecode(reportName);
                    Type reportType = Type.GetType(reportName);
                    if (reportType.Name == "DomainspecificAssessment" || reportType.Name == "DomainspecificAssessment_nl")
                    {
                        if (CultureID == "EN")
                        {
                            if (reportType.Name == "DomainspecificAssessment")
                            {
                                IReportDocument report = (IReportDocument)Activator.CreateInstance(reportType);
                                this.ReportViewer1.Report = report;
                                this.ReportViewer1.Resources.ProcessingReportMessage = "Generating Domainspecific Report...";
                                this.ReportViewer1.Resources.ExportButtonText = "Get Report";
                                this.Page.Title = "DomainspecificAssessment Report";
                                goto Last;
                            }
                        }
                        else if (CultureID == "NL")
                        {
                            if (reportType.Name == "DomainspecificAssessment_nl")
                            {
                                IReportDocument report = (IReportDocument)Activator.CreateInstance(reportType);
                                this.ReportViewer1.Report = report;
                                this.ReportViewer1.ProgressText = "Genereren Domainspecific rapport...";
                                this.ReportViewer1.Resources.ExportButtonText = "Krijgen rapport";
                                this.Page.Title = "DomainspecificAssessment Rapport";
                                goto Last;
                            }
                        }
                    }

                }
            Last: ;

            }
            catch { }
               
        }
    }
}
