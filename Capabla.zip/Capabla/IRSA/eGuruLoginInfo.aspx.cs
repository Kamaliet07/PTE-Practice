﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Web.Security;
using System.Net.Mail;

namespace IRSA
{
    public partial class eGuruLoginInfo : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;

            if (UserID != int.MinValue)
            {
                Lblmember.Text = SessionInfo.Username + " " + "!";
            }
            else
            {
                Lblmember.Text = "Guest" + " " + "!";
            }
            Page.Form.DefaultButton = BtnEnter.UniqueID;
        }

        protected void LinkButtonForgot_Click(object sender, EventArgs e)
        {
            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";
            rd.NavigateUrl = "~/ForgotPassword1.aspx";
            rd.VisibleOnPageLoad = true;
            rd.Width = 350;
            rd.Height = 250;
            rd.Left = 400;
            rd.Top = 320;
            RadWindowManager1.Windows.Add(rd);
        }


        protected void BtnSignIn_Click(object sender, EventArgs e)
        {

            string email;
            LoginSH objsh = new LoginSH();
            email = TbUserName.Text;
            if (Validation.IsValidEmailAddress(email))
            {
                objsh.UserID = email;
                objsh.Password = TbPaswd.Text;

            }
            else
            {
                if (TbUserName.Text == null || TbPaswd.Text == null)
                {
                    Lblerror.Visible = true;
                    Lblerror.Text = "Enter vaild email/Password";

                }
            }

            objsh.EmailID = TbUserName.Text;
            LoginFA objFA = new LoginFA();
            Encryption.HashPwd(TbPaswd.Text);
            string password = Encryption.HashPwd(TbPaswd.Text);
            objsh.Password = password;
            if (Encryption.verifyPwd(TbPaswd.Text, objsh.Password) && objsh.EmailID == TbUserName.Text)
            {
                objFA.GetValidate(objsh);


                int y = Convert.ToInt32(SessionInfo.UserId);
                String who = Convert.ToString(SessionInfo.RoleID);
                if (y > 0 && (who == "OR" || who == "RC"))
                {
                    MembershipUser search = Membership.GetUser(this.TbUserName.Text);
                    if (search == null)
                    {
                        MembershipCreateStatus status;
                        search = Membership.CreateUser(this.TbUserName.Text, TbPaswd.Text, this.TbUserName.Text, "What does 1+1 equal?", "2", true, out status);
                    }
                    FormsAuthentication.RedirectFromLoginPage(search.UserName, false);
                    DataTable dtorgid = new DataTable();
                    dtorgid = objFA.GetOrgID();
                    if (dtorgid.Rows.Count > 0)
                    {
                        SessionInfo.OrganisationID = Convert.ToInt32(dtorgid.Rows[0]["OrganisationID"].ToString());
                        SessionInfo.OrgID = Convert.ToInt32(dtorgid.Rows[0]["OrganisationID"].ToString());
                    }

                    if (who == "OR" || who == "RC")
                    {
                        Response.Redirect("TrainingPosting.aspx");
                    }

                }

                else
                {
                    if (!(who == "RC") && (email != "" && TbPaswd.Text != ""))
                    {
                        Lblmessage.Visible = true;
                        Lblmessage.Text = "You are not a Recruiter";
                    }
                    else if (!(who == "RC") && (email != "" && TbPaswd.Text == ""))
                    {
                        Lblmessage.Visible = true;
                        Lblmessage.Text = "Enter your password";
                    }

                    else if (!(who == "RC") && (email == "" && TbPaswd.Text != ""))
                    {
                        Lblmessage.Visible = true;
                        Lblmessage.Text = "Enter your User ID";
                    }
                    else
                    {
                        Lblmessage.Visible = true;
                        Lblmessage.Text = "Enter Correct EmailID/Password";
                    }
                }
            }
        }

        protected void BtnGetStarted_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
    }
}
