﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class PHOTOUPLOAD : System.Web.UI.Page
    {
        string PhotoDirectoryPath;
        string ResumeDirectoryPath;
        string OriginalFile;
        string NewFile;
        int NewWidth;
        int MaxHeight;
        bool OnlyResizeIfWider;
        string file;
        string str2;
        string AppName;
        int UserID;
        string CurrentWizardStep = "Welcome";
        string[] Format = { "jpg", "jpeg", "png", "gif", "bmp", "JPG", "JPEG", "PNG", "GIF", "BMP" };
        protected void Page_Load(object sender, EventArgs e)
        {
            {
                UserID = 89;
                PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];
                
            }
        }
     
     
     
        string Photo;
        protected void Upload_Click(object sender, EventArgs e)
        {
        
                try
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    AccountsetupSH objaccSH = new AccountsetupSH();
                    file = FileUpload1.FileName;
                    if (file != "")
                    {
                        for (int i = 0; i < Format.Length; i++)
                        {
                            string var = PhotoDirectoryPath + UserID + "." + Format[i];
                            FileInfo fiPath = new FileInfo(Server.MapPath(var));
                            if (fiPath.Exists)
                            {
                                //Delete the file from sever
                                File.Delete(Server.MapPath(var));
                            }
                        }
                        //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                        string strphoto = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                        FileUpload1.SaveAs(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto));
                        HttpPostedFile myFile = FileUpload1.PostedFile;
                        int nFileLen = myFile.ContentLength;
                        if (nFileLen > 0)
                        {
                            IRSA.Common.GlobalFunction.ResizeImage objImage = new IRSA.Common.GlobalFunction.ResizeImage();
                            objImage.ResizeFromStream(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto), 100, myFile.InputStream);
                        }

                        Photo = UserID + "." + strphoto;

                    }
                    else
                    {

                        DataTable dtphoto = new DataTable();
                        dtphoto = objaccFA.GetaccountData(UserID);
                        if (dtphoto.Rows.Count > 0)
                        {
                            Photo = dtphoto.Rows[0]["PhotoID"].ToString();
                        }
                        else
                        {
                            Photo = "0.png";
                        }


                    }


                    objaccFA.insertphoto(Photo, UserID);
                    Image1.Visible = true;
                    Image1.ImageUrl = PhotoDirectoryPath + Photo;
                  

            }
            catch{}

        }

       
    }
}