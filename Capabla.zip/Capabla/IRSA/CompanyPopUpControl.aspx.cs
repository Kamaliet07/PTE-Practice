﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;
using System.Globalization;
using Telerik.Web.UI;
using System.IO;
using IRSA.Facade;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA
{
    public partial class CompanyPopUpControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetData();
        }
        public void GetData()
        {
            string Organisation = Request.QueryString.Get("id");
            int OrganisationID = Convert.ToInt32(Organisation);
            DataTable dtCompanyPopUp = new DataTable();
            FindAgencyFA objCompanyPopUpControl = new FindAgencyFA();
            dtCompanyPopUp = objCompanyPopUpControl.GetCompanyPopUpControl(OrganisationID);
            if (dtCompanyPopUp.Rows.Count > 0)
            {
                string url = dtCompanyPopUp.Rows[0]["Website"].ToString();
                Response.Redirect(url);
                
              
            }

        }
    }
}
