﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Data;

namespace IRSA
{
    public partial class CareerLadderHealthCare : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void lnkBtnRN(object sender, EventArgs e)
        {
            int i = 0;
            Response.Redirect("CareerLadderHealthCareInfo.aspx?id=" + i);
        }

        protected void lnkBtnLPN(object sender, EventArgs e)
        {
            int i = 1;
            Response.Redirect("CareerLadderHealthCareInfo.aspx?id=" + i);
        }

        protected void lnkBtnCNA(object sender, EventArgs e)
        {
            int i = 2;
            Response.Redirect("CareerLadderHealthCareInfo.aspx?id=" + i);
        }

        protected void lnkBtnHomeHealthAide(object sender, EventArgs e)
        {
            int i = 3;
            Response.Redirect("CareerLadderHealthCareInfo.aspx?id=" + i);
        }

        protected void lnkBtnPersonalandHomeCareAide(object sender, EventArgs e)
        {
            int i = 4;
            Response.Redirect("CareerLadderHealthCareInfo.aspx?id=" + i);
        }

        protected void lnkBtnDirectSupportProfessional(object sender, EventArgs e)
        {
            int i = 5;
            Response.Redirect("CareerLadderHealthCareInfo.aspx?id=" + i);
        }

        
        protected void ImgbtnItmngrConsul_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void ImageButton16_Click(object sender, ImageClickEventArgs e)
        {

        }

       

        protected void lnkbtnCLITBAck_Click1(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderIntroduction.aspx");
        }

    }
}
