﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
using iTextSharp.text.pdf;
using System.Configuration;
using System.IO;
using IRSA.Facade;
using Telerik.Web.UI;
using System.ComponentModel;
using Telerik.Reporting;
using ReportLibrary;
namespace IRSA
{
    public partial class Knowledge : System.Web.UI.Page
    {
        string reportName;
        int UserID;
        string ChartsFilePath;
        string EID;
        string ElID;
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                ChartsFilePath = ConfigurationSettings.AppSettings["ChartsFilePath"];
                UserID = SessionInfo.UserId;
                getKnowledgeradar("[2].[C].[1-9].[a-z]", "Knowledge", "2.%");
                foreach (Type t in ReportExplorer.GetReports())
                {
                    DescriptionAttribute description =
                        TypeDescriptor.GetAttributes(t)[typeof(DescriptionAttribute)] as DescriptionAttribute;

                    object[] values = new object[]
                {
                   reportName = t.AssemblyQualifiedName
                };
                    reportName = Server.UrlDecode(reportName);
                    Type reportType = Type.GetType(reportName);
                    if (reportType.Name == "KnowledgeAssessment")
                    {
                        IReportDocument report = (IReportDocument)Activator.CreateInstance(reportType);
                        this.ReportViewer1.Report = report;
                        this.Page.Title = "KnowledgeAssessment Report";
                    }

                }

            }
            catch
            { }

        }
        public void getKnowledgeradar(string ID, string Name, string EiD)
        {
            EID = ID;
            ElID = EiD;
            double[] data = new double[8];

            // The labels for the chart
            string[] labels = new string[8];
            DataTable dtrpt = new DataTable();
            dtrpt = ReportBL.GetReportData(EID, ElID, "Knowledge Questionnaire");
            if (dtrpt.Rows.Count > 0)
            {
                for (int i = 0; i < dtrpt.Rows.Count; i++)
                {

                    data[i] = Convert.ToDouble(dtrpt.Rows[i]["YourRating"].ToString());
                    labels[i] = dtrpt.Rows[i]["ElementName"].ToString();
                }
            }
            // Create a PolarChart object of size 450 x 350 pixels
            ChartDirector.PolarChart c = new ChartDirector.PolarChart(800, 500, ChartDirector.Chart.silverColor(), 0x000000, 1);

            // Set center of plot area at (225, 185) with radius 150 pixels
            c.setPlotArea(400, 250, 200, 0xffcccc);
            ChartDirector.PolarLineLayer pl = new ChartDirector.PolarLineLayer();
            // Add an area layer to the polar chart
            pl = c.addLineLayer(data, 0x800000);
            pl.setDataSymbol(ChartDirector.Chart.DiamondSymbol, 12);
            pl.setLineWidth(3);

            // Set the labels to the angular axis as spokes
            c.angularAxis().setLabels(labels);
            c.radialAxis().setLinearScale(0, 6, 1);
            // Output the chart
            WebChartViewer1.Image = c.makeWebImage(ChartDirector.Chart.PNG);

            //include tool tip for the chart
            WebChartViewer1.ImageMap = c.getHTMLImageMap("", "",
                "title='{label}: score = {value}'");
            string filename = c.makeTmpFile(ChartsFilePath);
            string filesave;
            string filee = ChartsFilePath + filename;
            filesave = ChartsFilePath + UserID + Name + ".png";
            ResizeImage(filee, filesave, 700, 400);
        }
        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(OriginalFile);

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                NewImage.Save(NewFile);
            }
            catch
            {
            }
        }
    }
}
