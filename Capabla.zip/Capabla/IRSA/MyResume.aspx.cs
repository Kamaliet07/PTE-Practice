﻿using ASPNetFlashVideo;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using IRSA.Facade;
using IRSA.Shared;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Resources;
using System.Security.Cryptography;
using System.Threading;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class MyResume : System.Web.UI.Page
    {
        int userID;
        string ResumeDirectoryPath;
        string VidResumeSaveDirectoryPath;
        string VidResumeRetrieveDirectoryPath;
        DataTable dtAllowed;
        DataTable dtBlocked;
        string tooltip_MyJobCentre = "TooltipMsgCVUpload.xml";
        string CULINFO;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Response.Cache.SetExpires(DateTime.Now.AddYears(-1));
                getPageLanguageInfo();
                userID = SessionInfo.UserId;
                if (userID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(userID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";

                }
                else
                {
                    Response.Redirect("Login.aspx");
                }

                ResumeDirectoryPath = ConfigurationSettings.AppSettings["userResume"];
                VidResumeSaveDirectoryPath = ConfigurationSettings.AppSettings["VideoResumeSave"];
                VidResumeRetrieveDirectoryPath = ConfigurationSettings.AppSettings["VideoResumeRetrieve"];


                if (!IsPostBack)
                {
                    dtAllowed = new DataTable();
                    DataColumn dcNm = new DataColumn("Name");
                    dtAllowed.Columns.Add(dcNm);
                    dcNm = new DataColumn("OrganisationID");
                    dtAllowed.Columns.Add(dcNm);
                    radgridBlocked.DataSource = MyResFA.blockedList(userID, 0, "", "");
                    dtBlocked = MyResFA.blockedList(userID, 0, "", "");
                    if (dtBlocked.Columns.Count == 0)
                    {
                        dtBlocked = new DataTable();
                        dcNm = new DataColumn("Name");
                        dtBlocked.Columns.Add(dcNm);
                        dcNm = new DataColumn("OrganisationID");
                        dtAllowed.Columns.Add(dcNm);
                    }
                    ViewState["DTBlocked"] = null;
                    ViewState["DTBlocked"] = dtBlocked;
                    ViewState["DTAllowed"] = null;
                    ViewState["DTAllowed"] = dtAllowed;
                    radgridBlocked.DataBind();
                    if (MyResFA.ResumeFileName(userID, 0) != "")
                    {
                        lblClickHere.Visible = true;
                        imgbtnCVIcon.Visible = true;
                        lblResUpldSccssfl.Visible = false;
                    }
                    else
                    {
                        lblClickHere.Visible = false;
                        imgbtnCVIcon.Visible = false;
                        lblResUpldSccssfl.Visible = false;
                    }


                    imgbtnResTips.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, tooltip_MyJobCentre);
                    imgCVSelect.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(7, tooltip_MyJobCentre) + "<br />" + ToolTipMessages.GetiRsaToolTipModuleWiseMessage(8, tooltip_MyJobCentre) + "<br />" + ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, tooltip_MyJobCentre);
                    imgSelectVisibility.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(10, tooltip_MyJobCentre) + "<br />" + ToolTipMessages.GetiRsaToolTipModuleWiseMessage(11, tooltip_MyJobCentre) + "<br />" + ToolTipMessages.GetiRsaToolTipModuleWiseMessage(12, tooltip_MyJobCentre);
                    radedtrTxtPasteRes.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(13, tooltip_MyJobCentre);

                    foreach (Telerik.Web.UI.RadWindow win in RadWindowManager1.Windows)
                        win.Dispose();

                    getPastedResume();


                    //Load video resume if one has been uploaded by the current user
                    if (MyResFA.ResumeFileName(userID, 1) != "")
                    {
                        vidResCntrlCnnct();
                    }
                }

                //Display certain hidden labels depending on the state of the user's profile
                if (MyResFA.ResumeFileName(userID, 0) != "")
                {
                    lblClickHere.Visible = true;
                    imgbtnCVIcon.Visible = true;
                    lblResUpldSccssfl.Visible = false;
                }
                else
                {
                    lblClickHere.Visible = false;
                    imgbtnCVIcon.Visible = false;
                    lblResUpldSccssfl.Visible = false;
                }
                if (MyResFA.ResumeFileName(userID, 1) != "")
                {
                    vidResCntrlCnnct();
                }
                foreach (Telerik.Web.UI.RadWindow win in RadWindowManager1.Windows)
                    win.Dispose();
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________


        //Fetch pasted resume from the database

        void getPastedResume()
        {
            try
            {
                DataTable dtTmp = new DataTable();
                dtTmp = MyResFA.blockedList(userID, 3, "", "");
                if (dtTmp.Rows.Count > 0)
                    radedtrTxtPasteRes.Content = Convert.ToString(dtTmp.Rows[0]["TextResume"]);
                else
                    radedtrTxtPasteRes.Content = string.Empty;
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________


        //Function to upload resume


        protected void TxtResUpld(object sender, EventArgs e)
        {
            try
            {
                string file;
                if (flupldTxtRes.HasFile)
                {
                    HttpPostedFile postedfile = flupldTxtRes.PostedFile;
                    file = flupldTxtRes.FileName;
                    string str = file.Split(new string[] { "." }, 3, StringSplitOptions.None)[1];
                    if (str == "doc" || str == "DOC" || str == "docx" || str == "DOCX" || str == "pdf" || str == "PDF" || str == "odf" || str == "ODF")
                    {
                        if (postedfile.ContentLength <= (1024 * 500))
                        {
                            MyResSH objMyResSH = new MyResSH();
                            userID = SessionInfo.UserId;
                            flupldTxtRes.SaveAs(ResumeDirectoryPath + userID + "C." + str);
                            objMyResSH.ResumeID = userID + "C." + str;
                            MyResFA objMyResFA = new MyResFA();
                            objMyResFA.UpldRes(objMyResSH, userID, 1);
                            lblDocResFileSizeExceed.Visible = false;
                            lblInvalidExtensionDoc.Visible = false;
                            lblDocResFieldBlank.Visible = false;
                            lblResUpldSccssfl.Visible = false;
                            lblPstdTextLimitExceed.Visible = false;
                            lblPstdResFieldBlank.Visible = false;
                            lblInvalidExtensionVid.Visible = false;
                            lblVidResUpldSuccssfl.Visible = false;
                            lblVidResFieldBlank.Visible = false;
                            lblVidProcessFail.Visible = false;
                            lblResUpldSccssfl.Visible = true;
                            lblClickHere.Visible = true;
                            imgbtnCVIcon.Visible = true;
                        }
                        else
                        {
                            lblDocResFileSizeExceed.Visible = false;
                            lblInvalidExtensionDoc.Visible = false;
                            lblDocResFieldBlank.Visible = false;
                            lblResUpldSccssfl.Visible = false;
                            lblPstdTextLimitExceed.Visible = false;
                            lblPstdResFieldBlank.Visible = false;
                            lblInvalidExtensionVid.Visible = false;
                            lblVidResUpldSuccssfl.Visible = false;
                            lblVidResFieldBlank.Visible = false;
                            lblVidProcessFail.Visible = false;
                            lblDocResFileSizeExceed.Visible = true;
                        }
                    }
                    else
                    {
                        lblDocResFileSizeExceed.Visible = false;
                        lblInvalidExtensionDoc.Visible = false;
                        lblDocResFieldBlank.Visible = false;
                        lblResUpldSccssfl.Visible = false;
                        lblPstdTextLimitExceed.Visible = false;
                        lblPstdResFieldBlank.Visible = false;
                        lblInvalidExtensionVid.Visible = false;
                        lblVidResUpldSuccssfl.Visible = false;
                        lblVidResFieldBlank.Visible = false;
                        lblVidProcessFail.Visible = false;
                        lblInvalidExtensionDoc.Visible = true;
                    }
                }
                else
                {
                    lblDocResFileSizeExceed.Visible = false;
                    lblInvalidExtensionDoc.Visible = false;
                    lblDocResFieldBlank.Visible = false;
                    lblResUpldSccssfl.Visible = false;
                    lblPstdTextLimitExceed.Visible = false;
                    lblPstdResFieldBlank.Visible = false;
                    lblInvalidExtensionVid.Visible = false;
                    lblVidResUpldSuccssfl.Visible = false;
                    lblVidResFieldBlank.Visible = false;
                    lblVidProcessFail.Visible = false;
                    lblDocResFieldBlank.Visible = true;
                }
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________



        //Function to upload pasted resume

        protected void PstdTxtResUpld(object sender, EventArgs e)
        {
            try
            {

                if (radedtrTxtPasteRes.Content != "")
                {
                    if (radedtrTxtPasteRes.Text.Length < 3000)
                    {
                        MyResSH objMyResSH = new MyResSH();
                        userID = SessionInfo.UserId;
                        objMyResSH.TxtResume = radedtrTxtPasteRes.Content;
                        MyResFA objMyResFA = new MyResFA();
                        objMyResFA.UpldRes(objMyResSH, userID, 3);
                        lblDocResFileSizeExceed.Visible = false;
                        lblInvalidExtensionDoc.Visible = false;
                        lblDocResFieldBlank.Visible = false;
                        lblResUpldSccssfl.Visible = false;
                        lblPstdTextLimitExceed.Visible = false;
                        lblPstdResFieldBlank.Visible = false;
                        lblInvalidExtensionVid.Visible = false;
                        lblVidResUpldSuccssfl.Visible = false;
                        lblVidResFieldBlank.Visible = false;
                        lblVidProcessFail.Visible = false;
                        lblVidProcessFail.Visible = false;
                        getPastedResume();
                    }
                    else
                    {
                        lblDocResFileSizeExceed.Visible = false;
                        lblInvalidExtensionDoc.Visible = false;
                        lblDocResFieldBlank.Visible = false;
                        lblResUpldSccssfl.Visible = false;
                        lblPstdTextLimitExceed.Visible = false;
                        lblPstdResFieldBlank.Visible = false;
                        lblInvalidExtensionVid.Visible = false;
                        lblVidResUpldSuccssfl.Visible = false;
                        lblVidResFieldBlank.Visible = false;
                        lblVidProcessFail.Visible = false;
                        lblPstdTextLimitExceed.Visible = true;
                    }
                }
                else
                {
                    lblDocResFileSizeExceed.Visible = false;
                    lblInvalidExtensionDoc.Visible = false;
                    lblDocResFieldBlank.Visible = false;
                    lblResUpldSccssfl.Visible = false;
                    lblPstdTextLimitExceed.Visible = false;
                    lblPstdResFieldBlank.Visible = false;
                    lblInvalidExtensionVid.Visible = false;
                    lblVidResUpldSuccssfl.Visible = false;
                    lblVidResFieldBlank.Visible = false;
                    lblVidProcessFail.Visible = false;
                    lblPstdResFieldBlank.Visible = true;
                }
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________




        //Function to upload video resume

        protected void VidResUpld(object sender, EventArgs e)
        {
            try
            {
                string file;
                if (flupldVidRes.HasFile)
                {
                    HttpPostedFile postedfile = flupldVidRes.PostedFile;
                    file = flupldVidRes.FileName;
                    string str = file.Split(new string[] { "." }, 3, StringSplitOptions.None)[1];
                    if (str == "mpg" || str == "MPG" || str == "mpeg" || str == "MPEG" || str == "avi" || str == "AVI" || str == "3gp" || str == "3GP" || str == "wmv" || str == "WMV" || str == "vob" || str == "VOB" || str == "mov" || str == "MOV" || str == "flv" || str == "FLV")
                    {
                        if (File.Exists(VidResumeSaveDirectoryPath + userID + "V.flv"))
                            File.Delete(VidResumeSaveDirectoryPath + userID + "V.flv");

                        MyResSH objMyResSH = new MyResSH();
                        userID = SessionInfo.UserId;
                        flupldVidRes.SaveAs(VidResumeSaveDirectoryPath + userID + "V." + str);


                        //Convert the uploaded video to flv

                        Media_handler _mediahandler = new Media_handler();
                        string inputpath = VidResumeSaveDirectoryPath;
                        string outputpath = VidResumeSaveDirectoryPath;
                        string _ffmpegpath = HttpContext.Current.Server.MapPath("~\\ffmpeg\\ffmpeg.exe");
                        string fullstring = _mediahandler.Convert_Media((userID + "V." + str), _ffmpegpath, inputpath, outputpath, "320*240", 32, 44100, "120", true);
                        if (fullstring == "100" || fullstring == "101" || fullstring == "102" || fullstring == "103" || fullstring == "104" || fullstring == "105" || fullstring == "106" || fullstring == "107")
                        {
                            lblDocResFileSizeExceed.Visible = false;
                            lblInvalidExtensionDoc.Visible = false;
                            lblDocResFieldBlank.Visible = false;
                            lblResUpldSccssfl.Visible = false;
                            lblPstdTextLimitExceed.Visible = false;
                            lblPstdResFieldBlank.Visible = false;
                            lblInvalidExtensionVid.Visible = false;
                            lblVidResUpldSuccssfl.Visible = false;
                            lblVidResFieldBlank.Visible = false;
                            lblVidProcessFail.Visible = false;
                            lblVidProcessFail.Visible = true;
                            return;
                        }

                        string[] _arrstr;
                        _arrstr = fullstring.ToString().Split(char.Parse(","));
                        string Encode_Video_Name = _arrstr[0].Remove(0, _arrstr[0].LastIndexOf(":") + 1);
                        string Duration = _arrstr[1].Remove(0, _arrstr[1].IndexOf(":") + 1);


                        //Delete the original file as it has now been converted to flv
                        if (!str.Equals("flv"))
                            File.Delete(VidResumeSaveDirectoryPath + userID + "V." + str);


                        //Save the video resume file name to the database

                        objMyResSH.VidResumeID = Encode_Video_Name;
                        MyResFA objMyResFA = new MyResFA();
                        objMyResFA.UpldRes(objMyResSH, userID, 2);
                        vidResCntrlCnnct();
                        lblDocResFileSizeExceed.Visible = false;
                        lblInvalidExtensionDoc.Visible = false;
                        lblDocResFieldBlank.Visible = false;
                        lblResUpldSccssfl.Visible = false;
                        lblPstdTextLimitExceed.Visible = false;
                        lblPstdResFieldBlank.Visible = false;
                        lblInvalidExtensionVid.Visible = false;
                        lblVidResFieldBlank.Visible = false;
                        lblVidProcessFail.Visible = false;
                        lblVidResUpldSuccssfl.Visible = true;
                    }
                    else
                    {
                        lblDocResFileSizeExceed.Visible = false;
                        lblInvalidExtensionDoc.Visible = false;
                        lblDocResFieldBlank.Visible = false;
                        lblResUpldSccssfl.Visible = false;
                        lblPstdTextLimitExceed.Visible = false;
                        lblPstdResFieldBlank.Visible = false;
                        lblInvalidExtensionVid.Visible = false;
                        lblVidResUpldSuccssfl.Visible = false;
                        lblVidResFieldBlank.Visible = false;
                        lblVidProcessFail.Visible = false;
                        lblInvalidExtensionVid.Visible = true;
                    }
                }
                else
                {
                    lblDocResFileSizeExceed.Visible = false;
                    lblInvalidExtensionDoc.Visible = false;
                    lblDocResFieldBlank.Visible = false;
                    lblResUpldSccssfl.Visible = false;
                    lblPstdTextLimitExceed.Visible = false;
                    lblPstdResFieldBlank.Visible = false;
                    lblInvalidExtensionVid.Visible = false;
                    lblVidResUpldSuccssfl.Visible = false;
                    lblVidResFieldBlank.Visible = false;
                    lblVidProcessFail.Visible = false;
                    lblVidResFieldBlank.Visible = true;
                }
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________




        //Video resume control data binding on page load

        public void vidResCntrlCnnct()
        {
            try
            {
                string vidResURL = String.Empty;
                string VidResFile = string.Empty;
                VidResFile = MyResFA.ResumeFileName(userID, 1);
                vidResURL = (VidResumeRetrieveDirectoryPath + VidResFile);
                flvVidResume.VideoURL = vidResURL;
            }
            catch { }
        }



        protected void RadGrid1_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
        {

        }

        protected void RadGrid2_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
        {

        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________



        //Fill the company/recruiter selection grid with data


        protected void refreshGrid(object sender, EventArgs e)
        {
            try
            {

                //Find out the user search criteria using the checkboxes and the saerch textbox

                string queryArgument = string.Empty;
                string subQueryArgument = string.Empty;
                if (chkboxCompanies.Checked && !chkboxRecruiter.Checked)
                    queryArgument = "OR";
                else if (!chkboxCompanies.Checked && chkboxRecruiter.Checked)
                    queryArgument = "RC";
                else if (chkboxCompanies.Checked && chkboxRecruiter.Checked)
                    queryArgument = "%";
                else
                    queryArgument = "DOES_NOT_EXIST_DUMMY";
                subQueryArgument = txtSearchBox.Text;


                //Get the data from the database based on the search criteria

                dtAllowed = MyResFA.blockedList(userID, 1, queryArgument, subQueryArgument);
                ViewState["DTAllowed"] = null;
                ViewState["DTAllowed"] = dtAllowed;
                dtAllowed = (DataTable)ViewState["DTAllowed"];
                dtBlocked = (DataTable)ViewState["DTBlocked"];


                //Remove the rows those organisations that have been blocked by the user in the current session

                for (int y = 0; y < dtAllowed.Rows.Count; y++)
                    for (int z = 0; z < dtBlocked.Rows.Count; z++)
                        if (Convert.ToInt32(dtAllowed.Rows[y]["OrganisationID"]) == Convert.ToInt32(dtBlocked.Rows[z]["OrganisationID"]))
                        {
                            dtAllowed.Rows[y--].Delete();
                            dtAllowed.AcceptChanges();
                            break;
                        }


                //Refresh grid data

                ViewState["DTAllowed"] = null;
                ViewState["DTAllowed"] = dtAllowed;
                radgridSelect.DataSource = dtAllowed;
                radgridSelect.Rebind();
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________




        //Function to move items from Select Grid to Block Grid and block those organisations

        protected void btnRestrict_Click(object sender, EventArgs e)
        {
            try
            {
                dtAllowed = (DataTable)ViewState["DTAllowed"];
                dtBlocked = (DataTable)ViewState["DTBlocked"];
                if (dtAllowed.Rows.Count > 0)
                {
                    DataColumn dcNm = new DataColumn();
                    dtBlocked = (DataTable)ViewState["DTBlocked"];
                    DataTable dtTemp = new DataTable();
                    dcNm = new DataColumn("Name");
                    dtTemp.Columns.Add(dcNm);
                    dcNm = new DataColumn("OrganisationID");
                    dtTemp.Columns.Add(dcNm);

                    //Move selected rows to dtBlocked
                    for (int count = 0; count < radgridSelect.Items.Count; count++)
                    {
                        CheckBox tempCheckBox = (CheckBox)radgridSelect.Items[count]["chkBoxBlock"].FindControl("chkboxBlockSelectGrid");
                        if (tempCheckBox.Checked == true)
                        {
                            //Copy the selecteted row into dtBlocked

                            DataRow dr = dtBlocked.NewRow();
                            dr = dtAllowed.Rows[count];
                            dtBlocked.ImportRow(dr);

                            //Copy the selected row into dtTemp

                            DataRow DR = dtTemp.NewRow();
                            DR = dtAllowed.Rows[count];
                            dtTemp.ImportRow(DR);

                            //Make the changes inthe datatable permanent

                            dtBlocked.AcceptChanges();
                            dtTemp.AcceptChanges();
                        }
                    }

                    //Remove those rows from dtAllowed that have been moved to dtBlocked
                    for (int y = 0; y < dtAllowed.Rows.Count; y++)
                        for (int z = 0; z < dtTemp.Rows.Count; z++)
                            if (Convert.ToInt32(dtAllowed.Rows[y]["OrganisationID"]) == Convert.ToInt32(dtTemp.Rows[z]["OrganisationID"]))
                            {
                                dtAllowed.Rows[y--].Delete();
                                dtAllowed.AcceptChanges();
                                break;
                            }

                    //Free unused memory
                    dtTemp.Dispose();

                    //Refresh grids
                    ViewState["DTAllowed"] = null;
                    ViewState["DTBlocked"] = null;
                    ViewState["DTAllowed"] = dtAllowed;
                    ViewState["DTBlocked"] = dtBlocked;
                    radgridSelect.DataSource = dtAllowed;
                    radgridBlocked.DataSource = dtBlocked;
                    radgridSelect.Rebind();
                    radgridBlocked.Rebind();
                }
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________




        protected void btnAllow_Click(object sender, EventArgs e)
        {

            try
            {
                dtAllowed = (DataTable)ViewState["DTAllowed"];
                dtBlocked = (DataTable)ViewState["DTBlocked"];
                if (dtBlocked.Rows.Count > 0)
                {
                    DataColumn dcNm = new DataColumn();
                    if (dtAllowed.Columns.Count == 0)
                    {
                        dtAllowed = new DataTable();
                        dcNm = new DataColumn("Name");
                        dtAllowed.Columns.Add(dcNm);
                        dcNm = new DataColumn("OrganisationID");
                        dtAllowed.Columns.Add(dcNm);
                        ViewState["DTAllowed"] = dtAllowed;
                    }
                    DataTable dtTemp = new DataTable();
                    dcNm = new DataColumn("Name");
                    dtTemp.Columns.Add(dcNm);
                    dcNm = new DataColumn("OrganisationID");
                    dtTemp.Columns.Add(dcNm);

                    //Move selected rows to dtAllowed
                    for (int count = 0; count < radgridBlocked.Items.Count; count++)
                    {
                        CheckBox tempCheckBox = (CheckBox)radgridBlocked.Items[count]["chkboxAllow"].FindControl("chkboxRemoveBlock");
                        if (tempCheckBox.Checked == true)
                        {
                            DataRow dr = dtAllowed.NewRow();
                            dr = dtBlocked.Rows[count];
                            dtAllowed.ImportRow(dr);


                            DataRow DR = dtTemp.NewRow();
                            DR = dtBlocked.Rows[count];
                            dtTemp.ImportRow(DR);


                            dtAllowed.AcceptChanges();
                            dtTemp.AcceptChanges();
                        }
                    }

                    //Remove those rows from dtBlocked that have been moved to dtAllowed
                    for (int y = 0; y < dtBlocked.Rows.Count; y++)
                        for (int z = 0; z < dtTemp.Rows.Count; z++)
                            if (Convert.ToInt32(dtBlocked.Rows[y]["OrganisationID"]) == Convert.ToInt32(dtTemp.Rows[z]["OrganisationID"]))
                            {
                                dtBlocked.Rows[y--].Delete();
                                dtBlocked.AcceptChanges();
                                break;
                            }

                    //Free unused memory
                    dtTemp.Dispose();

                    //Refresh grids
                    ViewState["DTAllowed"] = null;
                    ViewState["DTBlocked"] = null;
                    ViewState["DTAllowed"] = dtAllowed;
                    ViewState["DTBlocked"] = dtBlocked;
                    radgridSelect.DataSource = dtAllowed;
                    radgridBlocked.DataSource = dtBlocked;
                    radgridSelect.Rebind();
                    radgridBlocked.Rebind();
                }
            }
            catch { }
        }



        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________




        //Function that blocks organisations

        private void blockOrganisation(RadGrid grid, string templateCol, string checkBoxid, int startCount, string datakeyOrgID)
        {
            try
            {
                //Unblock all organisations for the new list of organisations to be blocked

                MyResFA objMyResFA = new MyResFA();
                objMyResFA.unblockOrganisations(userID);


                //Block all organisations that appear in the "Blocked Organisations" grid :

                for (int count = startCount; count < grid.Items.Count; count++)
                    MyResFA.blockOrganisation(0, userID, Convert.ToInt32(grid.Items[count].GetDataKeyValue(datakeyOrgID)));


                //Refresh the grids :

                string queryArgument = string.Empty;
                string subQueryArgument = string.Empty;
                if (chkboxCompanies.Checked && !chkboxRecruiter.Checked)
                    queryArgument = "OR";
                else if (!chkboxCompanies.Checked && chkboxRecruiter.Checked)
                    queryArgument = "RC";
                else if (chkboxCompanies.Checked && chkboxRecruiter.Checked)
                    queryArgument = "%";
                else
                    queryArgument = "DOES_NOT_EXIST_DUMMY";
                subQueryArgument = txtSearchBox.Text;
                radgridSelect.DataSource = MyResFA.blockedList(userID, 1, queryArgument, subQueryArgument);
                radgridSelect.Rebind();
                radgridBlocked.DataSource = MyResFA.blockedList(userID, 0, "", "");
                radgridBlocked.DataBind();
            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________



        //Event handler for save button in the privacy settings panel

        protected void btnSavePrivacySettings_Click(object sender, EventArgs e)
        {
            try
            {
                //Save resume visibility

                MyResFA objMyResFA = new MyResFA();
                if (rdblstList.Items[0].Selected)
                    objMyResFA.savResumePrivSettings(userID, "Resume_Both", chkboxEveryone.Checked, chkbxMyContacts.Checked, chkboxMyCommunities.Checked);
                else if (rdblstList.Items[1].Selected)
                    objMyResFA.savResumePrivSettings(userID, "Resume_Text", chkboxEveryone.Checked, chkbxMyContacts.Checked, chkboxMyCommunities.Checked);
                else if (rdblstList.Items[2].Selected)
                    objMyResFA.savResumePrivSettings(userID, "Resume_Video", chkboxEveryone.Checked, chkbxMyContacts.Checked, chkboxMyCommunities.Checked);



                //Block organisations in the "Blocked Organisations" list

                blockOrganisation(radgridBlocked, "chkboxAllow", "chkboxRemoveBlock", 0, "OrganisationID");

            }
            catch { }
        }


        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________



        protected void imgbtnCVIcon_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (MyResFA.ResumeFileName(userID, 0) != "")
                {
                    string resumeFileName = MyResFA.ResumeFileName(userID, 0);
                    string filePath = ResumeDirectoryPath + resumeFileName;
                    FileInfo file = new FileInfo(filePath);
                    if (file.Exists)
                    {
                        Response.ClearContent();
                        Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                        Response.ContentType = "application/vnd.word";
                        Response.ContentType = "application/vnd.pdf";
                        Response.Flush();
                        Response.TransmitFile(file.FullName);
                        Response.End();
                    }
                }
            }
            catch { }
        }



        //___________________________________________________________________________
        //___________________________________________________________________________
        //___________________________________________________________________________


        protected void rdedtrTxtChngEvntHndlr(object sender, EventArgs e)
        { }

        protected void imgbtnResTips_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                RadWindow rd = new RadWindow();
                rd.ID = "PopUpViewJobs";
                rd.NavigateUrl = "~/PresentationPages/ResumeTipsPopUP.htm";
                rd.VisibleOnPageLoad = true;
                rd.Behaviors = (Telerik.Web.UI.WindowBehaviors)Enum.Parse(typeof(Telerik.Web.UI.WindowBehaviors), "Close");
                rd.OffsetElementID = Convert.ToString(imgbtnResTips.ClientID);
                rd.Top = 0;
                rd.Left = -540;
                rd.Height = 340;
                rd.Width = 540;
                rd.VisibleStatusbar = false;
                RadWindowManager1.KeepInScreenBounds = true;
                RadWindowManager1.Windows.Add(rd);
            }
            catch { }
        }
        protected void getPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                lblMyJobCenter.Text = (string)GetGlobalResourceObject("PageResource", "lblMyJobCenter_MyResume");
                lblJobCenterInfo.Text = (string)GetGlobalResourceObject("PageResource", "lblJobCenterInfo_MyResume");
                lblTxtResume.Text = (string)GetGlobalResourceObject("PageResource", "lblTxtResume_MyResume");
                lblPasteResume.Text = (string)GetGlobalResourceObject("PageResource", "lblPasteResume_MyResume");
                lblUpldDocRes.Text = (string)GetGlobalResourceObject("PageResource", "lblUpldDocRes_MyResume");
                // btnTxtResUpld.Text = (string)GetGlobalResourceObject("PageResource", "lblJobCenterInfo_MyResume");
                lblDocResFieldBlank.Text = (string)GetGlobalResourceObject("PageResource", "lblDocResFieldBlank_MyResume");
                lblInvalidExtensionDoc.Text = (string)GetGlobalResourceObject("PageResource", "lblDocResFieldBlank_MyResume");
                lblVidResume.Text = (string)GetGlobalResourceObject("PageResource", "lblVidResume_MyResume");
                lblDocResFileSizeExceed.Text = (string)GetGlobalResourceObject("PageResource", "lblDocResFileSizeExceed_MyResume");
                lblFileFormat.Text = (string)GetGlobalResourceObject("PageResource", "lblFileFormat_MyResume");
                lblResUpldSccssfl.Text = (string)GetGlobalResourceObject("PageResource", "lblResUpldSccssfl_MyResume");
                lblClickHere.Text = (string)GetGlobalResourceObject("PageResource", "lblClickHere_MyResume");
                lblVidResUpload.Text = (string)GetGlobalResourceObject("PageResource", "lblVidResUpload_MyResume");
                lblVidResFieldBlank.Text = (string)GetGlobalResourceObject("PageResource", "lblVidResFieldBlank_MyResume");
                lblVidResUpldSuccssfl.Text = (string)GetGlobalResourceObject("PageResource", "lblVidResUpldSuccssfl_MyResume");
                lblInvalidExtensionVid.Text = (string)GetGlobalResourceObject("PageResource", "lblInvalidExtensionVid_MyResume");
                lblVidFileSize.Text = (string)GetGlobalResourceObject("PageResource", "lblVidFileSize_MyResume");
                lblVidProcessFail.Text = (string)GetGlobalResourceObject("PageResource", "lblVidProcessFaill_MyResume");
                lblCharLeft.Text = (string)GetGlobalResourceObject("PageResource", "lblCharLeft_MyResume");
                btnSave.Text = (string)GetGlobalResourceObject("PageResource", "btnSave_MyResume");
                lblPstdResFieldBlank.Text = (string)GetGlobalResourceObject("PageResource", "lblPstdResFieldBlank_MyResume");
                lblPstdTextLimitExceed.Text = (string)GetGlobalResourceObject("PageResource", "lblPstdTextLimitExceed_MyResume");
                lblCharCount.Text = (string)GetGlobalResourceObject("PageResource", "lblCharCount_MyResume");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_MyResume");
                lblSelectCV.Text = (string)GetGlobalResourceObject("PageResource", "lblSelectCV_MyResume");
                lblResVisiblty.Text = (string)GetGlobalResourceObject("PageResource", "lblResVisiblty_MyResume");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_MyResume");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_MyResume");
                lblRestrict.Text = (string)GetGlobalResourceObject("PageResource", "lblRestrict_MyResume");
                btnSavePrivacySettings.Text = (string)GetGlobalResourceObject("PageResource", "btnSavePrivacySettings_MyResume");
            }
            catch
            {
            }

        }
    }
}



//___________________________________________________________________________
//___________________________________________________________________________
//___________________________________________________________________________
