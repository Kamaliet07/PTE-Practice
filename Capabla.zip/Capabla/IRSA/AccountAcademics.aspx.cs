﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class AccountAcademics : System.Web.UI.Page
    {
        string PhotoDirectoryPath;
        string ResumeDirectoryPath;
        int UserID;
        string firstdisplay;
        string strfirstname;
        string OriginalFile;
        string NewFile;
        int NewWidth;
        int MaxHeight;
        bool OnlyResizeIfWider;
        string file;
        string str2;
        string AppName;
        int count;
        string CULINFO;
        string CultureID1;
        string strExp;
        string CurrentWizardStep = "Academics";
       
        string Accountxml = "irsatooltipaccount.xml";
        public string HighestDegree
        {
            set
            {
                ViewState["HighestDegree"] = value;
            }
            get
            {
                if (ViewState["HighestDegree"] == null)
                {
                    ViewState["HighestDegree"] = "";
                }
                return ViewState["HighestDegree"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountAcademicsPageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            Page.Form.DefaultButton = Update.UniqueID;
            UserID = SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
            if (!this.IsPostBack)
            {
                Disableacademics();
                string str = Request.QueryString.Get("id");

                int id = Convert.ToInt32(str);
                if (str != null)
                {

                    str = Request.QueryString.Get("id");

                }
                XmlEducation();
                Bindarea();
                Getdata();
                //education();

            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
               
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["DisplayName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }
                //getAccountAcademicsPageLanguageInfo();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            
        }

        private void Bindarea()
        {
            DataSet ds = new DataSet();
            ds.ReadXml(Server.MapPath("~/xml/studyarea.xml"));
            DataView dv = ds.Tables["Item"].DefaultView;

            Ddnareaspe.DataTextField = "Text";
            Ddnareaspe.DataValueField = "Value";
            Ddnareaspe.DataSource = dv;
            Ddnareaspe.DataBind();
        }

        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(26, Accountxml);
                Txtinstitute.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(25, Accountxml);
                Txtnotes.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(23, Accountxml);
                Txtpassingyear.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(27, Accountxml);
                Txtspecialization.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(24, Accountxml);
                //Txtsplpassingyear.ToolTip = ToolTipMessages.GetiRsaToolTipMessage(18);
                Txtuniversity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(22, Accountxml);

            }
            catch { }
        }


        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {

                    //if (objdt.Rows[0]["PassingYear"].ToString() != "")
                    //{
                    //    Txtpassingyear.Text = objdt.Rows[0]["PassingYear"].ToString();
                    //}
                    //RadCombodegree.Text = objdt.Rows[0]["HighestDegree"].ToString();
                    //Txtuniversity.Text = objdt.Rows[0]["University"].ToString();
                    //Txtnotes.Text = objdt.Rows[0]["AdditionalNotes"].ToString();
                    //Txtspecialization.Text = objdt.Rows[0]["Specialization"].ToString();
                    //Txtinstitute.Text = objdt.Rows[0]["InstituteName"].ToString();
                    //if (objdt.Rows[0]["SplPasingYear"].ToString() != "0")
                    //{
                    //    Txtsplpassingyear.Text = objdt.Rows[0]["SplPasingYear"].ToString();
                    //}
                    RadGridAcademics.DataSource = objdt;
                    RadGridAcademics.DataBind();
                    Panel2.Visible = true;
                    RadGridAcademics.Visible = true;
                }
                else
                {
                    Panel2.Visible = false;
                    RadGridAcademics.Visible = false;
                }

            }
            catch { }
        }

        protected void RadGridAcademics_pageindexchanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {

            RadGridAcademics.CurrentPageIndex = e.NewPageIndex;
            Getdata();
        }


        private void XmlEducation()
        {
            try
            {


                XPathNavigator navdegree;
                XPathDocument docNavdegree;
                XPathNodeIterator NodeIterdegree;
                docNavdegree = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Educationlevel.xml"));
                navdegree = docNavdegree.CreateNavigator();
                if (CultureID1 == "EN")
                {
                    strExp = "/root/English";
                }
                else if (CultureID1 == "NL")
                {
                    strExp = "/root/Dutch";
                }
                NodeIterdegree = navdegree.Select(strExp);
                NodeIterdegree.MoveNext();
                RadCombodegree.LoadXml(NodeIterdegree.Current.InnerXml);


            }
            catch
            {

            }

        }


        public void savedata()
        {
            try
            {
               
                string str;
                string str1;
                str = DateTime.Today.Year.ToString();

                AccountsetupSH objaccaSH = new AccountsetupSH();
                //getcurrentyear();
                if (RadCombodegree.SelectedValue != "")
                {
                    objaccaSH.HighestDegree = RadCombodegree.SelectedValue;
                    if (Txtpassingyear.Text != "")
                    {
                        if (Convert.ToInt32(Txtpassingyear.Text) <= Convert.ToInt32(str))
                        {

                            objaccaSH.PassingYear = Convert.ToInt32(Txtpassingyear.Text);
                            count++;
                        }


                        else
                        {
                            lbldegreeyear.Visible = true;
                            lbldegreeyear.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(68);
                            goto Last;
                        }

                        if (Convert.ToInt32(Txtpassingyear.Text) < 1930)
                        {
                            lbldegreeyear.Visible = true;
                            lbldegreeyear.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(69);
                            goto Last;

                        }


                        else
                        {
                            objaccaSH.PassingYear = Convert.ToInt32(Txtpassingyear.Text);
                            //count++;   
                        }


                    }


                    objaccaSH.University = UCFirst(Txtuniversity.Text);
                    objaccaSH.AdditionalNotes = UCFirst(Txtnotes.Text);
                    objaccaSH.Specialization = UCFirst(Txtspecialization.Text);
                   
                    objaccaSH.InstituteName = UCFirst(Txtinstitute.Text);
                    objaccaSH.SpecializationArea = Ddnareaspe.SelectedValue;
                    #region Profile Progressbar
                    //string path = "~/App_Themes/Site/images/";
                    int i = 0;
                    if (Txtpassingyear.Text != "")
                    {
                        i++;
                    }
                    if (Txtuniversity.Text != "")
                    {
                        i++;
                    }
                    if (Txtnotes.Text != "")
                    {
                        i++;
                    }
                    if (Txtspecialization.Text != "")
                    {
                        i++;
                    }
                    //if (Txtsplpassingyear.Text != "")
                    //{
                    //    i++;
                    //}
                    if (Txtinstitute.Text != "")
                    {
                        i++;
                    }

                    int Acadimic = i * 100 / 5;
                    int AccountWelcome = 0, PastCompany = 0, Experience = 0, PresentCompany = 0, Projects = 0;
                    #endregion

                    AccountsetupFA objaccFA = new AccountsetupFA();
                    objaccFA.InsertAccountSetUpData(objaccaSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                    lbldegreeyear.Visible = false;
                    Lbldatamodified.Visible = true;
                    Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                   
                    Getdata();
                    Disableacademics();

                }
            Last: ;

            }

            catch { }
        }
        public void getcurrentyear()
        {
            string str;

            str = DateTime.Today.Year.ToString();

        }
        protected void btnprev_Click(object sender, EventArgs e)
        {
            try
            {

                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnprev");
                this.HighestDegree = Convert.ToString(RadGridAcademics.MasterTableView.DataKeyValues[gr.ItemIndex]["HighestDegree"]);
                Enableacademics();

                getgriddata();

            }
            catch
            {
            }

        }
        protected void BtnAddacad_Click(object sender, EventArgs e)
        {
            try
            {
                //Panel2.Visible = true;
                //RadGridAcademics.Visible = true;
                this.HighestDegree = "";
              
                Enableacademics();
            }
            catch { }
        }

        public void Enableacademics()
        {
            RadCombodegree.Text = "----Select Education Level----";

            Txtuniversity.Text = "";
            Txtnotes.Text = "";
            Txtspecialization.Text = "";
            Txtinstitute.Text = "";
            Txtpassingyear.Text = "";
            //Txtsplpassingyear.Text = "";
            RadCombodegree.Enabled = true;
            Ddnareaspe.Enabled = true;
            Ddnareaspe.SelectedIndex = 0;
            Txtuniversity.ReadOnly = false;
            Txtnotes.ReadOnly = false;
            Txtspecialization.ReadOnly = false;
            Txtinstitute.ReadOnly = false;
            Txtpassingyear.ReadOnly = false;
        }
        public void Disableacademics()
        {
           
            RadCombodegree.SelectedIndex = 0;

            Txtuniversity.Text = "";
            Txtnotes.Text = "";
            Txtspecialization.Text = "";
            Txtinstitute.Text = "";
            Txtpassingyear.Text = "";
            //Txtsplpassingyear.Text = "";
            RadCombodegree.Enabled = false;
            Ddnareaspe.Enabled = false;
            Ddnareaspe.SelectedIndex = 0;
            Txtuniversity.ReadOnly = true;
            Txtnotes.ReadOnly = true;
            Txtspecialization.ReadOnly = true;
            Txtinstitute.ReadOnly = true;
            Txtpassingyear.ReadOnly = true;
        }

       



        protected void lnkdelete_Click(object sender, EventArgs e)
        {
            try
            {

                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("lnkdelete");
                string HighestDegree = Convert.ToString(RadGridAcademics.MasterTableView.DataKeyValues[gr.ItemIndex]["HighestDegree"]);

                // string UserID = Convert.ToString(RadGridAcademics.MasterTableView.DataKeyValues[gr.ItemIndex]["UserID"]);
                AccountsetupFA objaccFA = new AccountsetupFA();

                objaccFA.deleteacadGridData(UserID, HighestDegree);
                
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = ErrorMessage.GetiRsaErrorMessage(63);

                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {
                    RadGridAcademics.DataSource = objdt;
                    RadGridAcademics.DataBind();
                    Panel2.Visible = true;
                    RadGridAcademics.Visible = true;
                    education();
                    Disableacademics();
                }
                else
                {
                    Panel2.Visible = false;
                    RadGridAcademics.Visible = false;
                    Disableacademics();
                }

            }
            catch
            {
            }
        }
        public void education()
        {
            try
            {
                AccountsetupSH objaccaSH = new AccountsetupSH();

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                string acadrows = string.Empty;
                if (objdt.Rows.Count > 0)
                {
                    foreach (DataRow dr in objdt.Rows)
                    {
                        string educount = dr["HighestDegree"].ToString();
                        if (acadrows == string.Empty)
                        {
                            acadrows = educount;
                        }
                        else
                        {
                            acadrows = acadrows + ',' + educount;
                        }


                    }
                    objaccaSH.Education = acadrows;
                    #region Profile Progressbar
                    //string path = "~/App_Themes/Site/images/";
                    int i = 0;
                    if (Txtpassingyear.Text != "")
                    {
                        i++;
                    }
                    if (Txtuniversity.Text != "")
                    {
                        i++;
                    }
                    if (Txtnotes.Text != "")
                    {
                        i++;
                    }
                    if (Txtspecialization.Text != "")
                    {
                        i++;
                    }
                    //if (Txtsplpassingyear.Text != "")
                    //{
                    //    i++;
                    //}
                    if (Txtinstitute.Text != "")
                    {
                        i++;
                    }

                    int Acadimic = i * 100 / 5;
                    int AccountWelcome = 0, PastCompany = 0, Experience = 0, PresentCompany = 0, Projects = 0;
                    #endregion
                    objaccFA.InserteducationData(objaccaSH, UserID);
                  
                    
                }

            }
            catch { }
        }
        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {
                if (strName.Length > 0)
                {
                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);
                }

            }
            catch { }
            return sb.ToString();
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            savedata();

            education();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.HighestDegree != "")
                {
                    Enableacademics();
                    getgriddata();
                }
                else
                {
                    Disableacademics();
                }
                //Txtsplpassingyear.Text = "";
            }
            catch { }
        }
        public void getgriddata()
        {
            AccountsetupFA objaccFA = new AccountsetupFA();
            DataTable objdtaca = new DataTable();
            objdtaca = objaccFA.GetAcademicGridData(UserID, this.HighestDegree);
          
            if (objdtaca.Rows.Count > 0)
            {
                RadCombodegree.SelectedValue = objdtaca.Rows[0]["HighestDegree"].ToString();
                Txtuniversity.Text = objdtaca.Rows[0]["University"].ToString();
                Txtnotes.Text = objdtaca.Rows[0]["AdditionalNotes"].ToString();
                Txtspecialization.Text = objdtaca.Rows[0]["Specialization"].ToString();
                Txtinstitute.Text = objdtaca.Rows[0]["InstituteName"].ToString();
                if (objdtaca.Rows[0]["PassingYear"].ToString() != "0")
                {
                    Txtpassingyear.Text = objdtaca.Rows[0]["PassingYear"].ToString();
                }
                Ddnareaspe.SelectedValue = objdtaca.Rows[0]["SpecilizaionArea"].ToString();
                //Txtsplpassingyear.Text = objdtaca.Rows[0]["SplPasingYear"].ToString();
            }
            objdtaca = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
            if (objdtaca.Rows.Count > 0)
            {


                RadGridAcademics.DataSource = objdtaca;
                RadGridAcademics.DataBind();
                Panel2.Visible = true;
                RadGridAcademics.Visible = true;
            }
            else
            {
                Panel2.Visible = false;
                RadGridAcademics.Visible = false;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountWelcome.aspx");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountPresentCmy.aspx");

        }

        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }




        }
        protected void getAccountAcademicsPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountAcademics");
                btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountAcademics");
                btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountAcademics");
                Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountAcademics");
                btnAccWlcm.Text = (string)GetGlobalResourceObject("PageResource", "btnAccWlcm_AccountAcademics");
                btnAccAcadmcs.Text = (string)GetGlobalResourceObject("PageResource", "btnAccAcadmcs_AccountAcademics");
                AccPastCmpny.Text = (string)GetGlobalResourceObject("PageResource", "AccPastCmpny_AccountAcademics");
                AccPresCmpny.Text = (string)GetGlobalResourceObject("PageResource", "AccPresCmpny_AccountAcademics");
                AccExprnc.Text = (string)GetGlobalResourceObject("PageResource", "AccExprnc_AccountAcademics");
                AccPrjcts.Text = (string)GetGlobalResourceObject("PageResource", "AccPrjcts_AccountAcademics");
                AccAddtnl.Text = (string)GetGlobalResourceObject("PageResource", "AccAddtnl_accountacademics");
                lblDegree.Text = (string)GetGlobalResourceObject("PageResource", "Lbldegree_AccountAcademics");
                lblPassYr.Text = (string)GetGlobalResourceObject("PageResource", "lblPassYr_AccountAcademics");
                lblUniversity.Text = (string)GetGlobalResourceObject("PageResource", "lblUniversity_AccountAcademics");
                Label63.Text = (string)GetGlobalResourceObject("PageResource", "Label63_AccountAcademics");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountAcademics");
                Update.Text = (string)GetGlobalResourceObject("PageResource", "btnNext_AccountAdditional");
                Reset.Text = (string)GetGlobalResourceObject("PageResource", "Btnnxt_AccountPast");
                RegularExpressionValidator13.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator13_AccountAcademics");
                ImageButton3.Text = (string)GetGlobalResourceObject("PageResource", "ImageButton3_AccountAcademics");
                lblSpclztion.Text = (string)GetGlobalResourceObject("PageResource", "lblSpclztion_AccountAcademics");
                Lblspearea.Text = (string)GetGlobalResourceObject("PageResource", "Lblspearea_AccountAcademics");
                lblNotes.Text = (string)GetGlobalResourceObject("PageResource", "lblNotes_AccountAcademics");
                RadGridAcademics.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdhighestdegree_accacad");
                RadGridAcademics.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdspecarea_accacad");
                RadGridAcademics.Columns[2].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdspecialization_accacad");
                RadGridAcademics.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
                RadGridAcademics.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
                RadGridAcademics.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "grid_pagetext");
                Button1.Text = (string)GetGlobalResourceObject("PageResource", "Update_AccountAcademics");
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
            }
            catch
            {
            }
                        
             
    


        }


    }
}
