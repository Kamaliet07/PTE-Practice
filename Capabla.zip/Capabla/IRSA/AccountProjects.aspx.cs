﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;


namespace IRSA
{
    public partial class AccountProjects : System.Web.UI.Page
    {
        int UserID;
        string AppName;
        string Accountxml = "irsatooltipaccount.xml";
        string CurrentWizardStep = "Projects";
        string CULINFO;
        string CultureID1;
        public string ProjectName
        {
            set
            {
                ViewState["ProjectName"] = value;
            }
            get
            {
                if (ViewState["ProjectName"] == null)
                {
                    ViewState["ProjectName"] = "";
                }
                return ViewState["ProjectName"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountProjectsPageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            Page.Form.DefaultButton = Update.UniqueID;
            UserID = SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
            if (!this.IsPostBack)
            {
                Disableproject();
                string str = Request.QueryString.Get("id");

                int id = Convert.ToInt32(str);
                if (str != null)
                {

                    str = Request.QueryString.Get("id");

                }
                Lbldatamodified.Visible = false;
                Getdata();
            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["DisplayName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }

            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                TxtDescription.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(67, Accountxml);
                TxtSkills.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(65, Accountxml);
                TxtClient.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(64, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(66, Accountxml);
                TxtProjName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(63, Accountxml);

            }
            catch { }
        }

        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {

                    RadGridProject.DataSource = objdt;
                    RadGridProject.DataBind();
                    Pnlgrid.Visible = true;
                    RadGridProject.Visible = true;
                }
                else
                {
                    Pnlgrid.Visible = false;
                }



            }
            catch { }
        }
        protected void btnprojupdate_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnprojupdate");
                this.ProjectName = Convert.ToString(RadGridProject.MasterTableView.DataKeyValues[gr.ItemIndex]["ProjectName"]);
                Enableproject();
                getgriddata();
            }
            catch
            {
            }
        }


        protected void RadGridProject_pageindexchanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            RadGridProject.CurrentPageIndex = e.NewPageIndex;
            Getdata();
        }

        protected void BtnAddproject_Click(object sender, EventArgs e)
        {
            try
            {

                this.ProjectName = "";
                Enableproject();
                Lbldatamodified.Visible = false;

            }
            catch { }
        }


        DateTime dateTo;
        DateTime dateFrom;
        DateTime dateToday;
        public void Savedata()
        {
            CULINFO = "en-GB";
            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            if (RadDatedurationTo.SelectedDate != null)
            {
                dateTo = RadDatedurationTo.SelectedDate.Value;
            }
            if (RadDatedurationfrm.SelectedDate != null)
            {
                dateFrom = RadDatedurationfrm.SelectedDate.Value;
            }
            try
            {

                dateToday = System.DateTime.Today.Date;

                AccountsetupSH objaccprojSH = new AccountsetupSH();
                if (TxtProjName.Text != "")
                {
                    objaccprojSH.ProjectName = UCFirst(TxtProjName.Text);
                    objaccprojSH.ClientName = UCFirst(TxtClient.Text);
                    objaccprojSH.Skills = UCFirst(TxtSkills.Text);
                    objaccprojSH.Location = UCFirst(TxtDescription.Text);
                    if ((RadDatedurationfrm.SelectedDate != null) && (RadDatedurationTo.SelectedDate != null))
                    {
                        objaccprojSH.DurationFrom = RadDatedurationfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                        objaccprojSH.DurationTo = RadDatedurationTo.SelectedDate.Value.ToString("dd/MMM/yyyy");
                        if ((dateFrom > dateToday))
                        {

                            lblDateErrorS.Visible = true;
                            RadDatedurationfrm.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        else
                        {
                            lblDateErrorS.Visible = false;
                            Lbldatamodified.Visible = false;
                        }
                        if (dateTo > dateToday)
                        {
                            lblDateErrorS.Visible = true;
                            RadDatedurationfrm.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        if ((dateFrom > dateTo))
                        {
                            Lbldatamodified.Visible = false;
                            lblDateErrorS.Visible = true;
                            RadDatedurationfrm.Focus();
                            goto Last;
                        }
                        else
                        {
                            Lbldatamodified.Visible = false;
                            lblDateErrorS.Visible = false;

                        }
                    }
                    else if (RadDatedurationfrm.SelectedDate != null)
                    {
                        objaccprojSH.DurationFrom = RadDatedurationfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                        objaccprojSH.DurationTo = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        if ((dateFrom > dateToday))
                        {

                            lblDateErrorS.Visible = true;
                            RadDatedurationfrm.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        else
                        {
                            lblDateErrorS.Visible = false;
                            Lbldatamodified.Visible = false;
                        }
                    }


                    #region Profile Progressbar
                    // string path = "~/App_Themes/Site/images/";
                    int i = 0;
                    if (TxtProjName.Text != "")
                    {
                        i++;
                    }
                    if (TxtClient.Text != "")
                    {
                        i++;
                    }
                    if (TxtSkills.Text != "")
                    {
                        i++;
                    }
                    if (TxtDescription.Text != "")
                    {
                        i++;
                    }
                    //if (RadDatedurationfrm.SelectedDate!=Convert.ToDateTime(""))
                    //{
                    //    i++;
                    //}
                    //if (RadDatedurationTo.SelectedDate != Convert.ToDateTime(""))
                    //{
                    //    i++;
                    //}


                    int Projects = i * 100 / 4;
                    int AccountWelcome = 0, Experience = 0, Acadimic = 0, PastCompany = 0, PresentCompany = 0;
                    AccountsetupFA objaccprojFA = new AccountsetupFA();
                    //objaccprojFA.UpdateProjectData(objaccprojSH, UserID);
                    objaccprojFA.InsertAccountSetUpData(objaccprojSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                    Lbldatamodified.Visible = true;
                    Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                    Disableproject();
                    Getdata();
                    #endregion


                }
            Last: ;
            }
            catch
            {
            }
        }





        protected void btnprojdelete_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnprojupdate");
                string ProjectName = Convert.ToString(RadGridProject.MasterTableView.DataKeyValues[gr.ItemIndex]["ProjectName"]);

                // string UserID = Convert.ToString(RadGridAcademics.MasterTableView.DataKeyValues[gr.ItemIndex]["UserID"]);
                AccountsetupFA objaccFA = new AccountsetupFA();
                objaccFA.deleteprojGridData(UserID, ProjectName);
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(63);
                DataTable objdtproj = new DataTable();
                objdtproj = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdtproj.Rows.Count > 0)
                {
                    Pnlgrid.Visible = true;
                    RadGridProject.Visible = true;
                    RadGridProject.DataSource = objdtproj;
                    RadGridProject.DataBind();
                    Disableproject();
                }
                else
                {
                    Pnlgrid.Visible = false;
                    Disableproject();
                }

            }


            catch { }


        }
        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {
                if (strName.Length > 0)
                {
                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);
                }
            }
            catch { }
            return sb.ToString();
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            Savedata();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.ProjectName != "")
                {
                    Enableproject();
                    getgriddata();
                }
                else
                {
                    Disableproject();
                }
                //Txtsplpassingyear.Text = "";
            }
            catch { }
        }

        protected void Next_Click(object sender, EventArgs e)
        {
            Savedata();

        }
        public void Enableproject()
        {
            TxtProjName.Text = "";
            TxtClient.Text = "";
            TxtSkills.Text = "";
            TxtDescription.Text = "";
            //RadDatedurationfrm.SelectedDate = Convert.ToDateTime("");
            //RadDatedurationTo.SelectedDate = Convert.ToDateTime("");
            TxtProjName.Enabled = true;
            TxtClient.Enabled = true;
            TxtSkills.Enabled = true;
            TxtDescription.Enabled = true;
            RadDatedurationfrm.Enabled = true;
            RadDatedurationTo.Enabled = true;

        }

        public void Disableproject()
        {
            TxtProjName.Text = "";
            TxtClient.Text = "";
            TxtSkills.Text = "";
            TxtDescription.Text = "";
            RadDatedurationfrm.SelectedDate = null;
            RadDatedurationTo.SelectedDate = null;
            TxtProjName.Enabled = false;
            TxtClient.Enabled = false;
            TxtSkills.Enabled = false;
            TxtDescription.Enabled = false;
            RadDatedurationfrm.Enabled = false;
            RadDatedurationTo.Enabled = false;

        }
        public void getgriddata()
        {
            AccountsetupFA objaccFA = new AccountsetupFA();
            DataTable objdtproj = new DataTable();
            objdtproj = objaccFA.GetProjectGridData(UserID, ProjectName);
            if (objdtproj.Rows.Count > 0)
            {
                TxtProjName.Text = objdtproj.Rows[0]["ProjectName"].ToString();
                TxtClient.Text = objdtproj.Rows[0]["ClientName"].ToString();
                TxtSkills.Text = objdtproj.Rows[0]["Skills"].ToString();
                TxtDescription.Text = objdtproj.Rows[0]["Description"].ToString();
                if (objdtproj.Rows[0]["DurationFrom"].ToString() != "")
                {
                    RadDatedurationfrm.SelectedDate = Convert.ToDateTime(objdtproj.Rows[0]["DurationFrom"].ToString());
                }
                if (objdtproj.Rows[0]["DurationTo"].ToString() != "")
                {
                    RadDatedurationTo.SelectedDate = Convert.ToDateTime(objdtproj.Rows[0]["DurationTo"].ToString());
                }
                //AccountsetupFA objaccFA1 = new AccountsetupFA();
                //DataTable objdt = new DataTable();
                //objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
               
            }
            objdtproj = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
            if (objdtproj.Rows.Count > 0)
            {

                RadGridProject.DataSource = objdtproj;
                RadGridProject.DataBind();
                Pnlgrid.Visible = true;
                RadGridProject.Visible = true;
            }
            else
            {
                Pnlgrid.Visible = false;
            }
           
        }

        protected void Bupre_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountExperience.aspx");
        }

        protected void Bunxt_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountAdditional.aspx");
        }

        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void getAccountProjectsPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountProjects");
                btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountProjects");
                btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountProjects");
                Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountProjects");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountProjects");
                Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccountProjects");
                Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccountProjects");
                Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccountProjects");
                Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccountProjects");
                Button7.Text = (string)GetGlobalResourceObject("PageResource", "Button7_AccountProjects");
                Button8.Text = (string)GetGlobalResourceObject("PageResource", "Button8_AccountProjects");
                Bupre.Text = (string)GetGlobalResourceObject("PageResource", "Bupre_AccountProjects");
                Bunxt.Text = (string)GetGlobalResourceObject("PageResource", "Bunxt_AccountProjects");
                Update.Text = (string)GetGlobalResourceObject("PageResource", "Update_AccountProjects");
                Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountProjects");
                Label66.Text = (string)GetGlobalResourceObject("PageResource", "Label66_AccountProjects");
                Label67.Text = (string)GetGlobalResourceObject("PageResource", "Label67_AccountProjects");
                Label68.Text = (string)GetGlobalResourceObject("PageResource", "Label68_AccountProjects");
                Label69.Text = (string)GetGlobalResourceObject("PageResource", "Label69_AccountProjects");
                Label70.Text = (string)GetGlobalResourceObject("PageResource", "Label70_AccountProjects");
                Label71.Text = (string)GetGlobalResourceObject("PageResource", "Label71_AccountProjects");
                Label72.Text = (string)GetGlobalResourceObject("PageResource", "Label72_AccountProjects");
                ImageButton1.Text = (string)GetGlobalResourceObject("PageResource", "ImageButton3_AccountAcademics");
                RadGridProject.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdproj_accproject");
                RadGridProject.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdclient_accproject");
                RadGridProject.Columns[2].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdSkills_accproject");
                RadGridProject.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
                RadGridProject.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
                RadGridProject.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "grid_pagetext");
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
            }
            catch
            {
            }
        }
    }
}
