﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using Telerik.Web.UI;

using System.Reflection;

namespace IRSA
{
    public partial class PopUptrainingDescription : System.Web.UI.Page
    {
        int PostTrainingID;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DescriptionInfo();
            }

        }
        protected void DescriptionInfo()
        {
            string PostTraining1 = Request.QueryString.Get("id");
            PostTrainingID = Convert.ToInt32(PostTraining1);
            DataTable dt = new DataTable();
            TrainingPostFA ObjTrainingPostFA = new TrainingPostFA();
            dt = ObjTrainingPostFA.SelectTraining(PostTrainingID);
            if (dt.Rows.Count > 0)
            {
                LblTraDescription.Text = dt.Rows[0]["Description"].ToString();
            }
        }
    }
}
