﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Data;
namespace IRSA
{
    public partial class CareerLadderIntroduction : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Lblmember.Text = "Guest !";
            }    

        }

        protected void lnkbtnITIndustry_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderIT.aspx");
        }

        protected void LnkContruction_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderConstruction.aspx");
        }

        protected void LnkBtnEnergy_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderEnergy.aspx");
        }

        protected void LnkBtnFinance_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderFinance.aspx");
        }

        protected void LnkbtnHospitality_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderHospitality.aspx");
        }

        protected void LnkBtnManufacturing_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderManufacturing.aspx");
        }

        protected void LnkBtnHealthcare_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderHealthCare.aspx");
        }

        protected void LnkBtnRetail_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderRetail.aspx");
        }

    }
}
