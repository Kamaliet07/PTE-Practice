﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Web.Security;
using System.Text;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;


namespace IRSA
{
    public partial class DigitalAdvisorInfo : System.Web.UI.Page
    {
        public string UserName
        {
            set
            {
                ViewState["UserName"] = value;
            }
            get
            {
                if (ViewState["UserName"] == null)
                {
                    ViewState["UserName"] = string.Empty;
                }
                return ViewState["UserName"].ToString();
            }
        }
        public string Password
        {
            set
            {
                ViewState["Password"] = value;
            }
            get
            {
                if (ViewState["Password"] == null)
                {
                    ViewState["Password"] = string.Empty;
                }
                return ViewState["Password"].ToString();
            }
        }
        public int ProductID
        {
            set
            {
                ViewState["ProductID"] = value;
            }
            get
            {
                if (ViewState["ProductID"] == null)
                {
                    ViewState["ProductID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["ProductID"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            
            int UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                Lblmember.Text = SessionInfo.FirstName + " " + "!";
                Pnlvisibilty.Visible = false;
                Panelbuy.Visible = true;
                
            }
            else 
            {
                Panelbuy.Visible = false;
                Pnlvisibilty.Visible = true;
               
            }
            if (!IsPostBack)
            {
                if (Request.Cookies["username"] != null)
                {
                    HttpCookie cookie = Request.Cookies.Get("username");
                    this.UserName = Request.Cookies["username"]["username"];
                    this.Password = Request.Cookies["username"]["password"];
                    CheckBox rm = (CheckBox)ChkBox.FindControl("RememberMe");

                }
                if (this.UserName != string.Empty)
                {
                    TxtLoginname.Text = this.UserName;
                    Textpassword.Attributes.Add("Value", this.Password);
                    ChkBox.Checked = true;
                }
                this.ProductID = 101;
                GetProductDetail(this.ProductID);
                
            }
 
        }

        private void GetProductDetail(int productid)
        {
            DigitalAdvisorFA objprodDt = new DigitalAdvisorFA();
            DataTable objdt = new DataTable();
            objdt = objprodDt.GetProductDetail(this.ProductID);
            LabelRate.Text = objdt.Rows[0]["Rate"].ToString();
            LabelDefn.Text = objdt.Rows[0]["ShortDesc"].ToString();
        }
             
        
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string email;
                LoginSH objsh = new LoginSH();
                email = TxtLoginname.Text;
                if (Validation.IsValidEmailAddress(email))
                {
                    objsh.UserID = email;
                    objsh.Password = Textpassword.Text;

                }
                else
                {
                    LblError.Visible = true;
                    LblError.Text = "Invalid User";
                }
                if (TxtLoginname.Text == null && Textpassword.Text == null)
                {
                    LblError.Visible = true;
                    LblError.Text = "Invalid User";

                }
                objsh.EmailID = TxtLoginname.Text;
                LoginFA objFA = new LoginFA();
                Encryption.HashPwd(Textpassword.Text);
                string password = Encryption.HashPwd(Textpassword.Text);
                objsh.Password = password;
                if (Encryption.verifyPwd(Textpassword.Text, objsh.Password) && objsh.EmailID == TxtLoginname.Text)
                {
                    objFA.GetValidate(objsh);

                    int y = Convert.ToInt32(SessionInfo.UserId);

                    if (y > 0)
                    {
                        if (ChkBox.Checked == true)
                        {

                            HttpCookie cookie = new HttpCookie("username");
                            cookie.Values.Add("username", TxtLoginname.Text);
                            cookie.Values.Add("password", Textpassword.Text);
                            cookie.Expires = DateTime.Now.AddDays(1);
                            HttpContext.Current.Response.AppendCookie(cookie);
                            ChkBox.Checked = true;

                        }
                        else if (ChkBox.Checked == false)
                        {
                            HttpContext.Current.Response.Cookies.Remove("username");
                            Response.Cookies["username"].Expires = DateTime.Now;
                            ChkBox.Checked = false;
                        }
                        BtnLogin.Enabled = false;
                        Pnlvisibilty.Visible = false;
                        Panelbuy.Visible = true;
                        InsertUserPurchageRecord();
                    }
                    else
                    {
                        LblError.Visible = true;
                        LblError.Text = "Invalid User";
                    }
                }
            }

            catch
            { 
            
            }



        }

        private void InsertUserPurchageRecord()
        {
            if (this.UserName != string.Empty && SessionInfo.UserId != int.MinValue)
            {
                int productid = 101;
                DigitalAdvisorFA objbuydet = new DigitalAdvisorFA();
                objbuydet.InserUserPurchageIntery(this.UserName,productid, SessionInfo.UserId);
            
            }
        }

        protected void LinkButtonRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void LinkButtonForgot_Click1(object sender, EventArgs e)
        {
            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";
            rd.NavigateUrl = "~/ForgotPassword1.aspx";
            rd.VisibleOnPageLoad = true;
            rd.Width = 330;
            rd.Height = 250;
            rd.Left = 400;
            rd.Top = 320;
            RadWindowManager1.Windows.Add(rd);
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            OpenNewWindow("http://www.regsoft.com");
        }

        private void OpenNewWindow(string url)
        {
            string winFeatures = "toolbar=no,status=no,menubar=no,location=center,scrollbars=no,resizable=no,height=500,width=657";
            ClientScript.RegisterStartupScript(this.GetType(), "newWindow", string.Format("<script type='text/javascript'>window.open('{0}', 'yourWin', '{1}');</script>", url, winFeatures));
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string emailid = string.Empty;
               emailid  = TextBoxEmail.Text;
               if (emailid != string.Empty)
               {
                   string query = textarea1.Value;
                   SendMail(emailid, query);               
               
               }
            
        }

        private void SendMail(string emailid, string query)
        {
            try
            {

                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress("irsa@iprozone.com");
                MailAddress fromto = new MailAddress(emailid);
                MailMessage msg = new MailMessage(fromto, sendto);
                MailDefinition mailmsg = new MailDefinition();
                mailmsg.BodyFileName = "";
                mailmsg.IsBodyHtml = true;
                msg.IsBodyHtml = true;

                bodyMsg.Append("Query Submit from " + emailid);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");                
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Assess for irsa@iprozone.com Please Check on below link:");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append(query);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("iRSA values your privacy at no time has iRSA made your email address available to any other iRSA user without your permission @2009,Powered By iRSA");

                msg.Subject = "Query Submission From " + emailid + " from iRSA.com";
                msg.Body = bodyMsg.ToString();
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
            }
            catch { }
        }
         
        protected void ImageButtonLogin_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

       
    }
}
