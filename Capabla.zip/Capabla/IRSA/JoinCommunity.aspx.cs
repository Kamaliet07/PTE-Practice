﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;


namespace IRSA
{
    public partial class JoinCommunity : System.Web.UI.Page
    {
        int CommunityID;
        protected void Page_Load(object sender, EventArgs e)
        {
            CommunityID = Convert.ToInt32(Request.QueryString.Get("id"));
        }

        protected void btnYes_Click(object sender, EventArgs e)
        {
            IRSA.Facade.Community.CommunityFA comm = new IRSA.Facade.Community.CommunityFA();
            comm.SaveCommunityMember(1,CommunityID,SessionInfo.Deleted,"Insert");
        }
    }
}
