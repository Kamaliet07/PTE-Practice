﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Net.Mail;
using System.Configuration;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using System.Security.Cryptography.X509Certificates;

namespace IRSA
{
    public partial class CompanySendmail : System.Web.UI.Page
    { 
        int UserID;
        string EmailID;
        CompanySearchSH objCompanySearchSH = new CompanySearchSH();
        CompanySearchFA objCompanySearchFA = new CompanySearchFA();
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if ((Request.QueryString["param1"] != null && Request.QueryString["param2"] != null))
            {
                UserID = Convert.ToInt32(Request.QueryString["param1"]);
                EmailID = Convert.ToString(Request.QueryString["param2"]);
                txtEMail.Text = EmailID;
               
            }
            //ServicePointManager.ServerCertificateValidationCallback = (obj, certificate, chain, errors) => true;


           
        }
        public static bool ValidateServerCertificate(Object sender, X509Certificate certificate, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        protected void Btnsubmit_Click(object sender, EventArgs e)
        {  
           
             lblmsg.Visible = false;
             try
              {
                string userAddress = getUserid(UserID); 
                StringBuilder bodyMsg = new StringBuilder();
                MailAddress fromto = new MailAddress(userAddress); 
                MailAddress  sendto= new MailAddress(txtEMail.Text);
                MailMessage msg = new MailMessage(fromto,sendto);
                msg.Subject = txtDetails.Text;
                msg.Body = txtDetails.Text;
                msg.IsBodyHtml = false;
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };
                smt.Send(msg);
                Btnsubmit.Enabled = false;
                lblmsg.Visible = true;
               
            }
                 
            catch { }
        }

        string Email;
        public string getUserid(int UserID)
        {
            DataTable dtEmail = new DataTable();
            dtEmail = objCompanySearchFA.getUser(UserID);
            if (dtEmail.Rows.Count > 0)
            {
                Email=dtEmail.Rows[0]["EmailID"].ToString();
            }
            return Email;
        }
           
        }

      
    }

