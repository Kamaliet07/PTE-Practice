﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;
namespace IRSA
{
    public partial class OrganisationWizardPrimaryContact : System.Web.UI.Page
    {
        string Accountxml = "irsatooltiporganisation.xml";
        int UserID=1;
        int OrganisationID;
        string PhotoDirectoryPathPri;
        string file;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ID"] != null)
            {
                OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);
              


            }

            PhotoDirectoryPathPri = ConfigurationSettings.AppSettings["PrimaryContactPhoto"];
            if (!IsPostBack)
            {
                XmlCountry();
                RetreiveData();
            }
            GetiRsaToolTipOrgMsg();
            if (OrganisationID != int.MinValue)
            {
                OrgAccountFA objaccFA = new OrgAccountFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.RetrievePriContactData(UserID, OrganisationID, true);
              //  Lblmember.Text = objdt.Rows[0]["FullName"].ToString() + " " + "!";
              //  SessionInfo.FirstName = objdt.Rows[0]["FullName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
        private void GetiRsaToolTipOrgMsg()
        {
            try
            {
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(19, Accountxml);
                Image5.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(17, Accountxml);
                Image4.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(20, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(16, Accountxml);
                txtfax.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(22, Accountxml);
                Image2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(21, Accountxml);
                Txtjobtitle.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(13, Accountxml);
                Txtemail.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(14, Accountxml);
                Txtname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(12, Accountxml);


            }
            catch { }
        }
        public void SaveData(int UserID)
        {


            //if (CurrentWizardStep == "Welcome")
            //{
            //string Professionaltitle;
            //Professionaltitle = Txtprotitle.Text;
            OrgAccountSH objoraccSH = new OrgAccountSH();
            objoraccSH.FullName = Txtname.Text;
            objoraccSH.JobTitle = Txtjobtitle.Text;
            objoraccSH.Email = Txtemail.Text;
            objoraccSH.Country = ddncountry.SelectedValue;
            objoraccSH.DisplayAs = txtdisplay.Text;
            objoraccSH.PhFax = txtfax.Text;
            objoraccSH.PhMobile = Txtmobile.Text;
            if (txtzip.Text != "")
            {
                objoraccSH.Zip = Convert.ToInt32(txtzip.Text);
            }
            objoraccSH.PhBusiness = txtoffice.Text;
            objoraccSH.Flag = "True";
            string file = FileUpload1.FileName;
            if (file != "")
            {
                FileUpload1.SaveAs(PhotoDirectoryPathPri + file);
                //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);

                string strphoto = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];

                //image1.Save(PhotoDirectoryPath + file, System.Drawing.Imaging.ImageFormat.Png);
                ResizeImage(PhotoDirectoryPathPri + file, "~/UserData/OrganisationPhotos/" + "Pri" + OrganisationID + UserID + "." + strphoto, 85, 75);

                objoraccSH.Photo = "Pri" + OrganisationID + UserID + "." + strphoto;
            }
            else
            {
                OrgAccountFA objorgFA = new OrgAccountFA();
                DataTable objdt = new DataTable();
                objdt = objorgFA.RetrievePriContactData(UserID, OrganisationID, false);
                if (objdt.Rows.Count > 0)
                {
                    file = objdt.Rows[0]["Photo"].ToString();
                    objoraccSH.Photo = file;
                }
            }
            OrgAccountFA objaccFA = new OrgAccountFA();
            objaccFA.InsertPriContactData(objoraccSH, UserID, OrganisationID);



        }
        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(OriginalFile);

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                NewImage.Save(Server.MapPath(NewFile));
            }
            catch
            {
            }
        }

        public void RetreiveData()
        {
            OrgAccountFA objorgFA = new OrgAccountFA();
            DataTable objdt = new DataTable();
            objdt = objorgFA.RetrievePriContactData(UserID, OrganisationID, true);
            if (objdt.Rows.Count > 0)
            {
                Txtname.Text = objdt.Rows[0]["FullName"].ToString();
                string fullname = objdt.Rows[0]["FullName"].ToString();
                string jobtitle = objdt.Rows[0]["JobTitle"].ToString();
                Txtjobtitle.Text = objdt.Rows[0]["JobTitle"].ToString();
                Txtemail.Text = objdt.Rows[0]["Email"].ToString();
                ddncountry.SelectedValue = objdt.Rows[0]["Country"].ToString();
                txtdisplay.Text = objdt.Rows[0]["DisplayAs"].ToString();
                txtfax.Text = objdt.Rows[0]["PhFax"].ToString();
                Txtmobile.Text = objdt.Rows[0]["PhMobile"].ToString();
                txtzip.Text = objdt.Rows[0]["Zip"].ToString();
                txtoffice.Text = objdt.Rows[0]["PhBusiness"].ToString();
                string file = objdt.Rows[0]["Photo"].ToString();
                if (file != "")
                {
                    Image2.Visible = true;
                    Image2.ImageUrl = "~/UserData/OrganisationPhotos/" + file;
                }
                else
                {

                    Image2.ImageUrl = "~/UserData/OrganisationPhotos/" + "0.png";

                    //Image1.ImageUrl = PhotoDirectoryPath + "DefaultImage.Png";
                }



            }
        }
        public void XmlCountry()
        {


            XPathNavigator nav1;
            XPathDocument docNav1;
            XPathNodeIterator NodeIter1;
            docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
            nav1 = docNav1.CreateNavigator();
            string strExp = "/root/English";
            NodeIter1 = nav1.Select(strExp);
            NodeIter1.MoveNext();
            ddncountry.LoadXml(NodeIter1.Current.InnerXml);






        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {

            SaveData(UserID);

            RetreiveData();
            if (Request.QueryString["ID"] != null)
            {
                OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);
                Response.Redirect("OrganisationWizard.aspx?id=" + OrganisationID);


            }
        }

        protected void Upload_Click(object sender, EventArgs e)
        {
            OrgAccountSH objorgSH = new OrgAccountSH();
            file = FileUpload1.FileName;
            if (file != "")
            {
                FileUpload1.SaveAs(PhotoDirectoryPathPri + file);
                //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                string strphoto = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];

                //image1.Save(PhotoDirectoryPath + file, System.Drawing.Imaging.ImageFormat.Png);
                ResizeImage(PhotoDirectoryPathPri + file, "~/UserData/OrganisationPhotos/" + "Pri" + OrganisationID + UserID + "." + strphoto, 85, 75);

                string Photo = "Pri" + OrganisationID + UserID + "." + strphoto;
                OrgAccountFA objOrgFA = new OrgAccountFA();
                objOrgFA.insertpriphoto(Photo, OrganisationID, UserID);
                //objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);

                RetreiveData();









            }






        }

        //protected void BtnReset_Click(object sender, EventArgs e)
        //{

        //    Txtjobtitle.Text = "";

        //    ddncountry.SelectedIndex = 0;
        //    txtdisplay.Text = "";
        //    txtfax.Text = "";
        //    Txtmobile.Text = "";
        //    txtzip.Text = "";
        //    txtoffice.Text = "";
        //}

        protected void BtnNext_Click(object sender, EventArgs e)
        {
            SaveData(UserID);

            RetreiveData();
            if (Request.QueryString["ID"] != null)
            {
                OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);
                Response.Redirect("OrganisationWizardSecondaryContact.aspx?id=" + OrganisationID);


            }
        }
    }
}
