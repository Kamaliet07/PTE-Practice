﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;

namespace IRSA
{
    public partial class CompanySearchAdvanced : System.Web.UI.Page
    {    
        string str, str6;
        int UserID;
        CompanySearchSH objCompanySearchSH = new CompanySearchSH();
        CompanySearchFA objCompanySearchFA = new CompanySearchFA();
        string PhotoDirectoryPath;
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        string Accountxml = "irsaToolTipSearch.xml";
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
                FillIndustry();
                XmlCountry();
                PhotoDirectoryPath = ConfigurationSettings.AppSettings["orglogo"];

            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
            private void XmlCountry()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                countrybox.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {

            }
        }
            private void GetiRsaToolTipAccMsg()
            {
                try
                {
                    RKeyword.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(12, Accountxml);
                    RCompany.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                    RCompanyType.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);
                    RCity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                    RCompanyURL.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(10, Accountxml);
                   



                }
                catch { }
            }
         public void GetSearchWords(string str)
            {
                string pattern = @"\S+";
                Regex re = new Regex(pattern);

                MatchCollection matches = re.Matches(str);
                string[] words = new string[matches.Count];
                for (int i = 0; i < matches.Count; i++)
                {
                    words[i] = matches[i].Value;
                    string str4 = words[i];

                    getmember(str4);

                }
                   if (GetTempsearch == null)
                {
                    RadGrid1.DataSource = GetTempsearchCollection;
                    RadGrid1.DataBind();
                }
                else
                {
                    RadGrid1.DataSource = GetTempsearch;
                    RadGrid1.DataBind();
                }

        }
         public void getmember(string str4)
         {
             try
             {

                 DataTable dtCalc = new DataTable();
                 DataTable ds = new DataTable();

                 if (GetTempsearchCollection == null)
                 {
                     CompanySearchFA objCompanySearchFA = new CompanySearchFA();

                     ds = objCompanySearchFA.GetCompany(str4, objCompanySearchSH);
                     GetTempsearchCollection = ds;
                     dtCalc = ds;
                     int count = dtCalc.Rows.Count;
                     dtCalc.Merge(GetTempsearchCollection);
                     GetTempsearchCollection = dtCalc;
                 }
                 else
                 {
                     DataRow[] Result = GetTempsearchCollection.Select("Expr2 Like '%" + str4 + "%'");
                     DataTable dfg = new DataTable();
                     dfg.Columns.Add("Name", typeof(string));
                     dfg.Columns.Add("City", typeof(string));
                     //dfg.Columns.Add("CompanyType", typeof(string));
                     dfg.Columns.Add("Website", typeof(string));
                     dfg.Columns.Add("Country", typeof(string));
                     dfg.Columns.Add("LogoPath", typeof(string));
                     dfg.Columns.Add("OrganisationID", typeof(int));
                     dfg.Columns.Add("UserID", typeof(int));

                     foreach (DataRow dr in Result)
                     {
                         DataRow row;
                         row = dfg.NewRow();
                         row["Name"] = dr[0];
                         row["City"] = dr[5];
                         //row["CompanyType"] = dr[1];
                         row["Website"] = dr[3];
                         row["Country"] = dr[4];
                         row["LogoPath"] = dr[7];
                         row["OrganisationID"] = dr[8];
                         row["UserID"] = dr[9];
                         dfg.Rows.Add(row);
                     }
                     GetTempsearch = dfg;
                 }

             }
             catch { }

         }



         protected void button_Click(object sender, EventArgs e)
         {
             GetTempsearchCollection = null;
             GetTempsearch = null;
             if ((RKeyword.Text != "") && (RCompany.Text != ""))
             {
                 person();
             }
             else if ((RKeyword.Text == "") && (RCompany.Text != ""))
             {
                 person();
             }
             else if ((RKeyword.Text != "") && (RCompany.Text == ""))
             {
                 string strkey = RKeyword.Text;
                 int ln = strkey.Length;
                 if (ln > 1)
                 {
                     string[] words = strkey.Split(' ', ',');
                     foreach (string word in words)
                     {
                         str6 = str6 + " " + word;
                         str = str6;
                     }

                     GetSearchWords(str);
                 }
                 //GetTempsearchCollection = null;
                 //  GetTempsearch = null;
                 //  if (RKeyword.Text != "")
                 //  {

                 //      string strkey = RKeyword.Text;
                 //      int ln = strkey.Length;
                 //      if (ln > 1)
                 //      {
                 //          string[] words = strkey.Split(' ', ',');
                 //          foreach (string word in words)
                 //          {
                 //              str6 = str6 + " " + word;
                 //              str = str6;
                 //          }

                 //          GetSearchWords(str);
                 //      }

                 //    }
                 //  else if (RKeyword.Text == "")
                 //  {
                 //      person();
                 //  }

                 //  else if ((RKeyword.Text != "") && (RCompany.Text != ""))
                 //  {
                 //      person();
                 //  }
             }
         }
        

        protected void RadGrid1_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
             RadGrid1.CurrentPageIndex = e.NewPageIndex;

            if (GetTempsearch == null)
            {
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            }
            else
            {
                RadGrid1.DataSource = GetTempsearch;
                RadGrid1.DataBind();
            }
        }
        public void FillIndustry()
        {
            try
            {
                JobSearchFA objJobSearchFA = new JobSearchFA();
                DataTable temp = new DataTable();
                temp = objJobSearchFA.GetIndustryData();
                DataRow dr = temp.NewRow();
                dr["IndustryName"] = "Select IndustryName";
                temp.Rows.InsertAt(dr, 0);    
                Industrybox.DataTextField = "IndustryName";
                Industrybox.DataSource = temp;
                Industrybox.DataBind();
            }
            catch
            {
            }
        }
     protected void person()
        { 
            string str6, str7, str8, str9, str10,str15, str16, str13, str14, str5,
            str21,str22;
            str6 = RCompany.Text;
            str9 = " ";
            if (str6 == "")
            {
                str6 = null;
            }
            objCompanySearchSH.CompanyName = RCompany.Text;
            str7 = Industrybox.SelectedValue;
            if (str7 == "")
            {
                str7 = null;
            }
            str10 = " ";
            objCompanySearchSH.IndustryName = Industrybox.SelectedValue;
            str15 = RCity.Text;
            if (str15 == "")
            {
                str15 = null;
            }
            str16 = " ";
            objCompanySearchSH.City = RCity.Text;
            str8 = countrybox.SelectedValue;
            if (str8 == "")
            {
                str8 = null;
            }
            str22 = " ";
            objCompanySearchSH.CountryName = countrybox.SelectedValue;
            str13 = RCompanyType.Text;
            if (str13 == "")
            {
                str13 = null;
            }
            str14 = " ";
            objCompanySearchSH.Type = RCompanyType.Text;
            
            str5 = RCompanyURL.Text;
            if (str5 == "")
            {
                str5 = null;
            }
            str21 = " ";
            objCompanySearchSH.CompanyURL = RCompanyURL.Text;
            string ab = str6 + str9 + str7 + str10 + str15 + str16 + str8 + str22  + str13 + str14
            + str5 + str21 ;
           GetSearchWords(ab);
            }

     protected void Industrybox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
     {
         objCompanySearchSH.IndustryName = Industrybox.Text;
     }

     protected void countrybox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
     {
         objCompanySearchSH.CountryName = countrybox.SelectedItem.Text;
     }

     protected void LinkButton1_Click(object sender, EventArgs e)
     {
         GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
         LinkButton btnprev = (LinkButton)sender;
         LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton1");
         string OrganisationID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["OrganisationID"]);
         GridDataItem dtitem = this.RadGrid1.Items[gr.ItemIndex];
         string UseID = dtitem["UserID"].Text.ToString();
         int uid = Convert.ToInt32(UseID);
         string Message = string.Format("~/ViewOrg.aspx?param1={0}&param2={1}", uid, OrganisationID);
         RadWindow rd = new RadWindow();
         rd.ID = "RadWindowhelp";
         rd.NavigateUrl = Message;
         rd.VisibleOnPageLoad = true;
         rd.Width = 600;
         rd.Height = 500;
         rd.Left = 400;
         rd.Top = 150;
         RadWindowManager1.Windows.Add(rd);
     }

     protected void RadGrid1_ItemDataBound(object sender, GridItemEventArgs e)
     {
         if (e.Item is GridDataItem)
         {
             GridDataItem item = e.Item as GridDataItem;
             CompanySearchFA objCompanySearchFA = new CompanySearchFA();
             string Photo = (item["LogoPath"].Text.ToString());
            

             Image img = item["TemplateColumn"].FindControl("Image1") as Image;
             img.ImageUrl = PhotoDirectoryPath + Photo;
         }
     }

        }
  
}

