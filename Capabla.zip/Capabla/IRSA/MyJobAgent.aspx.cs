﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Xml.XPath;


namespace IRSA
{
    
    public partial class MyJobAgent : System.Web.UI.Page
    {
        //Declaring global variables to be used throughout the class
        int UserID;
        int AgentCount;
        string CultureID;
        string MsgCandidateSearch = "TooltipMsgMyJobCentre.xml";
        
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //UserID = SessionInfo.UserId;
            CultureID = "EN";
            UserID = 9;
            //if (AgentSave.Visible == true)
            //{
                Page.Form.DefaultButton = AgentSave.UniqueID;
            //}
            //if (imgBtnEdit.Visible == true)
            //{
            //    Page.Form.DefaultButton = imgBtnEdit.UniqueID;
            //}
            
            if (!IsPostBack)
            {
                GettooltipMessage();
                XmlCountry();
                DDJobFamilyBind();
                
                pnlCreateJobAgent.Visible = false;
                chkUpdateEmail.Checked = true;
                //chkUpdateMobile.Checked = true;---- To be uncommented when mobile implemented
                //ddMobile.Enabled = true;  ---- To be uncommented when mobile implemented
                //ddPostedMobile.Enabled = true;---- To be uncommented when mobile implemented
                //ddFrequencyMobile.Enabled = true;---- To be uncommented when mobile implemented
                ddEmail.Enabled = true;
                ddFrequencyEmail.Enabled = true;
                ddPostedEmail.Enabled = true;
                ddFrequencyEmail.SelectedValue = "None";
                ddPostedEmail.SelectedValue = "None";
                ddEmail.SelectedValue = "0";
                ddPostedMobile.SelectedValue = "None";
                ddFrequencyMobile.SelectedValue = "None";
                ddMobile.SelectedValue = "0";
                chkLocation.Checked = true;
                txtCity.Text = "-City-";
                txtCity.Enabled = false;
                RadCombocountry.Enabled = false;
                ddJobOccupation.Enabled = false;
                RaddatepickerFrom.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                RaddatepickerTo.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());

            }
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            //pnlCreateJobAgent.BorderWidth = 0;
            lblErrorAgents.Visible = false;
            pnlJobAgent.Visible = true;
            pnlAgent1.Visible = false;
            pnlAgent2.Visible = false;
            pnlAgent3.Visible = false;
            pnlAgent4.Visible = false;
            pnlAgent5.Visible = false;
            pnlAgent6.Visible = false;
            AgentCount=count();
            dispAgentPanel(UserID); // To display the agents associated with this User
            if (AgentCount>1)
                {
                    //lblAgent2Name.Text =Convert.ToString(AgentCount);
                
                }
        }
        //This method counts the number of Job Agents for a particular UserID i.e. Candidate
        int count()
        {

            {
                MyJobAgentFA objFA = new MyJobAgentFA();

                return objFA.getAgentCount(UserID,CultureID);
            }
        }

        protected void imgBtnCreateAgent_Click(object sender, ImageClickEventArgs e)
        {
            if (AgentCount < 6)  /* Here maximum no of allowed job agents is 6*/
            {
                empty();
                lblErrorAgents.Visible = false;
                pnlCreateJobAgent.Visible = true;
                lblError.Visible = false;
                txtAgentName.Enabled = true;
                txtAgentName.Text = null;
                imgBtnEdit.Visible = false;
                AgentSave.Visible = true;
                AgentSave.Enabled = true;
                imgBtnEdit.Enabled = false;
                
               
            }
            else 
            {
                lblErrorAgents.Visible = true;
                lblErrorAgents.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(3);

            }
        }

        //To retrieve the tool tip messages
        private void GettooltipMessage()
        {
            try
            {
                txtAgentName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, MsgCandidateSearch);
                txtKeyword.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, MsgCandidateSearch);
                txtCity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(4, MsgCandidateSearch);
                msgSalary.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, MsgCandidateSearch);
                chkLocation.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, MsgCandidateSearch);
                

            }
            catch { }
        }

        /*To set all the fields into their initial default or empty values*/
        void empty()
        {

            try
            {
                txtKeyword.Text = null;
                chkLocation.Checked = true;
                txtCity.Enabled = false;
                //RadCombocountry.SelectedValue
                RadCombocountry.Enabled = false;
                RadCombocountry.SelectedIndex = 0;
                txtCity.Text = "-City-";
                //txtCity.Enabled = false;
                DDExp.SelectedValue = "none";
                DDJobFamilyBind();
                ddJobType.SelectedValue = "none";
                DataTable dts = new DataTable();
                ddJobOccupation.DataSource = dts;
                ddJobOccupation.DataBind();
                ddJobOccupation.Enabled = false;
                chkUpdateEmail.Checked = true;
                chkUpdateMobile.Checked = true;
                ddEmail.Enabled = true;
                ddFrequencyEmail.Enabled = true;
                ddPostedEmail.Enabled = true;
                ddFrequencyEmail.SelectedValue = "None";
                ddPostedEmail.SelectedValue = "None";
                ddEmail.SelectedValue = "0";
                ddPostedMobile.SelectedValue = "None";
                ddFrequencyMobile.SelectedValue = "None";
                ddMobile.SelectedValue = "0";
                //ddMobile.Enabled = true;---- To be uncommented when mobile implemented
                //ddFrequencyMobile.Enabled = true;---- To be uncommented when mobile implemented
                //ddPostedMobile.Enabled = true;---- To be uncommented when mobile implemented
                txtbSal.Text = null;
                txtbSal.Enabled = false;
                ddCurrency.SelectedValue = "none";
                RaddatepickerFrom.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                RaddatepickerTo.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                lblDateErrorS.Visible = false;
            }
            catch { }
        }

        /*To store the data into the tables*/
        void storeData(int uid)
        {

           
                lblMainError.Visible = false;
                lblDateErrorS.Visible = false;
                lblKeywordError.Visible = false;
                lblAgentErr.Visible = false;
                lblErrSal.Visible = false;
                lblErrCity.Visible = false;
                lblErrJobFamily.Visible = false;
                lblErrOccupation.Visible = false;
           
                

                try
                {
                    MyJobAgentSH objSH = new MyJobAgentSH();
                    objSH.UserID = uid;
                    objSH.AgentName = txtAgentName.Text;
                    objSH.KeyWord = txtKeyword.Text;
                    if (chkLocation.Checked == false)
                    {
                        objSH.Location = true;
                        objSH.Country = RadCombocountry.SelectedValue;
                        objSH.City = txtCity.Text;
                    }
                    else
                    {
                        objSH.Location = false;
                        objSH.Country = "";
                        objSH.City = "";
                    }
                    if (DDExp.SelectedIndex != 0)
                    {
                        objSH.Experience = Convert.ToInt32(DDExp.SelectedValue);
                    }
                    else
                    {
                        objSH.Experience = 0;
                    }
                    //if (ddJobfamily.SelectedItem.Text != "-Select Job Family-")
                    if(ddJobfamily.SelectedIndex!=0)
                    {
                        string JobFamily = ddJobfamily.SelectedItem.Text;
                        MyJobAgentFA jbFamilyFA = new MyJobAgentFA();
                        objSH.JobFamilyID = jbFamilyFA.getJobFamilyID(JobFamily);/*Retrieving Job FamilyID from Job Family Name*/
                        //if (ddJobOccupation.SelectedItem.Text != "-Select Occupation-")
                        if (ddJobOccupation.SelectedIndex!=0)
                        {
                            string occupation = ddJobOccupation.SelectedItem.Text;
                            MyJobAgentFA occupationFA = new MyJobAgentFA();
                            objSH.OccupationID = (occupationFA.getOccupationID(occupation)).Trim();/*Retrieving OccupationID from Occupation Name*/
                        }
                        else
                        {
                            objSH.OccupationID = "";
                        }

                    }
                    else
                    {
                        objSH.JobFamilyID = "";
                        objSH.OccupationID = "";
                    }


                    objSH.JobType = ddJobType.SelectedValue;
                    if (chkUpdateEmail.Checked == true)
                    {
                        objSH.UpdateOnEmail = true;
                        objSH.JobAlertNoEmail = Convert.ToInt32(ddEmail.SelectedValue);
                        objSH.FrequencyEmail = (ddFrequencyEmail.SelectedValue).ToString();
                        objSH.PostedEmail = (ddPostedEmail.SelectedValue).ToString();

                    }
                    else
                    {
                        objSH.UpdateOnEmail = false;
                        objSH.JobAlertNoEmail = 0;
                        objSH.FrequencyEmail = "";
                        objSH.PostedEmail = "";
                    }
                    if (chkUpdateMobile.Checked == true)
                    {
                        objSH.UpdateOnMobile = true;
                        objSH.JobAlertNoMobile = Convert.ToInt32(ddMobile.SelectedValue);
                        objSH.FrequencyMobile = (ddFrequencyMobile.SelectedValue).ToString();
                        objSH.PostedMobile = (ddPostedMobile.SelectedValue).ToString();
                    }
                    else
                    {
                        objSH.UpdateOnMobile = false;
                        objSH.JobAlertNoMobile = 0;
                        objSH.FrequencyMobile = "";
                        objSH.PostedMobile = "";
                    }

                    objSH.PayCurrency = (ddCurrency.SelectedValue).ToString();
                    if (txtbSal.Text != "")
                    {
                        objSH.PreferredSalary = Double.Parse(txtbSal.Text);
                    }
                    else
                    {
                        objSH.PreferredSalary = 0.0;
                    }
                    objSH.AvailabilityFrom = RaddatepickerFrom.SelectedDate.Value.ToString("dd/MMM/yyyy");
                    objSH.AvailabilityTo = RaddatepickerTo.SelectedDate.Value.ToString("dd/MMM/yyyy");
                    objSH.CreateDate = System.DateTime.Today.Date.ToString("dd/MMM/yyyy");
                    MyJobAgentFA objFA = new MyJobAgentFA();
                    objFA.insertJobAgentData(objSH,CultureID);

                }
                catch
                {
                }
            
        }

        /* This function is to populate the Job Family field from the XML. */
        void DDJobFamilyBind()
        {
            try
            {
                MyJobAgentFA mjFA = new MyJobAgentFA();
                MyJobAgentSH mjSH = new MyJobAgentSH();
                DataTable temp = new DataTable();
                temp = mjFA.GetJobFamilyData();
                ddJobfamily.DataSource = temp;
                //ddJobfamily.DataValueField = "JobFamilyName";
                ddJobfamily.DataBind();
            }
            catch
            {
            }
        }

        /* This function is to populate the contry field from the XML. */
        private void XmlCountry()
        {
            try
            {


                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                RadCombocountry.LoadXml(NodeIter1.Current.InnerXml);
                RadCombocountry.LoadXml(NodeIter1.Current.InnerXml);




            }
            catch
            {

            }
        }


        /*This function is to display the various Job Agent Pannels*/
        void dispAgentPanel(int UserID)
        {
            MyJobAgentFA agentFA = new MyJobAgentFA();
            DataTable dt = agentFA.getAgentDataTable(UserID,CultureID);   /*To retrieve the table of all the agents for
                                                                a particular UserID*/
            
            //objdt.Rows[0]["FirstName"].ToString();
            int NoAgents = count();
            int counter=NoAgents; // Temporary Counter Variable
            int temp = 0; // Temporary Control Variable
            if (NoAgents > 0 && NoAgents <= 6)
            {
                //while (counter > 0)
                //{
                    if (counter == 6)
                    {
                        pnlAgent1.Visible = true;
                        lblAgentName1.Text = dt.Rows[0]["AgentName"].ToString();
                        lblCreateDate1.Text = dt.Rows[0]["CreateDate"].ToString();
                        counter = counter - 1;
                        temp++;
                    }
                    if (counter == 5)
                    {
                        if (temp == 0)
                        {
                            pnlAgent1.Visible = true;
                            lblAgentName1.Text = dt.Rows[0]["AgentName"].ToString();
                            lblCreateDate1.Text = dt.Rows[0]["CreateDate"].ToString();
                        }
                        else if(temp==1)
                        {
                            pnlAgent2.Visible = true;
                            lblAgentName2.Text = dt.Rows[1]["AgentName"].ToString();
                            lblCreateDate2.Text = dt.Rows[1]["CreateDate"].ToString();
                        }
                        temp++;
                        counter = counter - 1;
                    } 
                    if (counter == 4)
                    {
                        if (temp == 0)
                        {
                            pnlAgent1.Visible = true;
                            lblAgentName1.Text = dt.Rows[0]["AgentName"].ToString();
                            lblCreateDate1.Text = dt.Rows[0]["CreateDate"].ToString();
                        }
                        else if (temp == 1)
                        {
                            pnlAgent2.Visible = true;
                            lblAgentName2.Text = dt.Rows[1]["AgentName"].ToString();
                            lblCreateDate2.Text = dt.Rows[1]["CreateDate"].ToString();
                        }
                        else if (temp == 2)
                        {
                            pnlAgent3.Visible = true;
                            lblAgentName3.Text = dt.Rows[2]["AgentName"].ToString();
                            lblCreateDate3.Text = dt.Rows[2]["CreateDate"].ToString();
                        }
                        counter = counter - 1;
                        temp++;

                    }
                    if (counter == 3)
                    {
                        if (temp == 0)
                        {
                            pnlAgent1.Visible = true;
                            lblAgentName1.Text = dt.Rows[0]["AgentName"].ToString();
                            lblCreateDate1.Text = dt.Rows[0]["CreateDate"].ToString();
                        }
                        else if (temp == 1)
                        {
                            pnlAgent2.Visible = true;
                            lblAgentName2.Text = dt.Rows[1]["AgentName"].ToString();
                            lblCreateDate2.Text = dt.Rows[1]["CreateDate"].ToString();
                        }
                        else if (temp == 2)
                        {
                            pnlAgent3.Visible = true;
                            lblAgentName3.Text = dt.Rows[2]["AgentName"].ToString();
                            lblCreateDate3.Text = dt.Rows[2]["CreateDate"].ToString();
                        }
                        else if (temp == 3)
                        {
                            pnlAgent4.Visible = true;
                            lblAgentName4.Text = dt.Rows[3]["AgentName"].ToString();
                            lblCreateDate4.Text = dt.Rows[3]["CreateDate"].ToString();
                        }
                        counter = counter - 1;
                        temp++;
                    } 
                    if (counter == 2)
                    {
                        if (temp == 0)
                        {
                            pnlAgent1.Visible = true;
                            lblAgentName1.Text = dt.Rows[0]["AgentName"].ToString();
                            lblCreateDate1.Text = dt.Rows[0]["CreateDate"].ToString();
                        }
                        else if (temp == 1)
                        {
                            pnlAgent2.Visible = true;
                            lblAgentName2.Text = dt.Rows[1]["AgentName"].ToString();
                            lblCreateDate2.Text = dt.Rows[1]["CreateDate"].ToString();
                        }
                        else if (temp == 2)
                        {
                            pnlAgent3.Visible = true;
                            lblAgentName3.Text = dt.Rows[2]["AgentName"].ToString();
                            lblCreateDate3.Text = dt.Rows[2]["CreateDate"].ToString();
                        }
                        else if (temp == 3)
                        {
                            pnlAgent4.Visible = true;
                            lblAgentName4.Text = dt.Rows[3]["AgentName"].ToString();
                            lblCreateDate4.Text = dt.Rows[3]["CreateDate"].ToString();
                        }
                        else if (temp == 4)
                        {
                            pnlAgent5.Visible = true;
                            lblAgentName5.Text = dt.Rows[4]["AgentName"].ToString();
                            lblCreateDate5.Text = dt.Rows[4]["CreateDate"].ToString();
                        }
                        counter = counter - 1;
                        temp++;
                    } 
                    if (counter == 1)
                    {
                        if (temp == 0)
                        {
                            pnlAgent1.Visible = true;
                            lblAgentName1.Text = dt.Rows[0]["AgentName"].ToString();
                            lblCreateDate1.Text = dt.Rows[0]["CreateDate"].ToString();
                        }
                        else if (temp == 1)
                        {
                            pnlAgent2.Visible = true;
                            lblAgentName2.Text = dt.Rows[1]["AgentName"].ToString();
                            lblCreateDate2.Text = dt.Rows[1]["CreateDate"].ToString();
                        }
                        else if (temp == 2)
                        {
                            pnlAgent3.Visible = true;
                            lblAgentName3.Text = dt.Rows[2]["AgentName"].ToString();
                            lblCreateDate3.Text = dt.Rows[2]["CreateDate"].ToString();
                        }
                        else if (temp == 3)
                        {
                            pnlAgent4.Visible = true;
                            lblAgentName4.Text = dt.Rows[3]["AgentName"].ToString();
                            lblCreateDate4.Text = dt.Rows[3]["CreateDate"].ToString();
                        }
                        else if (temp == 4)
                        {
                            pnlAgent5.Visible = true;
                            lblAgentName5.Text = dt.Rows[4]["AgentName"].ToString();
                            lblCreateDate5.Text = dt.Rows[4]["CreateDate"].ToString();
                        }
                        else if (temp == 5)
                        {
                            pnlAgent6.Visible = true;
                            lblAgentName6.Text = dt.Rows[5]["AgentName"].ToString();
                            lblCreateDate6.Text = dt.Rows[5]["CreateDate"].ToString();
                        }
                        counter = counter - 1;
                        temp++;
                    }
                //}
            }

        }


        /* This function is used to fill all the fields of the Create Agent Form so as to enable editing*/
        void formFiller(MyJobAgentSH ffSH)
        {
            try
            {
                txtAgentName.Text = ffSH.AgentName;
                txtKeyword.Text = ffSH.KeyWord;
                if (ffSH.Location == true)
                {
                    chkLocation.Checked = false;
                    RadCombocountry.Enabled = true;
                    RadCombocountry.SelectedValue = ffSH.Country;
                    txtCity.Enabled = true;
                    txtCity.Text = ffSH.City;
                }
                else
                {
                    chkLocation.Checked = true;
                    RadCombocountry.Enabled = false;
                    //RadCombocountry.SelectedValue = "";
                    //RadCombocountry.SelectedIndex = 0;---- Check it out
                    txtCity.Text = "-City-";
                    txtCity.Enabled = false;
                }
                DDExp.SelectedValue = (ffSH.Experience).ToString();
                string family;
                string occupation;
                MyJobAgentFA ffFA = new MyJobAgentFA();
                if (ffSH.JobFamilyID != ""&&ffSH.JobFamilyID!=null)
                {
                    family = (ffFA.getFamilyName(ffSH.JobFamilyID));  //Retrieving family name from family ID
                    DDJobFamilyBind();
                    ddJobfamily.SelectedValue = family;
                    if ((ffSH.OccupationID).TrimEnd() != "" && (ffSH.OccupationID).TrimEnd() != null)
                    {
                        string testID = ffSH.OccupationID.Trim();
                        occupation = (ffFA.getOccupationName(testID)).Trim(); //Retrieving occupation name from occupation ID
                        OccupationDDBind(family); //Binding Occupation drop down
                        ddJobOccupation.Enabled = true;
                        ddJobOccupation.SelectedValue = occupation;//----derive a method so as to fill it using a tem data set
                    }
                    else
                    {
                        OccupationDDBind(family); //Binding Occupation drop down
                        ddJobOccupation.Enabled = true;
                        ddJobOccupation.SelectedValue = "-Select Occupation-";//---- Check it out
                    }
                }
                else
                {
                    ddJobfamily.SelectedValue =  "-Select Job Family-";//---- Check it out
                    ddJobOccupation.Enabled = false;
                    ddJobOccupation.SelectedValue = "-Select Occupation-";//---- Check it out
                }

                ddJobType.SelectedValue = ffSH.JobType;
                if (ffSH.UpdateOnEmail == true)
                {
                    chkUpdateEmail.Checked = true;
                    ddEmail.Enabled = true;
                    ddEmail.SelectedValue = Convert.ToString(ffSH.JobAlertNoEmail);
                    ddFrequencyEmail.Enabled = true;
                    ddPostedEmail.Enabled = true;
                    ddFrequencyEmail.SelectedValue = ffSH.FrequencyEmail;
                    ddPostedEmail.SelectedValue = ffSH.PostedEmail;
                }
                else
                {
                    chkUpdateEmail.Checked = false;
                    ddEmail.Enabled = false;
                    ddEmail.SelectedValue = "0";
                    ddFrequencyEmail.SelectedValue = "None";
                    ddFrequencyEmail.Enabled = false;
                    ddPostedEmail.Enabled = false;
                    ddPostedEmail.SelectedValue = "None";
                }
                if (ffSH.UpdateOnMobile == false)
                {
                    chkUpdateMobile.Checked = false;
                    ddMobile.Enabled = false;
                    ddMobile.SelectedValue = "0";
                    ddFrequencyMobile.SelectedValue = "None";
                    ddFrequencyMobile.Enabled = false;
                    ddPostedMobile.SelectedValue = "None";
                    ddPostedMobile.Enabled = false;
                }
                else
                {
                    //chkUpdateMobile.Checked = true;---- To be uncommented when mobile implemented
                    //ddMobile.Enabled = true;---- To be uncommented when mobile implemented
                    //ddMobile.SelectedValue = Convert.ToString(ffSH.JobAlertNoMobile);---- To be uncommented when mobile implemented
                    //ddFrequencyMobile.Enabled = true;---- To be uncommented when mobile implemented
                    //ddFrequencyMobile.SelectedValue = ffSH.FrequencyMobile;---- To be uncommented when mobile implemented
                    //ddPostedMobile.Enabled = true;---- To be uncommented when mobile implemented
                    //ddPostedMobile.SelectedValue = ffSH.PostedMobile;---- To be uncommented when mobile implemented
                }


                //ddJobPosted.SelectedValue = ffSH.JobPosted;-------make necessary changes
                if (((ffSH.PayCurrency).ToString()).TrimEnd() != "none")
                {
                    ddCurrency.SelectedValue = ((ffSH.PayCurrency).ToString()).TrimEnd();
                    txtbSal.Enabled = true;
                    txtbSal.Text = (ffSH.PreferredSalary).ToString();
                }
                else
                {
                    ddCurrency.SelectedValue = "none";
                    txtbSal.Text = null;
                    txtbSal.Enabled = false;
                }
             
                RaddatepickerFrom.SelectedDate = Convert.ToDateTime(ffSH.AvailabilityFrom);
                RaddatepickerTo.SelectedDate = Convert.ToDateTime(ffSH.AvailabilityTo);
            }
            catch { }
        }

        /*This function checks whether the Agent with the same name already exists or not*/
        protected Boolean doAgentExists()
        {
            string agentName = txtAgentName.Text;
            MyJobAgentFA agentExistsFA = new MyJobAgentFA();
            return agentExistsFA.doAgentExists(agentName, UserID,CultureID);

        }


        protected void btnJobAgent_Click(object sender, EventArgs e)
        {

        }

        protected void btnMyAppliedJob_Click(object sender, EventArgs e)
        {

        }

        protected void btnResumeUpload_Click(object sender, EventArgs e)
        {

        }

        protected void btnWhoVisited_Click(object sender, EventArgs e)
        {

        }

        protected void btnJobMatched_Click(object sender, EventArgs e)
        {

        }

        protected void btniRSAResume_Click(object sender, EventArgs e)
        {

        }

        protected void ChkBxLocation_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void rBtnAnywhere_CheckedChanged(object sender, EventArgs e)
        {
            pnlCreateJobAgent.Visible = true;
            RadCombocountry.SelectedIndex = 0;
            txtCity.Text = null;
            RadCombocountry.Enabled = false;
            txtCity.Enabled = false;
            //ddWeightLoc.Enabled = false;
        }

        protected void rbtnLocatedIn_CheckedChanged(object sender, EventArgs e)
        {
            pnlCreateJobAgent.Visible = true;
            RadCombocountry.Enabled = true;
            txtCity.Enabled = true;
            //ddWeightLoc.Enabled = true;
        }

        protected void OccupationDDBind(string family)
        {
            MyJobAgentFA mjaFA = new MyJobAgentFA();
            DataTable temp = new DataTable();
            temp = mjaFA.getOccupationData(family);
            ddJobOccupation.DataSource = temp;
            ddJobOccupation.DataValueField = "Title";
            ddJobOccupation.DataBind();
        }

        protected Boolean formValidation()
        {
            DateTime dateTo = RaddatepickerTo.SelectedDate.Value;
            DateTime dateFrom = RaddatepickerFrom.SelectedDate.Value;
            DateTime dateToday = System.DateTime.Today.Date;
            if (txtAgentName.Text.Length > 15)
            {
                lblAgentErr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(47);
                lblAgentErr.Visible = true;
                txtAgentName.Focus();
                return false;
            }
            else
            {
                lblAgentErr.Text = "";
                lblAgentErr.Visible = false;

            }
            if (!(Validation.RequiredCheck(txtAgentName.Text)))
            {
                lblAgentErr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(48);
                lblAgentErr.Visible = true;
                txtAgentName.Focus();
                return false;
            }
            else
            {
                lblAgentErr.Text = "";
                lblAgentErr.Visible = false;

            }
            if(Validation.IsContainsSpecialCharaters(txtAgentName.Text))
            {

                lblAgentErr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(49);
                lblAgentErr.Visible = true;
                txtAgentName.Focus();
                return false;
            }
            else
            {
                lblAgentErr.Text = "";
                lblAgentErr.Visible = false;
            }
            if (!(Validation.RequiredCheck(txtKeyword.Text)))
            {
                lblKeywordError.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(6);
                lblKeywordError.Visible = true;
                txtKeyword.Focus();
                return false;
            }
            else
            {
                lblKeywordError.Visible = false;
            }
            if (chkLocation.Checked == false)
            {
                if (txtCity.Text.Length > 20)
                {
                    lblErrCity.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(7);
                    lblErrCity.Visible = true;
                    txtCity.Focus();
                    return false;
                }
                else
                {
                    lblErrCity.Visible = false;
                    lblErrCity.Text = "";
                }
                if ((Validation.IsContainsSpecialCharaters(txtCity.Text)) || (Validation.IsNumeric(txtCity.Text)))
                {
                    lblErrCity.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(7);
                    lblErrCity.Visible = true;
                    txtCity.Focus();
                    return false;
                }
                else
                {
                    lblErrCity.Visible = false;
                    lblErrCity.Text = "";
                }
            }
            if (ddJobfamily.SelectedIndex < 1)
            {
                lblErrJobFamily.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(8);
                lblErrJobFamily.Visible = true;
                return false;
            }
            else
            {
                lblErrJobFamily.Visible = false;
            }
           if (ddJobOccupation.SelectedIndex < 1)
            {
                lblErrJobFamily.Visible = false;
                lblErrOccupation.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(9);
                lblErrOccupation.Visible = true;
                return false;
            }
            else
            {
                lblErrOccupation.Visible = false;
                lblErrJobFamily.Visible = false;
                

            }
            if (txtbSal.Text != "")
            {
                if ((Validation.IsContainsSpecialCharaters(txtbSal.Text)) || (!(Validation.IsNumeric(txtbSal.Text))) || (txtbSal.Text.Length > 7))
                {
                    txtbSal.Focus();
                    lblErrSal.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(10);
                    lblErrSal.Visible = true;
                    return false;

                }
                else
                {
                    lblErrSal.Text = "";
                    lblErrSal.Visible = false;
                }
            }
           
            if ((dateTo < dateToday) || (dateFrom < dateToday))
            {

                lblDateErrorS.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(11);
                lblDateErrorS.Visible = true;
                RaddatepickerFrom.Focus();
                return false;
            }
            else
            {
                lblDateErrorS.Visible = false;
               
            }
            if (dateFrom > dateTo)
            {
                lblDateErrorS.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(11);
                lblDateErrorS.Visible = true;
                RaddatepickerFrom.Focus();
                return false;
            }
            else
            {
                lblDateErrorS.Visible = false;
            }
            
            
            return true;
        }

       
        protected void ddJobfamily_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlCreateJobAgent.Visible = true; //To make the pannel visible once the item select event occurs//

            /*To retrieve the occupation list corresponding to Job Family*/

            string JobFamily = ddJobfamily.Text;
            OccupationDDBind(JobFamily);
            ddJobOccupation.Enabled = true;
            
        }

        protected void ddJobOccupation_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlCreateJobAgent.Visible = true;

        }

        protected void AgentSave_Click(object sender, ImageClickEventArgs e)
        {
            //UserID = SessionInfo.UserId;
            if (formValidation() == true)
            {
                try{

            Boolean agentExists = doAgentExists();
            if (agentExists == false)
            {
                //int UserID = SessionInfo.UserId;
                storeData(UserID);
                dispAgentPanel(UserID); // To display the agents associated with this User
                pnlCreateJobAgent.Visible = false; //to hide the Create Agent Pannel
            }
            else
            {
                pnlCreateJobAgent.Visible = true;
           
                txtAgentName.Text = null;
                txtAgentName.Focus();
                lblError.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(4);
                lblError.Visible = true;
            }
                }
                catch { }
            }
            else
            {
                lblMainError.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(5);
                lblMainError.Visible = true;

            }
          

        }

        protected void lnkBtnEdit1_Click(object sender, EventArgs e)
        {

            string agentName = lblAgentName1.Text;
            txtAgentName.Enabled = false;
            txtAgentName.Enabled = false;
            imgBtnEdit.Visible = true;
            AgentSave.Visible = false;
            imgBtnEdit.Enabled = true;
            AgentSave.Enabled = false;
            MyJobAgentFA edFA = new MyJobAgentFA();
            MyJobAgentSH edSH = new MyJobAgentSH();
            edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
            pnlCreateJobAgent.Visible = true;
            formFiller(edSH);   //Calling form filler so as to Fill in the fields of Create Agent Pannel for editing
            
            
        }

        protected void lnkBtnEdit2_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName2.Text;
            txtAgentName.Enabled = false;
            txtAgentName.Enabled = false;
            imgBtnEdit.Visible = true;
            AgentSave.Visible = false;
            imgBtnEdit.Enabled = true;
            AgentSave.Enabled = false;
            MyJobAgentFA edFA = new MyJobAgentFA();
            MyJobAgentSH edSH = new MyJobAgentSH();
            edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
            pnlCreateJobAgent.Visible = true;
            formFiller(edSH);   //Calling form filler so as to Fill in the fields of Create Agent Pannel for editing
            

        }

        protected void lnkBtnEdit3_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName3.Text;
            txtAgentName.Enabled = false;
            txtAgentName.Enabled = false;
            imgBtnEdit.Visible = true;
            AgentSave.Visible = false;
            imgBtnEdit.Enabled = true;
            AgentSave.Enabled = false;
            MyJobAgentFA edFA = new MyJobAgentFA();
            MyJobAgentSH edSH = new MyJobAgentSH();
            edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
            pnlCreateJobAgent.Visible = true;
            formFiller(edSH);   //Calling form filler so as to Fill in the fields of Create Agent Pannel for editing
            
        }

        protected void lnkBtnEdit4_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName4.Text;
            txtAgentName.Enabled = false;
            txtAgentName.Enabled = false;
            imgBtnEdit.Visible = true;
            AgentSave.Visible = false;
            imgBtnEdit.Enabled = true;
            AgentSave.Enabled = false;
            MyJobAgentFA edFA = new MyJobAgentFA();
            MyJobAgentSH edSH = new MyJobAgentSH();
            edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
            pnlCreateJobAgent.Visible = true;
            formFiller(edSH);   //Calling form filler so as to Fill in the fields of Create Agent Pannel for editing
            
        }

        protected void lnkBtnEdit5_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName5.Text;
            txtAgentName.Enabled = false;
            txtAgentName.Enabled = false;
            imgBtnEdit.Visible = true;
            AgentSave.Visible = false;
            imgBtnEdit.Enabled = true;
            AgentSave.Enabled = false;
            MyJobAgentFA edFA = new MyJobAgentFA();
            MyJobAgentSH edSH = new MyJobAgentSH();
            edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
            pnlCreateJobAgent.Visible = true;
            formFiller(edSH);   //Calling form filler so as to Fill in the fields of Create Agent Pannel for editing
            
        }

        protected void lnkBtnEdit6_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName6.Text;
            txtAgentName.Enabled = false;
            imgBtnEdit.Visible = true;
            AgentSave.Visible = false;
            imgBtnEdit.Enabled = true;
            AgentSave.Enabled = false;
            MyJobAgentFA edFA = new MyJobAgentFA();
            MyJobAgentSH edSH = new MyJobAgentSH();
            edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
            pnlCreateJobAgent.Visible = true;
            formFiller(edSH);   //Calling form filler so as to Fill in the fields of Create Agent Pannel for editing
            
        }

       

        protected void lnkBtnDelete1_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName1.Text;
            MyJobAgentFA.deleteAgent(agentName,UserID,CultureID);
            lblErrorAgents.Visible = false;
            dispAgentPanel(UserID); // To display the agents associated with this User
            Response.Redirect("MyJobAgent.aspx");
        }

        protected void lnkBtnDelete2_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName2.Text;
            MyJobAgentFA.deleteAgent(agentName,UserID,CultureID);
            lblErrorAgents.Visible = false;
            dispAgentPanel(UserID); // To display the agents associated with this User
            Response.Redirect("MyJobAgent.aspx");
        }

        protected void lnkBtnDelete3_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName3.Text;
            MyJobAgentFA.deleteAgent(agentName,UserID,CultureID);
            lblErrorAgents.Visible = false;
            Response.Redirect("MyJobAgent.aspx");
        }

        protected void lnkBtnDelete4_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName4.Text;
            MyJobAgentFA.deleteAgent(agentName,UserID,CultureID);
            lblErrorAgents.Visible = false;
            Response.Redirect("MyJobAgent.aspx");
        }

        protected void lnkBtnDelete5_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName5.Text;
            MyJobAgentFA.deleteAgent(agentName,UserID,CultureID);
            lblErrorAgents.Visible = false;
            Response.Redirect("MyJobAgent.aspx");
        }

        protected void lnkBtnDelete6_Click(object sender, EventArgs e)
        {
            string agentName = lblAgentName6.Text;
            MyJobAgentFA.deleteAgent(agentName, UserID,CultureID);
            lblErrorAgents.Visible = false;
            Response.Redirect("MyJobAgent.aspx");
        }

        protected void lnkbtnViewJobss_Click(object sender, EventArgs e)
        {
            try
            {
                //View jobs for candidate in popup using Job Agent
                string agentName = lblAgentName1.Text;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/CandidateViewJob.aspx?id=" + agentName;//Pass Agent Name to retrieve the search criteria for Job
                rd.VisibleOnPageLoad = true;
                rd.Width = 530;
                rd.Height = 250;
                rd.Left = 400;
                rd.Top = 320;
                RadWindowManager1.Windows.Add(rd);
                RadWindowManager1.KeepInScreenBounds = true;
            }
            catch
            {

            }
        }

        protected void chkUpdateMobile_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkUpdateMobile.Checked == true)
                {
                    ddMobile.Enabled = true;
                    ddPostedMobile.Enabled = true;
                    ddFrequencyMobile.Enabled = true;
                }
                else
                {
                    ddMobile.Enabled = false;
                    ddMobile.SelectedValue = "0";
                    ddPostedMobile.Enabled = false;
                    ddFrequencyMobile.Enabled = false;
                    ddPostedMobile.SelectedValue = "None";
                    ddFrequencyMobile.SelectedValue = "None";
                }
            }
            catch { }
        }

        protected void chkUpdateEmail_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkUpdateEmail.Checked == true)
                {
                    ddEmail.Enabled = true;
                    ddFrequencyEmail.Enabled = true;
                    ddPostedEmail.Enabled = true;
                }
                else
                {
                    ddEmail.Enabled = false;
                    ddEmail.SelectedValue = "0";
                    ddPostedEmail.Enabled = false;
                    ddFrequencyEmail.Enabled = false;
                    ddFrequencyEmail.SelectedValue = "None";
                    ddPostedEmail.SelectedValue = "None";
                }
            }
            catch { }
        }

        protected void lnkBtnViewJobs2_Click(object sender, EventArgs e)
        {
            try
            {
                //View jobs for candidate in popup using Job Agent
                string agentName = lblAgentName2.Text;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/CandidateViewJob.aspx?id=" + agentName;//Pass Agent Name to retrieve the search criteria for Job
                rd.VisibleOnPageLoad = true;
                rd.Width = 530;
                rd.Height = 250;
                rd.Left = 400;
                rd.Top = 320;
                RadWindowManager1.Windows.Add(rd);
                RadWindowManager1.KeepInScreenBounds = true;
            }
            catch
            {

            }
        }

        protected void lnkBtnViewJobs4_Click(object sender, EventArgs e)
        {
            try
            {
                //View jobs for candidate in popup using Job Agent
                string agentName = lblAgentName4.Text;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/CandidateViewJob.aspx?id=" + agentName;//Pass Agent Name to retrieve the search criteria for Job
                rd.VisibleOnPageLoad = true;
                rd.Width = 530;
                rd.Height = 250;
                rd.Left = 400;
                rd.Top = 320;
                RadWindowManager1.Windows.Add(rd);
                RadWindowManager1.KeepInScreenBounds = true;
            }
            catch
            {

            }
        }

        protected void lnkBtnViewJobs6_Click(object sender, EventArgs e)
        {
            try
            {
                //View jobs for candidate in popup using Job Agent
                string agentName = lblAgentName6.Text;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/CandidateViewJob.aspx?id=" + agentName;//Pass Agent Name to retrieve the search criteria for Job
                rd.VisibleOnPageLoad = true;
                rd.Width = 530;
                rd.Height = 250;
                rd.Left = 400;
                rd.Top = 320;
                RadWindowManager1.Windows.Add(rd);
                RadWindowManager1.KeepInScreenBounds = true;
            }
            catch
            {

            }
        }

        protected void lnkBtnViewJobs5_Click(object sender, EventArgs e)
        {
            try
            {
                //View jobs for candidate in popup using Job Agent
                string agentName = lblAgentName5.Text;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/CandidateViewJob.aspx?id=" + agentName;//Pass Agent Name to retrieve the search criteria for Job
                rd.VisibleOnPageLoad = true;
                rd.Width = 530;
                rd.Height = 250;
                rd.Left = 400;
                rd.Top = 320;
                RadWindowManager1.Windows.Add(rd);
                RadWindowManager1.KeepInScreenBounds = true;
            }
            catch
            {

            }
        }

        protected void lnkBtnViewJobs3_Click(object sender, EventArgs e)
        {
            try
            {
                //View jobs for candidate in popup using Job Agent
                string agentName = lblAgentName3.Text;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/CandidateViewJob.aspx?id=" + agentName;//Pass Agent Name to retrieve the search criteria for Job
                rd.VisibleOnPageLoad = true;
                rd.Width = 530;
                rd.Height = 250;
                rd.Left = 400;
                rd.Top = 320;
                RadWindowManager1.Windows.Add(rd);
                RadWindowManager1.KeepInScreenBounds = true;
            }
            catch
            {

            }

        }

        protected void ddCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (ddCurrency.SelectedValue == "none")
            {
                txtbSal.Text = null;
                txtbSal.Enabled = false;
               
            }
            else
            {
                txtbSal.Enabled = true;
                
            }

        }

        protected void imgBtnCancel_Click(object sender, ImageClickEventArgs e)
        {
            empty();
            pnlCreateJobAgent.Visible = false;
        }

        protected void imgBtnReset_Click(object sender, ImageClickEventArgs e)
        {
            string agentName = txtAgentName.Text;

            if (agentName == null)
            {
                empty();
            }
            else
            {
                MyJobAgentFA edFA = new MyJobAgentFA();
                MyJobAgentSH edSH = new MyJobAgentSH();
                edSH = edFA.retrieveAgent(agentName, UserID,CultureID);
                formFiller(edSH);
            }
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            lblErrCity.Visible = false;
            if (chkLocation.Checked == true)
            {
                txtCity.Enabled = false;
                txtCity.Text = "-City-";
                RadCombocountry.SelectedIndex = 0;
                RadCombocountry.Enabled = false;
                
            }
            else
            {
                txtCity.Enabled = true;
                RadCombocountry.Enabled = true;
                txtCity.Text = null;
                RadCombocountry.SelectedIndex = 0;

            }
        }

        protected void RadCombocountry_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            
        }

        protected void imgBtnEdit_Click(object sender, ImageClickEventArgs e)
        {
            if (formValidation() == true)
            {
                try
                {

                    int UserID = SessionInfo.UserId;
                    storeData(UserID);
                    dispAgentPanel(UserID); // To display the agents associated with this User
                    pnlCreateJobAgent.Visible = false; //to hide the Create Agent Pannel
                }
                catch { }

            }
            else
            {
                lblMainError.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(5);
                lblMainError.Visible = true;

            }
       }

        
        


        

        //protected void btnCreateCommunity_Click(object sender, EventArgs e)
        //{

        //}

        //protected void btnWhoVisited_Click(object sender, EventArgs e)
        //{

        //}
    }
}
