﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Collections;
using IRSA.BussinessLogic;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using ChartDirector;
using System.Configuration;

namespace IRSA
{
     
    public partial class Assessment360 : System.Web.UI.Page
    {

        string AssessmentCentreXML = "TooltipMsgAssessmentCentre.xml";
        public string JobOccupation
        {
            set
            {
                ViewState["JobOccupation"] = value;
            }
            get
            {
                if (ViewState["JobOccupation"] == null)
                {
                    ViewState["JobOccupation"] = "";
                }
                return ViewState["JobOccupation"].ToString();
            }
        }
        public string OccupationID
        {
            set
            {
                ViewState["OccupationID"] = value;
            }
            get
            {
                if (ViewState["OccupationID"] == null)
                {
                    ViewState["OccupationID"] = "";
                }
                return ViewState["OccupationID"].ToString();
            }
        }
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }


        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public int coquestioncount
        {
            set
            {
                ViewState["coquestioncount"] = value;
            }
            get
            {
                if (ViewState["coquestioncount"] == null)
                {
                    ViewState["coquestioncount"] = 0;
                }
                return Convert.ToInt32(ViewState["coquestioncount"].ToString());
            }
        }
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public int AttemptID
        {
            set
            {
                ViewState["AttemptID"] = value;
            }
            get
            {
                if (ViewState["AttemptID"] == null)
                {
                    ViewState["AttemptID"] = 0;
                }
                return Convert.ToInt32(ViewState["AttemptID"].ToString());
            }
        }
        string questemplate = "360 Degree Assessment";
        string Message;
        int UserID;
        string EmailID;
        string Name;
        string ChartsFilePath;
        string IP, Port;
        protected void Page_Load(object sender, EventArgs e)
        {
            //UserID = 3;
            UserID =  SessionInfo.UserId;
            ChartsFilePath = ConfigurationSettings.AppSettings["ChartsFilePath"];
            IP = ConfigurationSettings.AppSettings["IP"];
            //Port = ConfigurationSettings.AppSettings["Port"];
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                Name = objdt.Rows[0]["FirstName"].ToString() + " " + objdt.Rows[0]["LastName"].ToString();
                EmailID = objdt.Rows[0]["EmailID"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            if (!IsPostBack)
            {
              Comboboxbind();
            }
            GettooltipMessage();
            GetUserAttemptIDfromsubmissonList();
            getSubmitionstatus();
        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    
                    Assessment360FA objassessmentFA = new Assessment360FA();
                    Assessment360SH objAssessment = new Assessment360SH();
                    DataTable Getdt = new DataTable();
                    objAssessment.AttemptID = AttemptID;
                    Getdt = objassessmentFA.Get360AssessmentSubmitQuestions(questemplate, objAssessment, UserID);
                    //coquestioncount = Getdt.Rows.Count;
                    if (Getdt.Rows.Count > 0)
                    {
                        ComboJobFamily.SelectedValue = Getdt.Rows[0]["IndustryID"].ToString();
                        Assessment360FA AssessFA = new Assessment360FA();
                        DataTable temp = new DataTable();
                        int IndustryID = Convert.ToInt32(ComboJobFamily.SelectedValue);
                        temp = AssessFA.BindOccupation(IndustryID);
                        ComboOccupation.DataSource = temp;
                        ComboOccupation.DataBind();
                        ComboOccupation.Text = Getdt.Rows[0]["Title"].ToString();
                        JobOccupation = ComboOccupation.Text;
                        OccupationID = Getdt.Rows[0]["OccupationID"].ToString();
                        
                    }

                    getstatus();
                    if (JobOccupation != "")
                    {
                        BindAssessmentGrid(JobOccupation);
                    }
                }
               
                SelectRadioButton();
            }
            catch
            {
            }
        }
        public void getstatus()
        {
            try
            {
                DataTable dtgetstatus = new DataTable();
                dtgetstatus = ReportBL.GetUserQuestionnaireStatus(questemplate);
                if (dtgetstatus.Rows.Count > 0)
                {
                    string Status = dtgetstatus.Rows[0]["Status"].ToString();
                    if (Status.Trim() == "Submit")
                    {
                        ComboJobFamily.Enabled = false;
                        ComboOccupation.Enabled = false;
                        line1.Visible = true;
                        Panel2.Enabled = true;

                    }
                    else if (Status.Trim() == "Save")
                    {
                        ComboJobFamily.Enabled = false;
                        ComboOccupation.Enabled = false;
                        Panel2.Enabled = false;
                    }
                    else
                    {
                        ComboJobFamily.Enabled = true;
                        ComboOccupation.Enabled = true;
                        Panel2.Enabled = false;
                        Panel1.Visible = false;
                        line1.Visible = false;
                    }
                }
            }
            catch { }

        }
        protected void ComboJobFamily_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Assessment360FA AssessFA = new Assessment360FA();
                DataTable temp = new DataTable();
                int IndustryID = Convert.ToInt32(ComboJobFamily.SelectedValue);
                temp = AssessFA.BindOccupation(IndustryID);
                ComboOccupation.DataSource = temp;
                ComboOccupation.DataBind();
            }
            catch
            {
            }
        }
        public void Comboboxbind()
        {
            try
            {
                Assessment360FA AssessFA = new Assessment360FA();
                DataTable temp = new DataTable();
                temp = AssessFA.BindIndustryData();
                ComboJobFamily.DataSource = temp;
                ComboJobFamily.DataBind();
            }
            catch
            {
            }
        }

        protected void ComboOccupation_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                JobOccupation = ComboOccupation.Text;
                string jobid = ComboOccupation.SelectedValue;
                BindAssessmentGrid(JobOccupation);
            }
            catch
            {
            }
        }

        protected void AssessmentGrid_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                BindAssessmentGrid(JobOccupation);
            }
            catch { }
        }

        protected void rb1_list_selectedindexchanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);

                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");
                eid = AssessmentGrid.MasterTableView.DataKeyValues[gr.ItemIndex]["ElementID"].ToString();
              
                if (objrb2.SelectedValue != "")
                {
                    if (CRecordCount < TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(eid);
                        }
                        CRecordCount++;
                        SaveRecord(eid, objrb2.SelectedValue);
                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCount--;
                        RemoveRecord(eid);
                    }
                }

                SelectRadioButton();
                BindAssessmentGrid(JobOccupation);
            }
            catch { }
        }
        public void BindAssessmentGrid(string JobOccupation)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    GetSavedData();
                }
                Assessment360FA AssessFA = new Assessment360FA();
                DataTable temp = new DataTable();
                temp = AssessFA.Get360AssessmentData(JobOccupation);
                TotalCount = temp.Rows.Count;
                if (TotalCount > 0)
                {
                    LblMessage1.Visible = false;
                    line2.Visible = true;
                    Panel1.Visible = true;
                    AssessmentGrid.DataSource = temp;
                    AssessmentGrid.DataBind();
                }
                else
                {
                    LblMessage1.Visible = true;
                    LblMessage1.Text = "No Questions are Available for this Occupation.";
                }
                if (TotalCount == coquestioncount)
                {
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = false;
                }
                else
                {
                    btnSave.Enabled = true;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = true;
                }
                if (TotalCount == SelectedParentRecord.Count)
                {
                    if (coquestioncount == TotalCount)
                    {
                        btnSubmit.Enabled = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                    }
                    else
                    {
                        btnSubmit.Enabled = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                    }
                }
                else
                {
                    btnSubmit.Enabled = false;
                    btnSave.Enabled = true;
                    btnReset.Enabled = true;
                }
            }
            catch { }
        }
        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }

        private void DeleteAllRecord()
        {
            if (SelectedParentRecord.Count > 0)
            {

                SelectedParentRecord.Clear();
                CRecordCount = 0;
                coquestioncount = 0;
                OccupationID = "";
                JobOccupation = "";
            }

        }
        private void SelectRadioButton()
        {
            try
            {

                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < AssessmentGrid.MasterTableView.Items.Count; i++)
                    {
                        string eid = AssessmentGrid.MasterTableView.DataKeyValues[i]["ElementID"].ToString();



                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            RadioButtonList objrb1 = (RadioButtonList)AssessmentGrid.Items[i].FindControl("rb1_list");
                            objrb1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch
            {
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Assessment360SH objAssessment = new Assessment360SH();
            Assessment360FA objAssessmentFA = new Assessment360FA();
            SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
            SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
            try
            {
                
                    if (SelectedParentRecord.Count > 0)
                    {

                        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                        while (Enumerator.MoveNext())
                        {
                            objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                            objAssessment.ElementID = Enumerator.Key.ToString();
                            objAssessment.ScaleID = "LV";
                            objAssessment.DataValue = (Convert.ToInt32(Enumerator.Value));
                            objAssessment.IndustryID = Convert.ToInt32(ComboJobFamily.SelectedValue);
                            objAssessment.OccupationID = ComboOccupation.SelectedValue;
                            objAssessment.Status = "Save";
                            objAssessment.AttemptID = AttemptID;
                            objAssessmentFA.Insert360Assessment(objAssessment, UserID);
                            objskill.QuestionnaireTemplate = "360 Degree Assessment";
                            objskill.Status = "Save";
                            objskill.AttemptID = AttemptID;
                            objskill.DateSubmitted = System.DateTime.Now.ToString("dd/MMM/yyyy");

                        }
                        objskillFA.InsertQuesSubmissionList(objskill);
                    }
                    LblMsg.Visible = true;
                    LblMsg.Text = "Questions saved successfully.But You can't invite to others to Assess Yourself.You have to submit all questions.";
                    ComboJobFamily.Enabled = false;
                    ComboOccupation.Enabled = false;
                    Panel2.Enabled = false;
                    //string scriptstring = "radalert('Questions saved successfully.<br/> But You can't invite to others to Assess Yourself.<br/>You have to submit all questions.', 310, 150);";
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring, true);
                  
               

                SelectRadioButton();
                BindAssessmentGrid(JobOccupation);
            }
            catch
            {
            }

        }
        private void GetSavedData()
        {
            try
            {
                string questemplate = "360 Degree Assessment";
                Assessment360FA objassessmentFA = new Assessment360FA();
                Assessment360SH objAssessment = new Assessment360SH();
                objAssessment.AttemptID = AttemptID;
                DataTable Getdt = new DataTable();
                Getdt = objassessmentFA.Get360AssessmentSubmitQuestions(questemplate, objAssessment, UserID);
                coquestioncount = Getdt.Rows.Count;
                if (Getdt.Rows.Count > 0)
                {
                    for (int i = 0; i < Getdt.Rows.Count; i++)
                    {
                        string ElementID = Getdt.Rows[i]["ElementID"].ToString();
                        string DataValue = Getdt.Rows[i]["Datavalue"].ToString();
                        CRecordCount++;
                        SaveRecord(ElementID, DataValue);

                    }
                }

            }
            catch
            { }

        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                Assessment360FA objAssessmentFA = new Assessment360FA();
                DataTable temp = new DataTable();

                Assessment360SH objAssessment = new Assessment360SH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                        objAssessment.ElementID = Enumerator.Key.ToString();
                        objAssessment.ScaleID = "LV";
                        objAssessment.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objAssessment.IndustryID = Convert.ToInt32(ComboJobFamily.SelectedValue);
                        objAssessment.OccupationID = ComboOccupation.SelectedValue;
                        objAssessment.AttemptID = AttemptID;
                        objAssessmentFA.Delete360AssessmentSubmitQuestions(objAssessment, UserID);
                    }
                }
                DeleteAllRecord();
                
                BindAssessmentGrid(JobOccupation);
                Panel2.Enabled = false;
                line1.Visible = true;
            }
            catch
            {
            }
        }

        protected void ComboInvitie_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Lblmessage.Visible = false;
                Lblerror.Visible = false;
                Assessment360FA objAssessmentFA = new Assessment360FA();
                Assessment360SH objAssessment = new Assessment360SH();
                DataTable dtinvitestatus = new DataTable();
                objAssessment.WhoIs = ComboInvitie.SelectedValue;
                objAssessment.QuestionnaireTemplate = questemplate;
                objAssessment.AttemptID = AttemptID;
                objAssessment.SubmitStatus = "Send";
                dtinvitestatus = objAssessmentFA.GetInvitationStatus(objAssessment, UserID);
                if (dtinvitestatus.Rows.Count > 0)
                {
                    if (objAssessment.WhoIs != "")
                    {
                        TxtName.Text = dtinvitestatus.Rows[0]["Name"].ToString();
                        TxtEmail.Text = dtinvitestatus.Rows[0]["EmailID"].ToString();
                        TxtMsg.Text = dtinvitestatus.Rows[0]["Message"].ToString();
                    }
                }
                else
                {
                    
                    TxtName.Text = "";
                    TxtEmail.Text = "";
                    TxtMsg.Text = "";
                }
            }
            catch
            {
            }
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                Assessment360FA objAssessmentFA = new Assessment360FA();
                DataTable dtinvitestatus = new DataTable();
                Assessment360SH objAssessment = new Assessment360SH();
                objAssessment.Name = TxtName.Text;
                objAssessment.EmailID = TxtEmail.Text;
                objAssessment.Message = TxtMsg.Text;
                objAssessment.InvitationStatus = "Pending";
                objAssessment.SubmitStatus = "Send";
                objAssessment.WhoIs = ComboInvitie.SelectedValue;
                objAssessment.QuestionnaireTemplate = questemplate;
                objAssessment.AttemptID = AttemptID;
                dtinvitestatus = objAssessmentFA.GetInvitationStatus(objAssessment, UserID);
                if (dtinvitestatus.Rows.Count > 0)
                {
                    Lblerror.Visible = true;
                    Lblerror.Text = "You have already sent invitation to your " + ComboInvitie.SelectedItem.Text + " ." + "You Can't send invitation again.";
                }
                else
                {
                    if (ComboInvitie.SelectedValue != "")
                    {
                        objAssessment.WhoIs = "";
                        DataTable dtinvi = new DataTable();
                        dtinvi = objAssessmentFA.GetInvitationStatus(objAssessment, UserID);
                        if (TxtEmail.Text == EmailID.Trim())
                        {
                            Lblerror.Visible = true;
                            Lblerror.Text = "You Can't sent a invitation to this Email ID.This is your EmailID.Please , Enter other Email ID.";
                            goto Last;
                        }
                        if (dtinvi.Rows.Count > 0)
                        {
                            if (TxtEmail.Text != dtinvi.Rows[0]["EmailID"].ToString().Trim())
                            {
                                objAssessment.WhoIs = ComboInvitie.SelectedValue;
                                objAssessmentFA.Insert360AssessmentInviteStatus(objAssessment, UserID);
                                SendMail();
                                Lblmessage.Visible = true;
                                Lblmessage.Text = "Invitation Sent to your " + ComboInvitie.SelectedItem.Text + " Successfully.";
                                ComboInvitie.SelectedIndex = 0;
                                TxtName.Text = "";
                                TxtEmail.Text = "";
                                TxtMsg.Text = "";
                            }
                            else
                            {
                                Lblerror.Visible = true;
                                Lblerror.Text = "You have already sent a invitation to this Email ID.Please , Enter other Email ID.";
                            }
                        }
                        else
                        {
                            objAssessmentFA.Insert360AssessmentInviteStatus(objAssessment, UserID);
                            SendMail();
                            Lblmessage.Visible = true;
                            Lblmessage.Text = "Invitation Sent to your " + ComboInvitie.SelectedItem.Text + " Successfully.";
                            ComboInvitie.SelectedIndex = 0;
                            TxtName.Text = "";
                            TxtEmail.Text = "";
                            TxtMsg.Text = "";
                        }
                    }
                    else
                    {
                        Lblerror.Visible = true;
                        Lblerror.Text = "Please , First Select type of Invitie.";

                    }
                }
            Last: ;
            }
            catch
            {

            }
        }

        protected void btnInreset_Click(object sender, EventArgs e)
        {
            try
            {
                ComboInvitie.SelectedIndex = 0;
                TxtName.Text = "";
                TxtEmail.Text = "";
                TxtMsg.Text = "";
            }
            catch
            {
            }
        }
         
        public void SendMail()
        {
            try
            {
              
                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(TxtEmail.Text);
                MailAddress fromto = new MailAddress("irsa@iprozone.com");
                MailMessage msg = new MailMessage(fromto, sendto);
                MailDefinition mailmsg = new MailDefinition();
                mailmsg.BodyFileName = "";
                mailmsg.IsBodyHtml = true;
                msg.IsBodyHtml = true;
                string htmlmail;
                int IndustryID = Convert.ToInt32(ComboJobFamily.SelectedValue);
                Message = string.Format(IP+"Assessment360forUser.aspx?param1={0}&param2={1}&param3={2}&param4={3}&param5={4}", UserID, "360DegreeAssessment", ComboInvitie.SelectedValue, IndustryID, OccupationID);

                bodyMsg.Append("Invitation from " + Name);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append(TxtMsg.Text);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Assess for " + Name + ",Please Click on below link:");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");

                bodyMsg.Append(Message);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("iRSA values your privacy at no time has iRSA made your email address available to any other iRSA user without your permission @2009,Powered By iRSA");

                //if (cultureid == "EN")
                //{
                msg.Subject = "Assessment Invitation From " + Name + " from iRSA.com";

                    msg.Body = bodyMsg.ToString();
                

                msg.Priority = MailPriority.High;

                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
            }
            catch { }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Assessment360SH objAssessment = new Assessment360SH();
            Assessment360FA objAssessmentFA = new Assessment360FA();
            SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
            SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
            try
            {
                if (TotalCount == SelectedParentRecord.Count)
                {

                    if (SelectedParentRecord.Count > 0)
                    {

                        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                        while (Enumerator.MoveNext())
                        {
                            objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                            objAssessment.ElementID = Enumerator.Key.ToString();
                            objAssessment.ScaleID = "LV";
                            objAssessment.DataValue = (Convert.ToInt32(Enumerator.Value));
                            objAssessment.IndustryID = Convert.ToInt32(ComboJobFamily.SelectedValue);
                            objAssessment.OccupationID = ComboOccupation.Text;
                            objAssessment.Status = "Submit";
                            objAssessment.AttemptID = AttemptID;
                            objAssessmentFA.Insert360Assessment(objAssessment, UserID);
                            objskill.AttemptID = AttemptID;
                            objskill.QuestionnaireTemplate = "360 Degree Assessment";
                            objskill.Status = "Submit";
                            objskill.DateSubmitted = System.DateTime.Now.ToString("dd/MMM/yyyy");

                        }
                        objskillFA.InsertQuesSubmissionList(objskill);
                    }
                    LblMsg.Visible = true;
                    LblMsg.Text = "You have submitted Your all questions.Now You can invite to others to Assess Yourself.";
                    //string scriptstring = "radalert('You have submitted Your all questions.<br/>Now You can invite to others to Assess Yourself', 310, 150);";
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring, true);
                    ComboJobFamily.Enabled = false;
                    ComboOccupation.Enabled = false;
                    line1.Visible = true;
                    Panel2.Enabled = true;
                    btnReset.Enabled = false;
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;

                }
            }
            catch
            {
            }
        }

        

      
        public void GetUserAttemptIDfromsubmissonList()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable dtattempt = new DataTable();
                dtattempt = objskillFA.GetUserAttemptIDfromsubmissonList(UserID, questemplate);
                if (dtattempt.Rows.Count > 0)
                {
                    AttemptID = Convert.ToInt32(dtattempt.Rows[0]["AttemptID"].ToString());
                }
            }
            catch { }
        }
        private void GettooltipMessage()
        {
            try
            {
                ComboJobFamily.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(4, AssessmentCentreXML);
                ComboOccupation.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, AssessmentCentreXML);
                ComboInvitie.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, AssessmentCentreXML);
                TxtName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, AssessmentCentreXML);
                TxtEmail.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(7, AssessmentCentreXML);
                TxtMsg.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(8, AssessmentCentreXML);
                
                
            }
            catch { }
        }

        public void getSubmitionstatus()
        {
            try
            {
                Assessment360FA objAssessmentFA = new Assessment360FA();
                DataTable dtsumbitionstatus = new DataTable();
                dtsumbitionstatus = objAssessmentFA.GetSubmitionStatusofuser(UserID);
                if (dtsumbitionstatus.Rows.Count > 0)
                {
                    BtnworkcontexReport.Enabled = true;                  
                }
                else
                {
                    BtnworkcontexReport.Enabled = false; 
                }
            }
            catch { }

        }
       
       
    }
}
