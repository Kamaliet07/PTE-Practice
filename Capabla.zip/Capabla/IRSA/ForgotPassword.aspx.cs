﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Net.Mail;
using System.IO;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Text;

namespace IRSA
{
    public partial class ForgotPassword1 : System.Web.UI.Page
    {   
        
       static string passwordString;
       public string cultureid = "EN";
       public string Cultinfo;
        protected void Page_Load(object sender, EventArgs e)
        {
            //LoginLanguageInfo();
        }

                                                                          
        public static string randompassword()
        {
        
        string allowedChars = "";
        allowedChars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";
        allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";
        allowedChars += "1,2,3,4,5,6,7,8,9,0,!,";

        char[] sep = { ',' };
        string[] arr = allowedChars.Split(sep);

        passwordString = "";

        string temp = "";

        Random rand = new Random();
        for (int i = 0; i < 6 ; i++)
        {
            temp = arr[rand.Next(0, arr.Length)];
            passwordString += temp;
        }
            return passwordString;
        }
    
       
       
        public void SendMail()
        {
            try
            {
                LbMsg.Visible = true;
                LbMsg.Visible = true;
                LbMsg.Text = "Mail Send Successfully";
                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(RadTextBox2.Text);
                MailAddress fromto = new MailAddress("shivam@iprozone.com");
                MailMessage msg = new MailMessage(fromto, sendto);
                msg.Subject = "ForgotPassword information";
                msg.Body = "User Name :" + RadTextBox2.Text + "\n Password :" + passwordString + "\n Congratulation! This is Your new Password.After you login,explore the various tools & information to grow your career and get involved!.Your Participation Drives iRSA.com.Thank You for your interest in iRSA iRSA values your privacy at no time has iRSA made your email address available to any other iRSA user without your permission @2009,Powered By iRSA";
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
                }
               
            
            
            catch
            {
            }
        }



        //protected void LoginLanguageInfo()
        //{

        //    if (cultureid == "NL")

        //        Cultinfo = "nl-NL";

        //    else if (cultureid == "FR")

        //        Cultinfo = "fr-FR";

        //    else
        //        Cultinfo = "en-GB";

        //    CultureInfo objCulture = new CultureInfo(Cultinfo);
        //    Thread.CurrentThread.CurrentCulture = objCulture;
        //    Thread.CurrentThread.CurrentUICulture = objCulture;
        //    LblUsernameFP.Text = (string)GetGlobalResourceObject("irsaresource", "LblUsernameFP");
        //    Lblshow.Text = (string)GetGlobalResourceObject("irsaresource", "Lblshow");
        //    LbMsg.Text = (string)GetGlobalResourceObject("irsaresource", "Lblshow");
        //}

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            ForgotPasswordSH objForgotPasswordSH = new ForgotPasswordSH();
            if (RadTextBox2.Text == null)
            {
                Lblshow.Visible = true;
                Lblshow.Text = "EmailID is either Blank or not in correct Format";
            }
            if (Validation.IsValidEmailAddress(RadTextBox2.Text))
            {
                objForgotPasswordSH.UserName = RadTextBox2.Text;
            }
            objForgotPasswordSH.UserName = RadTextBox2.Text;
            ForgotPasswordFA objForgotPasswordFA = new ForgotPasswordFA();
            string pwd = randompassword();
            string newpassword = Encryption.HashPwd(pwd);
            objForgotPasswordSH.Password = newpassword;
            objForgotPasswordFA.GetData(objForgotPasswordSH);
            DataTable ds = new DataTable();
            ds = objForgotPasswordFA.GetData(objForgotPasswordSH);
            int count = ds.Rows.Count;
            if (count > 0)
            {
                SendMail();
                RadTextBox2.Enabled = false;
            }
            else
            {
                Lblshow.Visible = true;
                Lblshow.Text = "User Does Not Exist";
            }
        }
       
    }
        
    }







