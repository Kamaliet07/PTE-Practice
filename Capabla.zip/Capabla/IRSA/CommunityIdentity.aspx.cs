﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using System.Globalization;
using System.Resources;
using System.Configuration;
using System.Threading;
using IRSA.Shared;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using Telerik.Web.UI.Upload;
using System.Drawing;
using System.ComponentModel;
using System.Text;
using System.Security.Cryptography.X509Certificates;



namespace IRSA
{
    public partial class CommunityIdentity : System.Web.UI.Page
    {
        # region Decleration For View State 
        string PhotoDirectoryPath;
        private const string UPLOADFILETYPE = "jpg,gif,png";
        private const int FILESIZEINMB = 1;
        public string FunctionalDomainNem
        {
            set
            {
                ViewState["FunctionalDomainNem"] = value;
            }
            get
            {
                if (ViewState["FunctionalDomainNem"] == null)
                {
                    ViewState["FunctionalDomainNem"] = string.Empty;
                }
                return ViewState["FunctionalDomainNem"].ToString();
            }
        }
        public string ImageName
        {
            set
            {
                ViewState["ImageName"] = value;
            }
            get
            {
                if (ViewState["ImageName"] == null)
                {
                    ViewState["ImageName"] = string.Empty;
                }
                return ViewState["ImageName"].ToString();
            }
        }
        public string CommunityName
        {
            set
            {
                ViewState["CommunityName"] = value;
            }
            get
            {
                if (ViewState["CommunityName"] == null)
                {
                    ViewState["CommunityName"] = string.Empty;
                }
                return ViewState["CommunityName"].ToString();
            }
        }

        public string CommunityType
        {
            set
            {
                ViewState["CommunityType"] = value;
            }
            get
            {
                if (ViewState["CommunityType"] == null)
                {
                    ViewState["CommunityType"] = string.Empty;
                }
                return ViewState["CommunityType"].ToString();
            }
        }
        public string OwnerEmail
        {
            set
            {
                ViewState["OwnerEmail"] = value;
            }
            get
            {
                if (ViewState["OwnerEmail"] == null)
                {
                    ViewState["OwnerEmail"] = string.Empty;
                }
                return ViewState["OwnerEmail"].ToString();
            }
        }
        public int CommunityID
        {
            set
            {
                ViewState["CommunityID"] = value;
            }
            get
            {
                if (ViewState["CommunityID"] == null)
                {
                    ViewState["CommunityID"] = 0;
                }
                return Convert.ToInt32(ViewState["CommunityID"].ToString());
            }
        }
        
        #endregion
        string Accountxml = "Community.xml";
        string Message;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                PhotoDirectoryPath = ConfigurationSettings.AppSettings["CommunityLogo"];
                lblMessage.Text = string.Empty;
                int UserID = SessionInfo.UserId;
                if (UserID != int.MinValue)
                {
                    Lblmember.Text = SessionInfo.FirstName + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
              if (!IsPostBack)
               {
                  this.FunctionalDomainNem = SessionInfo.i_FunctionalDomain;
                  LabelDomainName.Text = SessionInfo.i_FunctionalDomain;
                  ButtonCreateComm.BackColor = System.Drawing.Color.OrangeRed;                 
                  FillCommunityType();
                  GetiRsaToolTipAccMsg();
                  ButtonSave.Enabled = false;
                  ImageCommunity.ImageUrl = "~/images/help.png";                  
               
               }
            }
            catch
            {
            }
        }       

        private void FillCommunityType()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/CommunityCategory.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                RadComboBoxCommunityType.LoadXml(NodeIter1.Current.InnerXml);

            }
            catch
            {
            }
        }              

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (RadComboBoxCommunityType.SelectedValue == "Select")
                {
                    LblError.Text = "Please Select Community type";
                }
                else if (TextBoxShortDes.Text == "")
                {
                    LblError.Text = "Please Enter Short Description";

                }
                else if (txtCommunityOwnerName.Text == "" || txtOwnerEmail.Text == "")
                {
                    LblError.Text = "Please Enter Owner Name and Email ID";

                }
                else
                {

                    NewCommunityInfo objcommunitysave = new NewCommunityInfo();
                    objcommunitysave.CommunityName = TxtBoxCommName.Text;
                    this.CommunityName = TxtBoxCommName.Text;
                    objcommunitysave.CommunityLogo = this.ImageName;
                    objcommunitysave.CommunityType = RadComboBoxCommunityType.SelectedValue;
                    this.CommunityType = RadComboBoxCommunityType.SelectedValue;
                    objcommunitysave.FunctionalDomain = this.FunctionalDomainNem;
                    objcommunitysave.ShortDescription = TextBoxShortDes.Text;
                    objcommunitysave.DetailDescription = TextBoxDetDesc.Text;
                    objcommunitysave.WebSiteURL = TextBoxWebUrl.Text;
                    objcommunitysave.CommunityOwnerName = txtCommunityOwnerName.Text;
                    objcommunitysave.CommunityOwnerEmail = txtOwnerEmail.Text;
                    this.OwnerEmail = txtOwnerEmail.Text;
                    objcommunitysave.CommunityDirectoryDisplay = CheckBox1.Checked;
                    objcommunitysave.CommunityLogoDisplay = CheckBox2.Checked;
                    objcommunitysave.CommunityOwnerApproval = CheckBox3.Checked;
                    objcommunitysave.Status = CheckBoxAcc.Checked;
                    IRSA.Facade.Community.CommunityFA objInsertComm = new IRSA.Facade.Community.CommunityFA();
                    DataTable objtb = new DataTable();
                    objInsertComm.SaveNewCommunity(this.FunctionalDomainNem, objcommunitysave);
                    LblError.Text = "Community Saved Successfully";
                    SendInfoToAdmin();
                    
                }
            }

            catch
            { 
            
            
            }
        }

        private void SendInfoToAdmin()
        {
            try
            {

                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress("kamal@iprozone.com");
                MailAddress fromto = new MailAddress(this.OwnerEmail);
                MailMessage msg = new MailMessage(fromto, sendto);
                MailDefinition mailmsg = new MailDefinition();
                mailmsg.BodyFileName = "";
                mailmsg.IsBodyHtml = true;
                msg.IsBodyHtml = true;

                bodyMsg.Append("A new community" + this.CommunityName + "under the community Type " + this.CommunityType);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");                
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Created By " + this.OwnerEmail + ",with functional domain" + this.FunctionalDomainNem);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");                
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Please Check For approval");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("iRSA values your privacy at no time has iRSA made your email address available to any other iRSA user without your permission @2009,Powered By iRSA");
                                
                msg.Subject = "Member Community Creation in iRSA.com";

                msg.Body = bodyMsg.ToString();


                msg.Priority = MailPriority.High;

                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
            }
            catch { }
        }

        protected void CheckBoxAcc_OnCheckedChanged(object sender, EventArgs e)
        {
            ButtonSave.Enabled = true;
        }

        protected void radAjaxManager_AjaxRequest(object sender, AjaxRequestEventArgs e)
        {

        }
        
        public void GetCommunityID()
        {

            IRSA.Facade.Community.CommunityFA comm = new IRSA.Facade.Community.CommunityFA();
            DataTable temp1 = new DataTable();
            temp1 = comm.GetMaxCommunityID();
            foreach (DataRow dr in temp1.Rows)
            {
                this.CommunityID = Convert.ToInt32(temp1.Rows[0]["CommunityID"].ToString());
                this.CommunityID = this.CommunityID + 1;
            }
        }

        protected void ButtonUpload_Click(object sender, EventArgs e)
        {
            //GetCommunityID();
            string file = FileUploadImg.FileName;
            //string NewFile;
            if (file != "")
            {
                this.ImageName = file;
                SaveFile();
                System.Threading.Thread.Sleep(5000);            
                //FileUploadImg.PostedFile.SaveAs(PhotoDirectoryPath + file);
                ImageCommunity.ImageUrl = "~/ProjectImage/" + file;                
                
            }
            else
            {
                this.ImageName = "help.png";
            }
        }

        #region Private Methods

        private void SaveFile()
        {
            string strFileName = null;
            string strInputFilePath = null;
            int i = 0;
            string strMessage = string.Empty;
            bool rtnValue = true;
            if (FileUploadImg.FileName != string.Empty && FileUploadImg.FileName != null)
            {
                strFileName = FileUploadImg.FileName.Trim();

                if (!IsValidFile(strFileName)) /// check Extention
                {
                    rtnValue = false;
                    strMessage += "<br>" + "Invalid file format. File must be of format jpg,gif or png";
                    i += 1;
                }

                //Files exists in our upload folder or not.
                strInputFilePath = Server.MapPath("ProjectImage") + "\\" + strFileName;

                if (System.IO.File.Exists(strInputFilePath))
                {
                    rtnValue = false;
                    strMessage += "<br> File '" + FileUploadImg.FileName + "' - already exists in destination folder";
                    i += 1;
                }

                if (FileUploadImg.PostedFile.ContentLength <= 0)
                {
                    strMessage += "<br>" + "File '" + FileUploadImg.FileName + "' - does not exists physically";
                    rtnValue = false;
                    i += 1;
                }

                if (FileUploadImg.PostedFile.ContentLength > ((FILESIZEINMB * 1024) * 1024))
                {
                    strMessage += "<br>" + "File size shouldbe less than or equal to " + FILESIZEINMB.ToString() + " MB";
                    rtnValue = false;
                    i += 1;
                }
                if (rtnValue)
                {
                    strInputFilePath = Server.MapPath("ProjectImage") + "\\";
                    FileUploadImg.PostedFile.SaveAs(strInputFilePath + FileUploadImg.FileName);
                    //string strFile = FileUpload1.FileName;
                    //string strFileExtension = strFile.Substring(strFile.LastIndexOf('.'));
                    //string strFileName1 = strFile.Substring(0, strFile.LastIndexOf('.'));
                    //FileUpload1.PostedFile.SaveAs(strInputFilePath + strFileName1 + "-" + DateTime.Now.Ticks.ToString() + strFileExtension);                   
                }

                if (strMessage != string.Empty)
                {
                    if (i > 1)
                    {
                        strMessage = "There are following errors while uploading file," + strMessage;
                    }
                    lblMessage.Text = strMessage;
                }
                if (rtnValue)
                {
                    lblMessage.Text = "File uploaded successfully";
                }
            }
            else
            {
                lblMessage.Text = "Please browse a file to upload";
            }


        }

        /// <summary>
        /// Check for uploaded file has valid Extension or not
        /// </summary>
        /// <param name="strFilename"></param>
        /// <returns></returns>
        public static bool IsValidFile(string strFilename)
        {
            string strFileType = GetFileExtension(strFilename);
            string[] strValidImageFile = UPLOADFILETYPE.Split(new char[] { ',' });
            bool blnIsValid = false;

            if (strValidImageFile.Length <= 0)
            {
                return false;
            }

            for (int indx = 0; indx < strValidImageFile.Length; indx++)
            {
                if (strFileType.ToUpper() == strValidImageFile[indx].ToUpper())
                {
                    blnIsValid = true;
                }
            }
            return blnIsValid;
        }

        /// <summary>
        /// To get the extension of particular file.
        /// </summary>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        public static string GetFileExtension(string strFileName)
        {
            int intIndex = strFileName.LastIndexOf(".");
            string strExtension = strFileName.Substring(intIndex + 1);
            return strExtension;
        }

        #endregion

        
        private string ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(OriginalFile);
            FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
            FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
            System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);
            FullsizeImage.Dispose();
            // Save resized picture
            NewImage.Save(NewFile);
            return NewImage.ToString();
        }

        protected void CheckBoxAcc_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBoxAcc.Checked)
            {
                ButtonSave.Enabled = true;
            }
            else
            {
                ButtonSave.Enabled = false;
            }
        }

        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                TxtBoxCommName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, Accountxml);
                FileUploadImg.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, Accountxml);
                TextBoxShortDes.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, Accountxml);
                TextBoxDetDesc.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(4, Accountxml);
                TextBoxWebUrl.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                txtCommunityOwnerName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                txtOwnerEmail.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(7, Accountxml);
                

            }
            catch { }
        }
        

        }
    }

