﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.Data;
using System.Text;
using System.Xml.XPath;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Configuration;
using IRSA.BussinessLogic;


namespace IRSA
{
    public partial class MyCommunity : System.Web.UI.Page
    {
        string strExpression;
        int UserID;
        string AddCommunityImage;
        public int CommunityID
        {
            set
            {
                ViewState["CommunityID"] = value;
            }
            get
            {
                if (ViewState["CommunityID"] == null)
                {
                    ViewState["CommunityID"] = 0;
                }
                return Convert.ToInt32(ViewState["CommunityID"].ToString());
            }
        }
        public DataTable AllMyCommunity
        {
            get { return (DataTable)ViewState["AllMyCommunity"]; }
            set { ViewState["AllMyCommunity"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserID = SessionInfo.UserId;
                AddCommunityImage = ConfigurationSettings.AppSettings["AddCommunityImage"];
                if (UserID != int.MinValue)
                {
                    Lblmember.Text = SessionInfo.FirstName + " " + "!";                   
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            if (!IsPostBack)
            {
                LabelDomainName.Text = SessionInfo.i_FunctionalDomain;               
                FindAllMyCommunity();
                btnMyCommunity.BackColor = System.Drawing.Color.OrangeRed;
                   
            }

            }
            catch
            {
            }

        }

        private void FindAllMyCommunity()
        {
            IRSA.Facade.Community.CommunityFA ObjMyComm = new IRSA.Facade.Community.CommunityFA();
            this.AllMyCommunity = ObjMyComm.getAllMyCommunityDetail();
            RebindTablleForImage();
            BindMyCommunityGrid();
        }

        private void RebindTablleForImage()
        {
            this.AllMyCommunity.Columns.Add(new DataColumn("NewImagePath", typeof(string)));
            foreach (DataRow dr in this.AllMyCommunity.Rows)
            {
                string imagpath = AddCommunityImage + dr["CommunityLogo"].ToString();
                dr["NewImagePath"] = imagpath;
            }
        }
        private void BindMyCommunityGrid()
        {
            try
            {
                if (this.AllMyCommunity.Rows.Count > 0)
                {
                    RadGridMyCommunity.DataSource = this.AllMyCommunity;
                    RadGridMyCommunity.DataBind();
                
                }
            }

            catch
            { 
            
            }
        }
               

        protected void RadGridMyCommunity_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGridMyCommunity.CurrentPageIndex = e.NewPageIndex;
        }
        
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton chk = (LinkButton)sender;
            LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LinkButton1");
            this.CommunityID = Convert.ToInt32(RadGridMyCommunity.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
            Response.Redirect("CommunityDetail.aspx?ID=" + this.CommunityID);
        }

        protected void LnkBtnOverview_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton chk = (LinkButton)sender;
            LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LnkBtnOverview");
            this.CommunityID = Convert.ToInt32(RadGridMyCommunity.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
            Response.Redirect("CommunityDetail.aspx?ID=" + this.CommunityID);
        }

        protected void LnkBtnDiscussn_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton chk = (LinkButton)sender;
            LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LnkBtnDiscussn");
            this.CommunityID = Convert.ToInt32(RadGridMyCommunity.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
        }

        protected void LnkBtnMember_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton chk = (LinkButton)sender;
            LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LnkBtnMember");
            this.CommunityID = Convert.ToInt32(RadGridMyCommunity.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
            Response.Redirect("CommunityMember.aspx?ID=" + this.CommunityID);
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton chk = (LinkButton)sender;
            LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LinkButton5");
            this.CommunityID = Convert.ToInt32(RadGridMyCommunity.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
        }

        protected void ImgBtnAdvance_Click(object sender, ImageClickEventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            ImageButton chk = (ImageButton)sender;
            ImageButton obj = (ImageButton)chk.NamingContainer.FindControl("ImgBtnAdvance");
            this.CommunityID = Convert.ToInt32(RadGridMyCommunity.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
            Response.Redirect("CommunityDetail.aspx?ID=" + this.CommunityID);
        }
        
        protected void radAjaxManager_AjaxRequest(object sender, AjaxRequestEventArgs e)
        {

        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {

        }

        protected void RadGridMyCommunity_OnItemCommand(object source, GridCommandEventArgs e)
        {
            if (e.CommandName == "MyDelete")
            {
                int rowindex = e.Item.ItemIndex;
                GridDataItem item = this.RadGridMyCommunity.Items[rowindex];
                int CommID = Convert.ToInt32(item.GetDataKeyValue("CommunityID").ToString());
                RemoveCommunityFromEmployeeContactList(CommID);
                FindAllMyCommunity();
            }
        }

        private void RemoveCommunityFromEmployeeContactList(int CommID)
        {
            try
            {
              IRSA.Facade.Community.CommunityFA CommRemove = new IRSA.Facade.Community.CommunityFA();
              CommRemove.RemoveFromUserList(CommID);
              RebindCommunityGrid();

            }
            catch
            {             
            
            }
        }

        private void RebindCommunityGrid()
        {
            RadGridMyCommunity.DataSource = EmptyUserSavedData();
            RadGridMyCommunity.DataBind();
            FindAllMyCommunity();

        }

        private static DataTable EmptyUserSavedData()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("CommunityID", typeof(int)));
            objDT.Columns.Add(new DataColumn("CommunityName", typeof(string)));
            objDT.Columns.Add(new DataColumn("ShortDescription", typeof(string)));            
            return objDT;

        }

        protected void RadGridMyCommunity_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGridMyCommunity.DataSource = this.AllMyCommunity;
            RadGridMyCommunity.DataBind();
        }

       
                        
        
    }
}
