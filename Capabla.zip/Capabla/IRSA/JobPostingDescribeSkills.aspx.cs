﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using Telerik.Web.UI;
using System.Collections;
using IRSA.Shared;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Resources;
using IRSA.BussinessLogic;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
namespace IRSA
{
    public partial class JobPostingDescribeSkills : System.Web.UI.Page
    {
        int UserID;
        
        int JobID;
        string CULINFO;
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }
        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {

            }
         //JobID = 15;
         //UserID = 9;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            string Job = Request.QueryString.Get("ID");
            if (Job != "")
            {
                JobID = Convert.ToInt32(Job);
            }
           
        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                getJobDescribeSkillsPageLanguageInfo();
                if (!Page.IsPostBack)
                {
                   
        
                    GetData();
                    selectOccupationName();

                }
                SelectQuestionnaireRadioList();

               
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        protected void selectOccupationName()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.selectOccupationName(JobID);
                if (dt.Rows.Count > 0)
                {
                    LblOccupationName.Text = dt.Rows[0]["Title"].ToString();
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }


        private void GetData()
        {
            if (!Page.IsPostBack)
            {
                GetSavedData();
            }
            JobPostingFA ObjJobBL = new JobPostingFA();
            DataTable dt = new DataTable();
            dt = ObjJobBL.SelectJobProfile44(JobID);
            TotalCount = dt.Rows.Count;
            Grid_JobQuestionnaire.DataSource = dt;
            Grid_JobQuestionnaire.DataBind();
        }


      
        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }

        private void DeleteAllRecord()
        {
            if (SelectedParentRecord.Count > 0)
            {

                SelectedParentRecord.Clear();

            }

        }
     

       

        protected void Button2_Click(object sender, EventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        protected void Savedata()
        {
            try
            {
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();


                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        JobPostingFA objJobFA = new JobPostingFA();
                        objskill.ElementID = Enumerator.Key.ToString();
                        objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objJobFA.InsertJobSkillQues(objskill, JobID);

                    }
                }
                LblMassge.Visible = true;
                LblMassge.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(50);
                SelectedParentRecord.Clear();
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
        }

        protected void CompanyInfo_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("PostJobCompanyInformation.aspx?ID=" + JobID);
        }

        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
        }

        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingDescribetoolsandtech.aspx?ID=" + JobID);
        }

        protected void rb1_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");

                eid = Grid_JobQuestionnaire.MasterTableView.DataKeyValues[gr.ItemIndex]["ElementID"].ToString();
                if (objrb2.SelectedValue != "")
                {
                    if (CRecordCount <= TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(eid);

                        }
                        CRecordCount++;
                        SaveRecord(eid, objrb2.SelectedValue);

                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCount--;
                        RemoveRecord(eid);

                    }
                }

                SelectQuestionnaireRadioList();

            }

            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }

        }

     

       

        

    

   

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Savedata();
        }
        private void GetSavedData()
        {
            try
            {
                JobPostingFA ObjjobFA = new JobPostingFA();
                DataTable Getdt = new DataTable();
                Getdt = ObjjobFA.GetJobQuestionnaireData(JobID);


                if (Getdt.Rows.Count > 0)
                {
                    for (int i = 0; i < Getdt.Rows.Count; i++)
                    {
                        string ElementID = Getdt.Rows[i]["ElementID"].ToString().Trim();
                        string DataValue = Getdt.Rows[i]["DataValue"].ToString();


                        SaveRecord(ElementID, DataValue);
                    }
                }
                else
                {
                    JobPostingFA ObjjobFA1 = new JobPostingFA();
                    DataTable Getdt1 = new DataTable();
                    Getdt1 = ObjjobFA1.SelectJobProfile44(JobID);
                    if (Getdt1.Rows.Count > 0)
                    {
                        for (int i = 0; i < Getdt1.Rows.Count; i++)
                        {
                            string ElementID = Getdt1.Rows[i]["ElementID"].ToString().Trim();
                            string DataValue = Getdt1.Rows[i]["DataValue"].ToString();


                            SaveRecord(ElementID, DataValue);

                        }
                    }
                }

            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }

        private void SelectQuestionnaireRadioList()
        {
            try
            {
                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < Grid_JobQuestionnaire.MasterTableView.Items.Count; i++)
                    {
                        string eid = Grid_JobQuestionnaire.MasterTableView.DataKeyValues[i]["ElementID"].ToString().Trim();


                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            RadioButtonList obj1 = (RadioButtonList)Grid_JobQuestionnaire.Items[i].FindControl("rb1_list");
                            obj1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        protected void getJobDescribeSkillsPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_JobPostingDescribeSkills");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_JobPostingDescribeSkills");
                //Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingProfile");

                Label224.Text = (string)GetGlobalResourceObject("PageResource", "Label224_JobPostingDescribeSkills");
                Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_JobPostingDescribeSkills");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_JobPostingDescribeSkills");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_JobPostingDescribeSkills");

                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_JobPostingDescribeSkills");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_JobPostingDescribeSkills");
                Lbltext.Text = (string)GetGlobalResourceObject("PageResource", "Lbltext_JobPostingDescribeSkills");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_JobPostingDescribeSkills");
                //Label22.Text = (string)GetGlobalResourceObject("PageResource", "Label22_JobPostingDescribeSkills");
                btnupdate.Text = (string)GetGlobalResourceObject("PageResource", "btnupdate_JobPostingDescribeSkills");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_JobPostingDescribeSkills");

                Button1.Text = (string)GetGlobalResourceObject("PageResource", "Button1_JobPostingDescribeSkills");
            }
            catch
            {
            }
        }

    }
}
