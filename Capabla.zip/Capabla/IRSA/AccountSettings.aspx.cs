﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;
using System.Collections.Specialized;

namespace IRSA
{
    public partial class AccountSettings : System.Web.UI.Page
    {
        int UserID;
        //StringCollection idCollection = new StringCollection();
        string IP;
        int OrganisationID;
        string Port;
        string AppName;
        public StringCollection idCollection
        {
            set
            {
                ViewState["idCollection"] = value;
            }
            get
            {
                if (ViewState["idCollection"] == null)
                {
                    ViewState["idCollection"] = "";
                }
                return (StringCollection)ViewState["idCollection"];
            }
        }
        //public string IDs
        //{
        //    set
        //    {
        //        ViewState["IDs"] = value;
        //    }
        //    get
        //    {
        //        if (ViewState["IDs"] == null)
        //        {
        //            ViewState["IDs"] = "";
        //        }
        //        return ViewState["IDs"].ToString();
        //    }
        //}
        public string streveryone
        {
            set
            {
                ViewState["streveryone"] = value;
            }
            get
            {
                if (ViewState["streveryone"] == null)
                {
                    ViewState["streveryone"] = "";
                }
                return ViewState["streveryone"].ToString();
            }
        }
        public string strcontact
        {
            set
            {
                ViewState["strcontact"] = value;
            }
            get
            {
                if (ViewState["strcontact"] == null)
                {
                    ViewState["strcontact"] = "";
                }
                return ViewState["strcontact"].ToString();
            }
        }
        public string strcommunities
        {
            set
            {
                ViewState["strcommunities"] = value;
            }
            get
            {
                if (ViewState["strcommunities"] == null)
                {
                    ViewState["strcommunities"] = "";
                }
                return ViewState["strcommunities"].ToString();
            }
        }
        string Message;
        string IDs;
        string CULINFO;

        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountSettingsPageLanguageInfo();
            IP = ConfigurationSettings.AppSettings["IP"];
            Port = ConfigurationSettings.AppSettings["Port"];
            OrganisationID = SessionInfo.OrgID;
            UserID = SessionInfo.UserId;
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Lblapp.Text = AppName;
            Lblapp1.Text = AppName;
            // UserID = 30;
            if (!this.IsPostBack)
            {
                GeetData();
                Getcontactsettig();
                Getvisible();
                GetProfilePhoto();
                getURL();
                Getirsapermission();
                GetSalaryDetails();
                FillIndustry();
                GetData();
                GetRecruiterAllow();
                GetPrefInd();
                Getnamestatus();
            }
            if (UserID != int.MinValue)
            {

                AccountSettingFA objaccsett = new AccountSettingFA();
                DataTable objroledt = new DataTable();
                objroledt = objaccsett.GetUserRole(UserID);
                if (objroledt.Rows.Count > 0)
                {
                    if (objroledt.Rows[0]["Who"].ToString() == "RC")
                    {
                        ViewOrganisationFA objaccFA = new ViewOrganisationFA();
                        DataTable objdt = new DataTable();
                        objdt = objaccFA.GetViewContactData(UserID, OrganisationID);
                        Lblmember.Text = objdt.Rows[0]["FullName"].ToString() + " " + "!";
                        SessionInfo.FirstName = objdt.Rows[0]["FullName"].ToString();
                    }
                    else if ((objroledt.Rows[0]["Who"].ToString() == "OR") || (objroledt.Rows[0]["Who"].ToString() == "IN"))
                    {
                        ViewOrganisationFA objaccFA = new ViewOrganisationFA();
                        DataTable objdt = new DataTable();
                        objdt = objaccFA.GetViewContactData(UserID, OrganisationID);
                        Lblmember.Text = objdt.Rows[0]["FullName"].ToString() + " " + "!";
                        SessionInfo.FirstName = objdt.Rows[0]["FullName"].ToString();
                    }
                    else if ((objroledt.Rows[0]["Who"].ToString() == "JS") || (objroledt.Rows[0]["Who"].ToString() == "St"))
                    {
                        AccountsetupFA objaccFA = new AccountsetupFA();
                        DataTable objdt = new DataTable();
                        objdt = objaccFA.GetaccountData(UserID);
                        if (objdt.Rows[0]["FirstName"].ToString() != "")
                        {
                            Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                            SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                        }
                        else
                        {
                            Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                            SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                        }
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            //    AccountsetupFA objaccFA = new AccountsetupFA();
            //    DataTable objdt = new DataTable();
            //    objdt = objaccFA.GetaccountData(UserID);
            //    if (objdt.Rows[0]["FirstName"].ToString() != "")
            //    {
            //        Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
            //        SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
            //    }
            //    else
            //    {
            //        Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            //        SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            //    }
            //}
            //else
            //{
            //    Response.Redirect("Login.aspx");
            //}

        }
        //***Code For Change Password***
        protected void Linkchangepwd_Click(object sender, EventArgs e)
        {

            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";
            rd.NavigateUrl = "~/ChangePassword.aspx";
            rd.VisibleOnPageLoad = true;
            rd.Width = 330;
            rd.Height = 300;
            rd.Left = 400;
            rd.Top = 320;
            rd.Title = "Change Password";
            RadWindowManager1.Windows.Add(rd);
        }
        //***Code For Name & Location***
        protected void Linkeditwelcome_Click(object sender, EventArgs e)
        {
            try
            {
                AccountSettingFA objaccsett = new AccountSettingFA();
                DataTable objroledt = new DataTable();
                objroledt = objaccsett.GetUserRole(UserID);
                if (objroledt.Rows.Count > 0)
                {
                    if (objroledt.Rows[0]["Who"].ToString() == "RC")
                    {
                        Response.Redirect("RecruiterAccount.aspx");
                    }
                    else if ((objroledt.Rows[0]["Who"].ToString() == "OR") || (objroledt.Rows[0]["Who"].ToString() == "IN"))
                    {
                        Response.Redirect("OrgAccount.aspx");
                    }
                    else if ((objroledt.Rows[0]["Who"].ToString() == "JS") || (objroledt.Rows[0]["Who"].ToString() == "St"))
                    {
                        Response.Redirect("AccountWelcome.aspx");
                    }
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }

            catch { }

        }


        //*** code for close account***
        protected void LinkCloseAccount_Click(object sender, EventArgs e)
        {
            Button3.Visible = true;
            Button4.Visible = true;
            Btnok.Visible = false;
            Lblmsg.Visible = false;
            Panel1.Visible = true;
            LinkCloseAccount.Text = "";
        }
        protected void Btnok_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
        }
        //protected void Button3_Click(object sender, EventArgs e)
        //{
        //   // Panel1.Visible = false;
        //}

        protected void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                IRSA.Facade.CloseAccountFA objcloseconnectionFA = new IRSA.Facade.CloseAccountFA();
                objcloseconnectionFA.Closeconn(UserID);
                Lblmsg.Visible = true;
                Lblmsg.Text = ErrorMessage.GetiRsaErrorMessage(88);
                Button3.Visible = false;
                Button4.Visible = false;
                Btnok.Visible = true;
            }
            catch { }
        }
        //Code for Contact Browse***
        protected void Button4_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
        }



        protected void LinkContact_Click(object sender, EventArgs e)
        {
            Button2.Visible = true;
            Btncontconfirm.Visible = true;
            Buttonok.Visible = false;
            Lblconbrozmsg.Visible = false;
            Panelcontactbrowse.Visible = true;
            GeetData();
        }

        protected void Btncontconfirm_Click(object sender, EventArgs e)
        {
            try
            {
                if (chkeveryone.Checked == true || Chkcontacts.Checked == true || chkcommunities.Checked == true)
                {
                    AccountSettingSH objaccsettSH = new AccountSettingSH();
                    AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                    objaccsettSH.ContactBrowse = "Contacts Browse";
                    if (chkeveryone.Checked == true)
                    {
                        objaccsettSH.everyone = "1";
                    }
                    if (Chkcontacts.Checked == true)
                    {
                        objaccsettSH.mycontacts = "1";
                    } if (chkcommunities.Checked == true)
                    {
                        objaccsettSH.mycommunities = "1";
                    }

                    objAccountSettingFA.Insertaccessroles(UserID, objaccsettSH);
                    Btncontconfirm.Visible = false;
                    Button2.Visible = false;
                    Lblconbrozmsg.Visible = true;
                    Lblconbrozmsg.Text = ErrorMessage.GetiRsaErrorMessage(89);
                    Buttonok.Visible = true;
                }
                else
                {
                    Lblconbrozmsg.Visible = true;
                    Lblconbrozmsg.Text = ErrorMessage.GetiRsaErrorMessage(90);
                }
            }
            catch { }
        }

        protected void Buttonok_Click(object sender, EventArgs e)
        {
            Panelcontactbrowse.Visible = false;

        }

        public void GeetData()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                objaccsettSH.ContactBrowse = "Contacts Browse";
                DataTable objdt = new DataTable();
                objdt = objaccsetFA.GetContactbrowseData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    chkeveryone.Checked = (Convert.ToBoolean(objdt.Rows[0]["everyone"].ToString()));
                    Chkcontacts.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyContact"].ToString()));
                    chkcommunities.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyCommunities"].ToString()));
                }
            }
            catch { }
        }


        protected void LinkProfile_Click(object sender, EventArgs e)
        {
            RadWindow rd = new RadWindow();
            rd.ID = "radprofileview";
            rd.NavigateUrl = "~/Previligesetting.aspx";
            rd.VisibleOnPageLoad = true;
            rd.Width = 400;
            rd.Height = 380;
            rd.Left = 400;
            rd.Top = 320;
            rd.Title = "Profile Settings";
            RadWindowManager1.Windows.Add(rd);
        }


        //code for contact setting(recieving invitations)***

        protected void LinkContsett_Click(object sender, EventArgs e)
        {
            PanelContactSetting.Visible = true;
            Btnconsett.Visible = true;
            Btnconsettcancel.Visible = true;
            Lblconset.Visible = false;
            Butok.Visible = false;
            Getcontactsettig();
        }
        public void Getcontactsettig()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objaccsettSH.ContactSettings = "Contact Settings";
                objdt = objaccsetFA.GetconsettData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    Checkeveryone.Checked = (Convert.ToBoolean(objdt.Rows[0]["everyone"].ToString()));
                    Checkcontacts.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyContact"].ToString()));
                    Checkcommunities.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyCommunities"].ToString()));
                }
            }
            catch { }
        }

        protected void Btnconsett_Click(object sender, EventArgs e)
        {
            try
            {
                if (Checkeveryone.Checked == true || Checkcontacts.Checked == true || Checkcommunities.Checked == true)
                {
                    AccountSettingSH objaccsettSH = new AccountSettingSH();
                    AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                    objaccsettSH.ContactSettings = "Contact Settings";
                    if (Checkeveryone.Checked == true)
                    {
                        objaccsettSH.everyone = "1";
                    }
                    if (Checkcontacts.Checked == true)
                    {
                        objaccsettSH.mycontacts = "1";
                    } if (Checkcommunities.Checked == true)
                    {
                        objaccsettSH.mycommunities = "1";
                    }

                    objAccountSettingFA.InsertContactSettings(UserID, objaccsettSH);
                    Btnconsett.Visible = false;
                    Btnconsettcancel.Visible = false;
                    Lblconset.Visible = true;
                    Lblconset.Text = ErrorMessage.GetiRsaErrorMessage(89);
                    Butok.Visible = true;
                }
                else
                {
                    Lblconset.Visible = true;
                    Lblconset.Text = ErrorMessage.GetiRsaErrorMessage(90);
                }
            }
            catch { }
        }

        protected void Btnconsettcancel_Click(object sender, EventArgs e)
        {
            PanelContactSetting.Visible = false;
        }

        protected void Butok_Click(object sender, EventArgs e)
        {
            PanelContactSetting.Visible = false;
        }

        //*** Code for irsa communications***
        protected void btnirsaallow_Click(object sender, EventArgs e)
        {
            try
            {

                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                objaccsettSH.iRSANewsletter = "iRSAnotification";
                //Hlirsanotification.Text
                //if (yes.Selected == true)
                //{
                //    objaccsettSH.iRSANotification = "1";
                //}
                //else if (No.Selected == true)
                //{
                //    objaccsettSH.iRSANotification = "1";
                //}
                objaccsettSH.iRSANotification = Radbtnnotify.SelectedValue;
                objAccountSettingFA.Insertnotify(UserID, objaccsettSH);
                btnirsaallow.Visible = false;
                btnnotecancel.Visible = false;
                lblnoteupdate.Visible = true;
                lblnoteupdate.Text = ErrorMessage.GetiRsaErrorMessage(89);
                Btnremove.Visible = true;
            }



            catch { }
        }

        protected void btnnotecancel_Click(object sender, EventArgs e)
        {
            Pnlirsacomm.Visible = false;
        }

        protected void Btnremove_Click(object sender, EventArgs e)
        {
            Pnlirsacomm.Visible = false;
        }

        protected void Linkirsanotify_Click(object sender, EventArgs e)
        {
            Pnlirsacomm.Visible = true;
            btnirsaallow.Visible = true;
            btnnotecancel.Visible = true;
            lblnoteupdate.Visible = false;
            Btnremove.Visible = false;
            Getirsapermission();
        }
        //*** code for My profile***
        protected void Linkupdateedu_Click(object sender, EventArgs e)
        {
            try
            {
                AccountSettingFA objaccsett = new AccountSettingFA();
                DataTable objroledt = new DataTable();
                objroledt = objaccsett.GetUserRole(UserID);
                if (objroledt.Rows.Count > 0)
                {

                    if ((objroledt.Rows[0]["Who"].ToString() != "JS") || (objroledt.Rows[0]["Who"].ToString() != "St"))
                    {
                        Response.Redirect("AccountAcademics.aspx");
                    }

                }
            }
            catch { }

        }
        //*** Code for Profile Photo***
        protected void Linkprofphoto_Click(object sender, EventArgs e)
        {
            Pnlprofilepic.Visible = true;
            Btnpropic.Visible = true;
            Bynpropiccancel.Visible = true;
            Lblpic.Visible = false;
            Btnpicok.Visible = false;
            GetProfilePhoto();
        }

        protected void Btnpropic_Click(object sender, EventArgs e)
        {
            try
            {
                if (Cheeveryone.Checked == true || Checont.Checked == true || Checomm.Checked == true)
                {
                    AccountSettingSH objaccsettSH = new AccountSettingSH();
                    AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                    objaccsettSH.MyProfilephoto = "My Profile Photo";
                    if (Cheeveryone.Checked == true)
                    {
                        objaccsettSH.everyone = "1";
                    }
                    if (Checont.Checked == true)
                    {
                        objaccsettSH.mycontacts = "1";
                    } if (Checomm.Checked == true)
                    {
                        objaccsettSH.mycommunities = "1";
                    }

                    objAccountSettingFA.InsertProflephoto(UserID, objaccsettSH);
                    Btnpropic.Visible = false;
                    Bynpropiccancel.Visible = false;
                    Lblpic.Visible = true;
                    Lblpic.Text = ErrorMessage.GetiRsaErrorMessage(89);
                    Btnpicok.Visible = true;
                }
                else
                {
                    Lblpic.Visible = true;
                    Lblpic.Text = ErrorMessage.GetiRsaErrorMessage(90);
                }
            }
            catch { }
        }

        protected void Bynpropiccancel_Click(object sender, EventArgs e)
        {
            Pnlprofilepic.Visible = false;
        }

        protected void Btnpicok_Click(object sender, EventArgs e)
        {
            Pnlprofilepic.Visible = false;
        }
        public void GetProfilePhoto()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objaccsettSH.MyProfilephoto = "My Profile Photo";
                objdt = objaccsetFA.GetpropicData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    Cheeveryone.Checked = (Convert.ToBoolean(objdt.Rows[0]["everyone"].ToString()));
                    Checont.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyContact"].ToString()));
                    Checomm.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyCommunities"].ToString()));
                }

            }
            catch
            {
            }
        }

        //*** code for my visibility***
        protected void Linkvisibility_Click(object sender, EventArgs e)
        {
            Pnlvisibilty.Visible = true;
            Btnvisibility.Visible = true;
            Btnvisiblecancel.Visible = true;
            lblvisible.Visible = false;
            Btnvisibleok.Visible = false;
            Getvisible();
        }

        protected void Btnvisibility_Click(object sender, EventArgs e)
        {
            try
            {
                if (Chevryone.Checked == true || Chmycon.Checked == true || Chmycomm.Checked == true)
                {
                    AccountSettingSH objaccsettSH = new AccountSettingSH();
                    AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                    objaccsettSH.MyVisibility = "Your Visibility";
                    if (Chevryone.Checked == true)
                    {
                        objaccsettSH.everyone = "1";
                    }
                    if (Chmycon.Checked == true)
                    {
                        objaccsettSH.mycontacts = "1";
                    } if (Chmycomm.Checked == true)
                    {
                        objaccsettSH.mycommunities = "1";
                    }

                    objAccountSettingFA.Insertvisibility(UserID, objaccsettSH);
                    Btnvisibility.Visible = false;
                    Btnvisiblecancel.Visible = false;
                    lblvisible.Visible = true;
                    lblvisible.Text = ErrorMessage.GetiRsaErrorMessage(89);
                    Btnvisibleok.Visible = true;
                }
                else
                {
                    lblvisible.Visible = true;
                    lblvisible.Text = ErrorMessage.GetiRsaErrorMessage(90);
                }
            }
            catch { }
        }

        protected void Btnvisiblecancel_Click(object sender, EventArgs e)
        {
            Pnlvisibilty.Visible = false;
        }

        protected void Btnvisibleok_Click(object sender, EventArgs e)
        {
            Pnlvisibilty.Visible = false;
        }
        public void Getvisible()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objaccsettSH.MyVisibility = "Your Visibility";
                objdt = objaccsetFA.GetvisibleData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    Chevryone.Checked = (Convert.ToBoolean(objdt.Rows[0]["everyone"].ToString()));
                    Chmycon.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyContact"].ToString()));
                    Chmycomm.Checked = (Convert.ToBoolean(objdt.Rows[0]["MyCommunities"].ToString()));
                }
            }
            catch
            {
            }
        }

        public void getURL()
        {
            try
            {
                string email;
                string identity;
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objdt = objaccsetFA.RetrieveUserID(UserID);
                if (objdt.Rows.Count > 0)
                {
                    email = objdt.Rows[0]["EmailID"].ToString();
                    int lastIndex = email.LastIndexOf("@");
                    identity = email.Substring(0, lastIndex);

                    //string Message = string.Format("http://localhost:2930/ViewAccount.aspx?param1={0}&param2={1}" ,UserID , identity);
                    if (SessionInfo.RoleID == "JS" || SessionInfo.RoleID == "ST")
                    {
                        Message = string.Format(IP + "ViewAccount.aspx?Key1={0}&Key2={1}", UserID, identity);
                    }
                    else if (SessionInfo.RoleID == "OR" || SessionInfo.RoleID == "IN")
                    {
                        Message = string.Format(IP + "ViewOrganisation.aspx?Key1={0}&Key2={1}&Key3={2}", UserID, identity, SessionInfo.OrgID);
                    }
                    else if (SessionInfo.RoleID == "RC")
                    {
                        Message = string.Format(IP + "ViewRecruiter.aspx?Key1={0}&Key2={1}&Key3={2}", UserID, identity, SessionInfo.OrgID);
                    }
                    HLprofileURL.Text = Message;
                    HLprofileURL.PostBackUrl = Message;
                }
                else { }
            }
            catch
            {
            }
        }
        public void Getirsapermission()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objaccsettSH.iRSANewsletter = "iRSAnotification";
                //objaccsettSH.iRSANewsletter
                objdt = objaccsetFA.GetirsaData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    string notifsts = objdt.Rows[0]["iRSAnotification"].ToString().Trim();
                    if (notifsts == "True")
                    {
                        Radbtnnotify.SelectedValue = "1";
                        //yes.Selected = true;
                    }
                    else
                    {
                        Radbtnnotify.SelectedValue = "0";
                        //No.Selected = true;
                    }


                }
            }
            catch
            {
            }
        }

        protected void Linksalary_Click(object sender, EventArgs e)
        {
            Pnlsalary.Visible = true;
            Btnsalok.Visible = false;
            Btncancel.Visible = true;
            btnsave.Visible = true;
            Lblsalarysave.Visible = false;
            GetSalaryDetails();
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txnsalary.Text != "0" || Ddncurrency.SelectedValue != "" || Ddnpayduration.SelectedValue != "" || Ddnpaytype.SelectedValue != "" || txnhrspw.Text != "")
                {
                    AccountSettingSH objaccsettSH = new AccountSettingSH();
                    AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                    if (txnsalary.Text != "0")
                    {
                        objaccsettSH.PreferredSalaryAmount = txnsalary.Text;
                    }
                    else
                    {
                        Lblsalarysave.Visible = true;
                        Lblsalarysave.Text = ErrorMessage.GetiRsaErrorMessage(91);
                        goto Last; 
                    }
                    if (Ddncurrency.SelectedValue != "")
                    {
                        objaccsettSH.PreferredCurrency = Ddncurrency.SelectedValue;
                    }
                    if (Ddnpayduration.SelectedValue != "")
                    {
                        objaccsettSH.PayDuration = Ddnpayduration.SelectedValue;
                    }
                    if (Ddnpaytype.SelectedValue != "")
                    {
                        objaccsettSH.JobTypes = Ddnpaytype.SelectedValue;
                    }
                    if (txnhrspw.Text != "")
                    {
                        {
                            if (Convert.ToInt32(txnhrspw.Text) <= 40)
                            {
                                lblhrs.Visible = false;
                                objaccsettSH.HoursPerweek = Convert.ToInt32(txnhrspw.Text);
                            }
                            else
                            {
                                lblhrs.Visible = true;
                                lblhrs.Text = ErrorMessage.GetiRsaErrorMessage(92);
                                goto Last; 
                            }
                        }
                    }

                    objAccountSettingFA.Insertsalarydetails(UserID, objaccsettSH);
                    Btnsalok.Visible = true;
                    Btncancel.Visible = false;
                    btnsave.Visible = false;
                    Lblsalarysave.Visible = true;
                    Lblsalarysave.Text = ErrorMessage.GetiRsaErrorMessage(89);
                Last: ;
                }


                else
                {
                    Lblsalarysave.Visible = true;
                    Lblsalarysave.Text = ErrorMessage.GetiRsaErrorMessage(93);
                }
            }

            catch { }

        }

        protected void Btncancel_Click(object sender, EventArgs e)
        {
            Pnlsalary.Visible = false;
        }

        protected void Btnsalok_Click(object sender, EventArgs e)
        {
            Pnlsalary.Visible = false;
        }

        public void GetSalaryDetails()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();

                objdt = objaccsetFA.GetsalaryData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    if (objdt.Rows[0]["PreferredSalaryAmount"].ToString() != "0")
                    {
                        string sal = objdt.Rows[0]["PreferredSalaryAmount"].ToString();
                        string[] arstr = new string[2]; char[] splitterpost = { '.' };
                        arstr = sal.Split(splitterpost);
                        string salary = arstr[0];
                        txnsalary.Text = salary;

                    }
                    if (objdt.Rows[0]["HoursPerweek"].ToString() != "-2147483648")
                    {
                        txnhrspw.Text = objdt.Rows[0]["HoursPerweek"].ToString();
                    }
                    if (objdt.Rows[0]["PreferredCurrency"].ToString() != "")
                    {
                        Ddncurrency.SelectedValue = objdt.Rows[0]["PreferredCurrency"].ToString();
                    }
                    if (objdt.Rows[0]["PayDuration"].ToString() != "")
                    {
                        Ddnpayduration.SelectedValue = objdt.Rows[0]["PayDuration"].ToString();
                    }
                    if (objdt.Rows[0]["JobTypes"].ToString() != "")
                    {
                        Ddnpaytype.SelectedValue = objdt.Rows[0]["JobTypes"].ToString();
                    }
                }
            }
            catch { }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Panelcontactbrowse.Visible = false;
        }

        protected void LinkResume_Click(object sender, EventArgs e)
        {
            Response.Redirect("MyResume.aspx");
        }

        protected void LinkBtnRecruiter_Click(object sender, EventArgs e)
        {
            PnlRecruiter.Visible = true;
            Btnrecconf.Visible = true;
            Btncancelrec.Visible = true;
            lblrecr.Visible = false;
            Btnokrec.Visible = false;
            GetRecruiterAllow();
        }

        protected void Btnrecconf_Click(object sender, EventArgs e)
        {
            try
            {

                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                objaccsettSH.allowrecruiters = "RecuriterAllowed";
                //Hlirsanotification.Text
                //if (allow.Selected == true)
                //{
                   // objaccsettSH.Recruitersallowed = "1";
              //  }
                //else if (nallow.Selected == true)
              //  {
                   // objaccsettSH.Recruitersallowed = "1";
               // }
                objaccsettSH.Recruitersallowed = Radbtnrecconf.SelectedValue;
                objAccountSettingFA.Insertrecallow(UserID, objaccsettSH);
                Btnrecconf.Visible = false;
                Btncancelrec.Visible = false;
                lblrecr.Visible = true;
                lblrecr.Text = ErrorMessage.GetiRsaErrorMessage(89);
                Btnokrec.Visible = true;
            }



            catch { }
        }

        protected void Btncancelrec_Click(object sender, EventArgs e)
        {
            PnlRecruiter.Visible = false;
        }

        protected void Btnokrec_Click(object sender, EventArgs e)
        {
            PnlRecruiter.Visible = false;
        }

        public void FillIndustry()
        {
            IRSA.Facade.AccountsetupFA Indus = new IRSA.Facade.AccountsetupFA();

            DataTable temp = new DataTable();
            temp = Indus.GetIndustryData();
            LstIndustries.DataTextField = "IndustryName";

            LstIndustries.DataSource = temp;
            LstIndustries.DataBind();

        }

        protected void Lnkbtnavst_Click(object sender, EventArgs e)
        {
            Pnlavailsts.Visible = true;
            Btnprefstscancel.Visible = true;
            Btnprefstts.Visible = true;
            lblprefIn.Visible = false;
            Btnpref.Visible = false;
            GetPrefInd();
        }

        protected void LnkbtnJobstatus_Click(object sender, EventArgs e)
        {
            PnlJS.Visible = true;
            GetData();
        }

        public void InsertData()
        {
         try
         {
            JobStatusSH jbsh = new JobStatusSH();
            // jbsh.RadComboBox1 = RadComboBox1.SelectedValue;
            // jbsh.RadDatePicker1 = Convert.ToString(RadDatePicker1.SelectedDate);
            jbsh.RadComboBox2 = RadComboBox2.Text;
            jbsh.RadDatePicker2 = Convert.ToDateTime(RadDatePicker2.SelectedDate).ToString("dd/MMM/yyyy");
            jbsh.RadComboBox3 = Convert.ToDateTime(RadDatePicker3.SelectedDate).ToString("dd/MMM/yyyy");
            jbsh.RadComboBox4 = RadComboBox4.SelectedValue;
            jbsh.RadComboBox5 = RadComboBox5.SelectedValue;
            jbsh.info = info.Text;
            jbsh.RadComboBox6 = RadComboBox6.SelectedValue;
            //jbsh.RadComboBox7 = RadComboBox7.SelectedValue;
            jbsh.TextBox1 = TextBox1.Text;
            //jbsh.RadComboBox8 = RadComboBox8.SelectedValue;
            jbsh.radio = radio.SelectedValue;
            JobStatusFA jbfa = new JobStatusFA();
            jbfa.InsertData(jbsh);

         }
            catch
         {
            }

        }
        public void GetData()
        {
            try
            {
            JobStatusFA jbfa = new JobStatusFA();
            DataTable dt = new DataTable();
            dt = jbfa.GetData();
            if (dt.Rows.Count == 0)
            {

            }

            else
            {
                RadComboBox1.Text = dt.Rows[0]["EmploymentStatus"].ToString();
                if (dt.Rows[0]["AvailibiltyFrom"].ToString() != "")
                {
                    RadDatePicker1.SelectedDate = Convert.ToDateTime(dt.Rows[0]["AvailibiltyFrom"].ToString());
                }
                RadComboBox2.Text = dt.Rows[0]["EmploymentStatus"].ToString();
                if (dt.Rows[0]["AvailibiltyFrom"].ToString() != "")
                {
                    RadDatePicker2.SelectedDate = Convert.ToDateTime(dt.Rows[0]["AvailibiltyFrom"].ToString());
                }
                if (dt.Rows[0]["AvailibiltyTo"].ToString() != "")
                {
                    RadDatePicker3.SelectedDate = Convert.ToDateTime(dt.Rows[0]["AvailibiltyTo"].ToString());
                }
                RadComboBox4.Text = dt.Rows[0]["JobTypes"].ToString();
                RadComboBox5.Text = dt.Rows[0]["PreferredCurrency"].ToString();

                string sal = dt.Rows[0]["PreferredSalaryAmount"].ToString();
                string[] arstr = new string[2]; char[] splitterpost = { '.' };
                arstr = sal.Split(splitterpost);
                string salary = arstr[0];
                info.Text = salary;
                //info.Text = dt.Rows[0]["PreferredSalaryAmount"].ToString();
                RadComboBox6.Text = dt.Rows[0]["PayDuration"].ToString();
                //   RadComboBox7.Text = dt.Rows[0]["PreferedRate"].ToString();
                TextBox1.Text = dt.Rows[0]["HoursPerweek"].ToString();
                //   RadComboBox8.Text = dt.Rows[0]["PreferedRateType"].ToString();
                radio.SelectedValue = dt.Rows[0]["Relocation"].ToString();
            }
                }
                catch
            {
                }
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {// Update Button

            RadComboBox2.Text = RadComboBox1.Text;
            RadDatePicker2.SelectedDate = RadDatePicker1.SelectedDate;
            mvMain.ActiveViewIndex = (mvMain.ActiveViewIndex + 1) % 2;
            RadTabStrip1.SelectedIndex = 0;
            RadMultiPage1.SelectedIndex = 0;
        }

        protected void Ok_Click(object sender, EventArgs e)
        {
            mvMain.ActiveViewIndex = (mvMain.ActiveViewIndex + 1) % 2;
            PnlJS.Visible = false;
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            InsertData();
            mvMain.ActiveViewIndex = (mvMain.ActiveViewIndex + 1) % 2;
            GetData();


        }

        protected void lnk_Click(object sender, EventArgs e)
        {
            mvMain.ActiveViewIndex = (mvMain.ActiveViewIndex + 1) % 2;
            RadTabStrip1.SelectedIndex = 0;
            RadMultiPage1.SelectedIndex = 0;
        }

        protected void PageView1_Load(object sender, EventArgs e)
        {
            // btnok.Visible = false;
        }

        protected void PageView2_Load(object sender, EventArgs e)
        {
            // btnok.Visible = false;
        }

        protected void PageView3_Load(object sender, EventArgs e)
        {
            //btnok.Visible = true;
        }
        
        protected void Btnprefstts_Click(object sender, EventArgs e)
        {
            try
            {
            AccountSettingSH objaccsettSH = new AccountSettingSH();
            AccountSettingFA objAccountSettingFA = new AccountSettingFA();
            objaccsettSH.PrefIndustries = "PreferedIndustry";
            //if (LstIndustries.SelectedValue != "")
            //{
            //    objaccsettSH.IndustriesPref = IDs;
            //}
            int Count=0;
            foreach (ListItem li in LstIndustries.Items)
            {
                if (li.Selected)
                {
                    IDs = IDs + li.Value + ",";
                    Count++;
                    if (Count > 3)
                    {
                        lblprefIn.Visible = true;
                        lblprefIn.Text = ErrorMessage.GetiRsaErrorMessage(94);
                        goto Last;
                    }
                }
            }
            objaccsettSH.IndustriesPref = IDs;
            objAccountSettingFA.InsertPref(UserID, objaccsettSH);
            Btnprefstscancel.Visible = false;
            Btnprefstts.Visible = false;
            lblprefIn.Visible = true;
            lblprefIn.Text = ErrorMessage.GetiRsaErrorMessage(89);
            Btnpref.Visible = true;
            }
                 
            catch
            {
            }
       
           Last:;
        }

        protected void Btnprefstscancel_Click(object sender, EventArgs e)
        {
            Pnlavailsts.Visible = false;

        }

        protected void Btnpref_Click(object sender, EventArgs e)
        {
            Pnlavailsts.Visible = false;
        }

        //protected void LstIndustries_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    StringCollection idCollection = new StringCollection();
        //    string strID;
        //    strID = Convert.ToString(LstIndustries.SelectedValue);

        //    idCollection.Add(strID);


        //    foreach (string id in idCollection)
        //    {

        //        IDs += id.ToString() + ",";



        //    }


        //}
        public void GetRecruiterAllow()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objaccsettSH.Recruitersallowed = "RecuriterAllowed";

                objdt = objaccsetFA.GetRAData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    string recall = objdt.Rows[0]["RecuriterAllowed"].ToString().Trim();
                    if (recall == "True")
                    {
                        Radbtnrecconf.SelectedValue = "1";
                    }
                    else
                    {
                        Radbtnrecconf.SelectedValue = "0";
                    }
                    //if (objdt.Rows[0]["RecuriterAllowed"].ToString() == "True")
                    //{
                    //    allow.Selected = true;
                    //}
                    //else
                    //{
                    //    nallow.Selected = true;
                    //}

                }
            }
            catch
            {
            }
        }
         
          public void Getnamestatus()
        {
              try
              {
            AccountSettingSH objaccsettSH = new AccountSettingSH();
            AccountSettingFA objaccsetFA = new AccountSettingFA();
            DataTable objdt = new DataTable();
            objaccsettSH.HideIdentity = "Hide Identity";
         
            objdt = objaccsetFA.GetNamestatus(UserID, objaccsettSH);
            if (objdt.Rows.Count > 0)
            {
                string namests = objdt.Rows[0]["HideName"].ToString().Trim();
                if (namests == "True")
                {
                    RbhideIdentity.SelectedValue = "1";
                }
                else
                {
                    RbhideIdentity.SelectedValue = "0";
                }

                //if (objdt.Rows[0]["HideName"].ToString() == "True")
                //{
                //Y.Selected = true;
                //}
                //else
                //{
                //N.Selected = true;
                //}
            }
              }
                  catch
              {

                  }
            
        }
        public void GetPrefInd()
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objaccsetFA = new AccountSettingFA();
                DataTable objdt = new DataTable();
                objaccsettSH.PrefIndustries = "PreferedIndustry";
                //objaccsettSH.iRSANewsletter
                objdt = objaccsetFA.GetPindData(UserID, objaccsettSH);
                if (objdt.Rows.Count > 0)
                {
                    //    if (objdt.Rows[0]["IndustryPreference"].ToString() != "")
                    //    {
                    //        Lblselectedind.Visible = true;

                    //        string str = objdt.Rows[0]["IndustryPreference"].ToString();
                    //        string str1 = str.Substring(0, (str.Length - 1));
                    //        lblsellang.Text = str1;
                    //    }
                    //   //string sal = objdt.Rows[0]["IndustryPreference"].ToString();
                    //   //char[] separator = new char[] {','};
                    //   //string[] Indus = sal.Split(separator);
                    //   //foreach( string ind in Indus)
                    //   //{
                    //   //    if (ind != "")
                    //   //    {
                    //   //        ListBox lst = (ListBox)FindControl("LstIndustries");
                    //   //        lst.Items.FindByValue(ind).Selected = true;
                    //   //    }
                    //   //}

                    //}  
                    string str = objdt.Rows[0]["IndustryPreference"].ToString();
                    string[] arstr = new string[22];
                    char[] splitterpost = { ',' };
                    arstr = str.Split(splitterpost);
                    foreach (string smlng in arstr)
                    {
                        if (smlng != "")
                        {
                            LstIndustries.Items.FindByValue(smlng).Selected = true;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        protected void Btnhidename_Click(object sender, EventArgs e)
        {
            try
            {
                AccountSettingSH objaccsettSH = new AccountSettingSH();
                AccountSettingFA objAccountSettingFA = new AccountSettingFA();
                objaccsettSH.HideIdentity = "Hide Identity";
                //if (Y.Selected==true)
                //{
                //    objaccsettSH.HideName = "1";
                //}
                //else 
                //{
                //    objaccsettSH.HideName = "0";
                //}
                objaccsettSH.HideName = RbhideIdentity.SelectedValue;
                objAccountSettingFA.InsertShowName(UserID, objaccsettSH);
                Btnhidename.Visible = false;
                btncanceleditname.Visible = false;
                Lblhideerr.Visible = true;
                Lblhideerr.Text = ErrorMessage.GetiRsaErrorMessage(89);
                btncloseeditname.Visible = true;
            }
            catch
            {
            }
        }

        protected void Lkidentityedit_Click(object sender, EventArgs e)
        {
            Pnleditname.Visible = true;
            Getnamestatus();
        }

        protected void btncanceleditname_Click(object sender, EventArgs e)
        {
            Pnleditname.Visible = false;
        }

        protected void btncloseeditname_Click(object sender, EventArgs e)
        {
            Pnleditname.Visible = false;
        }

        protected void getAccountSettingsPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                allow.Text = (string)GetGlobalResourceObject("PageResource", "allow_AccSetting");
                Anywhere.Text = (string)GetGlobalResourceObject("PageResource", "Anywhere_AccSetting");
                Btncancel.Text = (string)GetGlobalResourceObject("PageResource", "Btncancel_AccSetting");
                btncanceleditname.Text = (string)GetGlobalResourceObject("PageResource", "btncanceleditname_AccSetting");
                Btncancelrec.Text = (string)GetGlobalResourceObject("PageResource", "Btncancelrec_AccSetting");
                btncloseeditname.Text = (string)GetGlobalResourceObject("PageResource", "btncloseeditname_AccSetting");
                Btnconsett.Text = (string)GetGlobalResourceObject("PageResource", "Btnconsett_AccSetting");
                Btnconsettcancel.Text = (string)GetGlobalResourceObject("PageResource", "Btnconsettcancel_AccSetting");
                Btncontconfirm.Text = (string)GetGlobalResourceObject("PageResource", "Btncontconfirm_AccSetting");
                Btnhidename.Text = (string)GetGlobalResourceObject("PageResource", "Btnhidename_AccSetting");
                btnirsaallow.Text = (string)GetGlobalResourceObject("PageResource", "btnirsaallow_AccSetting");
                btnnotecancel.Text = (string)GetGlobalResourceObject("PageResource", "btnnotecancel_AccSetting");
                Btnok.Text = (string)GetGlobalResourceObject("PageResource", "Btnok_AccSetting");
                Btnokrec.Text = (string)GetGlobalResourceObject("PageResource", "Btnokrec_AccSetting");
                Btnpicok.Text = (string)GetGlobalResourceObject("PageResource", "Btnpicok_AccSetting");
                Btnpref.Text = (string)GetGlobalResourceObject("PageResource", "Btnpref_AccSetting");
                Btnprefstscancel.Text = (string)GetGlobalResourceObject("PageResource", "Btnprefstscancel_AccSetting");
                Btnprefstts.Text = (string)GetGlobalResourceObject("PageResource", "Btnprefstts_AccSetting");
                Btnpropic.Text = (string)GetGlobalResourceObject("PageResource", "Btnpropic_AccSetting");
                Btnrecconf.Text = (string)GetGlobalResourceObject("PageResource", "Btnrecconf_AccSetting");
                Btnremove.Text = (string)GetGlobalResourceObject("PageResource", "Btnremove_AccSetting");
                Btnsalok.Text = (string)GetGlobalResourceObject("PageResource", "Btnsalok_AccSetting");
                btnsave.Text = (string)GetGlobalResourceObject("PageResource", "btnsave_AccSetting");
                Btnvisibility.Text = (string)GetGlobalResourceObject("PageResource", "Btnvisibility_AccSetting");
                Btnvisiblecancel.Text = (string)GetGlobalResourceObject("PageResource", "Btnvisiblecancel_AccSetting");
                Btnvisibleok.Text = (string)GetGlobalResourceObject("PageResource", "Btnvisibleok_AccSetting");
                Butok.Text = (string)GetGlobalResourceObject("PageResource", "Butok_AccSetting");
                Button1.Text = (string)GetGlobalResourceObject("PageResource", "Button1_AccSetting");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccSetting");
                Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccSetting");
                Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccSetting");
                Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccSetting");
                Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccSetting");
                Buttonok.Text = (string)GetGlobalResourceObject("PageResource", "Buttonok_AccSetting");
                Bynpropiccancel.Text = (string)GetGlobalResourceObject("PageResource", "Bynpropiccancel_AccSetting");
                Checkcommunities.Text = (string)GetGlobalResourceObject("PageResource", "Checkcommunities_AccSetting");
                Checkcontacts.Text = (string)GetGlobalResourceObject("PageResource", "Checkcontacts_AccSetting");
                Checkeveryone.Text = (string)GetGlobalResourceObject("PageResource", "Checkeveryone_AccSetting");
                Checomm.Text = (string)GetGlobalResourceObject("PageResource", "Checomm_AccSetting");
                Checont.Text = (string)GetGlobalResourceObject("PageResource", "Checont_AccSetting");
                Cheeveryone.Text = (string)GetGlobalResourceObject("PageResource", "Cheeveryone_AccSetting");
                Chevryone.Text = (string)GetGlobalResourceObject("PageResource", "Chevryone_AccSetting");
                chkcommunities.Text = (string)GetGlobalResourceObject("PageResource", "chkcommunities_AccSetting");
                Chkcontacts.Text = (string)GetGlobalResourceObject("PageResource", "Chkcontacts_AccSetting");
                chkeveryone.Text = (string)GetGlobalResourceObject("PageResource", "chkeveryone_AccSetting");
                Chmycomm.Text = (string)GetGlobalResourceObject("PageResource", "Chmycomm_AccSetting");
                Chmycon.Text = (string)GetGlobalResourceObject("PageResource", "Chmycon_AccSetting");
                HLContactbrowse.Text = (string)GetGlobalResourceObject("PageResource", "HLContactbrowse_AccSetting");
                HLcontactsettings.Text = (string)GetGlobalResourceObject("PageResource", "HLcontactsettings_AccSetting");
                HLhidename.Text = (string)GetGlobalResourceObject("PageResource", "HLhidename_AccSetting");
                Hlirsanotification.Text = (string)GetGlobalResourceObject("PageResource", "Hlirsanotification_AccSetting");
                HLProfileView.Text = (string)GetGlobalResourceObject("PageResource", "HLProfileView_AccSetting");
                HLpropic.Text = (string)GetGlobalResourceObject("PageResource", "HLpropic_AccSetting");
                HLVisible.Text = (string)GetGlobalResourceObject("PageResource", "HLVisible_AccSetting");
                HyperLink1.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink1_AccSetting");
                HyperLink10.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink10_AccSetting");
                HyperLink12.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink12_AccSetting");
                HyperLink2.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink2_AccSetting");
                HyperLink3.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink3_AccSetting");
                HyperLink4.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink4_AccSetting");
                HyperLink5.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink5_AccSetting");
                HyperLink6.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink6_AccSetting");
                HyperLink7.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink7_AccSetting");
                HyperLink8.Text = (string)GetGlobalResourceObject("PageResource", "HyperLink8_AccSetting");

                HyperLinkclose.Text = (string)GetGlobalResourceObject("PageResource", "HyperLinkclose_AccSetting");
                Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_AccSetting");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_AccSetting");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_AccSetting");
                Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_AccSetting");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_AccSetting");
                Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_AccSetting");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_AccSetting");
                Label17.Text = (string)GetGlobalResourceObject("PageResource", "Label17_AccSetting");
                Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label18_AccSetting");
                Label19.Text = (string)GetGlobalResourceObject("PageResource", "Label19_AccSetting");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_AccSetting");
                Label20.Text = (string)GetGlobalResourceObject("PageResource", "Label20_AccSetting");
                Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_AccSetting");
                Label22.Text = (string)GetGlobalResourceObject("PageResource", "Label22_AccSetting");
                Label23.Text = (string)GetGlobalResourceObject("PageResource", "Label23_AccSetting");
                Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_AccSetting");
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "Label25_AccSetting");
                Label26.Text = (string)GetGlobalResourceObject("PageResource", "Label26_AccSetting");
                Label27.Text = (string)GetGlobalResourceObject("PageResource", "Label27_AccSetting");
                Label28.Text = (string)GetGlobalResourceObject("PageResource", "Label28_AccSetting");
                Label29.Text = (string)GetGlobalResourceObject("PageResource", "Label29_AccSetting");
                Label30.Text = (string)GetGlobalResourceObject("PageResource", "Label30_AccSetting");
                Label31.Text = (string)GetGlobalResourceObject("PageResource", "Label31_AccSetting");
                Label32.Text = (string)GetGlobalResourceObject("PageResource", "Label32_AccSetting");
                Label33.Text = (string)GetGlobalResourceObject("PageResource", "Label33_AccSetting");
                Label34.Text = (string)GetGlobalResourceObject("PageResource", "Label34_AccSetting");
                Label35.Text = (string)GetGlobalResourceObject("PageResource", "Label35_AccSetting");
                Label36.Text = (string)GetGlobalResourceObject("PageResource", "Label36_AccSetting");
                Label37.Text = (string)GetGlobalResourceObject("PageResource", "Label37_AccSetting");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_AccSetting");
                Label46.Text = (string)GetGlobalResourceObject("PageResource", "Label46_AccSetting");
                Label47.Text = (string)GetGlobalResourceObject("PageResource", "Label47_AccSetting");
                Label49.Text = (string)GetGlobalResourceObject("PageResource", "Label49_AccSetting");
                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label5_AccSetting");
                Label51.Text = (string)GetGlobalResourceObject("PageResource", "Label51_AccSetting");
                Label53.Text = (string)GetGlobalResourceObject("PageResource", "Label53_AccSetting");
                Label54.Text = (string)GetGlobalResourceObject("PageResource", "Label54_AccSetting");
                Label55.Text = (string)GetGlobalResourceObject("PageResource", "Label55_AccSetting");
                Label56.Text = (string)GetGlobalResourceObject("PageResource", "Label56_AccSetting");
                Label57.Text = (string)GetGlobalResourceObject("PageResource", "Label57_AccSetting");
                Label58.Text = (string)GetGlobalResourceObject("PageResource", "Label58_AccSetting");
                Label59.Text = (string)GetGlobalResourceObject("PageResource", "Label59_AccSetting");
                Label6.Text = (string)GetGlobalResourceObject("PageResource", "Label6_AccSetting");
                Label60.Text = (string)GetGlobalResourceObject("PageResource", "Label60_AccSetting");
                Label7.Text = (string)GetGlobalResourceObject("PageResource", "Label7_AccSetting");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_AccSetting");
                lblPI.Text = (string)GetGlobalResourceObject("PageResource", "lblPI_AccSetting");
                LinkBtnloc.Text = (string)GetGlobalResourceObject("PageResource", "LinkBtnloc_AccSetting");
                LinkBtnRecruiter.Text = (string)GetGlobalResourceObject("PageResource", "LinkBtnRecruiter_AccSetting");
                Linkchangepwd.Text = (string)GetGlobalResourceObject("PageResource", "Linkchangepwd_AccSetting");
                LinkCloseAccount.Text = (string)GetGlobalResourceObject("PageResource", "LinkCloseAccount_AccSetting");
                LinkContact.Text = (string)GetGlobalResourceObject("PageResource", "LinkContact_AccSetting");
                LinkContsett.Text = (string)GetGlobalResourceObject("PageResource", "LinkContsett_AccSetting");
                Linkeditwelcome.Text = (string)GetGlobalResourceObject("PageResource", "Linkeditwelcome_AccSetting");
                Linkirsanotify.Text = (string)GetGlobalResourceObject("PageResource", "Linkirsanotify_AccSetting");
                LinkProfile.Text = (string)GetGlobalResourceObject("PageResource", "LinkProfile_AccSetting");
                Linkprofphoto.Text = (string)GetGlobalResourceObject("PageResource", "Linkprofphoto_AccSetting");
                LinkResume.Text = (string)GetGlobalResourceObject("PageResource", "LinkResume_AccSetting");
                Linksalary.Text = (string)GetGlobalResourceObject("PageResource", "Linksalary_AccSetting");
                Linkupdateedu.Text = (string)GetGlobalResourceObject("PageResource", "Linkupdateedu_AccSetting");
                Linkvisibility.Text = (string)GetGlobalResourceObject("PageResource", "Linkvisibility_AccSetting");
                Lkidentityedit.Text = (string)GetGlobalResourceObject("PageResource", "Lkidentityedit_AccSetting");
                Lnkbtnavst.Text = (string)GetGlobalResourceObject("PageResource", "Lnkbtnavst_AccSetting");
                LnkbtnJobstatus.Text = (string)GetGlobalResourceObject("PageResource", "LnkbtnJobstatus_AccSetting");
                N.Text = (string)GetGlobalResourceObject("PageResource", "N_AccSetting");
                No.Text = (string)GetGlobalResourceObject("PageResource", "No_AccSetting");
                Select.Text = (string)GetGlobalResourceObject("PageResource", "Select_AccSetting");
                Y.Text = (string)GetGlobalResourceObject("PageResource", "Y_AccSetting");
                yes.Text = (string)GetGlobalResourceObject("PageResource", "yes_AccSetting");
                Label48.Text = (string)GetGlobalResourceObject("PageResource", "Label48_AccSetting");
                Label50.Text = (string)GetGlobalResourceObject("PageResource", "Label50_AccSetting");
                Label8.Text = (string)GetGlobalResourceObject("PageResource", "Label8_AccSetting");
                Label52.Text = (string)GetGlobalResourceObject("PageResource", "Label52_AccSetting");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_AccSetting");
                Lblnamevonfirm.Text = (string)GetGlobalResourceObject("PageResource", "Lblnamevonfirm_AccSetting");
            }
            catch { }
        }

        protected void RbhideIdentity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RbhideIdentity.SelectedValue == "0")
            {
                Lblnamevonfirm.Visible = true;
            }
            else 
            {
                Lblnamevonfirm.Visible = false;
            }
        }
    }

}

