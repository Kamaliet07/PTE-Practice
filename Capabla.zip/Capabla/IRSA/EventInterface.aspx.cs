﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using Telerik.Web.UI;
namespace IRSA
{
    public partial class EventInterface : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
           // Button2.Visible = false;
             UserID = SessionInfo.UserId;
           
             if (UserID != int.MinValue)
             {
                 Lblmember.Text = SessionInfo.Username + " " + "!";
             }
             else
             {
                 Response.Redirect("Login.aspx");
             }
           
        }
        public void InserdData()
        {
            EventInterfaceSH sh = new EventInterfaceSH();
            sh.Title = txttitle.Text;
            sh.Description = txtdescription.Text;
            sh.StartDate = Convert.ToDateTime(RadDatePicker1.SelectedDate).ToString("dd/MMM/yyyy");
           // sh.EventMonth = sh.StartDate;
            sh.EndDate = Convert.ToDateTime(RadDatePicker2.SelectedDate).ToString("dd/MMM/yyyy");
            sh.Url = txturl.Text;
            sh.City = txtboxcity.Text;
            sh.Country = txtcountry.Text;
            EventInterfaceFA fa = new EventInterfaceFA();
            fa.InsertData(sh,UserID);
        }
        public void GetData()
        {
            EventInterfaceFA fa = new EventInterfaceFA();
         
            DataTable dt=new DataTable();
            dt = fa.GetData();
            if (dt.Rows.Count > 0)
            {
                txttitle.Text = dt.Rows[0]["EventDescription"].ToString();
                txtdescription.Content = dt.Rows[0]["Summary"].ToString();
                RadDatePicker1.SelectedDate =Convert.ToDateTime( dt.Rows[0]["DateTo"].ToString());
                RadDatePicker2.SelectedDate =Convert.ToDateTime (dt.Rows[0]["LastDate"].ToString());
                txturl.Text = dt.Rows[0]["ContactMailID"].ToString();
            }
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button2.Visible = true;
            InserdData();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            
            string title=txttitle.Text;
            int UserID = SessionInfo.UserId;
            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";
            string Message = string.Format("~/EventInterfacePopUp.aspx?ID={0}&Title={1}", UserID, title);

            rd.NavigateUrl = Message;
            rd.VisibleOnPageLoad = true;

            rd.Width = 400;
            rd.Height = 550;
            rd.Left = 400;
            rd.Top = 150;
            RadWindowManagerSetting.Windows.Add(rd);
            RadWindowManagerSetting.KeepInScreenBounds = true;
           // GetData(); 
        }
    }
}
