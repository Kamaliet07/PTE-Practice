﻿using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using ASPNetFlashVideo;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class ApprovalCenter : System.Web.UI.Page
    {
        int UserID;
        string UserRole;
        bool fool;

        bool pic_vid_Flag;
        ApprovalCenterFA objApprCntrFA = new ApprovalCenterFA();
        string retreiveDirPath;


        public DataTable dtGridData
        {
            get { return (DataTable)ViewState["DTGridData"]; }
            set { ViewState["DTGridData"] = value; }
        }
        public DataTable dtUserIDsDisAp
        {
            get { return (DataTable)ViewState["DTUserIDsDisAp"]; }
            set { ViewState["DTUserIDsDisAp"] = value; }
        }
        public DataTable dtUserIDsAppr
        {
            get { return (DataTable)ViewState["DTUserIDsAppr"]; }
            set { ViewState["DTUserIDsAppr"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            UserRole = SessionInfo.RoleID;
            if (UserID != int.MinValue && UserRole.Equals("SA"))
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";

            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            fool = false;

            if (!IsPostBack)
            {
                if (fool)
                {
                    flvdUsrUpload.Dispose();
                    flvdUsrUpload = new FlashVideo();
                    flvdUsrUpload.Visible = false;
                }
                lblSerial.Dispose();
                lblSerial = new Label();
                lblSerial.Text = "";

                dtUserIDsDisAp = new DataTable();
                DataColumn dcTmp = new DataColumn("UserID");
                dtUserIDsDisAp.Columns.Add(dcTmp);

                dtUserIDsAppr = new DataTable();
                dcTmp = new DataColumn("UserID");
                dtUserIDsAppr.Columns.Add(dcTmp);
            }
        }


        //Load grid button click event handler

        protected void btnLoadGrid_Click(object sender, EventArgs e)
        {
            try
            {
                dtGridData = new DataTable();
                rdgrdUpldFiles.Columns[1].Visible = true;
                rdgrdUpldFiles.Columns[2].Visible = true;
                flvdUsrUpload.Visible = false;
                lblSerial.Text = string.Empty;
                dtUserIDsAppr.Clear();
                dtUserIDsDisAp.Clear();

                if (rdblstSelectPicVid.Items[0].Selected == true)
                {
                    pic_vid_Flag = false;
                    fool = false;
                    rdgrdUpldFiles.PageSize = 4;
                    flvdUsrUpload.Visible = false;
                    retreiveDirPath = ConfigurationSettings.AppSettings["UserPhotoRetrieve"];
                    dtGridData = objApprCntrFA.getGridData(0, 0);
                    DataColumn dcTmp = new DataColumn("PicFile");
                    dtGridData.Columns.Add(dcTmp);
                    dcTmp = new DataColumn("VidFile");
                    dtGridData.Columns.Add(dcTmp);
                    dcTmp = new DataColumn("ApprovalStatus");
                    dtGridData.Columns.Add(dcTmp);
                    dcTmp = new DataColumn("SerialNo");
                    dtGridData.Columns.Add(dcTmp);
                    for (int x = 0; x < dtGridData.Rows.Count; x++)
                    {
                        if (!((Convert.ToString(dtGridData.Rows[x]["PhotoID"])).Equals(null)) && !(Convert.ToString((dtGridData.Rows[x]["PhotoID"])).Equals(string.Empty)))
                            dtGridData.Rows[x]["PicFile"] = retreiveDirPath + Convert.ToString(dtGridData.Rows[x]["PhotoID"]);
                        else
                            dtGridData.Rows[x]["PicFile"] = "~/images/person.jpg";

                        dtGridData.Rows[x]["SerialNo"] = x + 1;

                        dtGridData.AcceptChanges();
                    }

                    rdgrdUpldFiles.DataSource = dtGridData;
                    rdgrdUpldFiles.DataBind();
                    rdgrdUpldFiles.Columns[2].Visible = false;
                }
                else if (rdblstSelectPicVid.Items[1].Selected == true)
                {
                    pic_vid_Flag = true;
                    rdgrdUpldFiles.PageSize = 5;
                    retreiveDirPath = ConfigurationSettings.AppSettings["VideoResumeRetrieve"];
                    dtGridData = objApprCntrFA.getGridData(1, 0);
                    DataColumn dcTmp = new DataColumn("PicFile");
                    dtGridData.Columns.Add(dcTmp);
                    dcTmp = new DataColumn("VidFile");
                    dtGridData.Columns.Add(dcTmp);
                    dcTmp = new DataColumn("ApprovalStatus");
                    dtGridData.Columns.Add(dcTmp);
                    dcTmp = new DataColumn("SerialNo");
                    dtGridData.Columns.Add(dcTmp);
                    for (int x = 0; x < dtGridData.Rows.Count; x++)
                    {
                        if (!((Convert.ToString(dtGridData.Rows[x]["VideoResumeID"])).Equals(null)) && !(Convert.ToString((dtGridData.Rows[x]["VideoResumeID"])).Equals(string.Empty)))
                            dtGridData.Rows[x]["VidFile"] = retreiveDirPath + Convert.ToString(dtGridData.Rows[x]["VideoResumeID"]);
                        else
                            dtGridData.Rows[x]["VidFile"] = string.Empty;

                        dtGridData.Rows[x]["SerialNo"] = x + 1;

                        dtGridData.AcceptChanges();
                    }

                    rdgrdUpldFiles.DataSource = dtGridData;
                    rdgrdUpldFiles.DataBind();
                    rdgrdUpldFiles.Columns[1].Visible = false;
                }
            }
            catch { }
        }


        //Radgrid page index changed event handler

        protected void rdgrdUpldFiles_IndxChng(object source, GridPageChangedEventArgs e)
        {
            try
            {
                rdgrdUpldFiles.CurrentPageIndex = e.NewPageIndex;
                rdgrdUpldFiles.DataSource = dtGridData;
                rdgrdUpldFiles.DataBind();
            }
            catch { }
        }


        //Save button click event handler

        protected void btnSavePrivacySettings_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtTable = new DataTable();
                dtTable = dtUserIDsDisAp;
                int y = 0;
                dtTable = dtUserIDsAppr;
                y = 20;

                if (!pic_vid_Flag)
                {
                    for (int x = 0; x < dtUserIDsDisAp.Rows.Count; x++)
                        objApprCntrFA.getGridData(3, Convert.ToInt32(dtUserIDsDisAp.Rows[x]["UserID"]));
                }
                else
                {

                    for (int x = 0; x < dtUserIDsDisAp.Rows.Count; x++)
                        objApprCntrFA.getGridData(4, Convert.ToInt32(dtUserIDsDisAp.Rows[x]["UserID"]));
                }

                if (!pic_vid_Flag)
                {
                    for (int x = 0; x < dtUserIDsAppr.Rows.Count; x++)
                        objApprCntrFA.getGridData(5, Convert.ToInt32(dtUserIDsAppr.Rows[x]["UserID"]));
                }
                else
                {

                    for (int x = 0; x < dtUserIDsAppr.Rows.Count; x++)
                        objApprCntrFA.getGridData(6, Convert.ToInt32(dtUserIDsAppr.Rows[x]["UserID"]));
                }
            }
            catch { }
        }

        protected void rdblstApprDisappr_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string srt = ((((Control)sender).NamingContainer.ClientID)).ToString();
                int liof = srt.LastIndexOf("_");
                string aayeedee = srt.Substring((liof + 1), (srt.Length - liof - 1));
                int aaayeeeeedeeeee = Convert.ToInt32(aayeedee);
                RadioButtonList rdblstTemp = (RadioButtonList)(rdgrdUpldFiles.Items[aaayeeeeedeeeee]["Change_Status"]).FindControl("rdblstApprDisappr");
                if (rdblstTemp.Items[0].Selected == true)
                {
                    DataRow drTemp = dtUserIDsDisAp.NewRow();
                    dtUserIDsDisAp.Rows.Add(drTemp);
                    dtUserIDsDisAp.Rows[dtUserIDsDisAp.Rows.Count-1]["UserID"] = Convert.ToInt32(((Label)(rdgrdUpldFiles.Items[aaayeeeeedeeeee]["UserID"]).FindControl("lblUsrID")).Text);
                }
                else if (rdblstTemp.Items[1].Selected == true)
                {
                    DataRow drTemp = dtUserIDsAppr.NewRow();
                    dtUserIDsAppr.Rows.Add(drTemp);
                    dtUserIDsAppr.Rows[dtUserIDsAppr.Rows.Count-1]["UserID"] = Convert.ToInt32(((Label)(rdgrdUpldFiles.Items[aaayeeeeedeeeee]["UserID"]).FindControl("lblUsrID")).Text);
                }
                dtUserIDsAppr.AcceptChanges();
            }
            catch { }
        }

        protected void lnkbtnVidURL_Click(object sender, EventArgs e)
        {
            try
            {
                fool = true;
                string srt = ((((Control)sender).NamingContainer.ClientID)).ToString();
                int liof = srt.LastIndexOf("_");
                string aayeedee = srt.Substring((liof + 1), (srt.Length - liof - 1));
                int aaayeeeeedeeeee = Convert.ToInt32(aayeedee);
                Label lblTemp = (Label)(rdgrdUpldFiles.Items[aaayeeeeedeeeee]["VideoColumn"]).FindControl("lblFileName");
                Label lblTemp2 = (Label)(rdgrdUpldFiles.Items[aaayeeeeedeeeee]["UserID"]).FindControl("lblSerialNo");
                flvdUsrUpload.VideoURL = lblTemp.Text;
                flvdUsrUpload.Visible = true;
                lblSerial.Text = lblTemp2.Text;
            }
            catch { }
        }


        //
    }
}
