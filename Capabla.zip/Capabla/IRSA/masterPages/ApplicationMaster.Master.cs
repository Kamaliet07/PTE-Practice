﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using IRSA.Common.GlobalFunction;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Telerik.Web.UI;
using System.Resources;
using System.Threading;
using System.Globalization;

namespace IRSA.masterPages
{

    public partial class ApplicationMaster : System.Web.UI.MasterPage
    {
        public enum SiteMapMenus
        {
            JS,ST,RC, NotSet
        }
        SiteMapMenus eMenuToLoad = SiteMapMenus.NotSet;
        public SiteMapMenus MenuToLoad
        {
            get { return eMenuToLoad; }
            set { eMenuToLoad = value; }
        }
        string str1, str, str6;
        string CULINFO;
        string strURL;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (SessionInfo.CultureID == "")
                {
                    SessionInfo.CultureID = "NL";
                }
                string combo = SessionInfo.ComboSearch;
                if (combo != "" || combo != string.Empty)
                {
                    RadComboBox1.SelectedValue = SessionInfo.ComboSearch;
                }
            }
            //
            getMasterPageLanguageInfo();
            try
            {
                string url = Request.Url.ToString();
                strURL = url.Split(new string[] { ConfigurationSettings.AppSettings["URL"] }, 2, StringSplitOptions.None)[1];
                if (strURL == "Home.aspx" || strURL == "Login.aspx")
                {

                    ImgBtnEng.Enabled = true;
                    Immbtndutch.Enabled = true;
                    ImmbtnSpanish.Enabled = false;


                }
                else
                {

                    ImgBtnEng.Visible = false;
                    Immbtndutch.Visible = false;
                    ImmbtnSpanish.Visible = false;
                }
                if (SessionInfo.UserId == int.MinValue)
                {
                    LblSignIn.Visible = true;
                    LblSignOut.Visible = false;
                    TreeView1.Visible = false;
                    LblAccountSetting.Visible = false;
                    Image1.Visible = true;
                }
                else
                {
                    SiteMapMenus eMenuToLoad = (SiteMapMenus)Enum.Parse(typeof(SiteMapMenus), SessionInfo.RoleID);
                    LblSignIn.Visible = false;
                    LblSignOut.Visible = true;
                    TreeView1.Visible = true;
                    TreeView1.DataSource = GetMenuDataSource(eMenuToLoad, Server.MapPath("~"));
                    TreeView1.DataBind();
                    Image1.Visible = false;
                    LblAccountSetting.Visible = true;

                }
            }
            catch { }
            //HttpCookie cookie = Request.Cookies["test"];
            //if (cookie != null)
            //{
            //    string[] toggleParts = cookie.Value.Split('*');
            //    foreach (string part in toggleParts)
            //    {
            //        if (String.IsNullOrEmpty(part)) continue;
            //        RadTreeNode toggledNode = TreeView1.FindNodeByValue(part);
            //        toggledNode.ExpandParentNodes();
            //        toggledNode.Expanded = true;
            //    }
            //}

        }

          protected void ImageButton1_Click(object sender, EventArgs e)
        {
            try
            {

       
                SessionInfo.ComboSearch = "";
                Search();
                str1 = RadComboBox1.SelectedValue;
                SessionInfo.ComboSearch = RadComboBox1.SelectedValue;
                
                if (RadTextBox1.Text != "")
                {
                    {
                        if (str1 == "Organization")
                        {
                            Response.Redirect("CompanySearch2.aspx?id=" + str,false);
                        }
                        else if (str1 == "People")
                        {
                            Response.Redirect("PersonSearch2.aspx?id=" + str,false);
                        }
                        else if (str1 == "Job")
                        {
                            Response.Redirect("JobSearch.aspx?id=" + str ,false);
                        }
                        else if (str1 == "Training")
                        {
                            Response.Redirect("BasicTrainingSetup.aspx?id=" + str,false);
                        }
                        else if (str1 == "Community")
                        {
                            Response.Redirect("CommunitySearch.aspx?id=" + str,false);
                        }
                        else if (str1 == "Education")
                        {
                            Response.Redirect("EducationSearch.aspx?id=" + str,false);
                        }
                    }


                }
                else
                {
                    if (str1 == "Organization")
                    {
                        Response.Redirect("CompanySearch2.aspx?id=" + str, false);
                    }
                    else if (str1 == "People")
                    {
                        Response.Redirect("PersonSearch2.aspx?id=" + str, false);
                    }
                    else if (str1 == "Job")
                    {
                        Response.Redirect("JobSearch.aspx?id=" + str, false);
                    }
                    else if (str1 == "Training")
                    {
                        Response.Redirect("BasicTrainingSetup.aspx?id=" + str, false);
                    }
                    else if (str1 == "Community")
                    {
                        Response.Redirect("CommunitySearch.aspx?id=" + str, false);
                    }
                    else if (str1 == "Education")
                    {
                        Response.Redirect("EducationSearch.aspx?id=" + str, false);
                    }
                }
            }
            catch
            { }
                }
        

        XmlDataSource GetMenuDataSource(SiteMapMenus menu,
                            string serverMapPath)
        {
            XmlDataSource objData = new XmlDataSource();
            objData.XPath = "siteMap/siteMapNode";
            if (SessionInfo.CultureID == "EN")
            {
                switch (menu)
                {
                    case SiteMapMenus.JS:
                        objData.DataFile = serverMapPath + @"\SiteMap\JsSiteMapEN.sitemap";
                        break;
                    //case SiteMapMenus.OR:
                    //    objData.DataFile = serverMapPath + @"\SiteMap\OrganizationSiteMap.sitemap";
                    //    break;
                    case SiteMapMenus.RC:
                        objData.DataFile = serverMapPath + @"\SiteMap\RecruiterSiteMapEN.sitemap";
                        break;
                    case SiteMapMenus.ST:
                        objData.DataFile = serverMapPath + @"\SiteMap\JsSiteMap.sitemapEN";
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (menu)
                {
                    case SiteMapMenus.JS:
                        objData.DataFile = serverMapPath + @"\SiteMap\JsSiteMap.sitemap";
                        break;
                    //case SiteMapMenus.OR:
                    //    objData.DataFile = serverMapPath + @"\SiteMap\OrganizationSiteMap.sitemap";
                    //    break;
                    case SiteMapMenus.RC:
                        objData.DataFile = serverMapPath + @"\SiteMap\RecruiterSiteMap.sitemap";
                        break;
                    case SiteMapMenus.ST:
                        objData.DataFile = serverMapPath + @"\SiteMap\JsSiteMap.sitemap";
                        break;
                    default:
                        break;
                }
            }
            objData.DataBind();
            return objData;
        }
        public void Search()
        {
            try
            {
                str = RadTextBox1.Text;
                int ln = str.Length;
                if (ln > 1)
                {
                    string[] words = str.Split(' ', ',');
                    foreach (string word in words)
                    {

                        str6 = str6 + " " + word;




                        str = str6;
                    }
                }
            }
            catch
            {
            }
        }

        protected void ImgBtnEng_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.CultureID = "EN";
            if (strURL == "Home.aspx")
            {
                Response.Redirect("Home.aspx");
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

        }
        protected void Immbtndutch_Click(object sender, ImageClickEventArgs e)
        {

            SessionInfo.CultureID = "NL";
            if (strURL == "Home.aspx")
            {
                Response.Redirect("Home.aspx");
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

        }
        protected void getMasterPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;

                Label3.Text = (string)GetGlobalResourceObject("PageResource", "LblHome");
                LblSignIn.Text = (string)GetGlobalResourceObject("PageResource", "LblSignIn");
                LblSignOut.Text = (string)GetGlobalResourceObject("PageResource", "LblSignOut");
                Label6.Text = (string)GetGlobalResourceObject("PageResource", "LblContactUs");
                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Lblhelp_Master");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "btnFind_ResumeVsSavedJobs");
                linkbtnchg.Text = (string)GetGlobalResourceObject("PageResource", "linkbtnchg_masterPage");
            }
            catch
            {
            }

        }

      

        }
        //protected void TreeView1_NodeClick(object sender, RadTreeNodeEventArgs e)
        //{
        //    //int value = Convert.ToInt32(e.Node.Value);
        //}

    }




