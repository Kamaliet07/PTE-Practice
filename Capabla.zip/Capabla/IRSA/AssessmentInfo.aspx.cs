﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;
using IRSA.BussinessLogic;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class AssessmentInfo : System.Web.UI.Page
    {
        int UserID;
        string ReportPath;
        public int PageID
        {
            set
            {
                ViewState["PageID"] = value;
            }
            get
            {
                if (ViewState["PageID"] == null)
                {
                    ViewState["PageID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["PageID"].ToString());
            }
        }
        public int productid
        {
            set
            {
                ViewState["productid"] = value;
            }
            get
            {
                if (ViewState["productid"] == null)
                {
                    ViewState["productid"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["productid"].ToString());
            }
        }
        public string UserName
        {
            set
            {
                ViewState["UserName"] = value;
            }
            get
            {
                if (ViewState["UserName"] == null)
                {
                    ViewState["UserName"] = string.Empty;
                }
                return ViewState["UserName"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            ReportPath = ConfigurationSettings.AppSettings["ReportDirectoryPath"];
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                UserName = objdt.Rows[0]["EmailID"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            if (!IsPostBack)
            {
                GetToolsName();
              //  InsertUserPurchageRecord();
            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (UserID != int.MinValue)
            {
                Response.Redirect("AbilityQuestionnaire.aspx?id=" + "Ability");
            }
            
        }

        protected void Link1_Click(object sender, EventArgs e)
        {
            try
            {
                
                    string filePath = ReportPath + "SkillAssessment.pdf";
                    FileInfo file = new FileInfo(filePath);
                    if (file.Exists)
                    {
                        Response.ClearContent();
                        Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                        Response.ContentType = "application/vnd.pdf";
                        Response.Flush();
                        Response.TransmitFile(file.FullName);
                        Response.End();
                    }
                
            }
            catch { }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "_360DegreeAssessment.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "WorkcontextAssessment.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        public void GetToolsName()
        {try{
            
            DataTable dttools = new DataTable();
            dttools = WorkContextBL.GetToolsName();
            Grid_Tools.DataSource = dttools;
            Grid_Tools.DataBind();
        }
        catch{}
        }

        protected void ImgTry_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void ImgBuy_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                ImageButton imgbtn = (ImageButton)sender;
                ImageButton obj = (ImageButton)imgbtn.NamingContainer.FindControl("ImgBuy");
                this.productid = Convert.ToInt32(Grid_Tools.MasterTableView.DataKeyValues[gr.ItemIndex]["ToolID"].ToString());
                InsertUserPurchageRecord();
                OpenNewWindow();
            }
            catch { }
        }
        private void InsertUserPurchageRecord()
        {
            if (this.UserName != string.Empty && SessionInfo.UserId != int.MinValue)
            {

                DigitalAdvisorFA objbuydet = new DigitalAdvisorFA();
                objbuydet.InserUserPurchageIntery(this.UserName, this.productid, SessionInfo.UserId);

            }
        }
        public void OpenNewWindow()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script language='javascript' type='text/javascript'>");
            sb.Append("window.open('http://www.regsoft.com', 'PopUp',");
            sb.Append("'top=100, left=200, width=900, height=600, menubar=yes,toolbar=yes,status,resizable=yes,addressbar=yes');<");
            sb.Append("/script>");

            Type t = this.GetType();

            if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
        }

    }
}
