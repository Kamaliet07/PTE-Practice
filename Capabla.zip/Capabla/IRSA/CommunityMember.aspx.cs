﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Configuration;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class CommunityMember : System.Web.UI.Page
    {
        string UserDetail;
        public int CommunityID
        {
            set
            {
                ViewState["CommunityID"] = value;
            }
            get
            {
                if (ViewState["CommunityID"] == null)
                {
                    ViewState["CommunityID"] = 0;
                }
                return Convert.ToInt32(ViewState["CommunityID"].ToString());
            }
        }
        public int UserID
        {
            set
            {
                ViewState["UserID"] = value;
            }
            get
            {
                if (ViewState["UserID"] == null)
                {
                    ViewState["UserID"] = 0;
                }
                return Convert.ToInt32(ViewState["UserID"].ToString());
            }
        }
        public DataTable GetCommunityMemberDetails
        {
            get { return (DataTable)ViewState["GetCommunityMemberDetails"]; }
            set { ViewState["GetCommunityMemberDetails"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                int UserID1 = SessionInfo.UserId;
                UserDetail = ConfigurationSettings.AppSettings["UserDetail"];
                if (UserID1 != int.MinValue)
                {
                    Lblmember.Text = SessionInfo.FirstName + " " + "!";
                    LabelDomainName.Text = SessionInfo.i_FunctionalDomain;
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
                if (!Page.IsPostBack)
                {
                    this.CommunityID = Convert.ToInt32(Request.QueryString.Get("id"));
                    GetCommunityMemberInformation();

                }


            }

            catch
            {
                

            }
        }

        private void GetCommunityMemberInformation()
        {
            IRSA.Facade.Community.CommunityFA ObjMyCommInfo = new IRSA.Facade.Community.CommunityFA();
            this.GetCommunityMemberDetails = ObjMyCommInfo.GetCommunityUserDetail(this.CommunityID);
            RebindTablleForImage();
            BindUserCommunityDetail();
        }

        private void RebindTablleForImage()
        {
            this.GetCommunityMemberDetails.Columns.Add(new DataColumn("NewImagePath", typeof(string)));
            foreach (DataRow dr in this.GetCommunityMemberDetails.Rows)
            {
                string imagpath = UserDetail + dr["PhotoID"].ToString();
                dr["NewImagePath"] = imagpath;
            }
        }
        private void BindUserCommunityDetail()
        {
            try
            {
                if (this.GetCommunityMemberDetails.Rows.Count != 0)
                {
                    RadGridCommunityMems.DataSource = this.GetCommunityMemberDetails;
                    RadGridCommunityMems.DataBind();
                }
            }
            catch
            { 
            
            }
        }

        protected void LnkBtnInvite_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton chk = (LinkButton)sender;
            LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LnkBtnInvite");
            this.UserID = Convert.ToInt32(RadGridCommunityMems.MasterTableView.DataKeyValues[gr.ItemIndex]["UserID"].ToString());

            RadWindow rd = new RadWindow();
            rd.ID = "RadWindoInvite";
            rd.NavigateUrl = "~/SendInvitation.aspx?ID=" + this.UserID;
            rd.VisibleOnPageLoad = true;
            rd.Width = 350;
            rd.Height = 450;
            rd.Left = 400;
            rd.Top = 150;
            RadWindowManager1.Windows.Add(rd);
            RadWindowManager1.KeepInScreenBounds = true;
        }

        protected void LnkBtnSendMsg_Click(object sender, EventArgs e)
        {

        }

        protected void RadGridCommunityMems_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem item = e.Item as GridDataItem;
                int userid = Convert.ToInt32(item["UserID"].Text.ToString());
                DataTable obj = new DataTable();
                obj = GetUserInviteStatus(userid);
                if (obj.Rows.Count != 0)
                {
                    if (obj.Rows[0]["Accepted"].ToString() != "False")
                    {
                        LinkButton lnkbtn = item["UserTemplateColumn"].FindControl("LnkBtnInvite") as LinkButton;
                        lnkbtn.Enabled = false;
                    }
                    else if (userid == SessionInfo.UserId)
                    {
                        LinkButton lnkbtn = item["UserTemplateColumn"].FindControl("LnkBtnInvite") as LinkButton;
                        lnkbtn.Enabled = false;
                    }
                
                }
                

            }
        }

        private DataTable GetUserInviteStatus(int userid)
        {
            IRSA.Facade.Community.CommunityFA ObjMyCommInfo = new IRSA.Facade.Community.CommunityFA();
            return ObjMyCommInfo.GetUserExistanceInNet(userid, SessionInfo.UserId);
        }
    }
}
