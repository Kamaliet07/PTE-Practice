﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;


using System.Xml.XPath;

namespace IRSA
{
    public partial class JobPostingOtherInfo : System.Web.UI.Page
    {
        int UserID;
        int JobID;
        string CULINFO;
        string step = "";
        string Collection = "";
        string JobPostingxml = "TooltripJobposting.xml";

        protected void Page_Load(object sender, EventArgs e)
        {
            GettooltipMessage();
            string Job = Request.QueryString.Get("ID");
            if (Job != "")
            {
                JobID = Convert.ToInt32(Job);

            }
            if (!IsPostBack)
            {
                XmlCountry();
                RadDatestartdate.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                Raddatepicker1.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                GetOtherInfo();

            }

            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            getJobOtherInfoPageLanguageInfo();
        }

        protected void ComapanyInfo_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("PostJobCompanyInformation.aspx?ID=" + JobID);
        }

        protected void JobInfo_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
        }

        protected void DesiredProfile_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingQuestionnaire.aspx?ID=" + JobID);
        }
        protected void GetOtherInfo()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJob(JobID);
                if (dt.Rows.Count > 0)
                {
                    TxtJobLocation.Text = dt.Rows[0]["JobCity"].ToString();
                    DdCountry.SelectedValue = dt.Rows[0]["JobCountry"].ToString();
                    Txtpostalcode.Text = dt.Rows[0]["JobPostalCode"].ToString();
                    if (dt.Rows[0]["PostingDate"].ToString() != "")
                    {
                        RadDatestartdate.SelectedDate = Convert.ToDateTime(dt.Rows[0]["PostingDate"].ToString());
                    }
                    if (dt.Rows[0]["ExpirationDate"].ToString() != "")
                    {
                        Raddatepicker1.SelectedDate = Convert.ToDateTime(dt.Rows[0]["ExpirationDate"].ToString());
                    }
                    if (dt.Rows[0]["Towhom"].ToString() != "")
                    {
                        RadioBtnTowhom.SelectedValue = dt.Rows[0]["Towhom"].ToString();
                    }
                    DdAmount.Text = dt.Rows[0]["ReferalBonusAmount"].ToString();
                    DdCurrency.Text = dt.Rows[0]["ReferalBonusCurrency"].ToString();
                }
            }
            catch
            {
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingPreview.aspx?ID=" + JobID);

        }
        protected void Savedata()
        {
            try
            {
                if (ValidateDate())
                {
                    LblMrssage.Visible = false;
                    LblMrssage.Text = " ";
                    string Job = Request.QueryString.Get("ID");
                    if (Job != "")
                    {
                        JobID = Convert.ToInt32(Job);

                    }
                    JobPostingSH JobPostSH = new JobPostingSH();
                    JobPostingFA Jobpostfa = new JobPostingFA();

                    DataTable temp = new DataTable();
                    step = "Otherinfo";
                    JobPostSH.JobLocation = TxtJobLocation.Text + "," + DdCountry.SelectedValue + "," + Txtpostalcode.Text;
                    JobPostSH.JobCity = TxtJobLocation.Text;
                    JobPostSH.JobPotalCode = Txtpostalcode.Text;
                    JobPostSH.JobCountry = DdCountry.SelectedValue;
                    CULINFO = "en-GB";

                    CultureInfo objCI = new CultureInfo(CULINFO);
                    Thread.CurrentThread.CurrentCulture = objCI;
                    Thread.CurrentThread.CurrentUICulture = objCI;

                    string PostoingStart = RadDatestartdate.SelectedDate.Value.ToString("dd/MMM/yyyy");

                    JobPostSH.PostingDate = PostoingStart;
                    string jobpostingEnd = Raddatepicker1.SelectedDate.Value.ToString("dd/MMM/yyyy");

                    JobPostSH.ExpirationDate = jobpostingEnd;
                    JobPostSH.ToWhom = RadioBtnTowhom.Text;
                    if (DdAmount.Text != "")
                    {
                        JobPostSH.ReferralBonusAmount = Convert.ToDouble(DdAmount.Text);
                    }
                    JobPostSH.ReferralBonusCurrency = DdCurrency.Text;
                    temp = Jobpostfa.GetCompany(JobPostSH, step, JobID, Collection);
                    LblMrssage.Visible = true;
                    LblMrssage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(50);
                }
                else
                {
                    LblMrssage.Visible = true;
                    LblMrssage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(43);
                }
            }

            catch
            {
            }
        }

        private void XmlCountry()
        {
            try
            {


                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                DdCountry.LoadXml(NodeIter1.Current.InnerXml);
                DdCountry.LoadXml(NodeIter1.Current.InnerXml);




            }
            catch
            {
                
            }
        }

        protected void DescribeSkills_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
        }

        //protected void Questionnaire_Click(object sender, ImageClickEventArgs e)
        //{
        //    Savedata();
        //    Response.Redirect("JobPostingOtherInfo.aspx.aspx?ID=" + JobID);
        //}



        protected void DescribeToolsAndTech_Click(object sender, ImageClickEventArgs e)
        {
            Savedata();
            Response.Redirect("JobPostingDescribetoolsandtech.aspx?ID=" + JobID);
        }
        private void GettooltipMessage()
        {
            try
            {
                TxtJobLocation.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(22, JobPostingxml);
                Txtpostalcode.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(24, JobPostingxml);
                RadioBtnTowhom.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(25, JobPostingxml);
                ImgAmount.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(27, JobPostingxml);
                ImrCurrency.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(28, JobPostingxml);
                ImgCountry.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(23, JobPostingxml);
                ImgExpdate.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(26, JobPostingxml);


            }
            catch
            {
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Savedata();
        }
        public bool ValidateDate()
        {


            if (Raddatepicker1.SelectedDate.Value <= RadDatestartdate.SelectedDate.Value || RadDatestartdate.IsEmpty == true || Raddatepicker1.IsEmpty == true)
            {
                LblErrrmassage.Visible = true;
                LblErrrmassage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(30);
                return false;

            }
            else
            {

                LblErrrmassage.Visible = false;
                LblErrrmassage.Text = "";
                return true;
            }






        }
        protected void getJobOtherInfoPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_JobPostingOtherInfo");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_JobPostingOtherInfo");
                //Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingProfile");
                //Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_JobPostingOtherInfo");
                Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_JobPostingOtherInfo");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_JobPostingOtherInfo");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_JobPostingOtherInfo");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_JobPostingOtherInfo");
                Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingOtherInfo");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_JobPostingOtherInfo");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_JobPostingOtherInfo");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_JobPostingOtherInfo");
                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label5_JobPostingOtherInfo");
                //Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_JobPostingOtherInfo");
                //Label17.Text = (string)GetGlobalResourceObject("PageResource", "Label17_JobPostingOtherInfo");

                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label5_JobPostingOtherInfo");
                Label6.Text = (string)GetGlobalResourceObject("PageResource", "Label6_JobPostingOtherInfo");
                Label7.Text = (string)GetGlobalResourceObject("PageResource", "Label7_JobPostingOtherInfo");
                Label8.Text = (string)GetGlobalResourceObject("PageResource", "Label8_JobPostingOtherInfo");

                RadioBtnTowhom.Items[0].Text = (string)GetGlobalResourceObject("PageResource", "Employees_JobPostingOtherInfo");
                RadioBtnTowhom.Items[1].Text = (string)GetGlobalResourceObject("PageResource", "Nonemployees_JobPostingOtherInfo");
                RadioBtnTowhom.Items[2].Text = (string)GetGlobalResourceObject("PageResource", "Anyone_JobPostingOtherInfo");
                
                
                
                
                
                
                
                
                //Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_JobPostingProfile");
                //Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label18_JobPostingOtherInfo");

                Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_JobPostingOtherInfo");

                btnupdate.Text = (string)GetGlobalResourceObject("PageResource", "btnupdate_JobPostingOtherInfo");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_JobPostingOtherInfo");

                Button1.Text = (string)GetGlobalResourceObject("PageResource", "Button1_JobPostingOtherInfo");
            }
            catch
            {
            }
        }
    }
}
