﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;



namespace IRSA
{
    public partial class jobpostinginfo : System.Web.UI.Page
    {
        int ModuleID;
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!this.IsPostBack)
            {

                Getdata();
            }
        }
        public void Getdata()
        {
            try
            {

                jobpostinginfoFA objaccFA = new jobpostinginfoFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetmoduleData();
                if (objdt.Rows.Count > 0)
                {
                   
                }

                RadGridmodule.DataSource = objdt;
                RadGridmodule.DataBind();

                RadGridmodule.Visible = true;


            }
            catch { }
        }


        protected void BtnSignIn_Click(object sender, EventArgs e)
        {

            string email;
            LoginSH objsh = new LoginSH();
            email = RadTextname.Text;
            if (Validation.IsValidEmailAddress(email))
            {
                objsh.UserID = email;
                objsh.Password = RadTextpwd.Text;

            }
            else
            {
                Lblerror.Visible = true;
                Lblerror.Text = "Enter vaild email/Password";
            }
            if (RadTextname.Text == null && RadTextpwd.Text == null)
            {
                Lblerror.Visible = true;
                Lblerror.Text = "Enter vaild email/Password";

            }
            objsh.EmailID = RadTextname.Text;
            LoginFA objFA = new LoginFA();
            Encryption.HashPwd(RadTextpwd.Text);
            string password = Encryption.HashPwd(RadTextpwd.Text);
            objsh.Password = password;
            if (Encryption.verifyPwd(RadTextpwd.Text, objsh.Password) && objsh.EmailID == RadTextname.Text)
            {
                objFA.GetValidate(objsh);


                int y = Convert.ToInt32(SessionInfo.UserId);

                if (y > 0)
                {
                    //MembershipUser search = Membership.GetUser(this.TxtLoginname.Text);
                    //if (search == null)
                    //{
                    //    MembershipCreateStatus status;
                    //    search = Membership.CreateUser(this.TxtLoginname.Text, Textpassword.Text, this.TxtLoginname.Text, "What does 1+1 equal?", "2", true, out status);
                    //}
                    //FormsAuthentication.RedirectFromLoginPage(search.UserName, false);
                    //DataTable dtorgid = new DataTable();
                    //dtorgid = objFA.GetOrgID();
                    //if (dtorgid.Rows.Count > 0)
                    //{
                    //    SessionInfo.OrganisationID = Convert.ToInt32(dtorgid.Rows[0]["OrganisationID"].ToString());
                    //    SessionInfo.OrgID = Convert.ToInt32(dtorgid.Rows[0]["OrganisationID"].ToString());

                    //}
                    Response.Redirect("MyDashBoard.aspx");

                }
                else
                {
                    Lblmessage.Visible = true;
                    Lblmessage.Text = "Invalid user";
                }
            }

        }

        protected void Imgbtnregister_click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

            
        protected void RadGridmodule_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                string Modules;
               
                GridDataItem item = e.Item as GridDataItem;
                
                jobpostinginfoFA objjobpostinginfoFA = new jobpostinginfoFA();
                int ModuleID = Convert.ToInt32(item["ModuleID"].Text.ToString());
                DataTable obj = new DataTable();
               Image img = item["StandardUser"].FindControl("imgStdUser") as Image;
                Image img1 = item["PremiumUser"].FindControl("imgPreUser") as Image;
                obj = objjobpostinginfoFA.getmodules(ModuleID);


                if (obj.Rows.Count > 0)
                {

                    if (obj.Rows[0]["StandardUser"].ToString().Trim() == "True")
                    {
                       img.ImageUrl="~/images/true.jpg";
                    }

                    else
                    {
                        img.ImageUrl="~/images/false.jpg";
                    }
                    
                
      
                        if (obj.Rows[0]["PremiumUser"].ToString().Trim() == "True")
                        {
                            img1.ImageUrl="~/images/true.jpg";
                        }

                        else
                        {
                            img1.ImageUrl="~/images/false.jpg";
                        }
                }
                    }

               
               
               

            }

        protected void Linkcondet_Click(object sender, EventArgs e)
        {
            if (UserID != int.MinValue)
            {
                Response.Redirect("AccountWelcome.aspx");  
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            ForgotPasswordSH objForgotPasswordSH = new ForgotPasswordSH();
            if (RTxtname.Text == null && REmailID.Text == null)
            {
                Lblshow.Visible = true;
                Lblshow.Text = "Name or EmailID is either Blank or not in correct Format";
            }
            if (Validation.IsValidEmailAddress(REmailID.Text))
            {
                objForgotPasswordSH.UserName = REmailID.Text;
            }

            try
            {
                LbMsg.Visible = true;
                LbMsg.Visible = true;
                LbMsg.Text = "Mail Send Successfully";
                //StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress("irsa@iprozone.com");
                MailAddress fromto = new MailAddress(REmailID.Text);
                MailMessage msg = new MailMessage(fromto, sendto);
                msg.Subject = "User Query";
                msg.Body = "User Name :" + RTxtname.Text + "\n" + "EmailID :" + REmailID.Text + "\n" + "Query :" + TextArea1.Value;
                //+ "Query :" + TextArea.Text
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
            }
            catch
            {
            }
        }

   }
 }

