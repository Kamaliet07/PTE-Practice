﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Telerik.Web.UI;
using IRSA.BussinessLogic;
using IRSA.Facade;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class AddWebPart : System.Web.UI.Page
    {
        int UserID = int.MinValue;
        //int UserID = SessionInfo.UserId;
        public DataTable GetAddedWebPart
        {
            get { return (DataTable)ViewState["addcontrol"]; }
            set { ViewState["addcontrol"] = value; }
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!Page.IsPostBack)
            {
                try
                {
                    BindRadTemplateGrid();
                    //HidepreviouslySavedControl();
                    //Button1.Visible = false;
                }
                catch
                { 
                                
                }
            }
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }    
            
            
        }
        public void BindRadTemplateGrid()
        {
            MyDashBoardBL objaddgrid = new MyDashBoardBL();
            DataTable objdt = new DataTable();
            objdt = objaddgrid.getGridValue();
            if (objdt.Rows.Count != 0)
            {
                RadGridControl.DataSource = objdt;
                RadGridControl.DataBind();
            }

        }
        private static DataTable EmptyAddedControl()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("controlName", typeof(string)));
            objDT.Columns.Add(new DataColumn("ControlTitle", typeof(string)));
            return objDT;

        }

        protected void BtnAdd_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            Button btnadd = (Button)sender;
            Button obj = (Button)btnadd.NamingContainer.FindControl("BtnAdd");
            string controlname = Convert.ToString(RadGridControl.MasterTableView.DataKeyValues[gr.ItemIndex]["ControlName"]);

            GridDataItem dtitem = this.RadGridControl.Items[gr.ItemIndex];
            Label txtbx = (Label)dtitem["ControlTitle"].FindControl("lblLevelTitle");
            string controlTitle = txtbx.Text.Trim();
            
            if (UserID != int.MinValue)
            {
                //SaveUserControl(this.UserID, controlname);
            }
            
            if (GetAddedWebPart == null)
            {
                GetAddedWebPart = EmptyAddedControl();
                DataTable controldt = new DataTable();
                controldt = GetAddedWebPart.DefaultView.ToTable();
                DataRow dr = controldt.NewRow();
                dr["controlName"] = controlname;
                dr["ControlTitle"] = controlTitle;
                controldt.Rows.Add(dr);
                GetAddedWebPart = controldt;
                Session["NewAddedControl"] = GetAddedWebPart.DefaultView.ToTable();
            }
            else
            {
                DataTable controldt = new DataTable();
                controldt = GetAddedWebPart.DefaultView.ToTable();
                DataRow dr = controldt.NewRow();
                dr["controlName"] = controlname;
                dr["ControlTitle"] = controlTitle;
                controldt.Rows.Add(dr);
                GetAddedWebPart = controldt;
                Session["NewAddedControl"] = GetAddedWebPart.DefaultView.ToTable();

            }
            
        }

        private void SaveUserControl(int userid, string controlname)
        {
            MyDashBoardFA objmydashboard = new MyDashBoardFA();
            objmydashboard.saveUserControl(userid, controlname);
        }
        # region Through this we can make control button enable true or false
        protected void HidepreviouslySavedControl()
        {
            ResetButtonSelection(this.RadGridControl, "ButtonTemplateColumn", "BtnAdd");
            DataTable objleveltemp = GetPreviouslySavedControl(this.UserID);
            if (objleveltemp.Rows.Count > 0)
            {
                PerviouslyAddedControl(RadGridControl, objleveltemp, "ControlName", "BtnAdd", "ButtonTemplateColumn");
            }
            else
            {
                ResetButtonSelection(this.RadGridControl, "ButtonTemplateColumn", "BtnAdd");
            }

        }
        #endregion

        #region to fing previously saved control according to userid
        private DataTable GetPreviouslySavedControl(int UserID)
        {
            MyDashBoardFA objmydashboard = new MyDashBoardFA();
            return objmydashboard.GetSavedUserControlAccUserId(UserID);

        }
        #endregion

        # region This function used for to identified and make button enable false if control related to button are saved by user previously

        private void PerviouslyAddedControl(RadGrid grid, DataTable tempDataRowArray, string columnName, string ButtonId, string templateCol)
        {
            for (int index = 0; index < tempDataRowArray.Rows.Count; index++)
            {
                for (int count = 0; count < grid.Items.Count; count++)
                {
                    if (grid.Items[count].GetDataKeyValue(columnName).ToString() == tempDataRowArray.Rows[index][columnName].ToString().Trim())
                    {
                        Button tempCheckBox = (Button)grid.Items[count][templateCol].FindControl(ButtonId);
                        tempCheckBox.Enabled = false;
                    }
                    
                }
            }

        }
        #endregion

        # region To reset button enable true
        private void ResetButtonSelection(RadGrid grid, string templateCol, string Buttonid)
        {
            for (int count = 0; count < grid.Items.Count; count++)
            {
                Button controlbtn = (Button)grid.Items[count][templateCol].FindControl(Buttonid);
                controlbtn.Enabled = true;
            }

        }
        #endregion

       
        protected void ImgBtmBack_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("MyDashBoard.aspx");
        }

        protected void RadGridControl_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGridControl.CurrentPageIndex= e.NewPageIndex;
            BindRadTemplateGrid();
        }

    }
}
