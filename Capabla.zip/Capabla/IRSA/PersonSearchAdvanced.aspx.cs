﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Net.Mail;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text;
        

namespace IRSA
{
    public partial class PersonSearchAdvanced : System.Web.UI.Page
    {
        string str,str6,strphoto;
        int UserID, inviteuserid;
        
        PersonSearchSH objpersonserachSH = new PersonSearchSH();
        PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
        string PhotoDirectoryPath, userpicspath;
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        string Accountxml = "irsaToolTipSearch.xml";
         protected void Page_Load(object sender, EventArgs e)
         {
            UserID = SessionInfo.UserId;
            PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];
            userpicspath = ConfigurationSettings.AppSettings["userpics"];

             if (!IsPostBack)
             {
                XmlCountry();
                XmlEducationLevel();
               
             }
             GetiRsaToolTipAccMsg();
             if (UserID != int.MinValue)
             {
                 AccountsetupFA objaccFA = new AccountsetupFA();
                 DataTable objdt = new DataTable();
                 objdt = objaccFA.GetaccountData(UserID);
                 Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                 SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
             }
             else
             {
                 Response.Redirect("Login.aspx");
             }
        }
         private void XmlCountry()/*Binding Xml Country data*/
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                countrybox.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {

            }
        }
         private void GetiRsaToolTipAccMsg()
         {
             try
             {
                 RKeyword.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(13, Accountxml);
                 RFtrstName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, Accountxml);
                 RLastName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, Accountxml);
                 RCity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                 RProTitle.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, Accountxml);
                 RCompany.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                 RUniversity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(8, Accountxml);
                 
                      

             }
             catch { }
         }
         public string GetFilePath(int userid, string Photo)/*To Get Status of Profile Photo*/
            {
                PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                DataTable photostat = new DataTable();
                photostat = objPersonSearchFA.Getphotostatusadvanced(userid);
                if (photostat.Rows.Count > 0)
                  {

                    if (photostat.Rows[0]["Everyone"].ToString() == "True")
                    {
                        strphoto = PhotoDirectoryPath + Photo;
                    }
                    else
                    {
                        if (photostat.Rows[0]["MyContact"].ToString() == "True")
                        {
                            strphoto = PhotoDirectoryPath + Photo;
                        }
                        else
                        {
                            strphoto = userpicspath;
                        }
                    }
                  }
               else
                {
                    strphoto = userpicspath;
                }
              return strphoto;
            }
            private void XmlEducationLevel()/*Binding Xml Education Data*/
            {
                try
                {
                    XPathNavigator nav2;
                    XPathDocument docNav2;
                    XPathNodeIterator NodeIter2;
                    docNav2 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/EducationLevel.xml"));
                    nav2 = docNav2.CreateNavigator();
                    string strExp = "/root/English";
                    NodeIter2 = nav2.Select(strExp);
                    NodeIter2.MoveNext();
                    HighestEducationnbox.LoadXml(NodeIter2.Current.InnerXml);
                }
                catch
                {

                }
            }
            public void GetSearchWords(string str)
            {
                try
                {
                    string pattern = @"\S+";
                    Regex re = new Regex(pattern);
                    MatchCollection matches = re.Matches(str);
                    string[] words = new string[matches.Count];
                    for (int i = 0; i < matches.Count; i++)
                    {
                        words[i] = matches[i].Value;
                        string str4 = words[i];
                        getmember(str4);

                    }

                    if (GetTempsearch == null || GetTempsearch.Rows.Count==0)
                    {
                        PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                        visiblityuserTemp();
                        blkOrgUserTemp();
                        RadGrid2.DataSource = GetTempsearchCollection;
                        RadGrid2.DataBind();
                    }
                    else
                    {
                        PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                        visiblityuser();
                        blkOrgUser();
                        RadGrid2.DataSource = GetTempsearch;
                        RadGrid2.DataBind();

                    }
                }
                catch
                {
                }
            }
            public void getmember(string str4)
            {
                try
                {
                    DataTable dtCalc = new DataTable();
                    DataTable ds = new DataTable();

                    if (GetTempsearchCollection == null)
                    {
                        PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                        ds = objPersonSearchFA.GetData1(str4,objpersonserachSH);
                        GetTempsearchCollection = ds;
                        dtCalc = ds;
                        int count = dtCalc.Rows.Count;
                        dtCalc.Merge(GetTempsearchCollection);
                        GetTempsearchCollection = dtCalc;
                    }
                    else
                    {
                        DataRow[] Result = GetTempsearchCollection.Select("Expr1 Like '%" + str4 + "%'");
                        DataTable dfg = new DataTable();
                        dfg.Columns.Add("FirstName", typeof(string));
                        dfg.Columns.Add("LastName", typeof(string));
                        dfg.Columns.Add("City", typeof(string));
                        dfg.Columns.Add("Country", typeof(string));
                        dfg.Columns.Add("ProfessionalTitle", typeof(string));
                        dfg.Columns.Add("EmailID", typeof(string));
                        dfg.Columns.Add("UserID", typeof(int));
                        dfg.Columns.Add("PhotoID", typeof(string));
                        dfg.Columns.Add("LocationDetl", typeof(string));


                        foreach (DataRow dr in Result)
                        {
                            DataRow row;
                            row = dfg.NewRow();
                            row["PhotoID"] = dr[0];
                            row["FirstName"] = dr[4];
                            row["LastName"] = dr[5];
                            row["ProfessionalTitle"] = dr[6];
                            row["City"] = dr[8];
                            row["Country"] = dr[7];
                            row["EmailID"] = dr[12];
                            row["UserID"] = dr[1];
                            if (dr[6].ToString() != "" && dr[7].ToString() != "" && dr[8].ToString() != "")
                            {
                                row["LocationDetl"] = dr[6].ToString() + "," + dr[7].ToString() + "," + dr[8].ToString();
                            }
                            else if (dr[6].ToString() != "" && dr[7].ToString() != "" && dr[8].ToString() == "")
                            {
                                row["LocationDetl"] = dr[6].ToString() + "," + dr[7].ToString();
                            }
                            else if (dr[6].ToString() != "" && dr[7].ToString() == "" && dr[8].ToString() != "")
                            {
                                row["LocationDetl"] = dr[6].ToString() + "," + dr[8].ToString();
                            }
                            else if (dr[6].ToString() != "" && dr[7].ToString() == "" && dr[8].ToString() == "")
                            {
                                row["LocationDetl"] = dr[6].ToString();
                            }
                            else if (dr[6].ToString() == "" && dr[7].ToString() != "" && dr[8].ToString() != "")
                            {
                                row["LocationDetl"] = dr[7].ToString() + "," + dr[8].ToString();
                            }
                            else if (dr[6].ToString() == "" && dr[7].ToString() == "" && dr[8].ToString() != "")
                            {
                                row["LocationDetl"] = dr[8].ToString();
                            }
                            else if (dr[6].ToString() == "" && dr[7].ToString() != "" && dr[8].ToString() == "")
                            {
                                row["LocationDetl"] = dr[7].ToString();
                            }
                            else if (dr[6].ToString() == "" && dr[7].ToString() == "" && dr[8].ToString() == "")
                            {
                                row["LocationDetl"] = "";
                            }
                            dfg.Rows.Add(row);
                        }
                        GetTempsearch = dfg;
                    }

                }
                catch
                {
                }
            }

        protected void RadGrid2_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGrid2.CurrentPageIndex = e.NewPageIndex;
            if (GetTempsearch == null)
            {
                RadGrid2.DataSource = GetTempsearchCollection;
                RadGrid2.DataBind();
            }
            else
            {
                RadGrid2.DataSource = GetTempsearch;
                RadGrid2.DataBind();
            }
        }

      protected void BtnSubmit_Click(object sender, EventArgs e)
            
        {
            GetTempsearchCollection = null;
            GetTempsearch = null;
            if ((RKeyword.Text != "") && (RFtrstName.Text != ""))
            {
                person();
            }
            else if ((RKeyword.Text == "") && (RFtrstName.Text != ""))
            {
                person();
            }
            else if ((RKeyword.Text != "") && (RFtrstName.Text == ""))
            {
                string strkey = RKeyword.Text;
                int ln = strkey.Length;
                if (ln > 1)
                {
                    string[] words = strkey.Split(' ', ',');
                    foreach (string word in words)
                    {
                        str6 = str6 + " " + word;
                        str = str6;
                    }

                    GetSearchWords(str);
                }
                //{
                //    GetTempsearchCollection = null;
                //    GetTempsearch = null;
                //    if (RKeyword.Text != "")
                //    {

                //        string strkey = RKeyword.Text;
                //        int ln = strkey.Length;
                //        if (ln > 1)
                //        {
                //            string[] words = strkey.Split(' ', ',');
                //            foreach (string word in words)
                //            {
                //                str6 = str6 + " " + word;
                //                str = str6;
                //            }

                //            GetSearchWords(str);
                //        }


                //    else if (RKeyword.Text == "")
                //    {
                //        person();
                //    }

                //    else if ((RKeyword.Text != "" )&& (RFtrstName.Text != ""))
                //    {
                //        person();
                //    }
                //}

            }
            }
        protected void countrybox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {

            objpersonserachSH.Country = countrybox.SelectedItem.Text;
        }
        protected void person()
        { 
            string str6, str7, str8, str9, str10,str15, str16, str13, str14, str5,str17, 
                 str29, str21,str22;
            str6 = RFtrstName.Text;
            if (str6 == "")
            {
                str6 = null;
            }
            str9 = " ";
            objpersonserachSH.FirstName = RFtrstName.Text;
            str7 = RLastName.Text;
            if (str7 == "")
            {
                str7 = null;
            }
            str10 = " ";
            objpersonserachSH.LastName = RLastName.Text;
            str15 = RCity.Text;
            if (str15 == "")
            {
                str15 = null;
            }
            str16 = " ";
            objpersonserachSH.City = RCity.Text;
            str8 = countrybox.SelectedValue;
            if (str8 == "")
            {
                str8 = null;
            }
            str22 = " ";
            objpersonserachSH.Country = countrybox.SelectedValue;

            str13 = RProTitle.Text;
            if (str13 == "")
            {
                str13 = null;
            }
            
            str14 = " ";
            objpersonserachSH.ProfessionalTitle = RProTitle.Text;
            str5 = RCompany.Text;
            if (str5 == "")
            {
                str5 = null;
            }
            str21 = " ";
            objpersonserachSH.Company = RCompany.Text;
            str17 = HighestEducationnbox.SelectedValue;
            if (str17 == "")
            {
                str17 = null;
            }
            str21 = " ";
          
            objpersonserachSH.HighestEducation = HighestEducationnbox.SelectedValue;
            
            str29 = RUniversity.Text;
            if (str29 == "")
            {
                str29 = null;
            }
            objpersonserachSH.University = RUniversity.Text;
            
            string ab = str6 + str9 + str7 + str10 + str15 + str16 + str8 + str22  + str13 + str14
            + str5 + str21  + str29;
           GetSearchWords(ab);
            }

        protected void HighestEducationnbox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objpersonserachSH.HighestEducation = HighestEducationnbox.SelectedItem.Text;
        }

        private void InsertUserInvitationDetail()
        {
            IRSA.Facade.Community.CommunityFA ObjMyloginUser = new IRSA.Facade.Community.CommunityFA();
            ObjMyloginUser.InsertUserInvitationDetail(SessionInfo.UserId, inviteuserid);
        }
        private void getuserID(string EmailID)
        {
            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            DataTable dtuserid = new DataTable();
            dtuserid = objPersonSearchFA.GetUser(EmailID);
            if (dtuserid.Rows.Count > 0)
            {
                inviteuserid = Convert.ToInt32(dtuserid.Rows[0]["UserID"].ToString());
            }

        }
        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton btnprev = (LinkButton)sender;
            LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton3");
            string EmailID = Convert.ToString(RadGrid2.MasterTableView.DataKeyValues[gr.ItemIndex]["EmailID"]);
            SendMail(EmailID);
            InsertUserInvitationDetail();
        }
        public void SendMail(string EmailID)
        {
            try
            {

                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(EmailID);
                MailAddress fromto = new MailAddress("kamika@iprozone.com");
                MailMessage msg = new MailMessage(fromto, sendto);
                MailDefinition mailmsg = new MailDefinition();
                mailmsg.BodyFileName = "";
                mailmsg.IsBodyHtml = true;
                msg.IsBodyHtml = true;
                bodyMsg.Append("Congratulations ");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("This is your account Information for iRSA.com ");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Before you can log into your iRSA account,you need to set your password by visiting this URL:");
                bodyMsg.Append("<br />");
                getuserID(EmailID);
                string mail = string.Format("http://localhost:4071/AcceptInformation.aspx?param1={0}&param2={1}", inviteuserid, UserID);
                bodyMsg.Append(mail);
                bodyMsg.Append("<br />");
                bodyMsg.Append("After you login,explore the various tools & information to grow your career and get involved!");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Your Participation Drives iRSA.com");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Thank You for your interest in iRSA");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("iRSA values your privacy at no time has iRSA made your email address available to any other iRSA user without your permission @2009,Powered By iRSA");

                msg.Subject = "Contact Information";
                msg.Body = bodyMsg.ToString();

                msg.Priority = MailPriority.High;

                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);

            }
            catch { }

        }
        private DataTable GetUserStatus(int inviteuserid)
        {
            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            return objPersonSearchFA.GetUserExistanceInNet(inviteuserid, SessionInfo.UserId);
        }

        protected void RadGrid2_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
               
                GridDataItem item = e.Item as GridDataItem;
                PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                int userid = Convert.ToInt32(item["UserID"].Text.ToString());
                string Photo = (item["PhotoID"].Text.ToString());
                DataTable obj = new DataTable();
                DataTable profilestat = new DataTable();
                DataTable photostat = new DataTable();
                profilestat = objPersonSearchFA.Getlinkstatusadvanced(userid);
                 if (profilestat.Rows.Count > 0)
                 {
                    if (profilestat.Rows[0]["Everyone"].ToString().Trim() == "True")
                    {
                        LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                        lnkbtn.Enabled = true;
                    }
                    else
                    {
                        if (profilestat.Rows[0]["MyContact"].ToString().Trim() == "True")
                        {
                        LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                        lnkbtn.Enabled = true;
                        }

                        else
                        {
                        LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                        lnkbtn.Enabled = false;
                        }
                    }
                }
                 else
                 {
                     LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                     lnkbtn.Enabled = false;
                 }
                 obj = GetUserStatus(userid);
                 if (obj.Rows.Count != 0)
                 {
                     if (obj.Rows[0]["Accepted"].ToString().Trim() != "False")
                     {
                         LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                         lnkbtn.Enabled = false;
                     }


                 }
                 string filepath = GetFilePath(userid,Photo);
                 Image img = item["TemplateColumn"].FindControl("Image1") as Image;
                 img.ImageUrl = filepath;
               }
           }
            protected void visiblityuser()
            {
                if (GetTempsearch.Rows.Count > 0)
                {

                    for (int i = GetTempsearch.Rows.Count - 1; i >= 0; i--)
                    {
                        int uid = Convert.ToInt32(GetTempsearch.Rows[i]["UserID"].ToString());
                        bool val = objPersonSearchFA.GetStatus(uid);
                        if (val == false)
                        {
                            bool varn = objPersonSearchFA.GetMyContact(UserID, uid);
                            if (varn == false)
                            {
                                GetTempsearch.Rows.RemoveAt(i);
                            }

                        }
                    }
                    this.GetTempsearch.AcceptChanges();
                }
           }
            protected void blkOrgUser()
            {
                if (GetTempsearch.Rows.Count > 0)
                {
                    for (int i = GetTempsearch.Rows.Count - 1; i >= 0; i--)
                    {
                        int uid = Convert.ToInt32(GetTempsearch.Rows[i]["UserID"].ToString());
                        bool val = objPersonSearchFA.GetOrgStatus(UserID, uid);
                        if (val == true)
                        {
                            GetTempsearch.Rows.RemoveAt(i);
                        }

                    }
                    this.GetTempsearch.AcceptChanges();
                }
            }
            protected void visiblityuserTemp()
            {
                if (GetTempsearchCollection.Rows.Count > 0)
                {
                    for (int i = GetTempsearchCollection.Rows.Count - 1; i >= 0; i--)
                    {
                        int uid = Convert.ToInt32(GetTempsearchCollection.Rows[i]["UserID"].ToString());
                        bool val = objPersonSearchFA.GetStatus(uid);
                        if (val == false)
                        {
                            bool varn = objPersonSearchFA.GetMyContact(UserID, uid);
                            if (varn == false)
                            {
                                GetTempsearchCollection.Rows.RemoveAt(i);
                            }

                        }
                    }
                    this.GetTempsearchCollection.AcceptChanges();
                }
            }
            protected void blkOrgUserTemp()
            {
                if (GetTempsearchCollection.Rows.Count > 0)
                {
                    for (int i = GetTempsearchCollection.Rows.Count - 1; i >= 0; i--)
                    {
                        int uid = Convert.ToInt32(GetTempsearchCollection.Rows[i]["UserID"].ToString());
                        bool val = objPersonSearchFA.GetOrgStatus(UserID, uid);
                        if (val == true)
                        {
                            GetTempsearchCollection.Rows.RemoveAt(i);
                        }

                    }
                    this.GetTempsearchCollection.AcceptChanges();
                }
            }

            protected void LinkButton1_Click(object sender, EventArgs e)
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton1");
                string EmailID = Convert.ToString(RadGrid2.MasterTableView.DataKeyValues[gr.ItemIndex]["EmailID"]);
                getuserID(EmailID);
                UserID = inviteuserid;
                if (SessionInfo.UserId != int.MinValue)
                {
                    RadWindow rd = new RadWindow();
                    rd.ID = "RadWindowhelp";
                    rd.NavigateUrl = "~/PersonProfileView.aspx?id=" + UserID;
                    rd.VisibleOnPageLoad = true;
                    rd.Width = 600;
                    rd.Height = 500;
                    rd.Left = 400;
                    rd.Top = 150;
                    RadWindowManagerperson.Windows.Add(rd);
                    //int UserID1 = UserID;
                    //int VisitedID = inviteuserid;
                    //string Visiteddate = System.DateTime.Now.ToString("dd/MMM/yyyy");
                    //PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                    //objPersonSearchFA.insertVisitorUser(UserID1, VisitedID, Visiteddate);
                }
            }

        }

        

    }

