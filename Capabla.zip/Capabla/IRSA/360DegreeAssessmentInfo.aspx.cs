﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using IRSA.BussinessLogic;

using System.Xml.XPath;
using System.IO;
using System.Configuration;

namespace IRSA
{
    public partial class _60DegreeAssessmentInfo : System.Web.UI.Page
    {
        public int PageID
        {
            set
            {
                ViewState["PageID"] = value;
            }
            get
            {
                if (ViewState["PageID"] == null)
                {
                    ViewState["PageID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["PageID"].ToString());
            }
        }
        public int productid
        {
            set
            {
                ViewState["productid"] = value;
            }
            get
            {
                if (ViewState["productid"] == null)
                {
                    ViewState["productid"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["productid"].ToString());
            }
        }
        public string UserName
        {
            set
            {
                ViewState["UserName"] = value;
            }
            get
            {
                if (ViewState["UserName"] == null)
                {
                    ViewState["UserName"] = string.Empty;
                }
                return ViewState["UserName"].ToString();
            }
        }
        public int AttemptID
        {
            set
            {
                ViewState["AttemptID"] = value;
            }
            get
            {
                if (ViewState["AttemptID"] == null)
                {
                    ViewState["AttemptID"] = 0;
                }
                return Convert.ToInt32(ViewState["AttemptID"].ToString());
            }
        }
        int UserID;
        string ReportPath;
        string Url;
        string questemplate = "360 Degree Assessment";
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            ReportPath = ConfigurationSettings.AppSettings["ReportDirectoryPath"];
            this.PageID = 1042;
            this.productid = 1042;

            if (!IsPostBack)
            {
                Lblmessage.Visible = false;
                InsertUserPurchageRecord();
                GetUserPurchageDetailInfo();
                GetReportsStatus();

            }
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                UserName = objdt.Rows[0]["EmailID"].ToString();
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void BtnCredit_Click(object sender, EventArgs e)
        {
            //InsertUserPurchageRecord();
            OpenNewWindow();
        }

        protected void BtnTry_Click(object sender, EventArgs e)
        {

        }

        protected void BtnNew_Click(object sender, EventArgs e)
        {
            int count = 0;
            Assessment360FA objAssessmentFA = new Assessment360FA();
            DataTable dtsumbitionstatus = new DataTable();
            dtsumbitionstatus = objAssessmentFA.GetSubmitionStatusofuser(UserID);
            if (dtsumbitionstatus.Rows.Count > 0)
            {
                Response.Redirect("Assessment360.aspx");
            }
            else
            {
                getattempt();
                DigitalAdvisorFA objAdvisePurchUpdate = new DigitalAdvisorFA();
                objAdvisePurchUpdate.UpdateUserPurchageDetail(UserID, this.PageID);
                Response.Redirect("Assessment360.aspx");
            }

        }
        private void GetUserPurchageDetailInfo()
        {
            int count = 0;
            DigitalAdvisorFA objAdvise = new DigitalAdvisorFA();
            DataTable PurchInfo = objAdvise.GetAmountPurchageAndUsed(UserID, this.PageID);
            if (PurchInfo.Rows.Count != 0)
            {

                LblPurch.Text = PurchInfo.Rows[0]["Quantity"].ToString();
                LblSave.Text = PurchInfo.Rows[0]["UsedQuantity"].ToString();
                int difference = Convert.ToInt32(PurchInfo.Rows[0]["Difference"].ToString());
                if (difference == 0)
                {
                    Assessment360FA objAssessmentFA = new Assessment360FA();
                    DataTable dtsumbitionstatus = new DataTable();
                    dtsumbitionstatus = objAssessmentFA.GetSubmitionStatusofuser(UserID);
                    if (dtsumbitionstatus.Rows.Count > 0)
                    {
                        BtnNew.Enabled = false;
                        Lblmessage.Visible = true;
                        BtnTry.Enabled = false;
                        BtnCredit.Enabled = true;
                        Lblmessage.Text = "Purchase 360 Degree Assessment !";

                        BtnNew.Text = "Start New";


                    }
                    else
                    {
                        BtnCredit.Enabled = true;
                        BtnNew.Enabled = true;
                        BtnTry.Enabled = false;
                        BtnNew.Text = "In Progress...";

                    }

                }
                else
                {

                    BtnCredit.Enabled = true;
                    BtnNew.Enabled = true;
                    BtnTry.Enabled = false;

                    Assessment360FA objAssessmentFA = new Assessment360FA();
                    DataTable dtsumbitionstatus = new DataTable();
                    dtsumbitionstatus = objAssessmentFA.GetSubmitionStatusofuser(UserID);
                    if (dtsumbitionstatus.Rows.Count > 0)
                    {
                        BtnNew.Text = "Start New";

                    }
                    else
                    {
                        BtnNew.Text = "In Progress...";

                    }



                }
            }
            else
            {
                BtnCredit.Enabled = true;
                BtnNew.Enabled = false;
                BtnTry.Enabled = true;
            }
        }
        private void InsertUserPurchageRecord()
        {
            if (this.UserName != string.Empty && SessionInfo.UserId != int.MinValue)
            {

                DigitalAdvisorFA objbuydet = new DigitalAdvisorFA();
                objbuydet.InserUserPurchageIntery(this.UserName, this.productid, SessionInfo.UserId);

            }
        }
        public void getattempt()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                Assessment360FA objassFA = new Assessment360FA();
                DataTable dtattempt = new DataTable();
                dtattempt = objassFA.Get360UserAttemptID(UserID, questemplate);
                if (dtattempt.Rows.Count > 0)
                {
                    AttemptID = Convert.ToInt32(dtattempt.Rows[0]["AttemptID"].ToString()) + 1;
                }
                else
                {
                    AttemptID = 1;
                }


                string scaleid = "LV";
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                objskill.QuestionnaireTemplate = "360 Degree Assessment";

                objskill.AttemptID = AttemptID;

                objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                objskill.Status = "";
                objskillFA.InsertQuesSubmissionList(objskill);
            }
            catch { }
        }


        public void OpenNewWindow()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script language='javascript' type='text/javascript'>");
            sb.Append("window.open('http://www.regsoft.com', 'PopUp',");
            sb.Append("'top=0, left=0, width='+screen.availwidth+', height='+screen.availheight+', menubar=yes,toolbar=yes,status,resizable=yes,addressbar=yes');<");
            sb.Append("/script>");

            Type t = this.GetType();

            if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
        }

        protected void Link1_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "_360DegreeAssessment.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void Lnkold_Click(object sender, EventArgs e)
        {
            Response.Redirect("Assessment360.aspx");
        }
        protected void ImgView_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                ImageButton imgbtn = (ImageButton)sender;
                ImageButton obj = (ImageButton)imgbtn.NamingContainer.FindControl("ImgView");
                int AttemptID = Convert.ToInt32(Grid_Report.MasterTableView.DataKeyValues[gr.ItemIndex]["AttemptID"].ToString());
                SessionInfo.AttemptID = AttemptID;
                GridDataItem dtitem = Grid_Report.Items[gr.ItemIndex];
                Label Name = (Label)dtitem["Name"].FindControl("Name");

                Url = "360AssessmentReport.aspx";


                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }

        }
        public void GetReportsStatus()
        {
            try
            {

                DataTable dtst = new DataTable();
                dtst = ReportBL.Get360ReportsStatus(UserID, this.productid);
                Grid_Report.DataSource = dtst;
                Grid_Report.DataBind();
            }
            catch { }
        }

        
    }
}
