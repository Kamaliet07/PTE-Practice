﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using IRSA.BussinessLogic;

using System.Xml.XPath;
using System.Configuration;
using System.IO;

namespace IRSA
{
    public partial class ExperienceAssessmentInfo : System.Web.UI.Page
    {
        public int PageID
        {
            set
            {
                ViewState["PageID"] = value;
            }
            get
            {
                if (ViewState["PageID"] == null)
                {
                    ViewState["PageID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["PageID"].ToString());
            }
        }
        public int productid
        {
            set
            {
                ViewState["productid"] = value;
            }
            get
            {
                if (ViewState["productid"] == null)
                {
                    ViewState["productid"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["productid"].ToString());
            }
        }
        public string UserName
        {
            set
            {
                ViewState["UserName"] = value;
            }
            get
            {
                if (ViewState["UserName"] == null)
                {
                    ViewState["UserName"] = string.Empty;
                }
                return ViewState["UserName"].ToString();
            }
        }
        public int AttemptID
        {
            set
            {
                ViewState["AttemptID"] = value;
            }
            get
            {
                if (ViewState["AttemptID"] == null)
                {
                    ViewState["AttemptID"] = 0;
                }
                return Convert.ToInt32(ViewState["AttemptID"].ToString());
            }
        }
        int UserID;
        string Url;
        string ReportPath;
        string quesName;
        string CULINFO;
        string[] questemplate = { "Job-domain Specific" };
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ReportPath = ConfigurationSettings.AppSettings["ReportDirectoryPath"];
                UserID = SessionInfo.UserId;
                this.PageID = 1043;
                this.productid = 1043;

                quesName = Request.QueryString.Get("id").ToString();
                if (!IsPostBack)
                {
                    Lblmessage.Visible = false;
                    //InsertUserPurchageRecord();
                    //GetUserPurchageDetailInfo();
                    getExperienceAssessmentPageLanguageInfo();
                    GetReportsStatus();
                    getsubmitionofStatus();

                }
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    UserName = objdt.Rows[0]["EmailID"].ToString();
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
               
            }
            catch { }
        }

        protected void BtnCredit_Click(object sender, EventArgs e)
        {
           // InsertUserPurchageRecord();
            try
            {
                OpenNewWindow();
            }
            catch { }
        }

        protected void BtnTry_Click(object sender, EventArgs e)
        {

        }

        protected void BtnNew_Click(object sender, EventArgs e)
        {
            try
            {
                int count = 0;
                DataTable dt = new DataTable();
                for (int i = 0; i < questemplate.Length; i++)
                {

                    dt = getstatus(questemplate[i]);
                    if (dt.Rows.Count > 0)
                    {

                        string strstatus = dt.Rows[0]["Status"].ToString();
                        if (strstatus.Trim() == "Submit")
                        {
                            count++;
                        }
                        if (count == questemplate.Length)
                        {
                            getattempt();
                            //DigitalAdvisorFA objAdvisePurchUpdate = new DigitalAdvisorFA();
                            //objAdvisePurchUpdate.UpdateUserPurchageDetail(UserID, this.PageID);
                            Response.Redirect("JobDomainQuestionnaire.aspx");
                        }
                        else
                        {
                            Response.Redirect("JobDomainQuestionnaire.aspx");
                        }
                    }
                    else
                    {
                        getattempt();
                        //DigitalAdvisorFA objAdvisePurchUpdate = new DigitalAdvisorFA();
                        //objAdvisePurchUpdate.UpdateUserPurchageDetail(UserID, this.PageID);
                        Response.Redirect("JobDomainQuestionnaire.aspx");
                    }
                }
            }
            catch { }
        }
        private void GetUserPurchageDetailInfo()
        {
            try
            {
                int count = 0;
                DigitalAdvisorFA objAdvise = new DigitalAdvisorFA();
                DataTable PurchInfo = objAdvise.GetAmountPurchageAndUsed(UserID, this.PageID);
                if (PurchInfo.Rows.Count != 0)
                {

                    LblPurch.Text = PurchInfo.Rows[0]["Quantity"].ToString();
                    LblSave.Text = PurchInfo.Rows[0]["UsedQuantity"].ToString();
                    int difference = Convert.ToInt32(PurchInfo.Rows[0]["Difference"].ToString());
                    if (difference == 0)
                    {
                        DataTable dt = new DataTable();
                        for (int i = 0; i < questemplate.Length; i++)
                        {

                            dt = getstatus(questemplate[i]);
                            if (dt.Rows.Count > 0)
                            {

                                string strstatus = dt.Rows[0]["Status"].ToString();
                                if (strstatus.Trim() == "Submit")
                                {
                                    count++;
                                }
                            }
                            else
                            {
                            }
                        }
                        if (count == questemplate.Length)
                        {
                            BtnNew.Enabled = true;
                            Lblmessage.Visible = true;
                            BtnTry.Enabled = false;
                            BtnCredit.Enabled = true;
                            Lblmessage.Text = "Purchase Experience Assessment !";
                            BtnNew.Text = "Start New";
                           
                        }
                        else
                        {
                            BtnCredit.Enabled = true;
                            BtnNew.Enabled = true;
                            BtnTry.Enabled = false;
                            BtnNew.Text = "In Progress...";
                           
                        }

                    
                        

                    }
                    else
                    {

                        BtnCredit.Enabled = true;
                        BtnNew.Enabled = true;
                        BtnTry.Enabled = false;

                        DataTable dt = new DataTable();
                        for (int i = 0; i < questemplate.Length; i++)
                        {

                            dt = getstatus(questemplate[i]);
                            if (dt.Rows.Count > 0)
                            {

                                string strstatus = dt.Rows[0]["Status"].ToString();
                                if (strstatus.Trim() == "Submit")
                                {
                                    count++;
                                }
                            }
                            else
                            {
                            }
                        }
                        if (count == questemplate.Length)
                        {
                            BtnNew.Text = "Start New";
                            
                        }
                        else
                        {
                            BtnNew.Text = "In Progress...";
                          
                        }

                    }
                }
                else
                {
                    BtnCredit.Enabled = true;
                    BtnNew.Enabled = true;
                    BtnTry.Enabled = true;
                }
            }
            catch { }
        }
        private void InsertUserPurchageRecord()
        {
            try
            {
                if (this.UserName != string.Empty && SessionInfo.UserId != int.MinValue)
                {

                    DigitalAdvisorFA objbuydet = new DigitalAdvisorFA();
                    objbuydet.InserUserPurchageIntery(this.UserName, this.productid, SessionInfo.UserId);

                }
            }
            catch{}
        }
        public void getattempt()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable dtattempt = new DataTable();
                dtattempt = objskillFA.GetAttemptID(UserID, questemplate[0]);
                if (dtattempt.Rows.Count > 0)
                {
                    AttemptID = Convert.ToInt32(dtattempt.Rows[0]["AttemptID"].ToString()) + 1;
                }
                else
                {
                    AttemptID = 1;
                }



                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                for (int i = 0; i < questemplate.Length; i++)
                {
                    objskill.QuestionnaireTemplate = questemplate[i];

                    objskill.AttemptID = AttemptID;

                    objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                    objskill.Status = "";
                    objskillFA.InsertQuesSubmissionList(objskill);
                }
            }
            catch { }
        }
        public DataTable getstatus(string name)
        {
            

                DataTable dtgetstatus = new DataTable();
               
           
            return dtgetstatus = ReportBL.GetUserQuestionnaireStatus(name);
        }
        public void OpenNewWindow()
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('http://www.regsoft.com', 'PopUp',");
                sb.Append("'top=0, left=0, width='+screen.availwidth+', height='+screen.availheight+', menubar=yes,toolbar=yes,status,resizable=yes,addressbar=yes');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void Link1_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "DomainspecificAssessment_nl.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "DomainspecificAssessment_nl.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "DomainspecificAssessment_nl.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void Lnkold_Click(object sender, EventArgs e)
        {
            if (quesName == "Work Activity")
            {
                Response.Redirect("WorkactivityQuestionnaire.aspx?id=" + "Work Activity");
            }
            else
            {
                Response.Redirect("WorkContext.aspx");
            }
        }

        protected void ImgView_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                ImageButton imgbtn = (ImageButton)sender;
                ImageButton obj = (ImageButton)imgbtn.NamingContainer.FindControl("ImgView");
                int AttemptID = Convert.ToInt32(Grid_Report.MasterTableView.DataKeyValues[gr.ItemIndex]["AttemptID"].ToString());
                SessionInfo.AttemptID = AttemptID;
                DataTable dtjobfamilyid = new DataTable();
                JobdomainFA objjobfam = new JobdomainFA();
                dtjobfamilyid = objjobfam.GetJobFamilyID(AttemptID,UserID,questemplate[0]);
                if (dtjobfamilyid.Rows.Count > 0)
                {
                    SessionInfo.JobfamilyIDforjobDomain = dtjobfamilyid.Rows[0]["JobID"].ToString();
                }
                GridDataItem dtitem = Grid_Report.Items[gr.ItemIndex];
                Label Name = (Label)dtitem["Name"].FindControl("Name");
                if (Name.Text.ToString().Trim() == "Work Context Questionnaire")
                {
                    Url = "WorkcontextReport.aspx";
                }
                else if (Name.Text.ToString().Trim() == "Work Style Questionnaire")
                {
                    Url = "WorkStyleReport.aspx";
                }
                else if (Name.Text.ToString().Trim() == "Work Activity Questionnaire")
                {
                    Url = "WorkActivityReport.aspx";
                }
                else
                {
                    Url = "DomainSpecificReport.aspx";
                }
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }

        }
        public void GetReportsStatus()
        {
            try
            {
                DataTable dtst = new DataTable();
                dtst = ReportBL.GetReportsStatus(UserID, this.productid);
               
                Grid_Report.DataSource = dtst;
                Grid_Report.DataBind();
            }
            catch { }
        }
      
       public void getsubmitionofStatus()
        {
            int count = 0;
            DataTable dtgetstatus = new DataTable();

            for (int i = 0; i < questemplate.Length; i++)
            {

                dtgetstatus = ReportBL.GetUserQuestionnaireStatus(questemplate[i]);



                if (dtgetstatus.Rows.Count > 0)
                {
                    string strstatus = dtgetstatus.Rows[0]["Status"].ToString();
                    if (strstatus.Trim() == "Submit")
                    {
                        count++;
                    }
                    if (count == questemplate.Length)
                    {
                        BtnNew.Text = "Start New";
                    }
                    else
                    {
                        BtnNew.Text = "In Progress...";

                    }

                }
                else
                {
                    BtnNew.Text = "Start New";

                }
               
            }

        }
        protected void getExperienceAssessmentPageLanguageInfo()
        {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
            LblMsg.Text = (string)GetGlobalResourceObject("PageResource", "LblMsg_ExperienceAssessmentInfo");
            Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_ExperienceAssessmentInfo");
            //Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingProfile");
            LblAssessmentC.Text = (string)GetGlobalResourceObject("PageResource", "LblAssessmentC_ExperienceAssessmentInfo");
            LblAssessmentDesc.Text = (string)GetGlobalResourceObject("PageResource", "LblAssessmentDesc_ExperienceAssessmentInfo");
            Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_ExperienceAssessmentInfo");
            Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_ExperienceAssessmentInfo");
            Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_ExperienceAssessmentInfo");
            Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_ExperienceAssessmentInfo");
            Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_ExperienceAssessmentInfo");
            LblEss.Text = (string)GetGlobalResourceObject("PageResource", "LblEss_ExperienceAssessmentInfo");
            Link1.Text = (string)GetGlobalResourceObject("PageResource", "Link1_ExperienceAssessmentInfo");
            lblgenral.Text = (string)GetGlobalResourceObject("PageResource", "lblgenral_ExperienceAssessmentInfo");

            //Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_JobPostingProfile");
            SavedRpt.Text = (string)GetGlobalResourceObject("PageResource", "SavedRpt_ExperienceAssessmentInfo");

            BtnNew.Text = (string)GetGlobalResourceObject("PageResource", "BtnNew_ExperienceAssessmentInfo");
            Grid_Report.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "Grid_Report_ExperienceAssessmentInfo1");
            Grid_Report.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "Grid_Report_ExperienceAssessmentInfo2");
            Grid_Report.Columns[2].HeaderText = (string)GetGlobalResourceObject("PageResource", "Grid_Report_ExperienceAssessmentInfo3");

        }
    }
}
