﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;
using System.Text.RegularExpressions;

namespace IRSA
{
    public partial class OrgAccount : System.Web.UI.Page
    {
        string Accountxml = "Irsatooltiporganisation.xml";
        string PhotoDirectoryPath;
        string LogoDirectoryPath;
        //string ResumeDirectoryPath;
        int UserID;
        int OrganisationID;
        string[] Format = { "jpg", "jpeg", "png", "gif", "bmp", "JPG", "JPEG", "PNG", "GIF", "BMP" };

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.DefaultButton = Update.UniqueID;
            UserID = SessionInfo.UserId;
            OrganisationID = SessionInfo.OrganisationID;
            //UserID = SessionInfo.UserId;


            LogoDirectoryPath = ConfigurationSettings.AppSettings["CompanyLogo"];

            if (!IsPostBack)
            {
                FillIndustry();

                XmlCountry();
                RetreiveData();
            }
           
            GetiRsaToolTipOrgMsg();

            //if (OrganisationID != int.MinValue)
            //{
            //    OrgAccountFA objaccFA = new OrgAccountFA();
            //    DataTable objdt = new DataTable();
            //    objdt = objaccFA.RetrievePriContactData(UserID, OrganisationID, true);
            //    Lblmember.Text = objdt.Rows[0]["FullName"].ToString() + " " + "!";
            //    SessionInfo.FirstName = objdt.Rows[0]["FullName"].ToString();
            //}
            //else
            //{
            //    Response.Redirect("Login.aspx");
            //}
            // Getdata();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }  
        }
        private void GetiRsaToolTipOrgMsg()
        {
            try
            {
                txthqadd.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, Accountxml);
                txtstocksymbol.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, Accountxml);
                RadEditorgoals.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(11, Accountxml);
                RadEditorCompanyDesc.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(10, Accountxml);
                Txtwebsite.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);
                Ddncompsize.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(8, Accountxml);
                Ddntype.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                txtcity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(16, Accountxml);
                Image2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(4, Accountxml);
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(21, Accountxml);
                RadNumericfounded.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(7, Accountxml);
                txtorgname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, Accountxml);
                
            }
            catch { }
        }
        public void RetreiveData()
        {
            try
            {
                OrgAccountFA objorgFA = new OrgAccountFA();
                DataTable objdt = new DataTable();
                objdt = objorgFA.RetrieveOrganisationData(UserID, OrganisationID);
                if (objdt.Rows.Count > 0)
                {
                    txtorgname.Text = objdt.Rows[0]["Name"].ToString();
                    txthqadd.Text = objdt.Rows[0]["HeadQuarterAddress"].ToString();
                    Txtwebsite.Text = objdt.Rows[0]["Website"].ToString();
                    txtstocksymbol.Text = objdt.Rows[0]["StockSymbol"].ToString();
                    RadNumericfounded.Text = objdt.Rows[0]["Founded"].ToString();
                    Ddncompsize.SelectedValue = objdt.Rows[0]["Size"].ToString().Trim();
                    //Ddnstatus.SelectedValue = objdt.Rows[0]["Status"].ToString();
                    txtcity.Text = objdt.Rows[0]["City"].ToString();
                    RadComboCountry.SelectedValue = objdt.Rows[0]["Country"].ToString();
                    RadComboIndustry.SelectedValue = objdt.Rows[0]["IndustryID"].ToString();

                    Ddntype.SelectedValue = objdt.Rows[0]["Type"].ToString().Trim();
                    RadEditorCompanyDesc.Content = objdt.Rows[0]["Description"].ToString();
                    RadEditorgoals.Content = objdt.Rows[0]["GoalsAndValues"].ToString();
                    txtstocksymbol.Text = objdt.Rows[0]["StockSymbol"].ToString();
                    //string file = objdt.Rows[0]["LogoPath"].ToString();
                    //if (file != "")
                    //{
                    //    Image2.Visible = true;
                    //    Image2.ImageUrl = LogoDirectoryPath + file;
                    //}
                    string file = objdt.Rows[0]["LogoPath"].ToString();
                    string approved = objdt.Rows[0]["LogoApproval"].ToString();
                    if (file != "")
                    {
                        if (approved == "1")
                        {
                            Image2.Visible = true;
                            Image2.ImageUrl = LogoDirectoryPath + file;
                        }
                        else
                        {
                            Image2.Visible = true;
                            Image2.ImageUrl = LogoDirectoryPath + "0.png";

                        }
                    }
                    else
                    {
                        Image2.Visible = true;
                        Image2.ImageUrl = LogoDirectoryPath + "0.png";

                        //Image1.ImageUrl = PhotoDirectoryPath + "DefaultImage.Png";
                    }

                }
            }
            catch { }
        }
        public void SaveData(int UserID)
        {
            try
            {
                string str;

                str = DateTime.Today.Year.ToString();
                //if (CurrentWizardStep == "Welcome")
                //{
                //string Professionaltitle;
                //Professionaltitle = Txtprotitle.Text;
                OrgAccountSH objoraccSH = new OrgAccountSH();
                objoraccSH.Name = txtorgname.Text;
                //objoraccSH.HeadQuarterAddress = txthqadd.Text;
                if (txthqadd.Text != "")
                {
                    if (Validation.IsValidAddress(txthqadd.Text))
                    {
                        objoraccSH.HeadQuarterAddress = UCFirst(txthqadd.Text);

                    }
                    else
                    {
                        Lblerr.Visible = true;
                        Lblerr.Text = "Incorrect Title";
                        goto Last;
                    }
                }

                objoraccSH.City = UCFirst(txtcity.Text);
                objoraccSH.Country = RadComboCountry.SelectedValue;
                objoraccSH.IndustryName = RadComboIndustry.Text;
                objoraccSH.Type = Ddntype.SelectedValue;
                //objoraccSH.Status = Ddnstatus.SelectedValue;
                objoraccSH.Size = Ddncompsize.SelectedValue;
                objoraccSH.Founded = UCFirst(RadNumericfounded.Text);
                if (RadNumericfounded.Text != "")
                {
                    if (Convert.ToInt32(RadNumericfounded.Text) <= Convert.ToInt32(str))
                    {

                        objoraccSH.Founded = RadNumericfounded.Text;

                    }
                    else
                    {
                        //lblerr1.Visible = true;
                        //lblerr1.Text = "Invalid Year";
                        goto Last;
                    }
                }

                //objoraccSH.Website = Txtwebsite.Text;
                if (Txtwebsite.Text != "")
                {
                    if (Validation.IsValidInternetURL(Txtwebsite.Text))
                    {
                        objoraccSH.Website = (Txtwebsite.Text);

                    }
                    else
                    {
                        Lbler.Visible = true;
                        Lbler.Text = "Incorrect WebSite URL";
                        goto Last;
                    }
                }
                else
                {
                    Lbler.Visible = true;
                    Lbler.Text = "Please Enter Website URL!";
                    goto Last;
                }
                objoraccSH.Description = UCFirst(RadEditorCompanyDesc.Text);
                objoraccSH.GoalsAndValues = UCFirst(RadEditorgoals.Text);
                objoraccSH.StockSymbol = (txtstocksymbol.Text).ToUpper();



                //     Regex imageFilenameRegex = new Regex(@"(.*?)\.(jpg|jpeg|png|gif|bmp|JPG|JPEG|PNG|GIF|BMP)$");

                string file = FileUpload1.PostedFile.FileName;
                if (file != "")
                {

                    for (int i = 0; i < Format.Length; i++)
                    {
                        string var = LogoDirectoryPath + OrganisationID + "." + Format[i];
                        FileInfo fiPath = new FileInfo(Server.MapPath(var));
                        if (fiPath.Exists)
                        {
                            //Delete the file from sever
                            File.Delete(Server.MapPath(var));
                        }
                    }
                    //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                    string strLogo = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                    FileUpload1.SaveAs(Server.MapPath(LogoDirectoryPath + OrganisationID + "." + strLogo));
                    HttpPostedFile myFile = FileUpload1.PostedFile;
                    int nFileLen = myFile.ContentLength;
                    if (nFileLen > 0)
                    {
                        IRSA.Common.GlobalFunction.ResizeImage objImage = new IRSA.Common.GlobalFunction.ResizeImage();
                        objImage.ResizeFromStream(Server.MapPath(LogoDirectoryPath + OrganisationID + "." + strLogo), 100, myFile.InputStream);
                    }


                    string LogoPath = UserID + "." + strLogo;
                    objoraccSH.LogoPath = LogoPath;


                }
                else
                {
                    OrgAccountFA objorgFA = new OrgAccountFA();
                    DataTable dtlogo = new DataTable();
                    dtlogo = objorgFA.RetrieveOrganisationData(UserID, OrganisationID);
                    if (dtlogo.Rows.Count > 0)
                    {
                        objoraccSH.Photo = dtlogo.Rows[0]["LogoPath"].ToString();
                    }
                    else
                    {
                        objoraccSH.Photo = "0.png";
                    }
                }


                OrgAccountFA objaccFA = new OrgAccountFA();
                objaccFA.InsertOrganisationData(objoraccSH, UserID, OrganisationID);

                                //objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep);

                                //Getdata();
            Last: ;
            }
            catch { }
        }
        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(Server.MapPath(OriginalFile));

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                //Now check if file exist on server or not
                for (int i = 0; i < Format.Length; i++)
                {
                    string var = LogoDirectoryPath + OrganisationID + "." + Format[i];
                    FileInfo fiPath = new FileInfo(Server.MapPath(var));
                    if (fiPath.Exists)
                    {
                        //Delete the file from sever
                        File.Delete(Server.MapPath(var));
                    }
                }
                NewImage.Save(Server.MapPath(NewFile));

            }
            catch
            {
            }
        }
        public void FillIndustry()
        {
            try
            {
                IRSA.Facade.AccountsetupFA Indus = new IRSA.Facade.AccountsetupFA();

                DataTable temp = new DataTable();
                temp = Indus.GetIndustryData();
                RadComboIndustry.DataValueField = "IndustryID";
                RadComboIndustry.DataTextField = "IndustryName";

                RadComboIndustry.DataSource = temp;
                RadComboIndustry.DataBind();
            }
            catch { }

        }

       

        public void XmlCountry()
        {
            try
            {

                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                RadComboCountry.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch { }





        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SaveData(UserID);
            RetreiveData();

           


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                txthqadd.Text = "";
                Txtwebsite.Text = "";
                txtstocksymbol.Text = "";
                RadNumericfounded.Text = "";
                Ddncompsize.SelectedIndex = 0;
                //Ddnstatus.SelectedIndex = 0;
                txtcity.Text = "";
                RadComboCountry.SelectedValue = "";
                RadComboIndustry.SelectedValue = "";
                Ddntype.SelectedIndex = 0;
                RadEditorCompanyDesc.Content = "";
                RadEditorgoals.Content = "";
                txtstocksymbol.Text = "";
            }
            catch { }
        }

        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
             if (strName.Length>0)
            {

                try
                {

                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);

                }
                catch (System.Exception ex)
                {
                    ErrorLog.Logging(ex, true);
                    Response.Redirect("Login.aspx");
                }

            }
            return sb.ToString();
        }
        string Logopath;
        protected void Upload_Click(object sender, EventArgs e)
        {
            try
            {
                AccountsetupSH objaccSH = new AccountsetupSH();
                string file = FileUpload1.FileName;
                if (file != "")
                {
                    for (int i = 0; i < Format.Length; i++)
                    {
                        string var = LogoDirectoryPath + OrganisationID + "." + Format[i];
                        FileInfo fiPath = new FileInfo(Server.MapPath(var));
                        if (fiPath.Exists)
                        {
                            //Delete the file from sever
                            File.Delete(Server.MapPath(var));
                        }
                    }
                    //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                    string strLogo = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                    FileUpload1.SaveAs(Server.MapPath(LogoDirectoryPath + OrganisationID + "." + strLogo));
                    HttpPostedFile myFile = FileUpload1.PostedFile;
                    int nFileLen = myFile.ContentLength;
                    if (nFileLen > 0)
                    {
                        IRSA.Common.GlobalFunction.ResizeImage objImage = new IRSA.Common.GlobalFunction.ResizeImage();
                        objImage.ResizeFromStream(Server.MapPath(LogoDirectoryPath + OrganisationID + "." + strLogo), 100, myFile.InputStream);
                    }

                    Logopath = OrganisationID + "." + strLogo;



                }
                else
                {
                    OrgAccountFA objorgFA = new OrgAccountFA();
                    DataTable dtlogo = new DataTable();
                    dtlogo = objorgFA.RetrieveOrganisationData(UserID, OrganisationID);
                    if (dtlogo.Rows.Count > 0)
                    {
                        Logopath = dtlogo.Rows[0]["LogoPath"].ToString();
                    }
                    else
                    {
                        Logopath = "0.png";
                    }
                }

                OrgAccountFA objorgsFA = new OrgAccountFA();
                objorgsFA.insertLogo(Logopath, OrganisationID);
                //objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                RetreiveData();
                //Getdata();

            }
            catch { }


        }

        protected void Update_Click(object sender, EventArgs e)
        {
            SaveData(UserID);
        }

       


    }
}


