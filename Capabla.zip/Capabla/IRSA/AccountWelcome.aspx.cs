﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;          
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class AccountWelcome : System.Web.UI.Page
    {
        string PhotoDirectoryPath;
        string ResumeDirectoryPath;
        int UserID;
        string firstdisplay;
        string strfirstname;
        string OriginalFile;
        string NewFile;
        int NewWidth;
        int MaxHeight;
        bool OnlyResizeIfWider;
        string file;
        string str2;
        string CULINFO;
        string CultureID1;
        string AppName;
        string[] Format = { "jpg", "jpeg", "png", "gif", "bmp", "JPG", "JPEG", "PNG", "GIF", "BMP" };
        string Accountxml = "irsatooltipaccount.xml";
        string  CurrentWizardStep = "Welcome";
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountWelcomePageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            Page.Form.DefaultButton = Btnupdate.UniqueID;
            PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];
            Lbldatamodified.Visible = false;
            UserID =SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
              if (!IsPostBack)
             {
                 Lbldatamodified.Visible = false;
                string str = Request.QueryString.Get("id");
               
                int id = Convert.ToInt32(str);
                if (str != null)
                {

                    str = Request.QueryString.Get("id");
                    
                }
              
                 XmlIndustry();
                //FillIndustry();

                XmlCountry();
               
                
                Getdata();
              
              }
              GetiRsaToolTipAccMsg();
              if (UserID != int.MinValue)
              {
                  AccountsetupFA objaccFA = new AccountsetupFA();
                  DataTable objdt = new DataTable();
                  objdt = objaccFA.GetaccountData(UserID);
                  if (objdt.Rows[0]["DisplayName"].ToString() != "")
                  {
                      Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                      SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                  }
                  else
                  {
                      Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                      SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                  }
             
              }
              else
              {
                  Response.Redirect("Login.aspx");
              }
       

}


        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {
                    string approved = objdt.Rows[0]["PhotoApproved"].ToString();
                    string file = objdt.Rows[0]["PhotoID"].ToString();
                    if (file != "0.png")
                    {
                        if (approved == "1")
                        {
                            Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(78, Accountxml); 
                        }
                        else
                        {
                            Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(78, Accountxml);
                        }
                    }
                    else
                    {
                        Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(78, Accountxml);
                        
                    }
                }
                Txtprotitle.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(18, Accountxml);
                TxtFirstName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, Accountxml);
                TxtLastName.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, Accountxml);
                Radbtndisplay.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(12, Accountxml);
                Radbtnsex.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(13, Accountxml);
                RadBtnms.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(14, Accountxml);
                RadBtnDL.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(16, Accountxml);
                Image2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(20, Accountxml);
                Image4.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(19, Accountxml);
                Image5.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);
                Txtpostal.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                Txtstate.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(21, Accountxml);
                Txtcity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(15, Accountxml);
                //Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(17, Accountxml);
                TxtHN.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(72, Accountxml);
             //   Txtpob.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(71, Accountxml);
                Image6.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(69, Accountxml);
                Image7.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(70, Accountxml);
                //FileUpload1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(77, Accountxml);
                txtothersunarea.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(80, Accountxml);
            }

            catch { }
        }


     
        private void XmlCountry()
        {
            try
            {


                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                if (CultureID1 == "EN")
                {
                    strExp = "/root/English";
                }
                else if (CultureID1 == "NL")
                {
                    strExp = "/root/Dutch";
                }
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                RadCombocountry.LoadXml(NodeIter1.Current.InnerXml);
                RadCombonationality.LoadXml(NodeIter1.Current.InnerXml);
                RadComboplbirth.LoadXml(NodeIter1.Current.InnerXml);


            }
            catch
            {

            }

        }
        string strExp;
        private void XmlIndustry()
        {

            try
            {


                XPathNavigator nvg4;
                XPathDocument docNvg4;
                XPathNodeIterator NdIter4;
                docNvg4 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Industry.xml"));
                nvg4 = docNvg4.CreateNavigator();
                if (CultureID1 == "EN")
                {
                    strExp = "/root/English";
                }
                else if (CultureID1 == "NL")
                {
                    strExp = "/root/Dutch";
                }
                NdIter4 = nvg4.Select(strExp);
                NdIter4.MoveNext();
                RadComboIndustry.LoadXml(NdIter4.Current.InnerXml);

            }
            catch(System.Exception  ex)
            {
                ErrorLog.Logging(ex,true);
                Response.Redirect("Login.aspx");
            }

        }

        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                 if (objdt.Rows.Count > 0)
                    {
                        TxtFirstName.Text = objdt.Rows[0]["FirstName"].ToString();
                        string strfirstname = TxtFirstName.Text;
                        TxtLastName.Text = objdt.Rows[0]["LastName"].ToString();
                        string strlastname = TxtLastName.Text;
                        Txtprotitle.Text = objdt.Rows[0]["ProfessionalTitle"].ToString();
                        Txtpostal.Text = objdt.Rows[0]["PostalCode"].ToString();
                        Txtstate.Text = objdt.Rows[0]["State"].ToString();
                        if (objdt.Rows[0]["Phone"].ToString() != "-2147483648" || objdt.Rows[0]["Phone"].ToString() != "0")
                        {
                            Txtphone.Text = objdt.Rows[0]["Phone"].ToString();
                        }

                        Txtcity.Text = objdt.Rows[0]["City"].ToString();
                       

                        if (objdt.Rows[0]["DateOfBirth"].ToString() != "")
                        {
                            RadDob.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["DateOfBirth"].ToString());

                        }
                        RadCombocountry.SelectedValue = objdt.Rows[0]["Country"].ToString();
                        if (objdt.Rows[0]["Sex"].ToString() != "")
                        {
                            Radbtnsex.SelectedValue = objdt.Rows[0]["Sex"].ToString();
                        }
                        if (objdt.Rows[0]["IndustryID"].ToString() != "")
                        {
                            RadComboIndustry.SelectedIndex = (Convert.ToInt32(objdt.Rows[0]["IndustryID"].ToString()));
                            if (RadComboIndustry.SelectedIndex == 22)
                            {
                                Panelothers.Visible = true;

                            }
                        }
                        if (objdt.Rows[0]["OthersIndustry"].ToString() != "")
                        {
                            txtothersunarea.Text = objdt.Rows[0]["OthersIndustry"].ToString();
                        }
                        if (objdt.Rows[0]["MaritalStatus"].ToString() != "")
                        {
                            RadBtnms.SelectedValue = objdt.Rows[0]["MaritalStatus"].ToString();
                        }
                        if (objdt.Rows[0]["DrivingLicence"].ToString() != "")
                        {
                            RadBtnDL.SelectedValue = objdt.Rows[0]["DrivingLicence"].ToString();
                        }

                        TxtHN.Text = objdt.Rows[0]["HouseNo"].ToString();
                        //Txtpob.Text = objdt.Rows[0]["PlaceofBirth"].ToString();
                        RadCombonationality.SelectedValue = objdt.Rows[0]["Nationality"].ToString();
                        RadComboplbirth.SelectedValue = objdt.Rows[0]["CountryofBirth"].ToString();
                         
                        string display = strfirstname.Remove(1);
                        string firstdisplay = display + "." + strlastname;
                        Display1.Text = firstdisplay;
                        Display2.Text = strfirstname;
                        //lblmem.Text = firstdisplay + "!";

                        //lblmem.Text = objdt.Rows[0]["DisplayName"].ToString();
                        string displayname = objdt.Rows[0]["DisplayName"].ToString().Trim();

                        if (Display1.Text.Trim() == displayname)
                        {
                            Radbtndisplay.Items.FindByValue(Display1.Text).Selected = true;
                        }
                        else
                        {
                            Radbtndisplay.Items.FindByValue(Display2.Text).Selected = true;
                        }
                        string file = objdt.Rows[0]["PhotoID"].ToString();
                        string approved = objdt.Rows[0]["PhotoApproved"].ToString();
                        if (file != "")
                        {
                            
                                Image1.Visible = true;
                                Image1.ImageUrl = PhotoDirectoryPath + file;
                         
                        }
                        else
                        {
                            Image1.Visible = true;
                            Image1.ImageUrl = PhotoDirectoryPath + "0.png";
                            
                        }
                        if (objdt.Rows[0]["DrivingLicence"].ToString() != "")
                        {
                            RadBtnDL.SelectedValue = objdt.Rows[0]["DrivingLicence"].ToString();
                        }
                        if (objdt.Rows[0]["MaritalStatus"].ToString() != "")
                        {
                            RadBtnms.SelectedValue = objdt.Rows[0]["MaritalStatus"].ToString();
                        }

                   
                } 
            }
            catch { }
        }
        public void savedata()
        {
            
            try
            {
                CULINFO = "en-GB";
                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                AccountsetupFA objaccFA = new AccountsetupFA();
                AccountsetupSH objaccSH = new AccountsetupSH();
               
                if (TxtFirstName.Text != "")
                {
                    objaccSH.FirstName = UCFirst(TxtFirstName.Text);
                }
                else 
                {
                    Lblerr.Visible = true;
                    Lblerr.Text = "*";
                    goto Last;
                }
                objaccSH.LastName = UCFirst(TxtLastName.Text);
                if (Txtprotitle.Text != "")
                {
                     objaccSH.Professionaltitle = UCFirst(Txtprotitle.Text);

                    
                }
                else
                {
                    Lblerr.Visible = true;
                    Lblerr.Text =IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(61);
                    goto Last;
                }
                if (Txtphone.Text != "")
                {
                    //objaccSH.Phone = Convert.ToInt32(Txtphone.Text);
                    objaccSH.Phone = Txtphone.Text;
                }
                objaccSH.City = UCFirst(Txtcity.Text);
                objaccSH.State = UCFirst(Txtstate.Text);
                if (RadDob.SelectedDate != null)
                {
                    int str = RadDob.SelectedDate.Value.Year;
                    int str1 = System.DateTime.Today.Year - 10;
                    if (str1 >= str)
                    {
                        objaccSH.dateofbirth = RadDob.SelectedDate.Value.ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        lbldoberr.Visible = true;
                        lbldoberr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(78);
                        goto Last;

                    }


                }
                else
                {
                    lbldoberr.Visible = true;
                    lbldoberr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(79);

                }

                objaccSH.sex = Radbtnsex.SelectedValue;
                objaccSH.Country = RadCombocountry.SelectedValue;
                if (RadComboIndustry.SelectedValue == "Others")
                {
                    objaccSH.OtherIndustry = txtothersunarea.Text;
                    objaccSH.Functionalarea = RadComboIndustry.SelectedValue;
                }
                else
                {
                    objaccSH.Functionalarea = RadComboIndustry.SelectedValue;
                }
                objaccSH.Postalcode = UCFirst(Txtpostal.Text);
                string strfirstname = TxtFirstName.Text;
                string strlastname = TxtLastName.Text;
                string display = strfirstname.Remove(1);
                string firstdisplay = display + "." + strlastname;
                Display1.Text = firstdisplay;
                Display2.Text = strfirstname;
                if (Display1.Selected)
                {
                    objaccSH.DisplayName = firstdisplay.Trim();
                }
                else if (Display2.Selected)
                {
                    objaccSH.DisplayName = strfirstname;
                }
                
                objaccSH.MaritalStatus = RadBtnms.SelectedValue;
                if (RadBtnDL.SelectedValue.ToString() != "")
                {
                    
                    objaccSH.DrivingLicence = Convert.ToBoolean(RadBtnDL.SelectedValue.ToString());
                }
                objaccSH.HouseNo = UCFirst(TxtHN.Text);
                //objaccSH.Placeofbirth = Txtpob.Text;
                objaccSH.Countryofbirth = RadComboplbirth.SelectedValue;
                objaccSH.Nationality = RadCombonationality.SelectedValue;
                //file = FileUpload1.FileName;
                //if (file != "")
                //{


                //    for (int j = 0; j < Format.Length; j++)
                //    {
                //        string var = PhotoDirectoryPath + UserID + "." + Format[j];
                //        FileInfo fiPath = new FileInfo(Server.MapPath(var));
                //        if (fiPath.Exists)
                //        {
                //            //Delete the file from sever
                //            File.Delete(Server.MapPath(var));
                //        }
                //    }
                //    //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                //    string strphoto = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                //    FileUpload1.SaveAs(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto));
                //    HttpPostedFile myFile = FileUpload1.PostedFile;
                //    int nFileLen = myFile.ContentLength;
                //    if (nFileLen > 0)
                //    {
                //        IRSA.Common.GlobalFunction.ResizeImage objImage = new IRSA.Common.GlobalFunction.ResizeImage();
                //        objImage.ResizeFromStream(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto), 100, myFile.InputStream);
                //    }


                //    string Photo = UserID + "." + strphoto;
                //    objaccSH.Photo = Photo;
                //    //objaccFA.insertphoto(Photo, UserID);
                //    //objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);

                //    //Getdata();
                //}
                //else
                //{

                //    DataTable dtphoto = new DataTable();
                //    dtphoto = objaccFA.GetaccountData(UserID);
                //    if (dtphoto.Rows.Count > 0)
                //    {
                //        objaccSH.Photo = dtphoto.Rows[0]["PhotoID"].ToString();
                //    }
                //    else
                //    {
                //        objaccSH.Photo = "0.png";
                //    }
                //}
                

                #region Profile Progressbar
                // string path = "~/App_Themes/Site/images/";
                int i = 0;
                if (Txtprotitle.Text != "")
                {
                    i++;
                }
                if (TxtFirstName.Text != "")
                {
                    i++;
                }
                if (TxtLastName.Text != "")
                {
                    i++;
                }
                if (Txtcity.Text != "")
                {
                    i++;
                }
                if (Txtpostal.Text != "")
                {
                    i++;
                }
                if (Txtstate.Text != "")
                {
                    i++;
                }
                if (TxtHN.Text != "")
                {
                    i++;
                }
                //if (Txtpob.Text != "")
                //{
                //    i++;
                //}
                if (Txtphone.Text != "")
                {
                    i++;
                }
                if (RadComboIndustry.SelectedIndex != 0)
                {
                    i++;
                }
                if (RadCombocountry.SelectedIndex != 0)
                {
                    i++;
                }
                if (RadCombonationality.SelectedIndex != 0)
                {
                    i++;
                }
                if (RadComboplbirth.SelectedIndex != 0)
                {
                    i++;
                }
                if (Radbtndisplay.SelectedValue != "")
                {
                    i++;
                }
                if (Radbtnsex.SelectedValue != "")
                {
                    i++;
                }
                if (RadBtnms.SelectedValue != "")
                {
                    i++;
                }
                if (RadBtnDL.SelectedValue != "")
                {
                    i++;
                }
                //if (RadDob.SelectedDate!= (Convert.ToDateTime("")))
                //{
                //    i++;
                //}

                int AccountWelcome = i * 100 / 16;
                int Experience = 0, Acadimic = 0, PastCompany = 0, PresentCompany = 0, Projects = 0;
                lbldoberr.Visible = false;
                Lblerr.Visible = false;
                objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
               
                Getdata();

                #endregion


            Last: ;
            }



            catch { }
        }
       
        protected void Button1_Click(object sender, EventArgs e)
        {
            savedata();
            Response.Redirect("AccountAcademics.aspx");
        }

        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(Server.MapPath(OriginalFile));

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                //Now check if file exist on server or not

               

                NewImage.Save(Server.MapPath(NewFile));
            }
            catch
            {
            }
        }
      

        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {
                if (strName.Length > 0)
                {
                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);
                }
            }
            catch { }
            return sb.ToString();
        }

        protected void Btnupdate_Click(object sender, EventArgs e)
        {
            savedata();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            
            Getdata();
            


        }
        string Photo;
       
        //protected void Upload_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        AccountsetupFA objaccFA = new AccountsetupFA();
        //        AccountsetupSH objaccSH = new AccountsetupSH();
        //        file = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
        //        if (file != "")
        //        {
        //            for (int i = 0; i < Format.Length; i++)
        //            {
        //                string var = PhotoDirectoryPath + UserID + "." + Format[i];
        //                FileInfo fiPath = new FileInfo(Server.MapPath(var));
        //                if (fiPath.Exists)
        //                {
        //                    //Delete the file from sever
        //                    File.Delete(Server.MapPath(var));
        //                }
        //            }
        //            //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
        //            string strphoto = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
        //            FileUpload1.SaveAs(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto));
        //            HttpPostedFile myFile = FileUpload1.PostedFile;
        //            int nFileLen = myFile.ContentLength;
        //            if (nFileLen > 0)
        //            {
        //                IRSA.Common.GlobalFunction.ResizeImage objImage = new IRSA.Common.GlobalFunction.ResizeImage();
        //                objImage.ResizeFromStream(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto), 100, myFile.InputStream);
        //            }

        //            Photo = UserID + "." + strphoto;

        //        }
        //        else
        //        {

        //            DataTable dtphoto = new DataTable();
        //            dtphoto = objaccFA.GetaccountData(UserID);
        //            if (dtphoto.Rows.Count > 0)
        //            {
        //                Photo = dtphoto.Rows[0]["PhotoID"].ToString();
        //            }
        //            else
        //            {
        //                Photo = "0.png";
        //            }


        //        }


        //        objaccFA.insertphoto(Photo, UserID);
        //        Lbldatamodified.Visible = true;
        //        Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(70);
        //        Image1.Visible = true;
        //        Image1.ImageUrl = PhotoDirectoryPath + Photo;
           
        //}
        //catch{}


        //}

        protected void DdnIndustry_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {
                string Str = RadComboIndustry.Text;
                int strln = Str.Length;
                Str = Str.Substring(0, 6);
                if (Str == "Others")
                {

                    Panelothers.Visible = true;
                }
                else
                {
                    Panelothers.Visible = false;
                }
            }
            catch { }
        }

        

        protected void btnnxt_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountAcademics.aspx");
        }
        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }



        protected void Buttonup_Click(object sender, EventArgs e)
        {
            try
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                AccountsetupSH objaccSH = new AccountsetupSH();
                file = System.IO.Path.GetFileName(FileUpload2.PostedFile.FileName);
                if (file != "")
                {
                    for (int i = 0; i < Format.Length; i++)
                    {
                        string var = PhotoDirectoryPath + UserID + "." + Format[i];
                        FileInfo fiPath = new FileInfo(Server.MapPath(var));
                        if (fiPath.Exists)
                        {
                            //Delete the file from sever
                            File.Delete(Server.MapPath(var));
                        }
                    }
                    //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                    string strphoto = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                    FileUpload2.SaveAs(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto));
                    HttpPostedFile myFile = FileUpload2.PostedFile;
                    int nFileLen = myFile.ContentLength;
                    if (nFileLen > 0)
                    {
                        IRSA.Common.GlobalFunction.ResizeImage objImage = new IRSA.Common.GlobalFunction.ResizeImage();
                        objImage.ResizeFromStream(Server.MapPath(PhotoDirectoryPath + UserID + "." + strphoto), 100, myFile.InputStream);
                    }

                    Photo = UserID + "." + strphoto;

                }
                else
                {

                    DataTable dtphoto = new DataTable();
                    dtphoto = objaccFA.GetaccountData(UserID);
                    if (dtphoto.Rows.Count > 0)
                    {
                        Photo = dtphoto.Rows[0]["PhotoID"].ToString();
                    }
                    else
                    {
                        Photo = "0.png";
                    }


                }


                objaccFA.insertphoto(Photo, UserID);
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(70);
                Image1.Visible = true;
                Image1.ImageUrl = PhotoDirectoryPath + Photo;

            }
            catch { }

        }

        protected void linkbtnremove_Click(object sender, EventArgs e)
        {
            AccountsetupFA objaccFA = new AccountsetupFA();
            AccountsetupSH objaccSH = new AccountsetupSH();
            objaccFA.updatephoto(UserID);
            for (int i = 0; i < Format.Length; i++)
            {
                string var = PhotoDirectoryPath + UserID + "." + Format[i];
                FileInfo fiPath = new FileInfo(Server.MapPath(var));
                if (fiPath.Exists)
                {
                    //Delete the file from sever
                    File.Delete(Server.MapPath(var));
                }
            }
            Image1.Visible = true;
            Image1.ImageUrl = PhotoDirectoryPath + "0.png";
        }


        protected void getAccountWelcomePageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountWelcome");
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "Label25_AccountWelcome");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label13_AccountWelcome");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label14_AccountWelcome");
                Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountWelcome");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_AccountWelcome");
                Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_AccountWelcome");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_AccountWelcome");
                //Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_AccountWelcome");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_AccountWelcome");
                Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_AccountWelcome");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_AccountWelcome");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_AccountWelcome");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_AccountWelcome");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_AccountWelcome");
                Label17.Text = (string)GetGlobalResourceObject("PageResource", "Label17_AccountWelcome");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_AccountWelcome");
                Label20.Text = (string)GetGlobalResourceObject("PageResource", "Label20_AccountWelcome");
                Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_AccountWelcome");
                Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label18_AccountWelcome");
                btnnxt.Text = (string)GetGlobalResourceObject("PageResource", "btnnxt_AccountWelcome");
                Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_AccountWelcome");
                Label22.Text = (string)GetGlobalResourceObject("PageResource", "Label22_AccountWelcome");
                //btnupdate.Text = (string)GetGlobalResourceObject("PageResource", "btnupdate_JobPostingProfile");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountWelcome");
                //RadioBtndl.Items[0].Text = (string)GetGlobalResourceObject("PageResource", "RadioBtndl1_Jobprofile");
                //RadioBtndl.Items[1].Text = (string)GetGlobalResourceObject("PageResource", "RadioBtndl2_Jobprofile");
                Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountWelcome");
                btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountWelcome");
                Btnupdate.Text = (string)GetGlobalResourceObject("PageResource", "Btnupdate_AccountWelcome");
                btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountWelcome");
                Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccountWelcome");
                Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccountWelcome");
                Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccountWelcome");
                Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccountWelcome");
                Button7.Text = (string)GetGlobalResourceObject("PageResource", "Button7_AccountWelcome");
                Button8.Text = (string)GetGlobalResourceObject("PageResource", "Button8_AccountWelcome");
                Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_AccountWelcome");
                Male.Text = (string)GetGlobalResourceObject("PageResource", "Male_AccountWelcome");
                RegularExpressionValidator5.Text = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator5_AccountWelcome");
                Ma.Text = (string)GetGlobalResourceObject("PageResource", "Ma_AccountWelcome");
                yes.Text = (string)GetGlobalResourceObject("PageResource", "yes_AccountWelcome");
                Button1.Text = (string)GetGlobalResourceObject("PageResource", "Upload_AccountWelcome");
                Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountWelcome");
                Fe.Text = (string)GetGlobalResourceObject("PageResource", "Fe_AccountWelcome");
                Female.Text = (string)GetGlobalResourceObject("PageResource", "Female_AccountWelcome");
                Label26.Text = (string)GetGlobalResourceObject("PageResource", "Label26_AccountWelcome");
                Label27.Text = (string)GetGlobalResourceObject("PageResource", "Label27_AccountWelcome");
                lnlk1.Text = (string)GetGlobalResourceObject("PageResource", "lnlk1_AccountWelcome");
                //Label23.Text = (string)GetGlobalResourceObject("PageResource", "Label23_AccountWelcome");
                no.Text = (string)GetGlobalResourceObject("PageResource", "no_AccountWelcome");
                Label19.Text = (string)GetGlobalResourceObject("PageResource", "Label19_AccountWelcome");
                RegularExpressionValidator2.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator2_AccountWelcome");
                RegularExpressionValidator5.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator5_AccountWelcome");
                RegularExpressionValidator3.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator5_AccountWelcome");
                emailValidator.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "emailValidator_AccountWelcome");
                RegularExpressionValidator4.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator4_AccountWelcome");
                RegularExpressionValidator6.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator6_AccountWelcome");
                Requiredfieldvalidator4.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "Requiredfieldvalidator4_AccountWelcome");
                Requiredfieldvalidator1.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "Requiredfieldvalidator1_AccountWelcome");
                linkbtnchg.Text = (string)GetGlobalResourceObject("PageResource", "linkbtnchg_AccountWelcome");
                linkbtnremove.Text = (string)GetGlobalResourceObject("PageResource", "linkbtnremove_AccountWelcome");
                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label9_AccountWelcome");
                //Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_AccountWelcome");
                Label23.Text = (string)GetGlobalResourceObject("PageResource", "Label10_AccountWelcome");
                Lblmember.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
                    
            }
            catch
            {
            }
        
        }

      

     
       


    }
}
