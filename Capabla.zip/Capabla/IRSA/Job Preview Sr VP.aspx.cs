﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;

namespace IRSA
{
    public partial class Job_Preview_Sr_VP : System.Web.UI.Page
    {
        int JobID;
        string CurrentJobRoleType;
        string str2 = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            string Job = Request.QueryString.Get("ID");
            if (Job != null)
            {
                JobID = Convert.ToInt32(Job);


            }
            if(!IsPostBack)
            {
            GetCompanyinfo();
            GetJobInfo();
            GetJobProfiles();
            GetJobQuestionnaire();
            }
           
        }
        protected void GetCompanyinfo()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJob(JobID);
                if (dt.Rows.Count > 0)
                {
                    lblCompanyName.Text = dt.Rows[0]["Name"].ToString();
                    lblCompanyDesc.Text = dt.Rows[0]["Description"].ToString();
                    lnkCompanyWebsite.Text = dt.Rows[0]["Website"].ToString();
                    lblCompanyCapacity.Text = dt.Rows[0]["Size"].ToString();
                    lblJobLocationTxt.Text = dt.Rows[0]["JobLocation"].ToString();
                    lblPostDateTxt.Text = dt.Rows[0]["PostingDate"].ToString();
                    lblExpirationDateTxt.Text = dt.Rows[0]["ExpirationDate"].ToString();
                   

                }
            }
            catch
            { }
        }
        protected void GetJobInfo()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobInfo(JobID);
                if (dt.Rows.Count > 0)
                {
                    lblHeadTextLal.Text = dt.Rows[0]["Expr1"].ToString();
                    lblJobTitleInfo.Text = dt.Rows[0]["Expr1"].ToString();
                    LblRef.Text = dt.Rows[0]["JobCodeRef"].ToString();
                    lblPayRangeFrom.Text = dt.Rows[0]["PayRangeTo"].ToString();
                    lblPayRangeTo.Text = dt.Rows[0]["PayRangefrom"].ToString();
                    lblCurrency.Text = dt.Rows[0]["PayCurrency"].ToString();
                    lblExporienceLvlTxt.Text = dt.Rows[0]["ExperienceLevel"].ToString();
                    Lbldes.Text = dt.Rows[0]["PayDescription"].ToString();
                    lblJobIndustryTxt.Text = dt.Rows[0]["JobFamilyName"].ToString();
                    lblJobTypeTxt.Text = dt.Rows[0]["JobType"].ToString();
                    lblJobDescTxt.Text = dt.Rows[0]["JobDescription"].ToString();
                    lblSkillsTxt.Text = dt.Rows[0]["Skills"].ToString();
                }
            }
            catch
            {
            }
        }
        protected void GetJobProfiles()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobProfile(JobID);
                if (dt.Rows.Count > 0)
                {

                    lblEduTxtOne.Text = dt.Rows[0]["Education"].ToString();
                    lblAgeTxt.Text = dt.Rows[0]["Age"].ToString();
                    lblJobIndFin.Text = dt.Rows[0]["JobFamilyName"].ToString();

                    if (dt.Rows[0]["DrivingLicense"].ToString() == "True")
                    {
                        lblDrivingLicTxt.Text = "Required";
                    }
                    else
                    {
                        lblDrivingLicTxt.Text = "Not Required";
                    }
                    lblDisTxt.Text = dt.Rows[0]["Distance"].ToString();
                    lblAvlblFrom.Text = dt.Rows[0]["AvailabiltyFrom"].ToString();
                    lblAvlblTo.Text = dt.Rows[0]["AvailabiltyTo"].ToString();
                    CurrentJobRoleType = dt.Rows[0]["CurrentJobRoleType"].ToString();
                    CurrentJobRoleBind();
                }
            }
            catch
            {
            }

        }
        protected void CurrentJobRoleBind()
        {

            int ln = CurrentJobRoleType.Length;
            if (ln > 1)
            {
                char[] ch = { ' ', ',' };
                int j = ch.Count();

                String[] words = CurrentJobRoleType.Split(ch);
                for (int i = 0; i < words.Length; i++)
                {
                    DataTable dt = new DataTable();
                    JobPostingFA ObjJobPostingFA = new JobPostingFA();
                    dt = ObjJobPostingFA.GetSourceTitle(words[i]);
                    if (dt.Rows.Count > 0)
                    {
                        str2 = dt.Rows[0]["Title"].ToString() + "," + str2;
                    }
                }
                LBlCurrentoccupation.Text = str2;
            }
        }
        protected void GetJobQuestionnaire()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.GetJobQuestionnaire(JobID);
                if (dt.Rows.Count > 0)
                {
                    imgbtnAssess.Visible = true;
                    lnkbtnOvrGreenTxt.Visible = true;
                }
                else
                {
                    imgbtnAssess.Visible = false;
                    lnkbtnOvrGreenTxt.Visible = false;
                }
            }
            catch
            { }
        }
    }
}
