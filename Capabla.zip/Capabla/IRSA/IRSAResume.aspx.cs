﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Xml.XPath;


namespace IRSA
{
    public partial class IRSAResume : System.Web.UI.Page
    {
        //Declaring global variables to be used throughout the class
        int UserID;
        string CultureID = string.Empty;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            CultureID = "EN";
            //UserID = 47;
            try
            {
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    //Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }
            catch { }
            getContactandOtherDetails(UserID);
            getPresentCompanyDetails(UserID);
            getPastCompanyDetails(UserID);
            getAcademicsDetails(UserID);
            getLicenseDetails(UserID);
            getAwardsAndAchievements(UserID);
            getAssociationDetails(UserID);
            getVisaDetails(UserID);
            getSecurityClearanceData(UserID);

            
        }

       //Function to infer titlr from gender
       protected string getTitle(string gender)
        {
            string title = string.Empty;
            if (gender == "Male")
            {
                title = "Mr.";
                return title;
            }
            else
            {
                title = "Ms.";
                return title;
            }
        }

        //This functions fetches the contact details from [txnMemeberAccount] table and assigns to labels
       protected void getContactandOtherDetails(int UserID)
       {
           IRSAResumeSH ContactSH = new IRSAResumeSH();
           IRSAResumeFA ContactFA = new IRSAResumeFA();
           DataTable ContactDT = new DataTable();
           int flag = 1;
           try
           {

               ContactDT = ContactFA.getContactandOtherDetails(UserID, flag,CultureID);
           }
           catch { }
           lblTitle.Text = getTitle(ContactDT.Rows[0]["Sex"].ToString());
           lblFirstName.Text=ContactDT.Rows[0]["FirstName"].ToString();
           lblLastName.Text = ContactDT.Rows[0]["LastName"].ToString();
           lblCity.Text = ContactDT.Rows[0]["City"].ToString();
           lblState.Text = ContactDT.Rows[0]["State"].ToString();
           lblPostalCode.Text = ContactDT.Rows[0]["PostalCode"].ToString();
           lblCountry.Text = ContactDT.Rows[0]["Country"].ToString();
           lblPhoneNo.Text = ContactDT.Rows[0]["Phone"].ToString();
           lblEmail.Text = ContactDT.Rows[0]["EmailID"].ToString();
           lblDOB.Text = ContactDT.Rows[0]["DateOfBirth"].ToString();
           lblGender.Text = ContactDT.Rows[0]["Sex"].ToString();
           lblMaritalStatus.Text = ContactDT.Rows[0]["MaritalStatus"].ToString();
           lblDL.Text = ContactDT.Rows[0]["DrivingLicence"].ToString();
           
        }

       //This functions fetches the Present Company details from [txnMemeberCompany] table and assigns to labels
       protected void getPresentCompanyDetails(int UserID)
       {
           IRSAResumeFA ContactFA = new IRSAResumeFA();
           DataTable ContactDT = new DataTable();
           if (ContactFA.isPresentCompExists(UserID,7,CultureID) == true)
           {
               int flag = 2;
               try
               {

                   ContactDT = ContactFA.getPresentCompanyDetails(UserID, flag,CultureID);
               }
               catch { }
               lblDesignation.Text = ContactDT.Rows[0]["Designation"].ToString();
               lblCompany.Text = ContactDT.Rows[0]["Company"].ToString();
               lblCountry.Text = ContactDT.Rows[0]["Country"].ToString();
               lblDesc.Text = ContactDT.Rows[0]["Description"].ToString();
               lblDateRange.Text = ContactDT.Rows[0]["WorkingFrom"].ToString();
           }
       }

       //This functions fetches the Past Companies details from [txnMemeberCompany] table and binds to grid
        protected void getPastCompanyDetails(int UserID)
       {
           IRSAResumeFA ContactFA = new IRSAResumeFA();
           DataTable ContactDT = new DataTable();
           if (ContactFA.isPastCompExists(UserID,8,CultureID) == true)
           {
               int flag = 3;
               try
               {
                   ContactDT = ContactFA.getPastCompanyDetails(UserID, flag,CultureID);
                   GridPastExp.DataSource = ContactDT;
                   GridPastExp.DataBind();
               }
               catch { }
           }
          
       }


        //This functions fetches the Academics details from [txnMemeberAcademics] table and binds to grid
        protected void getAcademicsDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            if (ContactFA.isAcademicsExists(UserID,0,CultureID) == true)
            {
                int flag = 4;
                try
                {
                    ContactDT = ContactFA.getAcademicsDetails(UserID, flag,CultureID);
                    GridAcademics.DataSource = ContactDT;
                    GridAcademics.DataBind();
                }
                catch { }
            }
        }

        //to retrieve the License and certification detrails
        protected void getLicenseDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            if (ContactFA.isCertiExists(UserID,2,CultureID) == true)
            {
                int flag = 5;
                try
                {
                    ContactDT = ContactFA.getLicenseDetails(UserID, flag,CultureID);
                    GridLicenseAndCertification.DataSource = ContactDT;
                    GridLicenseAndCertification.DataBind();
                }
                catch { }
            }

        }

        //to retrieve the Association details
        protected void getAssociationDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            if (ContactFA.isAssociationExists(UserID,5,CultureID) == true)
            {
                int flag = 6;
                try
                {
                    ContactDT = ContactFA.getAssociationDetails(UserID, flag,CultureID);
                    GridAssociations.DataSource = ContactDT;
                    GridAssociations.DataBind();
                }
                catch { }
            }
           
        }

        //to retrieve the Visa details
        protected void getVisaDetails(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            if (ContactFA.isVisaExists(UserID,4,CultureID) == true)
            {
                int flag = 7;
                try
                {
                    ContactDT = ContactFA.getVisaDetails(UserID, flag,CultureID);
                    GridVisaInfo.DataSource = ContactDT;
                    GridVisaInfo.DataBind();
                }
                catch { }
            }
            
        }

       //to retrieve the security clearance data
        protected void getSecurityClearanceData(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 8;
            try
            {
                ContactDT = ContactFA.getSecurityClearanceData(UserID, flag,CultureID);
            }
            catch { }
            lblSecurityName.Text = ContactDT.Rows[0]["SCName"].ToString();
            lblIssuerName.Text = ContactDT.Rows[0]["SCIssuingAuthority"].ToString();
            lblSecurityDescription.Text = ContactDT.Rows[0]["SCDescription"].ToString();
            lblObtainedOn.Text = ContactDT.Rows[0]["SCObtained"].ToString();
            lblSecValidityFrom.Text = ContactDT.Rows[0]["SCVaildFrom"].ToString();
            lblSecValidityTo.Text = ContactDT.Rows[0]["SCVaildTo"].ToString();

        }

        //to retrieve awards and achievements from txnMemberAccount table
        protected void getAwardsAndAchievements(int UserID)
        {
            IRSAResumeFA ContactFA = new IRSAResumeFA();
            DataTable ContactDT = new DataTable();
            int flag = 9;
            try
            {
                ContactDT = ContactFA.getAwardsAndAchievements(UserID, flag,CultureID);
            }
            catch { }
            lblAwards.Text = ContactDT.Rows[0]["AwardsandAchievements"].ToString();
            
        }

        protected void imgPDF_Click(object sender, ImageClickEventArgs e)
        {
            openPdf();
        }

        //This is the function to open the PDF form of iRSA Resume
        void openPdf()
        {
            try
            {
                SessionInfo.CandidateID = UserID;
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void imgPrint_Click(object sender, ImageClickEventArgs e)
        {
            Session["ctrl"] = pnlPrint;
            ClientScript.RegisterStartupScript(this.GetType(), "onclick", "<script language=javascript>window.open('Print.aspx','PrintMe','height=300px,width=300px,scrollbars=1,toolbar=yes,resizable=yes');</script>");
        }

   }
}
