﻿using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Facade;
using IRSA.Shared;
using System;
using IRSA.Common.GlobalFunction;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class PopUpRecruiterJobs : System.Web.UI.Page
    {
        int UserID;
        int OrgID;
        DataTable dtTemp = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserID = SessionInfo.UserId;
                OrgID = Convert.ToInt32(Request.QueryString.Get("id"));
                JobPostingFA objJobPostingFA = new JobPostingFA();
                this.Title = "Jobs posted by " + objJobPostingFA.GetOrgName(OrgID, UserID);
                populateGrid();
            }
            catch {}
        }

        void populateGrid()
        {
            try
            {
                JobPostingFA objJobPostingFA = new JobPostingFA();
                dtTemp = objJobPostingFA.RecruiterJobs(OrgID, UserID);
                DataColumn dcol = new DataColumn("Experience");
                dtTemp.Columns.Add(dcol);
                dtTemp.AcceptChanges();
                dcol = new DataColumn("LinkText");
                dtTemp.Columns.Add(dcol);
                dtTemp.AcceptChanges();
                dcol = new DataColumn("OnClntClck");
                dtTemp.Columns.Add(dcol);
                dtTemp.AcceptChanges();
                for (int x = 0; x < dtTemp.Rows.Count; x++)
                {
                    if (((dtTemp.Rows[x]["Experiencefrom"]).ToString()).Equals((dtTemp.Rows[x]["ExperienceTo"]).ToString()))
                        dtTemp.Rows[x]["Experience"] = (dtTemp.Rows[x]["ExperienceTo"]).ToString() + " yrs";
                    else
                        dtTemp.Rows[x]["Experience"] = (dtTemp.Rows[x]["Experiencefrom"]).ToString() + " - " + (dtTemp.Rows[x]["ExperienceTo"]).ToString() + " yrs";
                    dtTemp.AcceptChanges();

                    if ((dtTemp.Rows[x]["Status"]).ToString() == "True")
                    {
                        dtTemp.Rows[x]["LinkText"] = "Already Applied";
                        dtTemp.Rows[x]["Status"] = "False";
                    }
                    else
                    {
                        dtTemp.Rows[x]["LinkText"] = "View and Apply";
                        dtTemp.Rows[x]["Status"] = "True";
                        dtTemp.Rows[x]["OnClntClck"] = "redirectTo(" + (dtTemp.Rows[x]["JobID"]).ToString() + ")";
                    }
                    dtTemp.AcceptChanges();
                }
                RecruiterJobs.DataSource = dtTemp;
                RecruiterJobs.DataBind();
                ViewState["DTTemp"] = dtTemp;
            }
            catch { }
        }

        protected void RecruiterJobs_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                dtTemp = (DataTable)ViewState["DTTemp"];
                RecruiterJobs.CurrentPageIndex = e.NewPageIndex;
                RecruiterJobs.DataSource = dtTemp;
                RecruiterJobs.DataBind();
                ViewState["DTTemp"] = dtTemp;
            }
            catch { }
        }
    }
}
