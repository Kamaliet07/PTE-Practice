﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Net.Mail;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text;


namespace IRSA
{
    public partial class PersonSearch2 : System.Web.UI.Page
    {
        PersonSearchSH objpersonserachSH = new PersonSearchSH();
        PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
        string PhotoDirectoryPath, userpicspath;
        int UserID,inviteuserid,PhotoApproved;
        string strphoto,str4, strfname5, strPTitle, strLname6, strLoc, strkeyword,str, strCity;
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        public DataTable Persondetails
        {
            get { return (DataTable)ViewState["Persondetails"]; }
            set { ViewState["Persondetails"] = value; }
        }
        string Accountxml = "irsaToolTipSearch.xml";
        protected void Page_Load(object sender, EventArgs e)
        {

            PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];
            userpicspath = ConfigurationSettings.AppSettings["userpics"];
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
                XmlCountry();
                str = Request.QueryString.Get("id");
                if (str == "")
                {
                    GetList();
                }
                else
                {  int lng = str.Length;
                    if (lng <= 1)
                    {
                        GetpersonGrid();
                    }
                    else
                    {
                        GetSearchWords(str);
                     }
                }
            }
             GetiRsaToolTipAccMsg();
           
            if (SessionInfo.UserId != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                for (int i = 0; i < RadGrid1.MasterTableView.Items.Count; i++)
                {
                    LinkButton obj1 = (LinkButton)RadGrid1.Items[i].FindControl("LinkButton3");
                    obj1.Visible = true;
                }
            }
            else
            {
                Lblmember.Text = "Guest !";
            }

        }
        
        string PhotoID;

        public string GetFilePath(int UserID, string Photo)
        {
            PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
            DataTable profile = new DataTable();
            profile = objPersonSearchFA.Photostatus(UserID);

            if (profile.Rows.Count > 0)
            {
                string approved = this.GetTempsearchCollection.Rows[0]["PhotoApproved"].ToString();
                if (approved == "1")
                {
                    if (profile.Rows[0]["Everyone"].ToString() == "True")
                    {
                        strphoto = PhotoDirectoryPath + Photo;
                    }
                    
                }
                else
                {
                    strphoto = userpicspath;
                }
            }
                else
                {
                    strphoto = userpicspath;
                }
                return strphoto;
           
        }
                
            
        
        //protected void Page_LoadComplete(object sender, EventArgs e)
        //{

        //}
           private void GetiRsaToolTipAccMsg()
           {
            try
            {
                RtxtTitle.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, Accountxml);
                RtxtTitle0.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, Accountxml);
                RtxtTitle1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, Accountxml);
                RadTextBox2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
               
            }
            catch {
            }
          }
          
        private void XmlCountry()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                Countrybox.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {

            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {

        }


        public void GetpersonGrid()
        {
            
            try
           {

            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            DataTable dt = new DataTable();
            dt = objPersonSearchFA.GetData1(str, objpersonserachSH);
            RadGrid1.DataSource = dt;
            RadGrid1.DataBind();
            }
            catch
            {
            }
        }
        public void GetList()
        {
            try
            {

            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            DataTable dt = new DataTable();
            dt = objPersonSearchFA.GetDataList();
            this.Persondetails = EvaluateLocationDtl(dt);
            RadGrid1.DataSource = dt;
            RadGrid1.DataBind();
            }
            catch
            {
            }


        }
        private DataTable EvaluateLocationDtl(DataTable dfg)
        {
            try
            {

                dfg.Columns.Add("LocationDetl", typeof(string));
                foreach (DataRow dr in dfg.Rows)
                {
                    if (dr[6].ToString() != "" && dr[4].ToString() != "" && dr[5].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[6].ToString() + "," + dr[4].ToString() + "," + dr[5].ToString();
                    }
                    else if (dr[6].ToString() != "" && dr[4].ToString() != "" && dr[5].ToString() == "")
                    {
                        dr["LocationDetl"] = dr[6].ToString() + "," + dr[4].ToString();
                    }
                    else if (dr[6].ToString() != "" && dr[4].ToString() == "" && dr[5].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[6].ToString() + "," + dr[5].ToString();
                    }
                    else if (dr[6].ToString() != "" && dr[4].ToString() == "" && dr[5].ToString() == "")
                    {
                        dr["LocationDetl"] = dr[6].ToString();
                    }
                    else if (dr[6].ToString() == "" && dr[4].ToString() != "" && dr[5].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[4].ToString() + "," + dr[5].ToString();
                    }
                    else if (dr[6].ToString() == "" && dr[4].ToString() == "" && dr[5].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[5].ToString();
                    }
                    else if (dr[6].ToString() == "" && dr[4].ToString() != "" && dr[5].ToString() == "")
                    {
                        dr["LocationDetl"] = dr[4].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[6].ToString() == "" && dr[5].ToString() == "")
                    {
                        dr["LocationDetl"] = "";
                    }
                    dfg.AcceptChanges();
                }
                

            }
            catch
            {

            }
            return dfg;
         }
            
        public void getmember(string str4)
        {
            try
            {

                DataTable dtCalc = new DataTable();
                DataTable ds = new DataTable();
               if (GetTempsearchCollection == null)
                {
                    PersonSearchFA objPersonSearchFA = new PersonSearchFA();
                    ds = objPersonSearchFA.GetData1(str4 ,objpersonserachSH);
                    this.GetTempsearchCollection = ds;
                   
                }
                else
                {
                    if (GetTempsearchCollection.Rows.Count > 0)
                    {
                        if (GetTempsearchCollection.Rows[0]["details"].ToString() != "")
                        { 
                            DataRow[] Result = GetTempsearchCollection.Select("details Like '%" + str4 + "%'");
                            DataTable dfg = new DataTable();
                            dfg.Columns.Add("UserID", typeof(int));
                            dfg.Columns.Add("FirstName", typeof(string));
                            dfg.Columns.Add("LastName", typeof(string));
                            dfg.Columns.Add("ProfessionalTitle", typeof(string));
                            dfg.Columns.Add("City", typeof(string));
                            dfg.Columns.Add("Country", typeof(string));
                            dfg.Columns.Add("EmailID", typeof(string));
                            dfg.Columns.Add("PhotoID", typeof(string));
                            dfg.Columns.Add("PhotoApproved", typeof(string));

                            
                             foreach (DataRow dr in Result)
                            {
                                DataRow row;
                                row = dfg.NewRow();
                                row["UserID"] = dr[0];
                                row["FirstName"] = dr[2];
                                row["LastName"] = dr[3];
                                row["ProfessionalTitle"] = dr[4];
                                row["City"] = dr[5];
                                row["Country"] = dr[6];
                                row["EmailID"] = dr[7];
                                row["PhotoID"] = dr[8];
                                row["PhotoApproved"] = dr[10];

                                dfg.Rows.InsertAt(row, 0);
                               
                            }
                            this.GetTempsearchCollection = dfg;
                        }
                    }
                }


            }
            catch
            {
            }
        }
        


        public void GetSearchWords(string str)
        {
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str4 = words[i];
                
                getmember(str4);

            }
            if (this.GetTempsearchCollection == null)
            {
                visiblityuserTemp();
                blkOrgUserTemp();
                this.Persondetails = EvaluateLocationDtl(this.GetTempsearchCollection);
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            }
            else
            {
                visiblityuserTemp();
                blkOrgUserTemp();
                this.Persondetails = EvaluateLocationDtl(this.GetTempsearchCollection);
                RadGrid1.DataSource = this.Persondetails;
                RadGrid1.DataBind();

            }

        }


        protected void Button_Click1(object sender, EventArgs e)
        {
            GetTempsearchCollection = null;
            GetTempsearch = null;
            Person();
            if (UserID != int.MinValue)
            {

                for (int i = 0; i < RadGrid1.MasterTableView.Items.Count; i++)
                {
                    LinkButton obj1 = (LinkButton)RadGrid1.Items[i].FindControl("LinkButton3");
                    obj1.Visible = true;
                }
            }
            else
            {
                Lblmember.Text = "Guest !";
            }

        }

        protected void RadGrid1_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            if (str == "" || str == null)
            {
                GetList();
            }
            else
            {
                int lng = str.Length;
                if (lng <= 1)
                {
                    GetpersonGrid();
                }
                else
                {
                    GetSearchWords(str);

                }
            }
        }

        protected void Person()
        {
            string str6, str7, str8, str9, str10, str11, str12, str15, str16;
            str6 = RtxtTitle.Text;
            str9 = " ";
            objpersonserachSH.FirstName = RtxtTitle.Text; ;
            str7 = RtxtTitle0.Text;
            str10 = " ";
            objpersonserachSH.LastName = RtxtTitle0.Text;
            str15 = RtxtTitle1.Text;
            str16 = " ";
            objpersonserachSH.ProfessionalTitle = RtxtTitle1.Text;
            str11 = Countrybox.SelectedValue;
            str12 = " ";
            objpersonserachSH.Country = Countrybox.SelectedValue;
            str8 = RadTextBox2.Text;
            objpersonserachSH.City = RadTextBox2.Text;
            string ab = str6 + str9 + str7 + str10 + str15 + str16 + str11 + str12 + str8;
            GetSearchWords(ab);
        }

        protected void RtxtTitle_TextChanged1(object sender, EventArgs e)
        {
            strkeyword = RtxtTitle.Text;
        }

        protected void countrybox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objpersonserachSH.Country = Countrybox.SelectedItem.Text;
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton btnprev = (LinkButton)sender;
            LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton1");
            string EmailID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["EmailID"]);
            getuserID(EmailID);
            UserID = inviteuserid;
            if (SessionInfo.UserId != int.MinValue)
            {
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/PersonProfileView.aspx?id=" + UserID;
                rd.VisibleOnPageLoad = true;
                rd.Width = 600;
                rd.Height = 500;
                rd.Left = 400;
                rd.Top = 150;
                RadWindowManager1.Windows.Add(rd);
            }
            else
            {

                lblprofile.Visible = true;
                lblprofile.Text = "You must be logged in to view the profile";
            }
        }


        protected void lnkbutton_Click(object sender, EventArgs e)
        {

            Response.Redirect("PersonSearchAdvanced.aspx");


        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton btnprev = (LinkButton)sender;
            LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton3");
            string EmailID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["EmailID"]);
            SendMail(EmailID);
            InsertUserInvitationDetail();
        }
        private void InsertUserInvitationDetail()
        {
            IRSA.Facade.Community.CommunityFA ObjMyloginUser = new IRSA.Facade.Community.CommunityFA();
            ObjMyloginUser.InsertUserInvitationDetail(SessionInfo.UserId, inviteuserid);
        }

        private void getuserID(string EmailID)
        {
            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            DataTable dtuserid = new DataTable();
            dtuserid = objPersonSearchFA.GetUser(EmailID);
            if (dtuserid.Rows.Count > 0)
            {
                inviteuserid = Convert.ToInt32(dtuserid.Rows[0]["UserID"].ToString());
            }

        }

        public void SendMail(string EmailID)
        {
            try
            {

                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(EmailID);
                MailAddress fromto = new MailAddress("kamika@iprozone.com");
                MailMessage msg = new MailMessage(fromto, sendto);
                MailDefinition mailmsg = new MailDefinition();
                mailmsg.BodyFileName = "";
                mailmsg.IsBodyHtml = true;
                msg.IsBodyHtml = true;
                bodyMsg.Append("Congratulations ");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("This is your account Information for iRSA.com ");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Before you can log into your iRSA account,you need to set your password by visiting this URL:");
                bodyMsg.Append("<br />");
                getuserID(EmailID);
                string mail = string.Format("http://localhost:4071/AcceptInformation.aspx?param1={0}&param2={1}", inviteuserid, UserID);
                bodyMsg.Append(mail);
                bodyMsg.Append("<br />");
                bodyMsg.Append("After you login,explore the various tools & information to grow your career and get involved!");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Your Participation Drives iRSA.com");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("Thank You for your interest in iRSA");
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append("iRSA values your privacy at no time has iRSA made your email address available to any other iRSA user without your permission @2009,Powered By iRSA");

                msg.Subject = "Contact Information";
                msg.Body = bodyMsg.ToString();
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);

            }
            catch { }

        }
        private DataTable GetUserStatus(int inviteuserid)
        {
            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            return objPersonSearchFA.GetUserExistanceInNet(inviteuserid, SessionInfo.UserId);
        }

        protected void RadGrid1_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem item = e.Item as GridDataItem;
                PersonSearchAdvancedFA objPersonSearchFA = new PersonSearchAdvancedFA();
                int userid = Convert.ToInt32(item["UserID"].Text.ToString());
                string Photo = (item["PhotoID"].Text.ToString());
               
                DataTable obj = new DataTable();
                DataTable profilestat = new DataTable();
                DataTable visibilty = new DataTable();
                profilestat = objPersonSearchFA.contactstatus(userid);
                if (profilestat.Rows.Count > 0)
                {
                    if (profilestat.Rows[0]["Everyone"].ToString().Trim() == "True")
                    {
                        LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                        lnkbtn.Enabled = true;
                    }
                    else
                    {
                        if (profilestat.Rows[0]["MyContact"].ToString().Trim() == "True")
                        {
                            LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                            lnkbtn.Enabled = true;
                        }

                        else
                        {
                            LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                            lnkbtn.Enabled = false;
                        }
                    }
                }
                else
                {
                    LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                    lnkbtn.Enabled = false;
                }
                obj = GetUserStatus(userid);
                if (obj.Rows.Count != 0)
                {
                    if (obj.Rows[0]["Accepted"].ToString().Trim() != "False")
                    {
                        LinkButton lnkbtn = item["TemplateColumn"].FindControl("LinkButton3") as LinkButton;
                        lnkbtn.Enabled = false;
                    }
                   
                   
                }
                string filepath = GetFilePath(userid, Photo);

                Image img = item["TemplateColumn"].FindControl("Image1") as Image;
                img.ImageUrl = filepath;

            }

        }
        
        protected void visiblityuserTemp()
        {
            try
            {

                if (GetTempsearchCollection.Rows.Count == 0 || GetTempsearchCollection.Rows.Count == null)
                {
                    for (int i = GetTempsearchCollection.Rows.Count - 1; i >= 0; i--)
                    {
                        int uid = Convert.ToInt32(GetTempsearchCollection.Rows[i]["UserID"].ToString());
                        bool val = objPersonSearchFA.GetStatus(uid);
                        if (val == false)
                        {
                            bool varn = objPersonSearchFA.GetMyContact(UserID, uid);
                            if (varn == false)
                            {
                                GetTempsearchCollection.Rows.RemoveAt(i);
                            }

                        }
                    }
                    this.GetTempsearchCollection.AcceptChanges();
                }
            }
            catch
            {
            }
        }
        protected void blkOrgUserTemp()
        {
            try
            {

                if (GetTempsearchCollection.Rows.Count == 0 || GetTempsearchCollection.Rows.Count == null)
                {
                    for (int i = GetTempsearchCollection.Rows.Count - 1; i >= 0; i--)
                    {
                        int uid = Convert.ToInt32(GetTempsearchCollection.Rows[i]["UserID"].ToString());
                        bool val = objPersonSearchFA.GetOrgStatus(UserID, uid);
                        if (val == true)
                        {
                            GetTempsearchCollection.Rows.RemoveAt(i);
                        }

                    }
                    this.GetTempsearchCollection.AcceptChanges();
                }
            }
            catch
            {
            }
        }

        protected void RadGrid1_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
        {

        }

    }
}



       

   

       




        
    


