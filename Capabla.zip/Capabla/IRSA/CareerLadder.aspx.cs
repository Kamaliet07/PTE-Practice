﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Drawing.Drawing2D;

namespace IRSA
{
    public partial class CareerLadder : System.Web.UI.Page
    {
        int JobZoneSource;
        int JobZoneTarget;
        int height = 100;
        int width = 200;
        int Level1 = 50;
        int Level2 = 50;
        int Level3 = 50;
        int LevelSouece = 50;
        Array Myarray;
        string occupationName;
        string occuName;
        string SourceValue;
        string TargeValue;
        protected void Page_Load(object sender, EventArgs e)
        {
            DDSelectDomainBind();


        }

        public void DDSelectDomainBind()
        {
            CarrerLadderFA objLadderFA = new CarrerLadderFA();
            DataTable dtJobFamily = new DataTable();
            dtJobFamily = objLadderFA.GetJobFamilyData();
            DDSelectDomain.DataSource = dtJobFamily;
            DDSelectDomain.DataBind();
        }

        protected void DDSelectDomain_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarrerLadderFA objSourceFA = new CarrerLadderFA();
            string JobFamily = DDSelectDomain.SelectedValue;
            DataTable dtSource = new DataTable();
            dtSource = objSourceFA.GetSourceData(JobFamily);
            DDCurrentPosition.DataSource = dtSource;
            DDCurrentPosition.DataBind();
            DDTargetPosition.DataSource = dtSource;
            DDTargetPosition.DataBind();
           
        }



        protected void CareerLadderwizard_ActiveStepChanged(object sender, EventArgs e)
        {
            string CurrentWizardStep = CareerLadderwizard.ActiveStep.Name;

            if (CurrentWizardStep == "Step 3")
            {


                int objSum;
                string JobFamily = DDSelectDomain.SelectedValue;
                SourceValue = DDCurrentPosition.SelectedValue;
                TargeValue = DDTargetPosition.SelectedValue;
                DataTable CalculatedDatavalue = new DataTable();
                CalculatedDatavalue.Columns.Add(new DataColumn("ID", typeof(string)));
                CalculatedDatavalue.Columns.Add(new DataColumn("OccupationName", typeof(string)));
                CalculatedDatavalue.Columns.Add(new DataColumn("Datavalue", typeof(int)));
                DataTable CalulationResult = new DataTable();
                CalulationResult.Columns.Add(new DataColumn("Occupation", typeof(string)));
                CalulationResult.Columns.Add(new DataColumn("Weight", typeof(int)));
                CalulationResult.Columns.Add(new DataColumn("Level", typeof(int)));
                DataTable dtCalc = new DataTable();
                DataTable dtSource1 = new DataTable();
                DataTable dtTarget1 = new DataTable();


                for (int i = 1; i <= 6; i++)
                {
                    int TargetOccupation = 0;

                    DataTable dtOccupation = new DataTable();
                    CarrerLadderFA objOccupationFA = new CarrerLadderFA();
                    dtOccupation = objOccupationFA.GetOccupationCount(JobFamily, SourceValue, TargeValue, i);
                    int occupationCount = dtOccupation.Rows.Count;

                    CarrerLadderFA objsourceZoneFA = new CarrerLadderFA();
                    dtSource1 = objsourceZoneFA.GetDetailSourceData(JobFamily, SourceValue, TargeValue, i);
                    int SourceCount = dtSource1.Rows.Count;

                    CarrerLadderFA objTargetZoneFA = new CarrerLadderFA();
                    dtTarget1 = objTargetZoneFA.GetTargetData(JobFamily, SourceValue, TargeValue, i);



                    if (dtTarget1 != null)
                    {
                        for (int j = 0; j < occupationCount; j++)
                        {
                            occupationName = dtOccupation.Rows[j]["Title"].ToString();
                            for (int k = 0; k < SourceCount; k++)
                            {
                                double f = Convert.ToDouble(dtTarget1.Rows[143]["DataValue"]);
                                if (Convert.ToDouble(dtSource1.Rows[k]["SourceDataValue"]) >= Convert.ToDouble(dtTarget1.Rows[TargetOccupation]["DataValue"]))
                                {
                                    DataRow myNewRow;
                                    myNewRow = CalculatedDatavalue.NewRow();
                                    myNewRow["Id"] = j;
                                    myNewRow["OccupationName"] = occupationName;
                                    myNewRow["Datavalue"] = "1";
                                    CalculatedDatavalue.Rows.Add(myNewRow);
                                }
                                TargetOccupation = TargetOccupation + 1;
                            }


                        }

                    }


                }
                int ij = 0;
                CarrerLadderFA objOccupFA = new CarrerLadderFA();
                DataTable dtOccCount = new DataTable();
                dtOccCount = objOccupFA.GetOccupationCount(JobFamily, SourceValue, TargeValue, ij);
                int occCount = dtOccCount.Rows.Count;

                for (int temp = 0; temp < occCount; temp++)
                {
                    string filter = temp.ToString();
                    occuName = dtOccCount.Rows[temp]["Title"].ToString();
                    int Level = Convert.ToInt32(dtOccCount.Rows[temp]["JobZone"]);

                    objSum = Convert.ToInt32(CalculatedDatavalue.Compute("Sum(Datavalue)", "Id=" + filter + ""));

                    DataRow NewRow;
                    NewRow = CalulationResult.NewRow();
                    NewRow["Occupation"] = occuName;
                    NewRow["Weight"] = objSum;
                    NewRow["Level"] = Level;
                    CalulationResult.Rows.Add(NewRow);


                }
                DrawCareerladder(CalulationResult, SourceValue, TargeValue);



            }
        }

        public void DrawCareerladder(DataTable CalulationResult, string SourceValue, string TargeValue)
        {
            int LevelCount;
            int SourceId;
            int TargetID;
            int HierarchyLevel = 0;
            CarrerLadderFA objDummydataFA = new CarrerLadderFA();
            DataTable dtSourceId = objDummydataFA.GetSourceZone(SourceValue);
            DataTable dtTargetID = objDummydataFA.GetSourceZone(TargeValue);
            if (dtTargetID.Rows.Count == 0 || dtSourceId.Rows.Count == 0)
            {
                lblErrorMsg.Visible = true;
                lblErrorMsg.Text = "Job Zone does not exist";
            }
            else
            {
                SourceId = Convert.ToInt32(dtSourceId.Rows[0]["JobZone"]);

                TargetID = Convert.ToInt32(dtTargetID.Rows[0]["JobZone"]);

                Bitmap bmpDiagram = new Bitmap(500, 450);
                Graphics g = Graphics.FromImage(bmpDiagram);
                g.Clear(Color.White);
                g.SmoothingMode = SmoothingMode.HighQuality;

                // Ggenerate the shape of a person
                GraphicsPath Person = new GraphicsPath();
                Person.AddEllipse(23, 1, 14, 14);
                Person.AddLine(18, 16, 42, 16);
                Person.AddLine(50, 40, 44, 42);
                Person.AddLine(38, 25, 37, 42);
                Person.AddLine(45, 75, 37, 75);
                Person.AddLine(30, 50, 23, 75);
                Person.AddLine(16, 75, 23, 42);
                Person.AddLine(22, 25, 16, 42);
                Person.AddLine(10, 40, 18, 16);
                DataTable dt = new DataTable();

                String Target = TargeValue;
                if (TargetID - SourceId == 1)
                {
                    this.DrawPerson(g, Person, Color.Red, 200, 10, Target);
                    this.DrawPerson(g, Person, Color.Red, Level1, 170, SourceValue);
                    this.ConnectPerson(g, 80, 160, 230, 110,
                      Color.Blue);
                }
                else if (TargetID - SourceId == 2)
                {
                    this.DrawPerson(g, Person, Color.Red, 200, 10, Target);
                    for (int i = 1; i < SourceId; i++)
                    {
                        HierarchyLevel = HierarchyLevel + 1;
                        int Level = TargetID - i;
                        DataRow[] Result = CalulationResult.Select("Level=" + Level + "", " Weight");
                        DataTable OccuByLevel = new DataTable();
                        OccuByLevel.Columns.Add("OccupationName", typeof(string));
                        OccuByLevel.Columns.Add("Weight", typeof(int));

                        foreach (DataRow dr in Result)
                        {
                            DataRow row;
                            row = OccuByLevel.NewRow();
                            row["OccupationName"] = dr[0];
                            row["Weight"] = dr[1];
                            OccuByLevel.Rows.Add(row);
                        }
                        int j = OccuByLevel.Rows.Count;

                        if (j > 4)
                        {
                            LevelCount = 4;

                        }
                        else
                        {
                            LevelCount = j;
                        }
                        for (int k = 0; k < LevelCount; k++)
                        {
                            string OccName = OccuByLevel.Rows[k]["OccupationName"].ToString();
                            this.DrawPerson(g, Person, Color.Blue,
                                             Level1, 170, OccName);
                            this.ConnectPerson(g, 80, 160, 230, 110,
                  Color.Blue);
                            Level1 = Level1 + 100;

                        }
                    }

                    this.DrawPerson(g, Person, Color.Red, LevelSouece, 330, SourceValue);
                    this.ConnectPerson(g, 80, 320, 80, 270, Color.Blue);











                    // GetTempsearch = dfg;
                    //int Level = TargetID - i;
                    //int minWeight = Convert.ToInt32(CalulationResult.Compute("Min(Weight)", "Level=" + Level + ""));

                    //Myarray = CalulationResult.Select("Occupation","Weight=" + minWeight + "");
                    //Array my =dt.Select("OccupationName  JobZoneLevel='" + Level + "'");
                    //DataRow[] results = dt.Select("JobZoneLevel='" + Level + "' ");



                    //       this.DrawPerson(g, Person, Color.Blue,
                    // 150, 170, "Worker 2");
                    //       this.DrawPerson(g, Person, Color.Green,
                    //250, 170, "Worker 3");


                }
                else if (TargetID - SourceId == 0)
                {
                    this.DrawPerson(g, Person, Color.Red, 200, 10,SourceValue );
                    this.DrawPerson(g, Person, Color.Red, 300, 10, Target);
                    this.ConnectPerson(g, 250, 40, 300, 40, Color.Blue);

                }
                Response.ContentType = "image/jpeg";
                bmpDiagram.Save(@"C:\test.Jpeg", ImageFormat.Jpeg);
               //CLImg.Visible = true;
               //CLImg.ImageUrl = @"C:\test.jpeg";
                //Response.End();
            }
           
        }



        private void DrawPerson(Graphics graphics,
        GraphicsPath Shape, Color fill, float x,
        float y, string Name)
        {
            // Position the shape
            graphics.TranslateTransform(x, y);

            // Draw the person and fill it 
            // with a gradient
            //Font oFont = new Font("Tahoma", 7);
            System.Drawing.Brush oBrush =
               new LinearGradientBrush(
               new Rectangle(0, 0, 60, 90),
               Color.White, fill, 90, true);
            graphics.FillPath(oBrush, Shape);
            graphics.DrawPath(Pens.Black, Shape);

            // Draw the name
            StringFormat sf = new StringFormat();
            
            sf.Alignment = StringAlignment.Center;
            Font oFont = new Font("Tahoma", 8);
            System.Drawing.SizeF size =
               graphics.MeasureString(Name, oFont);

            System.Drawing.RectangleF rect =
               new RectangleF(30 - (size.Width /2),
               80, size.Width, size.Height);
            
            graphics.DrawString(Name, oFont,
               Brushes.Black, rect, sf);

            // Rset the coordinate shift
            graphics.ResetTransform();

        }

        public void ConnectPerson(Graphics g, float x1,
           float y1, float x2, float y2, Color lineColor)
        {
            // Draw a line with a custom arrow-head
            Pen p = new Pen(lineColor, 1);
            CustomLineCap myCap =
               new AdjustableArrowCap(5, 5, true);
            p.EndCap = LineCap.Custom;
            p.CustomEndCap = myCap;
            g.DrawLine(p, x1, y1, x2, y2);
        }

        protected void ImgStep1_Click(object sender, ImageClickEventArgs e)
        {

        }
        protected void ImgStep2_Click(object sender, ImageClickEventArgs e)
        {

        }
        protected void ImgStep3_Click(object sender, ImageClickEventArgs e)
        {

        }


    }
}
