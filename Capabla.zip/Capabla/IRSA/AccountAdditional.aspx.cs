﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;
using System.Collections.Specialized;


namespace IRSA
{
    public partial class AccountAdditional : System.Web.UI.Page
    {
        int UserID;
        string AppName;
        string Accountxml = "irsatooltipaccount.xml";
        string CurrentWizardStep = "AdditionalInfo";
        string CULINFO;
        string CultureID1;
        public StringCollection idCollection
        {
            set
            {
                ViewState["idCollection"] = value;
            }
            get
            {
                if (ViewState["idCollection"] == null)
                {
                    ViewState["idCollection"] = "";
                }
                return (StringCollection)ViewState["idCollection"];
            }
        }
        public string WorkPermitName
        {
            set
            {
                ViewState["WorkPermitName"] = value;
            }
            get
            {
                if (ViewState["WorkPermitName"] == null)
                {
                    ViewState["WorkPermitName"] = "";
                }
                return (ViewState["WorkPermitName"].ToString());
            }
        }
      
        public string AName
        {
            set
            {
                ViewState["AName"] = value;
            }
            get
            {
                if (ViewState["AName"] == null)
                {
                    ViewState["AName"] = "";
                }
                return (ViewState["AName"].ToString());
            }
        }
        public string LCName
        {
            set
            {
                ViewState["LCName"] = value;
            }
            get
            {
                if (ViewState["LCName"] == null)
                {
                    ViewState["LCName"] = "";
                }
                return (ViewState["LCName"].ToString());
            }
        }
        public string headtext
        {
            set
            {
                ViewState["headtext"] = value;
            }
            get
            {
                if (ViewState["headtext"] == null)
                {
                    ViewState["headtext"] = "";
                }
                return (ViewState["headtext"].ToString());
            }
        }
        public string IDs
        {
            set
            {
                ViewState["IDs"] = value;
            }
            get
            {
                if (ViewState["IDs"] == null)
                {
                    ViewState["IDs"] = "";
                }
                return ViewState["IDs"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountAdditionalPageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            //Page.Form.DefaultButton = Update.UniqueID;
            UserID =  SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
            if (!IsPostBack)
            {
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

                disablevisainfoform();
                disableAssociationsinform();
                disableLicenseform();
                XmlCountry();
                Getdata();
                GetSecCleardata();
                GetAssociationsdata();
                GetLicencedata();
            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["DisplayName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }

            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(45, Accountxml);
                Image2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(43, Accountxml);
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);
                Image4.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(41, Accountxml);
                Image5.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(40, Accountxml);
                Image6.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(38, Accountxml);
                Image7.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(44, Accountxml);
                txnwrkpermit.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(29, Accountxml);
                txtsecclname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(30, Accountxml);
                txtissauth.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(31, Accountxml);
                txtdesc.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(32, Accountxml);
                txtassoname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(33, Accountxml);
                txturl.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(34, Accountxml);
                txtlicname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(35, Accountxml);
                txtlicid.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(36, Accountxml);
                txtlicissuedby.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(37, Accountxml);
                Txtpersonalint.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(73, Accountxml);
                ListLanguage.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(74, Accountxml);
                Image8.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(75, Accountxml);
                
                
               
            }
            catch { }
        }
        DateTime dateToWP;
        DateTime datefrmWP;
        DateTime obtSC;
        DateTime dateToSC;
        DateTime datefrmSC;
        DateTime dateutlasso;
        DateTime datesncasso;
        DateTime datefrmlic;
        DateTime datetolic;
        DateTime dateToday = System.DateTime.Today.Date;
        public void savedata(string headtext)
        {
            
            try
            {
                CULINFO = "en-GB";
                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Lbldatamodified.Visible = false;
                AccountsetupSH objaddinfoSH = new AccountsetupSH();
                AccountsetupFA objaccpastFA = new AccountsetupFA();
                if (headtext == "Additional1")
                {
                    if (txnwrkpermit.Text != "")
                    {
                        Lblwrkpermiterror.Visible = false;
                        objaddinfoSH.Workpermit = UCFirst(txnwrkpermit.Text);
                        objaddinfoSH.VisaCountry = radcomcosountry.SelectedValue;
                        if ((RadDatewpvalidto.SelectedDate != null) && (RadDatewpvalidfrm.SelectedDate != null) )
                        {
                            dateToWP = RadDatewpvalidto.SelectedDate.Value;
                            datefrmWP = RadDatewpvalidfrm.SelectedDate.Value;
                            objaddinfoSH.WPValidTo = RadDatewpvalidto.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            objaddinfoSH.WPvalidFrm = RadDatewpvalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            if ((datefrmWP.Year >= (System.DateTime.Now.Year - 20)) && (datefrmWP.Year <= System.DateTime.Now.Year))
                            {


                                lblDateErrorS.Visible = false;

                            }
                            else
                            {
                                lblDateErrorS.Visible = true;
                                RadDatewpvalidfrm.Focus();
                                goto Last;

                            }
                            if ((dateToWP.Year <= (System.DateTime.Now.Year + 10)) && (dateToWP.Year >= datefrmWP.Year))
                            {

                                lblDateErrorS.Visible = false;
                            }
                            else
                            {
                                lblDateErrorS.Visible = true;
                                RadDatewpvalidfrm.Focus();
                                goto Last;


                            }
                            if (datefrmWP > dateToWP)
                            {
                                lblDateErrorS.Visible = true;
                                RadDatewpvalidfrm.Focus();
                                goto Last;

                            }
                            else
                            {


                                lblDateErrorS.Visible = false;
                            }
                        }
                        else if (RadDatewpvalidfrm.SelectedDate != null)
                        {
                            objaddinfoSH.WPValidTo = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            objaddinfoSH.WPvalidFrm = RadDatewpvalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            if ((datefrmWP.Year >= (System.DateTime.Now.Year - 20)) && (datefrmWP.Year <= System.DateTime.Now.Year))
                            {


                                lblDateErrorS.Visible = false;

                            }
                            else
                            {
                                lblDateErrorS.Visible = true;
                                RadDatewpvalidfrm.Focus();
                                goto Last;

                            }

                        }
                       
                        
                        Lblwrkpermiterror.Visible = false;
                        objaccpastFA.InsertVisaData(objaddinfoSH, UserID, CurrentWizardStep, headtext);
                        Lbldatamodified.Visible = true;
                        Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                        disablevisainfoform();
                        goto Last;
                    }
                    else
                    {
                        Lblwrkpermiterror.Visible = true;
                        Lblwrkpermiterror.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(64); 
                        goto Last;
                    }
                   
                    

                }
                else if (headtext == "Additional2")
                {
                    if (txtsecclname.Text != "")
                    {
                        Lblsecuritycl.Visible = false;
                        objaddinfoSH.SecurityClearance = UCFirst(txtsecclname.Text);
                        objaddinfoSH.SCIssuingAuthority = UCFirst(txtissauth.Text);
                        objaddinfoSH.SCDescription = UCFirst(txtdesc.Text);
                        if (raddateobtained.SelectedDate != null)
                        {
                            obtSC = raddateobtained.SelectedDate.Value;
                            if (obtSC.Year >= System.DateTime.Now.Year - 50 && obtSC.Year <= System.DateTime.Now.Year)
                            {
                                LblerrSC.Visible = false;
                                objaddinfoSH.SCObtained = raddateobtained.SelectedDate.Value.ToString("dd/MMM/yyyy");


                            }
                            else
                            {
                                LblerrSC.Visible = true;
                                raddateobtained.Focus();
                                goto Last;
                            }
                        }
                        if ((raddatevalidto.SelectedDate != null) && (raddatevalidfrm.SelectedDate != null))
                        {
                                dateToSC = raddatevalidto.SelectedDate.Value;
                                datefrmSC = raddatevalidfrm.SelectedDate.Value;
                           

                            if ((datefrmSC.Year >= (System.DateTime.Now.Year - 50)) && (datefrmSC.Year <= System.DateTime.Now.Year))
                            {
                                LblerrSC.Visible = false;
                                objaddinfoSH.SCValidfrm = raddatevalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");

                            }
                            else
                            {
                                LblerrSC.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }
                            if ((dateToSC.Year <= (System.DateTime.Now.Year + 10)) && (dateToSC.Year >= datefrmSC.Year))
                            {
                                LblerrSC.Visible = false;
                                objaddinfoSH.SCValidto = raddatevalidto.SelectedDate.Value.ToString("dd/MMM/yyyy");


                            }
                            else
                            {
                                LblerrSC.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }

                            if (datefrmSC > dateToSC)
                            {
                                LblerrSC.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }
                            else
                            {
                                LblerrSC.Visible = false;
                            }
                            
                        }
                        else if (raddatevalidfrm.SelectedDate != null)
                        {
                            objaddinfoSH.SCValidfrm = raddatevalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            objaddinfoSH.SCValidto = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            if ((datefrmSC.Year >= (System.DateTime.Now.Year - 50)) && (datefrmSC.Year <= System.DateTime.Now.Year))
                            {
                                LblerrSC.Visible = false;
                                objaddinfoSH.SCValidfrm = raddatevalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");

                            }
                            else
                            {
                                LblerrSC.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }
                        }
                        
                        objaccpastFA.InsertVisaData(objaddinfoSH, UserID, CurrentWizardStep, headtext);
                        Lbldatamodified.Visible = true;
                        Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                        goto Last;
                    }
                    else
                    {
                        Lblsecuritycl.Visible = true;
                        Lblsecuritycl.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(65);
                        goto Last;
                    }
                   
                }
                else if (headtext == "Additional3")
                {
                    if (txtassoname.Text != "")
                    {
                        lblassocierr.Visible = false;
                        if ((RadDateuntil.SelectedDate != null) && (RadDatesince.SelectedDate != null))
                        {
                            dateutlasso = RadDateuntil.SelectedDate.Value;
                            datesncasso = RadDatesince.SelectedDate.Value;
                            objaddinfoSH.AssoSince = RadDatesince.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            objaddinfoSH.AssoUntil = RadDateuntil.SelectedDate.Value.ToString("dd/MMM/yyyy");

                            if (RadDatesince.SelectedDate != null)
                            {

                            }
                            if ((datesncasso.Year >= (System.DateTime.Now.Year - 20)) && (datesncasso.Year <= System.DateTime.Now.Year))
                            {
                                Lblerrasso.Visible = false;
                            }
                            else
                            {
                                Lblerrasso.Visible = true;
                                RadDatesince.Focus();
                                goto Last;
                            }
                            if ((dateutlasso.Year >= datesncasso.Year) && (dateutlasso.Year <= (System.DateTime.Now.Year + 10)))
                            {
                                Lblerrasso.Visible = false;

                            }
                            else
                            {
                                Lblerrasso.Visible = true;
                                RadDatesince.Focus();
                                goto Last;

                            }
                            if (datesncasso > dateutlasso)
                            {
                                Lblerrasso.Visible = true;
                                RadDatesince.Focus();
                                goto Last;
                            }
                            else
                            {
                                Lblerrasso.Visible = false;
                            }
                        }
                        else if (RadDatesince.SelectedDate != null)
                        {
                            objaddinfoSH.AssoSince = RadDatesince.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            objaddinfoSH.AssoUntil = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            if (RadDatesince.SelectedDate != null)
                            {

                            }
                            if ((datesncasso.Year >= (System.DateTime.Now.Year - 20)) && (datesncasso.Year <= System.DateTime.Now.Year))
                            {
                                Lblerrasso.Visible = false;
                            }
                            else
                            {
                                Lblerrasso.Visible = true;
                                RadDatesince.Focus();
                                goto Last;
                            }
                        }
                        
                        objaddinfoSH.Awards = UCFirst(RadEditorawards.Content);
                        objaddinfoSH.AssociationName = UCFirst(txtassoname.Text);
                        objaddinfoSH.AssociationURL = txturl.Text;

                        objaccpastFA.InsertVisaData(objaddinfoSH, UserID, CurrentWizardStep, headtext);
                        Lbldatamodified.Visible = true;
                        Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                        disableAssociationsinform();
                        goto Last;
                    }
                    else
                    {
                        lblassocierr.Visible = true;
                        lblassocierr.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(66); ;
                        goto Last;
                    }

                }
                else if (headtext == "Additional4")
                {
                    if (txtlicname.Text != "")
                    {
                        lblliceror.Visible = false;
                        if ((raddatevalidfrm.SelectedDate != null) && (raddatevalidto.SelectedDate != null))
                        {
                            datefrmlic = raddatevalidfrm.SelectedDate.Value;
                            datetolic = raddatevalidto.SelectedDate.Value;


                            if ((datefrmlic.Year >= (System.DateTime.Now.Year - 20)) && (datefrmlic.Year <= System.DateTime.Now.Year))
                            {
                                Lblerrlic.Visible = false;
                                objaddinfoSH.LicenseValidfrm = raddatevalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");

                            }
                            else
                            {
                                Lblerrlic.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }
                            if ((datetolic.Year <= (System.DateTime.Now.Year + 20)) && (datetolic.Year >= datefrmlic.Year))
                            {
                                Lblerrlic.Visible = false;
                                objaddinfoSH.LicenseValidTo = raddatevalidto.SelectedDate.Value.ToString("dd/MMM/yyyy");

                            }
                            else
                            {
                                Lblerrlic.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }
                            if (datefrmlic > datetolic)
                            {
                                Lblerrlic.Visible = true;
                               
                                goto Last;
                            }
                            else
                            {
                                Lblerrlic.Visible = false;
                            }
                        }
                        else if (raddatevalidfrm.SelectedDate != null)
                        {
                            objaddinfoSH.LicenseValidfrm = raddatevalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                            objaddinfoSH.LicenseValidTo = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            if ((datefrmlic.Year >= (System.DateTime.Now.Year - 20)) && (datefrmlic.Year <= System.DateTime.Now.Year))
                            {
                                Lblerrlic.Visible = false;
                                objaddinfoSH.LicenseValidfrm = raddatevalidfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");

                            }
                            else
                            {
                                Lblerrlic.Visible = true;
                                raddatevalidfrm.Focus();
                                goto Last;
                            }
                        }
                        objaddinfoSH.Licensename = UCFirst(txtlicname.Text);
                        objaddinfoSH.LicenseID = UCFirst(txtlicid.Text);
                        objaddinfoSH.LicenseIssuedby = UCFirst(txtlicissuedby.Text);

                        objaccpastFA.InsertVisaData(objaddinfoSH, UserID, CurrentWizardStep, headtext);
                        Lbldatamodified.Visible = true;
                        Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                        disableLicenseform();
                        goto Last;
                    }
                    else
                    {
                        lblliceror.Visible = true;
                        lblliceror.Text =IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(67);
                        goto Last;
                    }

                }
                else if (headtext == "Additional5")
                {
                    objaddinfoSH.PersonalInterest = UCFirst(Txtpersonalint.Text);
                    foreach (ListItem li in ListLanguage.Items)
                    {
                        if (li.Selected)
                        {
                            IDs = IDs + li.Value + ",";
                        }
                    }
                    objaddinfoSH.LangSkill = IDs;
                    objaddinfoSH.CompSkill = Chkcompskills.Checked;
                    objaddinfoSH.Awards = RadEditorawards.Content;
                    objaccpastFA.InsertVisaData(objaddinfoSH, UserID, CurrentWizardStep, headtext);
                    Lbldatamodified.Visible = true;
                    Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                    goto Last;

                }
              
             
            Last: ;

              
            }

            catch { }
        }
        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetVisaData(UserID);
                if (objdt.Rows.Count > 0)
                {

                    panelvisa.Visible = true;
                    RadGridvisa.DataSource = objdt;
                    RadGridvisa.DataBind();

                }
                else
                {
                    panelvisa.Visible = false;
                }



            }
            catch { }
        }
        public void GetSecCleardata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetSCData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    txtsecclname.Text = objdt.Rows[0]["SCName"].ToString();
                    txtissauth.Text = objdt.Rows[0]["SCIssuingAuthority"].ToString();
                    txtdesc.Text = objdt.Rows[0]["SCDescription"].ToString();
                    CULINFO = "en-GB";
                    CultureInfo objCI = new CultureInfo(CULINFO);
                    Thread.CurrentThread.CurrentCulture = objCI;
                    Thread.CurrentThread.CurrentUICulture = objCI;

                    if (objdt.Rows[0]["SCObtained"].ToString() != "")
                    {
                        raddateobtained.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["SCObtained"].ToString());
                    }
                    if (objdt.Rows[0]["SCVaildFrom"].ToString()!="")
                    {
                        raddatevalidfrm.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["SCVaildFrom"].ToString());
                    }
                    if (objdt.Rows[0]["SCVaildTo"].ToString() != "")
                    {
                        raddatevalidto.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["SCVaildTo"].ToString());
                    }
                    RadEditorawards.Content = objdt.Rows[0]["AwardsandAchievements"].ToString();
                    Txtpersonalint.Text = objdt.Rows[0]["PersonalInterest"].ToString();
                    Chkcompskills.Checked = (Convert.ToBoolean(objdt.Rows[0]["ComputerSkill"].ToString()));
                    string str = objdt.Rows[0]["LanguageSkill"].ToString();
                    string[] arstr = new string[7];
                    char[] splitterpost = { ',' };
                    arstr = str.Split(splitterpost);
                    foreach (string smlng in arstr)
                    {
                        if (smlng != "")
                        {
                            ListLanguage.Items.FindByValue(smlng).Selected = true;
                        }
                    }
                }
            }
            catch { }
        }

        public void GetAssociationsdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAssoData(UserID);
                if (objdt.Rows.Count > 0)
                {


                    pnlAssogrid.Visible = true;
                    RadGridAsso.DataSource = objdt;
                    RadGridAsso.DataBind();
                }
                else
                {
                    pnlAssogrid.Visible = false;
                }

            }


            catch { }
        }

        public void GetLicencedata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetLicData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    Pnllicencegrid.Visible = true;
                    RadGridlicense.DataSource = objdt;
                    RadGridlicense.DataBind();
                }
                else
                {
                    Pnllicencegrid.Visible = false;
                }

            }
            catch { }
        }



        private void XmlCountry()
        {
            try
            {


                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                radcomcosountry.LoadXml(NodeIter1.Current.InnerXml);




            }
            catch
            {

            }

        }

        protected void imgaddvisa_Click(object sender, EventArgs e)
        {
            try
            {
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

                enablevisainfoform();
            }
            catch { }

        }
        protected void RadGridvisa_pageindexchanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            try
            {
                RadGridvisa.CurrentPageIndex = e.NewPageIndex;
                Getdata();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
            }
            catch { }

        }

        protected void RadGridAsso_pageindexchanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            try
            {
                RadGridAsso.CurrentPageIndex = e.NewPageIndex;

                GetAssociationsdata();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
            }
            catch { }

           
        }

        protected void RadGridlicense_pageindexchanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            try
            {
                RadGridlicense.CurrentPageIndex = e.NewPageIndex;


                GetLicencedata();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
            }
            catch { }

        }
      

        protected void btnvisaupdate_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnvisaupdate");
                this.WorkPermitName = Convert.ToString(RadGridvisa.MasterTableView.DataKeyValues[gr.ItemIndex]["WorkPermitName"]);

                getvisagriddata();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
                Getdata();
              
            }
            catch
            {
            }
        }

        protected void btnvisadelete_Click(object sender, EventArgs e)
        {
            try
            {


                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnvisaupdate");
                string WorkPermitName = Convert.ToString(RadGridvisa.MasterTableView.DataKeyValues[gr.ItemIndex]["WorkPermitName"]);
                AccountsetupFA objaccFA = new AccountsetupFA();
                objaccFA.deletevisaGridData(UserID, WorkPermitName);
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetVisaData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    panelvisa.Visible = true;
                    RadGridvisa.DataSource = objdt;
                    RadGridvisa.DataBind();
                }
                else
                {
                    panelvisa.Visible = false;
                }
                disablevisainfoform();

                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = ErrorMessage.GetiRsaErrorMessage(63);
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;


            }
            catch
            {
            }
        }

        protected void btnassoupdate_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnassoupdate");
                this.AName = Convert.ToString(RadGridAsso.MasterTableView.DataKeyValues[gr.ItemIndex]["AName"]);

                getassociationgriddata();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
                GetAssociationsdata(); 
            }

            catch
            {
            }
        }

        protected void btnassodelete_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnassoupdate");
                string AName = Convert.ToString(RadGridAsso.MasterTableView.DataKeyValues[gr.ItemIndex]["AName"]);
                AccountsetupFA objaccFA = new AccountsetupFA();
                objaccFA.deleteAssoGridData(UserID, AName);
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAssoData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    pnlAssogrid.Visible = true;
                    RadGridAsso.DataSource = objdt;
                    RadGridAsso.DataBind();
                }
                else
                {
                    pnlAssogrid.Visible = false;
                }
                disableAssociationsinform();
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = ErrorMessage.GetiRsaErrorMessage(63);
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

            }
            catch { }
        }

        protected void Imgaddassociation_Click(object sender, EventArgs e)
        {
            try
            {
                enableAssociationsinform();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

            }
            catch { }

        }

        protected void Imaddlicense_Click(object sender, EventArgs e)
        {
            try
            {
                enableLicenseform();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

            }
            catch { }

        }

        protected void btnlicenseupdate_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnlicenseupdate");
                this.LCName = Convert.ToString(RadGridlicense.MasterTableView.DataKeyValues[gr.ItemIndex]["LCName"]);
                getLicencegriddata();
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
                GetLicencedata();
                

            }
            catch
            {
            }
        }


        protected void btnlicensedelete_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btnlicenseupdate");
                string LCName = Convert.ToString(RadGridlicense.MasterTableView.DataKeyValues[gr.ItemIndex]["LCName"]);
                AccountsetupFA objaccFA = new AccountsetupFA();
                objaccFA.deletelicGridData(UserID, LCName);
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetLicData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    Pnllicencegrid.Visible = true;
                    RadGridlicense.DataSource = objdt;
                    RadGridlicense.DataBind();
                }
                else
                {
                    Pnllicencegrid.Visible = false;
                }
                disableLicenseform();
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = ErrorMessage.GetiRsaErrorMessage(63);
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

            }
            catch { }
        }

        protected void Previous_Click(object sender, EventArgs e)
        {
            savedata(headtext);
            Response.Redirect("AccountProjects.aspx");
        }
        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {
                if (strName.Length > 0)
                {
                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);
                }
            }
            catch { }
            return sb.ToString();
        }



        protected void Update_Click(object sender, EventArgs e)
        {
            try
            {
                headtext = "Additional1";
                savedata(headtext);
                Getdata();
            }
            catch { }
            
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetSCData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    RadEditorawards.Content = objdt.Rows[0]["AwardsandAchievements"].ToString();
                    Txtpersonalint.Text = objdt.Rows[0]["PersonalInterest"].ToString();
                    Chkcompskills.Checked = (Convert.ToBoolean(objdt.Rows[0]["ComputerSkill"].ToString()));
                    string str = objdt.Rows[0]["LanguageSkill"].ToString();
                    string[] arstr = new string[7];
                    char[] splitterpost = { ',' };
                    arstr = str.Split(splitterpost);
                    foreach (string smlng in arstr)
                    {
                        if (smlng != "" || smlng != " ")
                        {
                            ListLanguage.Items.FindByValue(smlng).Selected = true;
                        }
                    }
                }
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

            }
            catch { }
        }


        protected void Resetvisa_Click(object sender, EventArgs e)
        {
            if (this.WorkPermitName != "")
            {
                getvisagriddata();
            }
            else
            {
                disablevisainfoform();
            }
            Lbldatamodified.Visible = false;
            Lblwrkpermiterror.Visible = false;
            lblDateErrorS.Visible = false;

            Lblsecuritycl.Visible = false;
            LblerrSC.Visible = false;


            lblassocierr.Visible = false;
            Lblerrasso.Visible = false;
            lblliceror.Visible = false;
            Lblerrlic.Visible = false;

        }

        protected void ResetSC_Click(object sender, EventArgs e)
        {
            try
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetSCData(UserID);
                if (objdt.Rows.Count > 0)
                {
                    txtsecclname.Text = objdt.Rows[0]["SCName"].ToString();
                    txtissauth.Text = objdt.Rows[0]["SCIssuingAuthority"].ToString();
                    txtdesc.Text = objdt.Rows[0]["SCDescription"].ToString();
                    CULINFO = "en-GB";
                    CultureInfo objCI = new CultureInfo(CULINFO);
                    Thread.CurrentThread.CurrentCulture = objCI;
                    Thread.CurrentThread.CurrentUICulture = objCI;

                   if (objdt.Rows[0]["SCObtained"].ToString() != "")
                    {
                        raddateobtained.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["SCObtained"].ToString());
                    }
                    if (objdt.Rows[0]["SCVaildFrom"].ToString() != "")
                    {
                        raddatevalidfrm.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["SCVaildFrom"].ToString());
                    }
                    if (objdt.Rows[0]["SCVaildTo"].ToString() != "")
                    {
                        raddatevalidto.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["SCVaildTo"].ToString());
                    }
                }
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;

            }
            catch { }
        }

        protected void ResetAsso_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.AName != "")
                {
                    getassociationgriddata();
                }
                else
                {
                    disableAssociationsinform();
                }
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
            }
            catch { }

        }

        protected void ResetLic_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.LCName != "")
                {
                    getLicencegriddata();
                }
                else
                {
                    disableLicenseform();
                }
                Lbldatamodified.Visible = false;
                Lblwrkpermiterror.Visible = false;
                lblDateErrorS.Visible = false;

                Lblsecuritycl.Visible = false;
                LblerrSC.Visible = false;


                lblassocierr.Visible = false;
                Lblerrasso.Visible = false;
                lblliceror.Visible = false;
                Lblerrlic.Visible = false;
            }
            catch { }

        }

        protected void UpdateAsso_Click(object sender, EventArgs e)
        {
            try
            {
                headtext = "Additional3";
                savedata(headtext);
                GetAssociationsdata();
            }
            catch { }
          
            
        }

      
        protected void UpdateSC_Click(object sender, EventArgs e)
        {
            try
            {
                headtext = "Additional2";
                savedata(headtext);
                GetSecCleardata();
            }
            catch { }
        }

        protected void Updatelicense_Click(object sender, EventArgs e)
        {
            try
            {
                headtext = "Additional4";
                savedata(headtext);
                GetLicencedata();
            }
            catch { }
           
        }

        protected void UpdateAward_Click(object sender, EventArgs e)
        {
            try
            {
                headtext = "Additional5";
                savedata(headtext);
                GetSecCleardata();
            }
            catch { }
        }
        public void enablevisainfoform()
        {
            txnwrkpermit.ReadOnly = false;
            radcomcosountry.Enabled = true;
            RadDatewpvalidfrm.Enabled = true;
            RadDatewpvalidto.Enabled = true;
            txnwrkpermit.Text = "";
            radcomcosountry.SelectedIndex = 0;

            
        }
        public void disablevisainfoform()
        {
            txnwrkpermit.ReadOnly = true;
            radcomcosountry.Enabled = false;
            RadDatewpvalidfrm.Enabled = false;
            RadDatewpvalidto.Enabled = false;
           
            txnwrkpermit.Text = "";
            radcomcosountry.SelectedIndex = 0;
            RadDatewpvalidfrm.SelectedDate = null;
            RadDatewpvalidto.SelectedDate = null;

        }
        public void getvisagriddata()
        {
            try
            {
                txnwrkpermit.ReadOnly = false;
                radcomcosountry.Enabled = true;
                RadDatewpvalidfrm.Enabled = true;
                RadDatewpvalidto.Enabled = true;

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdtvisa = new DataTable();
                objdtvisa = objaccFA.GetvisaGridData(UserID, this.WorkPermitName);
                if (objdtvisa.Rows.Count > 0)
                {
                    txnwrkpermit.Text = objdtvisa.Rows[0]["WorkPermitName"].ToString();
                    radcomcosountry.SelectedValue = objdtvisa.Rows[0]["Country"].ToString();
                    CULINFO = "en-GB";
                    CultureInfo objCI = new CultureInfo(CULINFO);
                    Thread.CurrentThread.CurrentCulture = objCI;
                    Thread.CurrentThread.CurrentUICulture = objCI;

                    RadDatewpvalidfrm.SelectedDate = Convert.ToDateTime(objdtvisa.Rows[0]["ValidFrom"].ToString());
                    RadDatewpvalidto.SelectedDate = Convert.ToDateTime(objdtvisa.Rows[0]["ValidTo"].ToString());
                }
            }
            catch { }
        }
        public void enableAssociationsinform()
        {
            txtassoname.ReadOnly = false;
            txturl.ReadOnly = false;
            RadDatesince.Enabled = true;
            RadDateuntil.Enabled = true;
            txtassoname.Text = "";
            


        }
        public void disableAssociationsinform()
        {
            txtassoname.ReadOnly = true;
            txturl.ReadOnly = true;
            RadDatesince.Enabled = false;
            RadDateuntil.Enabled = false;

            txtassoname.Text = "";
            txturl.Text = "";
            RadDatesince.SelectedDate = null;
            RadDateuntil.SelectedDate = null;

        }
        public void enableLicenseform()
        {
            txtlicname.ReadOnly = false;
            txtlicid.ReadOnly = false;
            txtlicissuedby.ReadOnly = false;
            RadDatelicvalidfrm.Enabled = true;
            RadDatelicvalidto.Enabled = true;
            txtlicname.Text = "";
            txtlicid.Text = "";
            txtlicissuedby.Text = "";
         
        }
        public void disableLicenseform()
        {
            txtlicname.ReadOnly = true;
            txtlicid.ReadOnly = true;
            txtlicissuedby.ReadOnly = true;
            RadDatelicvalidfrm.Enabled = false;
            RadDatelicvalidto.Enabled = false;
            txtlicname.Text = "";
            txtlicid.Text = "";
            txtlicissuedby.Text = "";
            RadDatelicvalidfrm.SelectedDate = null;
            RadDatelicvalidto.SelectedDate = null;

        }
        public void getassociationgriddata()
        {
            try
            {
                txtassoname.ReadOnly = false;
                txturl.ReadOnly = false;
                RadDatesince.Enabled = true;
                RadDateuntil.Enabled = true;
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdtAsso = new DataTable();
                objdtAsso = objaccFA.GetAssoGridData(UserID, this.AName);
                if (objdtAsso.Rows.Count > 0)
                {
                    txtassoname.Text = objdtAsso.Rows[0]["AName"].ToString();
                    txturl.Text = objdtAsso.Rows[0]["AURL"].ToString();
                    CULINFO = "en-GB";
                    CultureInfo objCI = new CultureInfo(CULINFO);
                    Thread.CurrentThread.CurrentCulture = objCI;
                    Thread.CurrentThread.CurrentUICulture = objCI;

                    RadDatesince.SelectedDate = Convert.ToDateTime(objdtAsso.Rows[0]["ASinceDate"].ToString());
                    RadDateuntil.SelectedDate = Convert.ToDateTime(objdtAsso.Rows[0]["AUntilDate"].ToString());

                }
            }
            catch { }
        }
        public void getLicencegriddata()
        {
            try
            {
                txtlicname.ReadOnly = false;
                txtlicid.ReadOnly = false;
                txtlicissuedby.ReadOnly = false;
                RadDatelicvalidfrm.Enabled = true;
                RadDatelicvalidto.Enabled = true;
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdtlic = new DataTable();
                objdtlic = objaccFA.GetlicGridData(UserID, this.LCName);
                if (objdtlic.Rows.Count > 0)
                {
                    txtlicname.Text = objdtlic.Rows[0]["LCName"].ToString();
                    txtlicid.Text = objdtlic.Rows[0]["LCICAndName"].ToString();
                    txtlicissuedby.Text = objdtlic.Rows[0]["LCIssuedBy"].ToString();
                    CULINFO = "en-GB";
                    CultureInfo objCI = new CultureInfo(CULINFO);
                    Thread.CurrentThread.CurrentCulture = objCI;
                    Thread.CurrentThread.CurrentUICulture = objCI;

                    RadDatelicvalidfrm.SelectedDate = Convert.ToDateTime(objdtlic.Rows[0]["LCValidfrom"].ToString());
                    RadDatelicvalidto.SelectedDate = Convert.ToDateTime(objdtlic.Rows[0]["LCValidto"].ToString());

                }
            }
            catch { }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountProjects.aspx");
        }

        protected void btnFinish_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAccount.aspx");
        }

        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void getAccountAdditionalPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountAdditional");
                btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountAdditional");
                btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountAdditional");
                Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountAdditional");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountAdditional");
                Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccountAdditional");
                Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccountAdditional");
                Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccountAdditional");
                Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccountAdditional");
                Button7.Text = (string)GetGlobalResourceObject("PageResource", "Button7_AccountAdditional");
                Button8.Text = (string)GetGlobalResourceObject("PageResource", "Button8_AccountAdditional");
                //Bupre.Text = (string)GetGlobalResourceObject("PageResource", "Bupre_AccountProjects");
                //Bunxt.Text = (string)GetGlobalResourceObject("PageResource", "Bunxt_AccountProjects");
                //Update.Text = (string)GetGlobalResourceObject("PageResource", "Update_AccountProjects");
                //Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountProjects");
                Label55.Text = (string)GetGlobalResourceObject("PageResource", "Label55_AccountAdditional");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_AccountAdditional");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_AccountAdditional");
                Label38.Text = (string)GetGlobalResourceObject("PageResource", "Label38_AccountAdditional");
                Label40.Text = (string)GetGlobalResourceObject("PageResource", "Label40_AccountAdditional");
                Updatevisa.Text = (string)GetGlobalResourceObject("PageResource", "Updatevisa_AccountAdditional");
                Resetvisa.Text = (string)GetGlobalResourceObject("PageResource", "Resetvisa_AccountAdditional");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_AccountAdditional");
                Label74.Text = (string)GetGlobalResourceObject("PageResource", "Label74_AccountAdditional");
                Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label5_AccountAdditional");
                Label6.Text = (string)GetGlobalResourceObject("PageResource", "Label6_AccountAdditional");
                Label7.Text = (string)GetGlobalResourceObject("PageResource", "Label7_AccountAdditional");
                Label8.Text = (string)GetGlobalResourceObject("PageResource", "Label8_AccountAdditional");
                Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_AccountAdditional");
                UpdateSC.Text = (string)GetGlobalResourceObject("PageResource", "UpdateSC_AccountAdditional");
                ResetSC.Text = (string)GetGlobalResourceObject("PageResource", "ResetSC_AccountAdditional");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_AccountAdditional");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_AccountAdditional");
                Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_AccountAdditional");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_AccountAdditional");
                Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_AccountAdditional");
                UpdateAsso.Text = (string)GetGlobalResourceObject("PageResource", "UpdateAsso_AccountAdditional");
                ResetAsso.Text = (string)GetGlobalResourceObject("PageResource", "ResetAsso_AccountAdditional");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_AccountAdditional");
                Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label18_AccountAdditional");
                Label19.Text = (string)GetGlobalResourceObject("PageResource", "Label19_AccountAdditional");
                Label20.Text = (string)GetGlobalResourceObject("PageResource", "Label20_AccountAdditional");
                Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_AccountAdditional");
                Label22.Text = (string)GetGlobalResourceObject("PageResource", "Label22_AccountAdditional");
                Updatelicense.Text = (string)GetGlobalResourceObject("PageResource", "Updatelicense_AccountAdditional");
                ResetLic.Text = (string)GetGlobalResourceObject("PageResource", "ResetLic_AccountAdditional");
                Label23.Text = (string)GetGlobalResourceObject("PageResource", "Label23_AccountAdditional");
                Label26.Text = (string)GetGlobalResourceObject("PageResource", "Label26_AccountAdditional");
                Label27.Text = (string)GetGlobalResourceObject("PageResource", "Label27_AccountAdditional");
                lblCharLeft.Text = (string)GetGlobalResourceObject("PageResource", "lblCharLeft_AccountAdditional");
                Label28.Text = (string)GetGlobalResourceObject("PageResource", "Label28_AccountAdditional");
                Label29.Text = (string)GetGlobalResourceObject("PageResource", "Label29_AccountAdditional");
                Chkcompskills.Text = (string)GetGlobalResourceObject("PageResource", "Chkcompskills_AccountAdditional");
                btnFinish.Text = (string)GetGlobalResourceObject("PageResource", "btnFinish_AccountAdditional");
                btnNext.Text = (string)GetGlobalResourceObject("PageResource", "btnNext_AccountAdditional");
                Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountAdditional");
                UpdateAward.Text = (string)GetGlobalResourceObject("PageResource", "UpdateAward_AccountAdditional");
                Imaddlicense.Text = (string)GetGlobalResourceObject("PageResource", "ImageButton3_AccountAcademics");
                Imgaddassociation.Text = (string)GetGlobalResourceObject("PageResource", "ImageButton3_AccountAcademics");
                imgaddvisa.Text = (string)GetGlobalResourceObject("PageResource", "ImageButton3_AccountAcademics");
                RadGridvisa.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdworkpermit_accadd");
                RadGridvisa.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdcountry_accadd");
                RadGridvisa.Columns[2].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdvalidto_accadd");
                RadGridvisa.Columns[3].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdvalidfrm_accadd");
                //RadGridAsso.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdvalidfrm_accadd");
                RadGridAsso.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdasso_accadd");
                RadGridAsso.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdURL_accadd");
                RadGridAsso.Columns[2].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdSINCE_accadd");
                RadGridAsso.Columns[3].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdTO_accadd");
                RadGridlicense.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdLIC_accadd");
                RadGridlicense.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdlicid_accadd");
                RadGridlicense.Columns[2].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdissby_accadd");
                RadGridvisa.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
                RadGridvisa.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
                RadGridvisa.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "grid_pagetext");
                RadGridAsso.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
                RadGridAsso.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
                RadGridAsso.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "grid_pagetext");
                RadGridlicense.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
                RadGridlicense.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
                RadGridlicense.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "grid_pagetext");
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
            }
            catch
            {
            }
        }
    }
}
