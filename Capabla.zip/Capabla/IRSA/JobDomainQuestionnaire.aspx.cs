﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using Telerik.Web.UI;
using System.Collections;
using IRSA.Shared;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Resources;
using IRSA.BussinessLogic;
using System.Configuration;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class JobDomainQuestionnaire : System.Web.UI.Page
    {
        string Reportpath;
        string directorypath;
        public string cultureid = "EN";
        int UserID;
        string CULINFO;
        public string Cultinfo;
        int quescount;
        string EID;
        string questemplate="Job-domain Specific";
        string quesName = "Domain-Specific";
        string Assessmentxml = "TooltipMsgAssessmentCentre.xml";
        public int RecuriterID
        {
            set
            {
                ViewState["RecuriterID"] = value;
            }
            get
            {
                if (ViewState["RecuriterID"] == null)
                {
                    ViewState["RecuriterID"] = 0;
                }
                return Convert.ToInt32(ViewState["RecuriterID"].ToString());
            }

        }
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }

        public string JobOccupation
        {
            set
            {
                ViewState["JobOccupation"] = value;
            }
            get
            {
                if (ViewState["JobOccupation"] == null)
                {
                    ViewState["JobOccupation"] = "";
                }
                return ViewState["JobOccupation"].ToString();
            }
        }
        public int OccupationID
        {
            set
            {
                ViewState["OccupationID"] = value;
            }
            get
            {
                if (ViewState["OccupationID"] == null)
                {
                    ViewState["OccupationID"] = 0;
                }
                return Convert.ToInt32(ViewState["OccupationID"].ToString());
            }
        }
        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public int coquestioncount
        {
            set
            {
                ViewState["coquestioncount"] = value;
            }
            get
            {
                if (ViewState["coquestioncount"] == null)
                {
                    ViewState["coquestioncount"] = 0;
                }
                return Convert.ToInt32(ViewState["coquestioncount"].ToString());
            }
        }
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public int AttemptID
        {
            set
            {
                ViewState["AttemptID"] = value;
            }
            get
            {
                if (ViewState["AttemptID"] == null)
                {
                    ViewState["AttemptID"] = 1;
                }
                return Convert.ToInt32(ViewState["AttemptID"].ToString());
            }
        }
        string str;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {   
                

                UserID = SessionInfo.UserId;
                if (Request.QueryString.Get("id") != null)
                {
                    str = Request.QueryString.Get("id").ToString();
                }
                if (str != "" || str != null)
                {
                    this.RecuriterID = Convert.ToInt32(str);
                }
                //GetiRsaToolTipAssMsg();
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }

                







                EID = "4.A.[1-9].[a-z].%";
                


                LblquestionnaireName.Text = quesName;
                Lblqu.Text = quesName;
                LblMsg.Visible = false;

                //GetUserAttemptIDfromsubmissonList();
                if (!IsPostBack)
                {
                    Comboboxbind();
                    
                }
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable Getdt = new DataTable();
                GetUserAttemptIDfromsubmissonList();
                Getdt = objskillFA.GetSubmitStatus(questemplate, AttemptID);
                quescount = Getdt.Rows.Count;
            }
            catch { }
        }
        
        public void Comboboxbind()
        {
            try
            {
                SkillQuestionnaireFA objFA = new SkillQuestionnaireFA();
                DataTable temp = new DataTable();
                temp = objFA.BindJobFamilyData();
                ComboJobFamily.DataSource = temp;
                ComboJobFamily.DataBind();
                OccupationID = Convert.ToInt32(ComboJobFamily.SelectedValue.ToString());
            }
            catch
            {
            }
        }
        public void GetUserAttemptIDfromsubmissonList()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable dtattempt = new DataTable();
                dtattempt = objskillFA.GetUserAttemptIDfromsubmissonList(UserID, questemplate);
                if (dtattempt.Rows.Count > 0)
                {
                    AttemptID = Convert.ToInt32(dtattempt.Rows[0]["AttemptID"].ToString());
                }
            }
            catch { }
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    Grid_Questionnairebind();

                }
                getPageLanguageInfo();

                SelectQuestionnaireRadioList();
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable Getdt = new DataTable();
                Getdt = objskillFA.GetSubmitStatus(questemplate, AttemptID);
                quescount = Getdt.Rows.Count;
                if (quescount == TotalCount)
                {
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = false;

                    BtnworkcontexReport.Enabled = true;
                }
                else
                {
                    btnSave.Enabled = true;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = true;

                    BtnworkcontexReport.Enabled = false;
                }
                if (TotalCount == SelectedParentRecord.Count)
                {
                    if (quescount == TotalCount)
                    {

                        btnSubmit.Enabled = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;

                        BtnworkcontexReport.Enabled = true;
                    }
                    else
                    {
                        btnSubmit.Enabled = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;

                        BtnworkcontexReport.Enabled = false;
                    }
                }
                else
                {
                    btnSubmit.Enabled = false;
                    btnSave.Enabled = true;
                    btnReset.Enabled = true;

                    BtnworkcontexReport.Enabled = false;
                }
            }
            catch
            {
            }
        }
        private void GetiRsaToolTipAssMsg()
        {
            try
            {
                Label9.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Assessmentxml);
                //Label12.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(15, Assessmentxml);
                //Label13.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(16, Assessmentxml);
                //Label14.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(17, Assessmentxml);
                //Label91.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(10, Assessmentxml);
                Label2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(11, Assessmentxml);
                Label3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(12, Assessmentxml);
                Label10.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(18, Assessmentxml);
                Label11.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(13, Assessmentxml);
            }
            catch { }
        }
        public void Grid_Questionnairebind()
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    GetSavedData();
                }

                JobdomainFA objskillFA = new JobdomainFA();
                DataTable temp = new DataTable();

                temp = objskillFA.GetJobdomainQuestionnaireData(EID);
                TotalCount = temp.Rows.Count;
                Grid_Questionnaire.DataSource = temp;
                Grid_Questionnaire.DataBind();
                if (quescount == TotalCount)
                {
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = false;

                    BtnworkcontexReport.Enabled = true;
                }
                else
                {
                    btnSave.Enabled = true;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = true;

                    BtnworkcontexReport.Enabled = false;
                }
                if (TotalCount == SelectedParentRecord.Count)
                {
                    if (quescount == TotalCount)
                    {

                        btnSubmit.Enabled = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;

                        BtnworkcontexReport.Enabled = true;
                    }
                    else
                    {
                        btnSubmit.Enabled = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;

                        BtnworkcontexReport.Enabled = false;
                    }
                }
                else
                {
                    btnSubmit.Enabled = false;
                    btnSave.Enabled = true;
                    btnReset.Enabled = true;

                    BtnworkcontexReport.Enabled = false;
                }
            }
            catch { }
        }




        protected void rb1_list_selectedindexchanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);

                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");
                eid = Grid_Questionnaire.MasterTableView.DataKeyValues[gr.ItemIndex]["ElementID"].ToString();

                if (objrb2.SelectedValue != "")
                {
                    if (CRecordCount < TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(eid);
                        }
                        CRecordCount++;
                        SaveRecord(eid, objrb2.SelectedValue);
                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCount--;
                        RemoveRecord(eid);
                    }
                }

                SelectQuestionnaireRadioList();
                Grid_Questionnairebind();
            }
            catch { }
        }

        protected void Grid_Questionnaire_pageindexchanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                Grid_Questionnaire.CurrentPageIndex = e.NewPageIndex;
                int i = e.NewPageIndex + 1;
                int j = i - 1;


                Grid_Questionnairebind();
                SelectQuestionnaireRadioList();
            }
            catch
            { }
        }

        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }


        private void DeleteAllRecord()
        {
            if (SelectedParentRecord.Count > 0)
            {

                SelectedParentRecord.Clear();
                CRecordCount = 0;
            }

        }
        private void SelectQuestionnaireRadioList()
        {
            try
            {
                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < Grid_Questionnaire.MasterTableView.Items.Count; i++)
                    {
                        string eid = Grid_Questionnaire.MasterTableView.DataKeyValues[i]["ElementID"].ToString();


                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            RadioButtonList obj1 = (RadioButtonList)Grid_Questionnaire.Items[i].FindControl("rb1_list");
                            obj1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch { }
        }





        protected void btnSubmit_click(object sender, EventArgs e)
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();

                string scaleid = "LV";
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                if (TotalCount == SelectedParentRecord.Count)
                {

                    if (SelectedParentRecord.Count > 0)
                    {

                        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                        while (Enumerator.MoveNext())
                        {
                            objskill.QuestionnaireTemplate = questemplate;
                            objskill.ElementID = Enumerator.Key.ToString();
                            objskill.ScaleID = scaleid;
                            objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                            objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            objskill.Status = "Submit";
                            objskill.AttemptID = AttemptID;
                            objskill.jobID = OccupationID;
                            objskillFA.InsertWorkActivityQuestionnaire(objskill);

                        }
                        objskillFA.InsertQuesSubmissionList(objskill);
                    }


                    LblMsg.Visible = true;
                    LblMsg.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(1);// "Answer Submitted Successfylly";
                    btnReset.Enabled = false;
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    SessionInfo.AttemptID = AttemptID;
                    SessionInfo.JobfamilyIDforjobDomain = OccupationID.ToString();
                    BtnworkcontexReport.Enabled = true;
                }
                sendmailtoRecuriter();

            }
            catch { }
        }

        private void GetSavedData()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable Getdt = new DataTable();
                Getdt = objskillFA.GetSubmitStatus(questemplate, AttemptID);
                quescount = Getdt.Rows.Count;
                if (Getdt.Rows.Count > 0)
                {
                    for (int i = 0; i < Getdt.Rows.Count; i++)
                    {
                        string ElementID = Getdt.Rows[i]["ElementID"].ToString();
                        string DataValue = Getdt.Rows[i]["DataValue"].ToString();
                        CRecordCount++;
                        SaveRecord(ElementID, DataValue);

                    }
                }

            }
            catch
            { }

        }



        protected void btnReset_click(object sender, EventArgs e)
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();

                string scaleid = "LV";
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        objskill.QuestionnaireTemplate = questemplate;
                        objskill.ElementID = Enumerator.Key.ToString();
                        objskill.ScaleID = scaleid;
                        objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        objskill.AttemptID = AttemptID;
                        objskillFA.DeleteskillQues(objskill);
                    }
                }


                DeleteAllRecord();
                LblMsg.Visible = true;
                LblMsg.Text = ErrorMessage.GetiRsaErrorMessage(73);
                Grid_Questionnairebind();
                BtnworkcontexReport.Enabled = false;
            }
            catch { }
        }





        protected void btnSave_click(object sender, EventArgs e)
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();

                string scaleid = "LV";
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        objskill.QuestionnaireTemplate = questemplate;
                        objskill.ElementID = Enumerator.Key.ToString();
                        objskill.ScaleID = scaleid;
                        objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        objskill.Status = "Save";
                        objskill.AttemptID = AttemptID;
                        objskill.jobID = OccupationID;
                        objskillFA.InsertWorkActivityQuestionnaire(objskill); ;

                    }
                    objskillFA.InsertQuesSubmissionList(objskill);
                }

                LblMsg.Visible = true;
                LblMsg.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(2);// "Answers Saved Successfylly";


                SelectQuestionnaireRadioList();
                Grid_Questionnairebind();
            }
            catch { }
        }
        public void sendmailtoRecuriter()
        {
            SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
            objskillFA.InboxcandidateAssessmentCompleted(UserID,this.RecuriterID);
        }
        protected void getPageLanguageInfo()
        {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
            Lblques.Text = (string)GetGlobalResourceObject("PageResource", "Lblques_Questionnaire");
            Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_JobDomainQuestionnaire");
            Grid_Questionnaire.Columns[1].HeaderText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire1");
            Grid_Questionnaire.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
            Grid_Questionnaire.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
            Grid_Questionnaire.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire4");
            BtnworkcontexReport.Text = (string)GetGlobalResourceObject("PageResource", "BtnworkcontexReport_Questionnaire");
            lblquess.Text = (string)GetGlobalResourceObject("PageResource", "lblquess_Questionnaire");
            btnSave.Text = (string)GetGlobalResourceObject("PageResource", "btnSave_Questionnaire");
            btnSubmit.Text = (string)GetGlobalResourceObject("PageResource", "btnSubmit_Questionnaire");
            btnReset.Text = (string)GetGlobalResourceObject("PageResource", "btnReset_Questionnaire");
            Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_Questionnaire");
           // Label91.Text = (string)GetGlobalResourceObject("PageResource", "Label1_Questionnaire");
            Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_Questionnaire");
            Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_Questionnaire");
            Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_Questionnaire");
            Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_Questionnaire");
            Label123.Text = (string)GetGlobalResourceObject("PageResource", "Label123_Questionnaire");
            Label1234.Text = (string)GetGlobalResourceObject("PageResource", "Label1234_Questionnaire");
           // Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_JobDomainQuestionnaire");
           // Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_JobDomainQuestionnaire");
           // Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_JobDomainQuestionnaire");
            Lbljobfamilly.Text = (string)GetGlobalResourceObject("PageResource", "Lbljobfamilly_JobDomainQuestionnaire");
            btnSave.ToolTip = (string)GetGlobalResourceObject("PageResource", "btnSave_Questionnaire");
            btnSubmit.ToolTip = (string)GetGlobalResourceObject("PageResource", "btnSubmit_Questionnaire");
            btnReset.ToolTip = (string)GetGlobalResourceObject("PageResource", "btnReset_Questionnaire");
            LblquestionnaireName.Text = (string)GetGlobalResourceObject("PageResource", "LblquestionnaireName_JobdomainQuestionnaire");
            Lblqu.Text = (string)GetGlobalResourceObject("PageResource", "Lblqu_JobdomainQuestionnaire");
            for (int i = 0; i < Grid_Questionnaire.MasterTableView.Items.Count; i++)
            {




                RadioButtonList obj1 = (RadioButtonList)Grid_Questionnaire.Items[i].FindControl("rb1_list");
                obj1.ToolTip = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire5"); 

            }
        }
    }
}
