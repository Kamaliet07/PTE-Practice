﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using IRSA.Facade;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using Telerik.Web.UI;
using AjaxControlToolkit;

namespace IRSA
{
    public partial class DigitalAdvisor : System.Web.UI.Page
    {
        public DataTable Category
        {
            set
            {
                ViewState["Category"] = value;
            }
            get
            {

                return (DataTable)ViewState["Category"];
            }
        }

        public string TopicName
        {
            set
            {
                ViewState["TopicName"] = value;
            }
            get
            {
                if (ViewState["TopicName"] == null)
                {
                    ViewState["TopicName"] = string.Empty;
                }
                return ViewState["TopicName"].ToString();
            }
        }

        public string Situation
        {
            set
            {
                ViewState["Situation"] = value;
            }
            get
            {
                if (ViewState["Situation"] == null)
                {
                    ViewState["Situation"] = string.Empty;
                }
                return ViewState["Situation"].ToString();
            }
        }

        public string Status
        {
            set
            {
                ViewState["Status"] = value;
            }
            get
            {
                if (ViewState["Status"] == null)
                {
                    ViewState["Status"] = string.Empty;
                }
                return ViewState["Status"].ToString();
            }
        }
        public int CategoryId
        {
            set
            {
                ViewState["CategoryId"] = value;
            }
            get
            {
                if (ViewState["CategoryId"] == null)
                {
                    ViewState["CategoryId"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["CategoryId"].ToString());
            }
        }

        public int PageID
        {
            set
            {
                ViewState["PageID"] = value;
            }
            get
            {
                if (ViewState["PageID"] == null)
                {
                    ViewState["PageID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["PageID"].ToString());
            }
        }
        public int Rating
        {
            set
            {
                ViewState["Rating"] = value;
            }
            get
            {
                if (ViewState["Rating"] == null)
                {
                    ViewState["Rating"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["Rating"].ToString());
            }
        }
        public int TopicId
        {
            set
            {
                ViewState["TopicId"] = value;
            }
            get
            {
                if (ViewState["TopicId"] == null)
                {
                    ViewState["TopicId"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["TopicId"].ToString());
            }
        }
        public DataTable Topic
        {
            get { return (DataTable)ViewState["Topic"]; }
            set { ViewState["Topic"] = value; }
        }

        public DataTable GetUserSituation
        {
            get { return (DataTable)ViewState["GetUserSituation"]; }
            set { ViewState["GetUserSituation"] = value; }
        }

        public DataTable GetUserSavedAdvise
        {
            get { return (DataTable)ViewState["GetUserSavedAdvise"]; }
            set { ViewState["GetUserSavedAdvise"] = value; }
        }

        public DataTable GetQuickTips
        {
            get { return (DataTable)ViewState["GetQuickTips"]; }
            set { ViewState["GetQuickTips"] = value; }
        }
        public DataTable SituationSolution
        {
            get { return (DataTable)ViewState["SituationSolution"]; }
            set { ViewState["SituationSolution"] = value; }
        }
        public DataTable QuickTipsSituation
        {
            get { return (DataTable)ViewState["QuickTipsSituation"]; }
            set { ViewState["QuickTipsSituation"] = value; }
        }

        public DataTable GetUserSavedDataUserID
        {
            get { return (DataTable)ViewState["GetUserSavedDataUserID"]; }
            set { ViewState["GetUserSavedDataUserID"] = value; }
        }
        public DataTable GetUserPurchageDetail
        {
            get { return (DataTable)ViewState["GetUserPurchageDetail"]; }
            set { ViewState["GetUserPurchageDetail"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                int UserID = SessionInfo.UserId;
                this.PageID = 101;//SessionInfo.PageID;
                if (UserID != int.MinValue)
                {
                    Lblmember.Text = SessionInfo.FirstName + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
                if (!Page.IsPostBack)
                {
                    if (!Page.IsPostBack)
                    {
                        this.Category = GetCategory();

                        this.GetUserSavedAdvise = GetPreviousSaveAdvise();
                        BindGrids();
                        GetUserPurchageDetailInfo();
                    }
                }


            }
            catch
            {


            }

        }

        private void GetUserPurchageDetailInfo()
        {
            this.GetUserPurchageDetail = GetAmountPurchageAndUsed();
            if (this.GetUserPurchageDetail.Rows.Count != 0)
            {

                LblPurch.Text = this.GetUserPurchageDetail.Rows[0]["Quantity"].ToString();
                LblSave.Text = this.GetUserPurchageDetail.Rows[0]["UsedQuantity"].ToString();
                int difference = Convert.ToInt32(this.GetUserPurchageDetail.Rows[0]["Difference"].ToString());
                if (difference == 0)
                {
                    ImageButton4.Enabled = false;

                }

            }
            else
            {
                Response.Redirect("DigitalAdvisorInfo.aspx");
            }
        }

        private DataTable GetAmountPurchageAndUsed()
        {
            DigitalAdvisorFA objAdvise = new DigitalAdvisorFA();
            DataTable PurchInfo = objAdvise.GetAmountPurchageAndUsed(SessionInfo.UserId, this.PageID);

            return PurchInfo;
        }


        private DataTable GetPreviousSaveAdvise()
        {
            DigitalAdvisorFA objAdvise = new DigitalAdvisorFA();
            DataTable Advise = objAdvise.GetPreviousSaveUserAdvise();

            return Advise;
        }


        private DataTable GetCategory()
        {
            DigitalAdvisorFA objcategory = new DigitalAdvisorFA();
            DataTable temp = objcategory.getDetCategory();

            return temp;
        }

        private void BindGrids()
        {
            try
            {
                this.RadGridCategory.DataSource = this.Category;
                this.RadGridCategory.DataBind();



                this.RadGridRecentAdvise.DataSource = this.GetUserSavedAdvise;
                this.RadGridRecentAdvise.DataBind();

                BindTopicGridAccFristCatrg();
                FillDefaultSituation();

            }
            catch
            {


            }
        }

        private void FillDefaultSituation()
        {
            this.TopicId = Convert.ToInt32(this.Topic.Rows[0]["DATopicID"].ToString());
            this.SituationSolution = GetSituation(this.TopicId);
            FillSituationInfo();
        }

        private void BindTopicGridAccFristCatrg()
        {
            this.CategoryId = Convert.ToInt32(this.Category.Rows[0]["CatagoryID"].ToString());
            this.Topic = GetTopic(this.CategoryId);
            FillCategoryGrid();
        }
        private static DataTable EmptyCategory()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("CatagoryID", typeof(int)));
            objDT.Columns.Add(new DataColumn("CatagoryName", typeof(string)));
            return objDT;

        }
        private static DataTable EmptyCategoryGroup()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("DATopicID", typeof(int)));
            objDT.Columns.Add(new DataColumn("DaTopicName", typeof(string)));
            return objDT;

        }
        private static DataTable EmptySituationGroup()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("Situation", typeof(string)));
            return objDT;

        }
        private static DataTable EmptyUserSavedData()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("CatagoryName", typeof(string)));
            objDT.Columns.Add(new DataColumn("DaTopicName", typeof(string)));
            objDT.Columns.Add(new DataColumn("CategoryID", typeof(int)));
            objDT.Columns.Add(new DataColumn("DATopicID", typeof(int)));
            objDT.Columns.Add(new DataColumn("Rating", typeof(int)));
            return objDT;

        }
        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (this.CategoryId == int.MinValue)
                {
                    string scriptstring1 = "radalert('Please Select Category <b></b><b>!</b>', 310, 150);";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);
                    //LblError.Text = "Please Select Category";                 
                }
                else
                {
                    if (this.TopicId == int.MinValue)
                    {
                        string scriptstring1 = "radalert('Please Select Topic <b></b><b>!</b>', 310, 150);";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);
                        // LblError.Text = "Please Select Topic";
                    }
                    else
                    {
                        if (this.TopicName == string.Empty && this.Situation == string.Empty && this.Status == string.Empty)
                        {
                            string scriptstring1 = "radalert('Please Select Situation <b></b><b>!</b>', 310, 150);";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);
                            //LblError.Text = "Please Select Situation";
                        }
                        else
                        {
                            if (SessionInfo.Rating == int.MinValue)
                            {
                                string scriptstring1 = "radalert('Please Rate Your Advise <b></b><b>!</b>', 310, 150);";
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);
                                // LblError.Text = "Please Rate Your Advise";
                            }
                            else
                            {
                                if (TextBoxAdviseName.Text == "")
                                {
                                    string scriptstring1 = "radalert('Please Write Advise Name <b></b><b>!</b>', 310, 150);";
                                    ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);
                                    //LblError.Text = "Please Write Advise Name";
                                }
                                else
                                {

                                    DigitalAdvisorSH objdigSH = new DigitalAdvisorSH();
                                    objdigSH.AdviseName = TextBoxAdviseName.Text;
                                    objdigSH.AdviseRate = SessionInfo.Rating;
                                    objdigSH.CategoryID = this.CategoryId;
                                    objdigSH.TopicID = this.TopicId;
                                    DataTable objsit = new DataTable();
                                    objsit = EmptySituationGroup();
                                    if (this.TopicName != string.Empty)
                                    {
                                        DataRow ndr = objsit.NewRow();
                                        ndr["Situation"] = this.Status;
                                        objsit.Rows.InsertAt(ndr, 0);
                                    }
                                    if (this.Situation != string.Empty)
                                    {
                                        DataRow ndr2 = objsit.NewRow();
                                        ndr2["Situation"] = this.Situation;
                                        objsit.Rows.InsertAt(ndr2, 0);
                                    }
                                    if (this.Status != string.Empty)
                                    {
                                        DataRow ndr3 = objsit.NewRow();
                                        ndr3["Situation"] = this.TopicName;
                                        objsit.Rows.InsertAt(ndr3, 0);
                                    }
                                    DigitalAdvisorFA objAdviseSave = new DigitalAdvisorFA();
                                    int userID = IRSA.Common.GlobalFunction.SessionInfo.UserId;
                                    objAdviseSave.SaveUserAdviseAccUserID(objdigSH, objsit, userID);
                                    DigitalAdvisorFA objAdvisePurchUpdate = new DigitalAdvisorFA();
                                    objAdvisePurchUpdate.UpdateUserPurchageDetail(userID, this.PageID);
                                    BindAdviseGridForNewEntry();
                                    GetUserPurchageDetailInfo();
                                    //LblError.Text = "Your Advise Saved Successfully";
                                }

                            }
                        }

                    }

                }



            }

            catch
            {


            }
        }

        private void BindAdviseGridForNewEntry()
        {
            this.GetUserSavedAdvise = GetPreviousSaveAdvise();
            this.RadGridRecentAdvise.DataSource = this.GetUserSavedAdvise;
            this.RadGridRecentAdvise.DataBind();
        }


        protected void MyAccordion_ItemCreated(object sender, AccordionItemEventArgs e)
        {

        }

        protected void MyAccordion_ItemCommand(object sender, CommandEventArgs e)
        {

        }


        private void BindUserSavedData()
        {
            if (this.GetUserSavedDataUserID.Rows.Count > 0)
            {
                BingUserSelectedFields();
                BindRating();
                BindSituationLevelText();
            }

            if (this.GetQuickTips.Rows.Count > 0)
            {
                BindFieldInTipsCollection();
            }
            if (this.GetUserSituation.Rows.Count > 0)
            {
                BindRadioButton();

            }
        }

        private void BindSituationLevelText()
        {
            LabelWhat.Text = this.GetUserSavedDataUserID.Rows[0]["What"].ToString();
            LabelHow.Text = this.GetUserSavedDataUserID.Rows[0]["How"].ToString();
        }

        private void BindRadioButton()
        {
            DataTable situation = new DataTable();
            situation = this.GetUserSituation;
            RadioButnTopic.ClearSelection();
            RadioButtonSituation.ClearSelection();
            RadioButtonListStatus.ClearSelection();
            RadioButnTopic.SelectedValue = situation.Rows[0]["DASituation"].ToString().Trim();
            RadioButtonSituation.SelectedValue = situation.Rows[1]["DASituation"].ToString().Trim();
            RadioButtonListStatus.SelectedValue = situation.Rows[2]["DASituation"].ToString().Trim();

        }

        private void BindRating()
        {
            DataTable fetchdata = new DataTable();
            fetchdata = this.GetUserSavedDataUserID;
            ThaiRating.CurrentRating = Convert.ToInt32(fetchdata.Rows[0]["Rating"]);
            ThaiRating.ReadOnly = true;
        }



        private void BingUserSelectedFields()
        {
            DataTable fetchdata = new DataTable();
            fetchdata = this.GetUserSavedDataUserID;
            DataTable cat = new DataTable();
            cat = EmptyCategory();
            DataTable top = new DataTable();
            top = EmptyCategoryGroup();

            foreach (DataRow cdr in fetchdata.Rows)
            {
                DataRow ndrcat = cat.NewRow();
                ndrcat["CatagoryID"] = cdr["CategoryID"].ToString();
                ndrcat["CatagoryName"] = cdr["CatagoryName"].ToString();
                cat.Rows.InsertAt(ndrcat, 0);

            }
            foreach (DataRow tdr in fetchdata.Rows)
            {
                DataRow ndrtop = top.NewRow();
                ndrtop["DATopicID"] = tdr["DATopicID"].ToString();
                ndrtop["DaTopicName"] = tdr["DaTopicName"].ToString();
                top.Rows.InsertAt(ndrtop, 0);

            }


            this.RadGridCategory.DataSource = cat;
            this.RadGridCategory.DataBind();
            this.RadGridTopic.DataSource = top;
            this.RadGridTopic.DataBind();

        }


        private DataTable GetUserSituationSaved(int DAdviceID)
        {
            DigitalAdvisorFA objUserSavedSituation = new DigitalAdvisorFA();
            DataTable objuserSittemp = objUserSavedSituation.GetUserSituationAccrAdviceID(DAdviceID);
            return objuserSittemp;

        }

        private DataTable GetUserSavedQuickTipsAccrAdviceID(int DAdviceID)
        {
            DigitalAdvisorFA objUserSavedQuickTips = new DigitalAdvisorFA();
            DataTable objusertemp = objUserSavedQuickTips.GetUserSavedQuickTipsAccrAdviceID(DAdviceID);
            return objusertemp;
        }

        private DataTable GetUserSavedDataAccrAdviceID(int DAdviceID)
        {
            DigitalAdvisorFA objUserSavedData = new DigitalAdvisorFA();
            DataTable objusertempdata = objUserSavedData.GetUserSavedDataAccrAdviceIDAccrAdviceID(DAdviceID);
            return objusertempdata;
        }


        private void FillCategoryGrid()
        {
            DataTable objempty = new DataTable();
            objempty = EmptyCategoryGroup();
            this.RadGridTopic.DataSource = objempty;
            this.RadGridTopic.DataBind();
            if (this.Topic.Rows.Count > 0)
            {
                this.RadGridTopic.DataSource = this.Topic;
                this.RadGridTopic.DataBind();

            }
        }

        private DataTable GetTopic(int top)
        {
            DigitalAdvisorFA objcategory = new DigitalAdvisorFA();
            DataTable Top = objcategory.getDetTopic(top);
            return Top;
        }

        protected void radAjaxManager_AjaxRequest(object sender, AjaxRequestEventArgs e)
        {

        }


        private void FillSituationInfo()
        {
            DataTable objsituation = new DataTable();
            objsituation = this.SituationSolution;
            if (objsituation.Rows.Count > 0)
            {
                LabelWhat.Text = objsituation.Rows[0]["What"].ToString();
                LabelHow.Text = objsituation.Rows[0]["How"].ToString();

            }
        }

        private DataTable GetSituation(int topcID)
        {
            DigitalAdvisorFA objSitu = new DigitalAdvisorFA();
            DataTable Situation = objSitu.getSituationSelect(topcID);

            return Situation;
        }


        protected void RadioButnTopic_selectedindexchanged(object sender, EventArgs e)
        {
            this.TopicName = RadioButnTopic.SelectedItem.Value;
        }

        protected void RadioButtonSituation_selectedindexchanged(object sender, EventArgs e)
        {
            this.Situation = RadioButtonSituation.SelectedItem.Value;
        }

        protected void RadioButtonListStatus_selectedindexchanged(object sender, EventArgs e)
        {
            this.Status = RadioButtonListStatus.SelectedItem.Value;
        }

        protected void ImageButtonFindTips_Click(object sender, ImageClickEventArgs e)
        {
            if (this.TopicId == int.MinValue)
            {
                string scriptstring1 = "radalert('Please Select Topic  <b></b><b>!</b>', 310, 150);";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);

            }
            else if (this.TopicName == string.Empty || this.Situation == string.Empty || this.Status == string.Empty)
            {
                string scriptstring1 = "radalert('Please Select Appropriate Selection From Each Row <b></b><b>!</b>', 310, 150);";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring1, true);

            }

            else
            {

                this.GetQuickTips = GetUserQuickTipsAccordingTopicID();
                BindFieldInTipsCollection();

            }
        }
        private static DataTable EmptyTips()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("DAQuickTipsID", typeof(int)));
            objDT.Columns.Add(new DataColumn("DAQuickTipsName", typeof(string)));
            return objDT;

        }
        private void BindFieldInTipsCollection()
        {
            int count = 0;
            int agcount = 0;
            DataTable TotalTips = new DataTable();
            TotalTips = this.GetQuickTips;
            int spit = TotalTips.Rows.Count / 3;
            DataTable Tips1 = new DataTable();
            Tips1 = EmptyTips();
            DataTable Tips2 = new DataTable();
            Tips2 = EmptyTips();
            DataTable Tips3 = new DataTable();
            Tips3 = EmptyTips();
            for (int i = 0; i < TotalTips.Rows.Count; i++)
            {

                if (count < spit)
                {
                    DataRow ndr = Tips1.NewRow();
                    ndr["DAQuickTipsID"] = TotalTips.Rows[i]["DAQuickTipsID"].ToString();
                    ndr["DAQuickTipsName"] = TotalTips.Rows[i]["DAQuickTipsName"].ToString();
                    Tips1.Rows.InsertAt(ndr, 0);
                    count++;
                    TotalTips.Rows[i].Delete();
                }
                else
                {

                    if (agcount < spit)
                    {
                        DataRow prndr = Tips2.NewRow();
                        prndr["DAQuickTipsID"] = TotalTips.Rows[i]["DAQuickTipsID"].ToString();
                        prndr["DAQuickTipsName"] = TotalTips.Rows[i]["DAQuickTipsName"].ToString();
                        Tips2.Rows.InsertAt(prndr, 0);
                        agcount++;
                        TotalTips.Rows[i].Delete();
                    }
                    else
                    {
                        DataRow ndrdt = Tips3.NewRow();
                        ndrdt["DAQuickTipsID"] = TotalTips.Rows[i]["DAQuickTipsID"].ToString();
                        ndrdt["DAQuickTipsName"] = TotalTips.Rows[i]["DAQuickTipsName"].ToString();
                        Tips3.Rows.InsertAt(ndrdt, 0);
                        TotalTips.Rows[i].Delete();

                    }

                }

            }
            try
            {

                if (Tips3.Rows.Count > 0)
                {
                    this.RadGridTips1.DataSource = Tips3;
                    this.RadGridTips1.DataBind();
                }
                if (Tips2.Rows.Count > 0)
                {
                    this.RadGridTips2.DataSource = Tips2;
                    this.RadGridTips2.DataBind();
                }
                if (Tips1.Rows.Count > 0)
                {
                    this.RadGridTips1.DataSource = Tips1;
                    this.RadGridTips1.DataBind();
                }

            }

            catch
            {


            }
        }

        private DataTable GetUserQuickTipsAccordingTopicID()
        {
            DigitalAdvisorFA objQuickTips = new DigitalAdvisorFA();
            DataTable tips = objQuickTips.GetUserQuickTipsAccordingTopicID(this.TopicId, this.TopicName, this.Situation, this.Status);
            return tips;
        }

        protected void TextBoxAdviseName_OnTextChanged(object sender, EventArgs e)
        {
            if (TextBoxAdviseName.Text != string.Empty)
            {
                ImageButton4.Enabled = true;

            }


        }

        protected void ThaiRating_Changed(object sender, RatingEventArgs e)
        {
            e.CallbackResult = ((Rating)sender).ID + ";" + e.Value + ";" + e.Tag;
            SessionInfo.Rating = Convert.ToInt32(e.Value);
        }


        protected void btnCatRow_Click(object sender, EventArgs e)
        {
            int index = Convert.ToInt32(this.hdnCatRowParameter.Value.ToString());
            GridDataItem item = this.RadGridCategory.Items[index];
            this.CategoryId = Convert.ToInt32(item.GetDataKeyValue("CatagoryID").ToString());
            this.Topic = GetTopic(this.CategoryId);
            FillCategoryGrid();
            this.TopicId = int.MinValue;
            this.TopicName = string.Empty;
            this.Situation = string.Empty;
            this.Status = string.Empty;

        }

        protected void btnTopRow_Click(object sender, EventArgs e)
        {
            int index = Convert.ToInt32(this.hdntopicRowPrm.Value.ToString());
            GridDataItem item = this.RadGridTopic.Items[index];
            this.TopicId = Convert.ToInt32(item.GetDataKeyValue("DATopicID").ToString());
            this.SituationSolution = GetSituation(this.TopicId);
            FillSituationInfo();
            RadioButnTopic.ClearSelection();
            RadioButtonSituation.ClearSelection();
            RadioButtonListStatus.ClearSelection();
            this.QuickTipsSituation = EmptySituationSolution();
            this.RadGridTips1.DataSource = this.QuickTipsSituation;
            this.RadGridTips1.DataBind();
            this.RadGridTips2.DataSource = this.QuickTipsSituation;
            this.RadGridTips2.DataBind();
            this.RadGridTips3.DataSource = this.QuickTipsSituation;
            this.RadGridTips3.DataBind();
        }

        protected void BtnAdvise_Click(object sender, EventArgs e)
        {
            int index = Convert.ToInt32(this.hdnAdviseRowParam.Value.ToString());
            GridDataItem item = this.RadGridRecentAdvise.Items[index];
            int DAdviceID = Convert.ToInt32(item.GetDataKeyValue("DAdviceID").ToString());
            try
            {

                DataTable objdtsituation = new DataTable();
                //this.GetUserSavedDataUserID = EmptyUserSavedData();
                this.GetUserSituation = EmptySituationGroup();
                if (DAdviceID != int.MinValue)
                {
                    this.GetUserSavedDataUserID = GetUserSavedDataAccrAdviceID(DAdviceID);
                    this.GetUserSituation = GetUserSituationSaved(DAdviceID);
                    objdtsituation = this.GetUserSituation;
                    int topicid = Convert.ToInt32(GetUserSavedDataUserID.Rows[0]["DATopicID"].ToString());
                    this.GetQuickTips = GetUserSavedQuickTipsAccrAdviceID(topicid, objdtsituation);

                }

                BindUserSavedData();
                TextBoxAdviseName.ReadOnly = true;
                ImageButton4.Enabled = false;
                ImageButtonFindTips.Enabled = false;
                ThaiRating.ReadOnly = true;

            }

            catch
            {



            }
        }

        private DataTable GetUserSavedQuickTipsAccrAdviceID(int topicid, DataTable objdtsituation)
        {
            DigitalAdvisorFA objUserSavedQuickTips = new DigitalAdvisorFA();
            DataTable objusertemp = objUserSavedQuickTips.GetUserSavedQuickTipsAccrAdviceID(topicid, objdtsituation);
            return objusertemp;
        }

        protected void ImageButtonReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                this.Category = GetCategory();

                this.GetUserSavedAdvise = GetPreviousSaveAdvise();
                this.Topic = EmptyCategoryGroup();
                this.QuickTipsSituation = EmptySituationSolution();
                ThaiRating.ReadOnly = false;                
                ImageButtonFindTips.Enabled = true;
                RadioButnTopic.ClearSelection();
                RadioButtonSituation.ClearSelection();
                RadioButtonListStatus.ClearSelection();
                TextBoxAdviseName.Text = " ";
                BindGrids();
                BindResetGrid();
            }

            catch
            {

            }

        }

        private void BindResetGrid()
        {
            try
            {
                this.RadGridTopic.DataSource = this.Topic;
                this.RadGridTopic.DataBind();
                this.RadGridTips1.DataSource = this.QuickTipsSituation;
                this.RadGridTips1.DataBind();
                this.RadGridTips2.DataSource = this.QuickTipsSituation;
                this.RadGridTips2.DataBind();
                this.RadGridTips3.DataSource = this.QuickTipsSituation;
                this.RadGridTips3.DataBind();
                LabelHow.Text = "No Information";
                LabelWhat.Text = "No Info";


            }

            catch
            {

            }
        }

        private DataTable EmptySituationSolution()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("DAQuickTipsID", typeof(string)));
            objDT.Columns.Add(new DataColumn("DAQuickTipsName", typeof(string)));
            return objDT;
        }

        protected void RadGridCategory_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGridCategory.DataSource = this.Category;
            RadGridCategory.DataBind();
        }

        protected void RadGridTopic_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            this.RadGridTopic.DataSource = this.Topic;
            this.RadGridTopic.DataBind();
        }

        protected void RadGridRecentAdvise_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            this.RadGridRecentAdvise.DataSource = this.GetUserSavedAdvise;
            this.RadGridRecentAdvise.DataBind();
        }

        protected void RadGridTips1_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            this.RadGridTips1.DataSource = this.QuickTipsSituation;
            this.RadGridTips1.DataBind();
        }

        protected void RadGridTips2_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            this.RadGridTips2.DataSource = this.QuickTipsSituation;
            this.RadGridTips2.DataBind();
        }

        protected void RadGridTips3_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            this.RadGridTips3.DataSource = this.QuickTipsSituation;
            this.RadGridTips3.DataBind();
        }

        protected void RadGridCategory_OnItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem item = e.Item as GridDataItem;
                int catid = Convert.ToInt32(item["CatagoryID"].Text.ToString());
                if (catid == Convert.ToInt32(this.Category.Rows[0].ToString()))
                {
                    item.Selected = true;
                }


            }
        }

        protected void RadGridCategory_OnPreRender(object sender, EventArgs e)
        {
            RadGridCategory.MasterTableView.Items[0].Selected = true;
        }

        protected void RadGridTopic_OnPreRender(object sender, EventArgs e)
        {
            if (this.TopicId != int.MinValue)
            {
                RadGridTopic.MasterTableView.Items[0].Selected = true;
            }
        }



    }
}
