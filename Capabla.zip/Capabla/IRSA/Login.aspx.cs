﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Web.Security;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Collections.Specialized;
using System.Configuration;
using System.Collections;
using System.Management;
using System.Security;
using System.Runtime.InteropServices;
using System.Text;
namespace IRSA
{
    public partial class Login : System.Web.UI.Page
    {
        public string password;
        string CULINFO;
        string Regxml = "Irsatooltiporganisation.xml";
        public string UserName
        {
            set
            {
                ViewState["UserName"] = value;
            }
            get
            {
                if (ViewState["UserName"] == null)
                {
                    ViewState["UserName"] = string.Empty;
                }
                return ViewState["UserName"].ToString();
            }
        }
        public string Password
        {
            set
            {
                ViewState["Password"] = value;
            }
            get
            {
                if (ViewState["Password"] == null)
                {
                    ViewState["Password"] = string.Empty;
                }
                return ViewState["Password"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            
            try
            {

                Page.Form.DefaultButton = BtnSignIn_Login.UniqueID;
                GettooltipMessage();
                getLoginPageLanguageInfo();
                if (!IsPostBack)
                {
                    DecryptFile();
                    License();
                    TxtLoginname.Focus();
                    if (Request.Cookies["username"] != null)
                    {
                        HttpCookie cookie = Request.Cookies.Get("username");
                        this.UserName = Request.Cookies["username"]["username"];
                        this.password = Request.Cookies["username"]["password"];
                        CheckBox rm = (CheckBox)ChkBox.FindControl("RememberMe");

                    }
                    if (this.UserName != string.Empty)
                    {
                        TxtLoginname.Text = this.UserName;
                        Textpassword.Attributes.Add("value", this.password);
                        ChkBox.Checked = true;
                    }
                    //SessionInfo objsession = new SessionInfo();
                    //objsession.Equals(null);
                    //Session.Abandon();
                    //Session.Clear();
                    //Session.RemoveAll();

                }
            }
            catch
            {


            }
 
        }
    

        protected void BtnSignIn_Click(object sender, EventArgs e)
        {
         try
          {
            string email;
            LoginSH objsh = new LoginSH();
            if (TxtLoginname.Text == "" || Textpassword.Text == "")
            {
                LblError_Login.Visible = true;
                LblError_Login.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(23);

            }
            else
            {
                email = TxtLoginname.Text;
                if (Validation.IsValidEmailAddress(email))
                {
                    objsh.UserID = email;
                    objsh.Password = Textpassword.Text;
                    objsh.EmailID = TxtLoginname.Text;
                    LoginFA objFA = new LoginFA();
                    Encryption.HashPwd(Textpassword.Text);
                    string password = Encryption.HashPwd(Textpassword.Text);
                    objsh.Password = password;
                    if (Encryption.verifyPwd(Textpassword.Text, objsh.Password) && objsh.EmailID == TxtLoginname.Text)
                    {
                        objFA.GetValidate(objsh);

                        int y = Convert.ToInt32(SessionInfo.UserId);

                        if (y > 0)
                        {
                            MembershipUser search = Membership.GetUser(this.TxtLoginname.Text);
                            if (search == null)
                            {
                                MembershipCreateStatus status;
                                search = Membership.CreateUser(this.TxtLoginname.Text, Textpassword.Text, this.TxtLoginname.Text, "What does 1+1 equal?", "2", true, out status);
                            }
                            FormsAuthentication.RedirectFromLoginPage(search.UserName, false);
                            if (ChkBox.Checked == true)
                            {

                                HttpCookie cookie = new HttpCookie("username");
                                cookie.Values.Add("username", TxtLoginname.Text);
                                cookie.Values.Add("password", Textpassword.Text);
                                cookie.Expires = DateTime.Now.AddDays(1);
                                HttpContext.Current.Response.AppendCookie(cookie);
                                ChkBox.Checked = true;

                            }
                            else if (ChkBox.Checked == false)
                            {
                                HttpContext.Current.Response.Cookies.Remove("username");
                                Response.Cookies["username"].Expires = DateTime.Now;
                                ChkBox.Checked = false;

                            }
                            DataTable dtorgid = new DataTable();
                            dtorgid = objFA.GetOrgID();
                            if (dtorgid.Rows.Count > 0)
                            {
                                SessionInfo.OrganisationID = Convert.ToInt32(dtorgid.Rows[0]["OrganisationID"].ToString());
                                SessionInfo.OrgID = Convert.ToInt32(dtorgid.Rows[0]["OrganisationID"].ToString());

                            }
                            
                            Response.Redirect("MyDashboard.aspx",false);

                        }
                        else
                        {
                            LblError_Login.Visible = true;
                            LblError_Login.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(23);
                        }
                    }
                    else
                    {
                        LblError_Login.Visible = true;
                        LblError_Login.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(23);
                    }
                }
                else
                {
                    LblError_Login.Visible = true;
                    LblError_Login.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(23);
                }           
            
             }

           }
           catch(System.Exception  Ex)
           {
               
               IRSA.Exception.ErrorLog.Logging(Ex,true);
           }


        }

        
        protected void Btn4_Click(object sender, EventArgs e)
        {
            TxtLoginname.Text = "";
            Textpassword.Text = "";

        }
        protected void txtpasswd_TextChanged(object sender, EventArgs e)
        {

        }
        protected void LinkBtnForgotPwd_Click(object sender, EventArgs e)
        {
            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";
            rd.NavigateUrl = "~/ForgotPassword1.aspx";
            rd.VisibleOnPageLoad = true;
          
            RadWindowManager1.Windows.Add(rd);
        }
        
        protected void BtnSignUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void LinkBtnSignUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void LinkButtonForgot_Click(object sender, EventArgs e)
        {
            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";            
            rd.NavigateUrl = "~/ForgotPassword1.aspx";
            rd.VisibleOnPageLoad = true;
            rd.Width = 300;
            rd.Height = 220;
            rd.Left = 420;
            rd.Top = 420;
            RadWindowManager1.Windows.Add(rd);
        }

        protected void LinkButtonRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
        private void GettooltipMessage()
        {
            try
            {
                TxtLoginname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(28, Regxml);
                Textpassword.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(29, Regxml);
                

            }
            catch { }
        }
        protected void getLoginPageLanguageInfo()
        {
            try
            {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            LblWelcome_Login.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
            Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_Login");
            Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_Login");
            Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label5_Login");
            Label6.Text = (string)GetGlobalResourceObject("PageResource", "Label6_Login");
            Btnjoin.Text = (string)GetGlobalResourceObject("PageResource", "Btnjoin_Login");
            LblUsrName.Text = (string)GetGlobalResourceObject("PageResource", "LblUsrName_Login");
            LblPassword.Text = (string)GetGlobalResourceObject("PageResource", "LblPassword_Login");
            ChkBox.Text = (string)GetGlobalResourceObject("PageResource", "ChkBox");
            LinkButtonForgot_Login.Text = (string)GetGlobalResourceObject("PageResource", "LinkButtonForgot_Login");
            LinkButtonRegister_Login.Text = (string)GetGlobalResourceObject("PageResource", "LinkButtonRegister_Login");
            BtnSignIn_Login.Text = (string)GetGlobalResourceObject("PageResource", "BtnSignIn_Login");
            LblHelp_Login.Text = (string)GetGlobalResourceObject("PageResource", "LblHelp_Login");
            LblNewAccount_Login.Text = (string)GetGlobalResourceObject("PageResource", "LblNewAccount_Login");
            Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_Login");
            Label7.Text = (string)GetGlobalResourceObject("PageResource", "Label7_Login");
            Label8.Text = (string)GetGlobalResourceObject("PageResource", "Label8_Login");
            Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_Login");
            Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_Login");
            Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_Login");
            Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_Login");
            Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_Login");
            Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_Login");
            Label19.Text = (string)GetGlobalResourceObject("PageResource", "Label19_Login");
            Label23.Text = (string)GetGlobalResourceObject("PageResource", "Label23_Login");
            Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_Login");
            Label26.Text = (string)GetGlobalResourceObject("PageResource", "Label26_Login");
            Label28.Text = (string)GetGlobalResourceObject("PageResource", "Label28_Login");
            Label29.Text = (string)GetGlobalResourceObject("PageResource", "Label29_Login");
            lbltitle.Text = (string)GetGlobalResourceObject("PageResource", "lbltitle_login");
            Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_login");
            LinkbtnUseragree_Login.Text = (string)GetGlobalResourceObject("PageResource", "LinkbtnUseragree_Login");
            LblPrivPolicy_Login.Text = (string)GetGlobalResourceObject("PageResource", "LblPrivPolicy_Login");
            LblCopyrghtPolicy_Login.Text = (string)GetGlobalResourceObject("PageResource", "LblCopyrghtPolicy_Login");
            LblCopyrghtL2_Home.Text = (string)GetGlobalResourceObject("PageResource", "LblCopyrghtL2_Home");
            LblCopyrghtL3_Home.Text = (string)GetGlobalResourceObject("PageResource", "LblCopyrghtL3_Home");
            lnkcontact.Text = (string)GetGlobalResourceObject("PageResource", "lnkcontact");
            }
            catch
            {
            }
        }
        string macc;
        public string GetMacAddress()
        {
           
            ManagementClass mc = new ManagementClass("Win32_NetworkAdapter");
            foreach (ManagementObject mo in mc.GetInstances())
            {
                string macAddr = mo["MACAddress"] as string;
                if (macAddr != null && macAddr.Trim() != "")
                    macc = macAddr.ToString();
              

            }
            return "";
        }

        string date;
        string users;
        string mac;
        public void DecryptFile()
        {
            GetMacAddress();
           try
            {
                string sErrorCompletePathEn = sErrorDirectoryPath + sErrorFileNameEn;
                string sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
                OrganisationLicenseFA fa = new OrganisationLicenseFA();
                DataTable dt = new DataTable();
                dt = fa.GetData();
                string key = dt.Rows[0]["LicenseKey"].ToString();
                DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
                DES.Key = ASCIIEncoding.ASCII.GetBytes(key);
                DES.IV = ASCIIEncoding.ASCII.GetBytes(key);
                FileStream fsread = new FileStream(sErrorCompletePathEn, FileMode.Open, FileAccess.Read);
                ICryptoTransform desdecrypt = DES.CreateDecryptor();
                CryptoStream cryptostreamDecr = new CryptoStream(fsread,desdecrypt,CryptoStreamMode.Read);
                StreamWriter fsDecrypted = new StreamWriter(sErrorCompletePath);
                fsDecrypted.Write(new StreamReader(cryptostreamDecr).ReadToEnd());
                fsDecrypted.Flush();
                fsDecrypted.Close();
                StreamReader srd = new StreamReader(sErrorCompletePath);
                while (!srd.EndOfStream)
                {
                    string str = srd.ReadLine();
                    string str1 = srd.ReadLine();
                    string str2 = srd.ReadLine();
                    string str3 = srd.ReadLine();
                    string str4 = srd.ReadLine();
                    string str5 = srd.ReadLine();
                    if (str1.Contains("Users") || str2.Contains("Mac Address") || str5.Contains("DateTo"))
                    {    

                        string Availability = str1;
                        string[] arAvailability = new string[2];
                        char[] splitter = { '=' };
                        arAvailability = Availability.Split(splitter);
                        string Availability1 = arAvailability[1];
                        users = Availability1;

                        string Availability111 = str2;
                        string[] arAvailability111 = new string[2];
                        char[] splitter1 = { '=' };
                        arAvailability111 = Availability111.Split(splitter1);
                        string Availability11 = arAvailability111[1];
                        mac = Availability11;

                        string Availability1111 = str5;
                        string[] arAvailability1111 = new string[2];
                        char[] splitter11 = { '=' };
                        arAvailability1111 = Availability1111.Split(splitter11);
                        string Availability112 = arAvailability1111[1];

                        date = Availability112;
                        break;
                 
                    }

                } srd.Close();
                DeleteFile();
              }

            catch { }
        }
        string sErrorFileNameEn = ConfigurationSettings.AppSettings["TelerikLogFilePathEn"];
        string sErrorDirectoryPath = ConfigurationSettings.AppSettings["TelerikLogDirectoryPath"];
        string sErrorFileName = ConfigurationSettings.AppSettings["TelerikLogFilePathDecrpted"];
       // string sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
        public void DeleteFile()
        {
            string sErrorDirectoryPath = ConfigurationSettings.AppSettings["TelerikLogDirectoryPath"];
            string sErrorFileName = ConfigurationSettings.AppSettings["TelerikLogFilePathDecrpted"];
            string sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
            FileInfo fiPath = new FileInfo(sErrorCompletePath);
            if (fiPath.Exists)
            {
                //Delete the file from sever
                File.Delete(sErrorCompletePath);
            }

        }
        public void License()
        {
            try
            {
                OrganisationLicenseFA fa = new OrganisationLicenseFA();
                fa.GetUserCount();
                DataTable dt = new DataTable();
                dt = fa.GetUserCount();
                string Users = dt.Rows[0]["Column1"].ToString();
                CULINFO = "en-GB";
                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                DateTime dateToday =Convert.ToDateTime(System.DateTime.Today.Date.ToString());


                DateTime dateto = Convert.ToDateTime(date).Date;
            
                if (mac.ToString().Trim() != macc.ToString().Trim()) 
                {
                    Response.Redirect("LicenseExpired.aspx");

                }
                else if (dateToday >= dateto)
                {
                    Response.Redirect("LicenseExpired.aspx");
                  
                }
                else if (Convert.ToInt32(Users.ToString()) >= Convert.ToInt32(users.ToString()))
                {
                    Response.Redirect("LicenseExpired.aspx");
                }
                else
                {
                }

            }
            catch { }
        }
    }
    }
