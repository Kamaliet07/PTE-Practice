﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Reporting;
using System.Reflection;
using System.ComponentModel;
using System.IO;
using ReportLibrary;
using System.Data;
using System.Drawing;
//using System.Windows.Forms;
using Telerik.Reporting.Drawing;
using IRSA.Common.GlobalFunction;
using System.Configuration;
using System.Security.Cryptography;
using IRSA.Facade;
using IRSA.Common.Validation;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Xml.XPath;

namespace IRSA
{
    public partial class PdfIRSAResume: System.Web.UI.Page
    {
        string reportName;
        int UserID = int.MinValue;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (SessionInfo.RoleID == "RC" || SessionInfo.RoleID == "OR" || SessionInfo.RoleID == "IN")
                {
                    UserID = SessionInfo.CandidateID;

                }
                else
                {
                    UserID = SessionInfo.UserId;

                }

               // UserID = 89;//-----DO COMMENT IT AFTER TESTING!!!!!!!!!!
                if (UserID != int.MinValue)
                {
                    IRSA.Facade.AccountsetupFA objaccFA = new IRSA.Facade.AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    //Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
                foreach (Type t in ReportExplorer.GetReports())
                {
                    DescriptionAttribute description =
                    TypeDescriptor.GetAttributes(t)[typeof(DescriptionAttribute)] as DescriptionAttribute;

                    object[] values = new object[]
                {
                    reportName = t.AssemblyQualifiedName
                };
                    reportName = Server.UrlDecode(reportName);
                    Type reportType = Type.GetType(reportName);
                    if (reportType.Name == "IRSAResumePDF")
                    {
                        IReportDocument report = (IReportDocument)Activator.CreateInstance(reportType);
                        this.ReportViewer1.Report = report;
                        this.Page.Title = "iRSA Resume";
                    }

                }

            }
            catch
            { }


        }
    }
}
