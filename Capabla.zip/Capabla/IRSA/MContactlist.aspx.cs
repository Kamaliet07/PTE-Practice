﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Net.Mail;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text;
namespace IRSA
{
    public partial class MContactlist : System.Web.UI.Page
    {
        MContactListSH objMContactListSH = new MContactListSH();
        string PhotoDirectoryPath;
        int Userid;
        string strphoto;
        string PhotoID;
        public int UserID
        {
            set
            {
                ViewState["UserID"] = value;
            }
            get
            {
                if (ViewState["UserID"] == null)
                {
                    ViewState["UserID"] = int.MinValue;
                }
                return Convert.ToInt32(ViewState["UserID"].ToString());
            }
        }
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        public DataTable GetMyContactMember
        {
            get { return (DataTable)ViewState["GetMyContactMember"]; }
            set { ViewState["GetMyContactMember"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];
                UserID = SessionInfo.UserId;
                Userid = SessionInfo.UserId;
                AutoCompleteExtender1.ContextKey = UserID.ToString();
                if (this.Userid != int.MinValue)
                {

                    Labelmember.Text = SessionInfo.Username;
                }
                else
                {
                    Labelmember.Text = "Guest !";
                }


                if (!Page.IsPostBack)
                {
                    this.GetMyContactMember = GetMyContactmemberDetail();
                    BindContactInformation();

                }
                GetFilePath();
            }
            catch
            {


            }
        }
        private void BindContactInformation()
        {
            if (this.GetMyContactMember != null)
            {
                RadGridContactmem.DataSource = this.GetMyContactMember;
                RadGridContactmem.DataBind();

            }

        }
        public string GetFilePath()
        {

            strphoto = PhotoDirectoryPath;
            return strphoto;
        }
        private DataTable GetMyContactmemberDetail()
        {
            IRSA.Facade.Community.CommunityFA CommMember = new IRSA.Facade.Community.CommunityFA();
            return CommMember.GetContactList(UserID,TxtSearch.Text);
        }
        protected void RadGridContactmem_PreRender(object sender, EventArgs e)
        {
            int itemCount = (sender as RadGrid).MasterTableView.GetItems(GridItemType.Item).Length + (sender as RadGrid).MasterTableView.GetItems(GridItemType.AlternatingItem).Length;
            foreach (GridItem item in (sender as RadGrid).Items)
            {
                if (item is GridDataItem && item.ItemIndex < itemCount - 1)
                {
                    ((item as GridDataItem)["UserID"] as TableCell).Controls.Add(new LiteralControl("<table style='display:none;'><tr><td>"));
                }
            }
        }

       

        protected void ImgbtnSearch_Click(object sender, ImageClickEventArgs e)
        {
            this.GetMyContactMember = GetMyContactmemberDetail();
            BindContactInformation();
            RadTextBox3.Text="";
            RadTextBox2.Text="";
            RadTextBox4.Text="";
            RadTextBox1.Text = "";
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            GetTempsearchCollection = null;
            GetTempsearch = null;
            Contact();
        }

        private void Contact()
        {
           string str6, str7, str8, str9, str10, str11, str12, str15, str16;
             str6 = TxtSearch.Text.Trim();
             
             str9 = " ";
             str7 = RadTextBox3.Text;
             objMContactListSH.Company = RadTextBox3.Text;
             str10 = " ";
             str15 = RadTextBox2.Text;
             objMContactListSH.EmailID = RadTextBox2.Text;
             str16 = " ";
             str11 = RadTextBox4.Text;
             objMContactListSH.FullName = RadTextBox4.Text;
             str12 = " ";
             str8 = RadTextBox1.Text;
             objMContactListSH.Phone = RadTextBox1.Text;
             string ab = str6 + str9 + str7 + str10 + str15 + str16 + str11 + str12 + str8;
             GetSearchWords(ab);
        }

        public void GetSearchWords(string str)
        {
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str4 = words[i];

                getmember(str4);

            }


            if (GetTempsearch == null)
            {
                RadGridContactmem.DataSource = GetTempsearchCollection;
                RadGridContactmem.DataBind();
            }
            else if (GetTempsearch != null)
            {
                RadGridContactmem.DataSource = GetTempsearch;
                RadGridContactmem.DataBind();
            }

        }
        public void getmember(string str4)
        {
            try
            {

                DataTable dtCalc = new DataTable();
                DataTable ds = new DataTable();

                if (GetTempsearchCollection == null)
                {
                    MContactListFA objMContactListFA = new MContactListFA();

                    ds = objMContactListFA.GetData1(str4, objMContactListSH, UserID);
                    GetTempsearchCollection = ds;
                    dtCalc = ds;
                    int count = dtCalc.Rows.Count;
                    dtCalc.Merge(GetTempsearchCollection);
                    GetTempsearchCollection = dtCalc;
                }
                else
                {
                    if (GetTempsearchCollection.Rows.Count > 0)
                    {
                        DataRow[] Result = GetTempsearchCollection.Select("Details Like '%" + str4 + "%'");
                        DataTable dfg = new DataTable();
                        dfg.Columns.Add("UserID", typeof(int));
                        dfg.Columns.Add("FullName", typeof(string));
                        dfg.Columns.Add("ProfessionalTitle", typeof(string));
                        dfg.Columns.Add("EmailID", typeof(string));
                        dfg.Columns.Add("Phone", typeof(string));
                        dfg.Columns.Add("PhotoID", typeof(int));
                        dfg.Columns.Add("Company", typeof(string));



                        foreach (DataRow dr in Result)
                        {
                            DataRow row;
                            row = dfg.NewRow();
                            row["UserID"] = Result[0].ItemArray[0];
                            row["FullName"] = Result[0].ItemArray[1];
                            row["ProfessionalTitle"] = Result[0].ItemArray[2];
                            row["EmailID"] = Result[0].ItemArray[3];
                            row["Phone"] = Result[0].ItemArray[4];
                            row["PhotoID"] = Result[0].ItemArray[5];
                            row["Company"] = Result[0].ItemArray[6];
                            dfg.Rows.Add(row);

                        }
                        this.GetTempsearch = dfg;
                    }
                }
            }
            catch { }
        }

        protected void Btn_Click(object sender, EventArgs e)
        {
            try
            {
                string str = string.Empty;
                MContactListSH objcontlistSH = new MContactListSH();


                if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "A")
                {
                    str = "A";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "B")
                {
                    str = "B";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "C")
                {
                    str = "C";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "D")
                {
                    str = "D";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "E")
                {
                    str = "E";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "F")
                {
                    str = "F";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "G")
                {
                    str = "G";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "H")
                {
                    str = "H";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "I")
                {
                    str = "I";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "J")
                {
                    str = "J";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "K")
                {
                    str = "K";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "L")
                {
                    str = "L";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "M")
                {
                    str = "M";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "N")
                {
                    str = "N";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "O")
                {
                    str = "O";

                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "P")
                {
                    str = "P";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "Q")
                {
                    str = "Q";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "R")
                {
                    str = "R";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "S")
                {
                    str = "S";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "T")
                {
                    str = "T";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "U")
                {
                    str = "U";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "V")
                {
                    str = "V";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "W")
                {
                    str = "W";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "X")
                {
                    str = "X";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "Y")
                {
                    str = "Y";
                }
                else if (((System.Web.UI.WebControls.Button)(sender)).CommandName == "Z")
                {
                    str = "Z";
                }




                this.GetMyContactMember = GetMyContactmemberDet(str, UserID);
                //this.GetMyContact = GetMyContactmemberDet(str, UserID);
                BindContacts();
                RadTextBox3.Text = "";
                RadTextBox2.Text = "";
                RadTextBox4.Text = "";
                RadTextBox1.Text = "";
                TxtSearch.Text = "";
            }
            catch { }

        }
        private DataTable GetMyContactmemberDet(string str, int UserID)
        //private void getsearchvalue(string str, int UserID)
        {
          
            MContactListFA objMContactListFA = new MContactListFA();
            return objMContactListFA.GetUserSearch(str, UserID);
           
            
        }

        private void BindContacts()
        {


            if (this.GetMyContactMember != null)
            {
                RadGridContactmem.DataSource = this.GetMyContactMember;
                RadGridContactmem.DataBind();

            }
        }

        

        //protected void RadGridContactmem_ItemDataBound(object sender, GridItemEventArgs e)
        //{
        //    GridDataItem item = e.Item as GridDataItem;
        //    string filepath = GetFilePath(UserID,PhotoID);
        //    Image img = item["Photo1"].FindControl("Image1") as Image;
        //    img.ImageUrl = filepath;
        //}

        

     


    }
}
