﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using Telerik.Web.UI;
namespace IRSA
{
    public partial class EventInterfacePopUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Request.QueryString["ID"] != null && Request.QueryString["Title"] != null))
            {
                int EventID = Convert.ToInt32(Request.QueryString["ID"]);
                string Title = Convert.ToString(Request.QueryString["Title"]);




                EventInterfaceFA fa = new EventInterfaceFA();
                DataTable dt = new DataTable();
                dt = fa.GetDataPopUp(EventID, Title);
                if (dt.Rows.Count > 0)
                {

                    LblTilte.Text = dt.Rows[0]["EventDescription"].ToString();
                    LblDescription.Content = dt.Rows[0]["Summary"].ToString();
                    LblStartDate.Text = (dt.Rows[0]["DateTo"].ToString());
                    LblEndDate.Text = (dt.Rows[0]["LastDate"].ToString());
                    LblUrl.Text = dt.Rows[0]["ContactMailID"].ToString();
                    LblCity.Text = dt.Rows[0]["City"].ToString();
                    LblCountry.Text = dt.Rows[0]["Country"].ToString();
                }
            }
        }
    }
}
        //public void GetDataPopUp()
        //{
        //    if ((Request.QueryString["ID"] != null && Request.QueryString["Tilte"] != null))
        //    {
        //        int EventID = Convert.ToInt32(Request.QueryString["ID"]);
        //        string Title = Convert.ToString(Request.QueryString["Tilte"]);




        //        EventInterfaceFA fa = new EventInterfaceFA();
        //        DataTable dt = new DataTable();
        //        dt = fa.GetDataPopUp(EventID, Title);
        //        if (dt.Rows.Count > 0)
        //        {

        //            LblTilte.Text = dt.Rows[0]["EventDescription"].ToString();
        //            LblDescription.Content = dt.Rows[0]["Summary"].ToString();
        //            LblStartDate.Text = (dt.Rows[0]["DateTo"].ToString());
        //            LblEndDate.Text = (dt.Rows[0]["LastDate"].ToString());
        //            LblUrl.Text = dt.Rows[0]["ContactMailID"].ToString();
        //        }
        //        else
        //        {

        //        }
        //    }


        
    

