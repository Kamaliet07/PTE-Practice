﻿using IRSA.DataAccess;
using IRSA.DALFactory;
using IRSA.DALInterface;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace IRSA
{
    /// <summary>
    /// Summary description for ContactList
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ContactList : System.Web.Services.WebService
    {

        [WebMethod]
        public string[] searchcontact(string prefixText, string contextkey)
        {
            //int UserID = 9;// SessionInfo.UserId;
            string ErrorMessage = "No Data Found";
            string ConnectionString = GlobalMethod.GetConnectionString();
            string dbType = GlobalMethod.GetDbType();
            Factory objFactory = new IRSA.DALFactory.Factory(dbType);
            IRSA.DALInterface.DataAccessInterface objDataAccessLayer = objFactory.GetDBProvider();
            objDataAccessLayer.ConnectionString = ConnectionString;
            string query = "Select * from (SELECT dbo.txnMemberAccount.FirstName, dbo.txnMemberAccount.LastName,(RTrim(dbo.txnMemberAccount.FirstName)+' '+RTrim(dbo.txnMemberAccount.LastName)) as FullName ,dbo.txnMemberAccount.ProfessionalTitle,dbo.txnMemberAccount.EmailID,dbo.txnMemberAccount.Phone,dbo.txnMemberAccount.PhotoID,(RTrim(dbo.txnMemberAccount.FirstName)+RTrim(dbo.txnMemberAccount.LastName)) as Name FROM dbo.txnMemberAccount INNER JOIN dbo.txnUserNetworkList ON dbo.txnMemberAccount.UserID = dbo.txnUserNetworkList.NetworkUserID where Accepted='True' and txnUserNetworkList.UserID='" + contextkey + "')Table1 where Table1.Name Like '" + prefixText + "%' ";

            //string query = "select * from (select Name from lkpOrganisation where Name like '" + prefixText + "%') as temp";
            DataTable dt = new DataTable();
            dt = objDataAccessLayer.GetDataTable(query, CommandType.Text, ref ErrorMessage);
            string[] items = new string[dt.Rows.Count];
            int i = 0;
            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr["FirstName"].ToString(), i);
                i++;
            }

            return items;
        }
    }
}
