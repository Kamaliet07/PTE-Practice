﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;


namespace IRSA
{
    public partial class PersonSearch : System.Web.UI.Page
    {
        PersonSearchSH objpersonserachSH = new PersonSearchSH();
        string PhotoDirectoryPath;
        string str;
        string str4, strfname5, strPTitle, strLname6, strLoc, strkeyword, strCity;
        //string[] str4;
        //string str6 = "";
        //string[] str1;
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                XmlCountry();
                PhotoDirectoryPath = ConfigurationSettings.AppSettings["userdetails"];
                str = Request.QueryString.Get("id");

                int lng = str.Length;
                if (lng <= 1)
                {
                    GetpersonGrid();
                }
                else
                {
                    GetSearchWords(str);
                    //getmember();
                }
            }
        }
          
        private void XmlCountry()
           {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                countrybox.LoadXml(NodeIter1.Current.InnerXml);
                }
            catch
            {

            }
            }
        

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {

        }

        
        public void GetpersonGrid()
        {

            PersonSearchFA objPersonSearchFA = new PersonSearchFA();
            DataTable dt = new DataTable();
            dt = objPersonSearchFA.GetData1(str);
            RadGrid1.DataSource = dt;
            RadGrid1.DataBind();


        }
        public void getmember(string str4)
        {
            
            DataTable dtCalc = new DataTable();
            DataTable ds = new DataTable();

            if (GetTempsearchCollection == null)
            {
                PersonSearchFA objPersonSearchFA = new PersonSearchFA();

                ds = objPersonSearchFA.GetData1(str4);
                GetTempsearchCollection = ds;
                dtCalc = ds;
                int count = dtCalc.Rows.Count;
                dtCalc.Merge(GetTempsearchCollection);
                GetTempsearchCollection = dtCalc;
            }
            else
            {
                DataRow[] Result = GetTempsearchCollection.Select("keywords Like '%" +  str4  + "%'");
                
                //GetTempsearch.Rows.Add(Result);

                //Result = GetTempsearch.Result();
               
                DataTable dfg = new DataTable();
                dfg.Columns.Add("FirstName", typeof(string));
                dfg.Columns.Add("LastName", typeof(string));
                dfg.Columns.Add("City", typeof(string));
                dfg.Columns.Add("Country", typeof(string));


               
                foreach (DataRow dr in Result)
                {
                    DataRow  row;
                    row = dfg.NewRow();
                    row["FirstName"] = dr[1];
                    row["LastName"] = dr[2];
                    row["City"] = dr[3];
                    row["Country"] = dr[5];
                    dfg.Rows.Add(row);
                   
                    
                }
                GetTempsearch = dfg;
            }
                
            }
           
        
        public void GetSearchWords(string str)
        {
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str4 = words[i];
                
                getmember(str4);
                
            }


            if (GetTempsearch == null)
            {
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            }
            else
            {
                RadGrid1.DataSource = GetTempsearch;
               
                RadGrid1.DataBind();
            }
            
        }


        protected void Button_Click1(object sender, EventArgs e)
        {
            PersonSearchFA objpersonserachFA = new PersonSearchFA();
            
            PersonSearchSH objpersonserachSH = new PersonSearchSH();
            objpersonserachSH.Keyword = RtxtTitle.Text;
            objpersonserachSH.FirstName = RtxtTitle0.Text;
            objpersonserachSH.LastName = RtxtTitle1.Text;
            objpersonserachSH.City = RadTextBox1.Text;
            DataTable dtcal=new DataTable();
            //dtcal=objpersonserachFA.GetData1(objpersonserachSH);
            RadGrid1.DataSource=dtcal;
            RadGrid1.DataBind();
            //getmember1();
        }
        
            //objpersonserachSH.City = RadTextBox1.Text;
        //    public void getmember1()
        //    {
            
        //    DataTable dtCal = new DataTable();
        //    DataTable dt = new DataTable();

        //    if (GetTempsearchCollection == null)
        //    {
        //        PersonSearchFA objPersonSearchFA = new PersonSearchFA();

        //        dt = objPersonSearchFA.GetData(objpersonserachSH.Keyword,objpersonserachSH.FirstName,objpersonserachSH.LastName,objpersonserachSH.City,objpersonserachSH.Country);
        //        GetTempsearchCollection = dt;
        //        dtCal = dt;
        //        int count = dtCal.Rows.Count;
        //        dtCal.Merge(GetTempsearchCollection);
        //        GetTempsearchCollection = dtCal;
        //    }
        //    else
        //    {
        //        DataRow[] Result = GetTempsearchCollection.Select("keywords Like '%" +  str4  + "%'");
                
        //        //GetTempsearch.Rows.Add(Result);

        //        //Result = GetTempsearch.Result();
               
        //        DataTable df = new DataTable();
        //        df.Columns.Add("FirstName", typeof(string));
        //        df.Columns.Add("LastName", typeof(string));
        //        df.Columns.Add("City", typeof(string));
        //        df.Columns.Add("Country", typeof(string));


               
        //        foreach (DataRow dr in Result)
        //        {
        //            DataRow  row;
        //            row = df.NewRow();
        //            row["FirstName"] = dr[1];
        //            row["LastName"] = dr[2];
        //            row["City"] = dr[3];
        //            row["Country"] = dr[5];
        //            df.Rows.Add(row);
                   
                    
        //        }
        //        GetTempsearch = df;
        //    }
                
        //    }
        
        //public void GetSearchWords1(string strkeyword)
        //{
        //    string pattern = @"\S+";
        //    Regex re = new Regex(pattern);

        //    MatchCollection matches = re.Matches(str);
        //    string[] words = new string[matches.Count];
        //    for (int i = 0; i < matches.Count; i++)
        //    {
        //        words[i] = matches[i].Value;
        //        string str4 = words[i];
                
        //        //getmember1(objpersonserachSH);
                
        //    }
            
               
            //if((strkeyword.Length)!!(strfname5.Length)!!(strPTitle.Length)!!(strLoc.Length)!!(strPTitle.Length))>1
        //    int length = strkeyword.Length;
        //    if (length > 1)
        //{
        //    GetSearchWords1(strkeyword);
        //}

            //else if (strfname5.Length > 1)
            //{
            //    GetSearchWords(strfname5);
            //}
        //    else if (strLname6.Length>1)
        //    { 
        //        GetSearchWords(strLname6);
        //    }
        //    else if(strPTitle.Length>1)
        //    {GetSearchWords(strPTitle);
        //    }
        //  else if (strLoc.Length > 1)
        //{
        //    GetSearchWords(strLoc);
        //}
        //else if (strkeyword.Length > 1)
        //{
        //    GetSearchWords(strLoc);
        //}



        

      protected void RadGrid1_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {

            RadGrid1.CurrentPageIndex = e.NewPageIndex;

            if (GetTempsearch == null)
            {
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            }
            else
            {
                RadGrid1.DataSource = GetTempsearch;

                RadGrid1.DataBind();
            }
        }

        protected void RtxtTitle_TextChanged1(object sender, EventArgs e)
        {
            strkeyword = RtxtTitle.Text;
        }

       

    //protected void RtxtTitle0_TextChanged(object sender, EventArgs e)
        //{
        //    strfname5 = RtxtTitle0.Text;
        //}

        //protected void RtxtTitle2_TextChanged(object sender, EventArgs e)
        //{
        //    strPTitle = RtxtTitle2.Text;
        //}

        //protected void RtxtTitle1_TextChanged(object sender, EventArgs e)
        //{
        //    strLname6 = RtxtTitle1.Text;
        //}

        //protected void RadTextBox1_TextChanged(object sender, EventArgs e)
        //{
        //    strLoc = RadTextBox1.Text;
        //}

       
    }
}

        
    


