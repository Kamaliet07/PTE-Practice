﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;


using System.Xml.XPath;


namespace IRSA
{
    public partial class JobPostingPreview : System.Web.UI.Page
    {
        int JobID;
        string step = "";
        string Collection = "";
        string Job;
        string CULINFO;
        int UserID;
        string Status;
        string title;
        string ExpiryDate;
        string CurrentJobRoleType;
        string str2 = "";
        public int PageID
        {
            set
            {
                ViewState["PageID"] = value;
            }
            get
            {
                if (ViewState["PageID"] == null)
                {
                    ViewState["PageID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["PageID"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
          UserID = SessionInfo.UserId;
           this.PageID = 103;
            //UserID = 47;
            if (!IsPostBack)
            {
                //Lblmessage.Visible = false;
                //GetUserPurchageDetailInfo();

            }
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            getJobPreviewPageLanguageInfo();
            Job = Request.QueryString.Get("ID");

            if (Job != "")
            {
                JobID = Convert.ToInt32(Job);
               // JobID = 19;

            }
           
              GetPreviewData();
               GetJobInfo();
               GetJobProfiles();
               if (Status == "True")
               {
                   BtnSubmit.Visible = false;
                   linkbtnedit1.Visible = false;
                   linkbtnedit2.Visible = false;
                   LinkButton1.Visible = false;
                   LinkButton2.Visible = false;

               }
               else
               {
                   BtnSubmit.Visible = true;
                   linkbtnedit1.Visible = true;
                   linkbtnedit2.Visible = true;
                   LinkButton1.Visible = true;
                   LinkButton2.Visible = true;
               }
        }
        protected void GetPreviewData()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJob(JobID);
                if (dt.Rows.Count > 0)
                {
                    LblComapnyName.Text = dt.Rows[0]["Name"].ToString();
                    LblComapnyDescription.Text = dt.Rows[0]["CompanyDescription"].ToString();
                    LblComapnyURL.Text = dt.Rows[0]["CompanyURL"].ToString();
                    LblJobLocation.Text = dt.Rows[0]["JobCity"].ToString();
                    LblCountry.Text = dt.Rows[0]["JobCountry"].ToString();
                    LblPostalcode.Text = dt.Rows[0]["JobPostalCode"].ToString();
                    LblPostingDate.Text = dt.Rows[0]["PostingDate"].ToString();
                    LblExperationDate.Text = dt.Rows[0]["ExpirationDate"].ToString();
                    ExpiryDate = dt.Rows[0]["ExpirationDate"].ToString();
                    LblTowhom.Text = dt.Rows[0]["Towhom"].ToString();
                    LblAmount.Text = dt.Rows[0]["ReferalBonusAmount"].ToString();
                    LblCurrency.Text = dt.Rows[0]["ReferalBonusCurrency"].ToString();

                }
            }
            catch
            { }
        }
       
        protected void GetJobInfo()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobInfo(JobID);
                if (dt.Rows.Count > 0)
                {
                    
                    LblJobtitle.Text = dt.Rows[0]["Expr1"].ToString();
                    title = dt.Rows[0]["Expr1"].ToString();
                    Lblrefcode.Text = dt.Rows[0]["JobCodeRef"].ToString();
                    Lblnoofopening.Text = dt.Rows[0]["Openings#"].ToString();
                    Lblpayrangefrom.Text = dt.Rows[0]["PayRangeTo"].ToString();
                    Lblpayrangeto.Text = dt.Rows[0]["PayRangefrom"].ToString();
                    LblpayCurrency.Text = dt.Rows[0]["PayCurrency"].ToString();
                    LblExperinceLevel.Text = dt.Rows[0]["ExperienceLevel"].ToString()+" "+"years";
                    LblPaydescripation.Text = dt.Rows[0]["PayDescription"].ToString();
                    LBlJobframily.Text = dt.Rows[0]["JobFamilyName"].ToString();
                    LblJobType.Text = dt.Rows[0]["JobType"].ToString();
                    Lbljobdescription.Text = dt.Rows[0]["JobDescription"].ToString();
                    LblSkill.Text = dt.Rows[0]["Skills"].ToString();
                    Status = dt.Rows[0]["Sponser"].ToString();
                }
            }
            catch
            {
            }
        }
        protected void GetJobProfiles()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobProfile(JobID);
                if (dt.Rows.Count > 0)
                {

                    LblEducation.Text = dt.Rows[0]["Education"].ToString();
                    LblAge.Text = dt.Rows[0]["Age"].ToString() +" "+ "years"; ;
                    LblJobIndustry.Text = dt.Rows[0]["JobFamilyName"].ToString();
                   
                    if (dt.Rows[0]["DrivingLicense"].ToString() == "True")
                    {
                        LblDL.Text = "Required";
                    }
                    else
                    {
                        LblDL.Text = "Not Required";
                    }
                    LblDistance.Text = dt.Rows[0]["Distance"].ToString()+" "+"KM";
                    LBlAvailabilityto.Text = dt.Rows[0]["AvailabiltyFrom"].ToString();
                    LblavFrom.Text = dt.Rows[0]["AvailabiltyTo"].ToString();
                    CurrentJobRoleType = dt.Rows[0]["CurrentJobRoleType"].ToString();
                    CurrentJobRoleBind();
                }
            }
            catch
            {
            }

        }
        protected void CurrentJobRoleBind()
        {

            int ln = CurrentJobRoleType.Length;
            if (ln > 1)
            {
                char[] ch = { ' ', ',' };
                int j = ch.Count();

                String[] words = CurrentJobRoleType.Split(ch);
                for (int i = 0; i < words.Length; i++)
                {
                    DataTable dt = new DataTable();
                    JobPostingFA ObjJobPostingFA = new JobPostingFA();
                    dt = ObjJobPostingFA.GetSourceTitle(words[i]);
                    if (dt.Rows.Count > 0)
                    {
                        str2 = dt.Rows[0]["Title"].ToString() + "," + str2;
                    }
                }
                LBloccupation.Text = str2;
            }
        }
        protected void LblAssessment_Click(object sender, EventArgs e)
        {
            Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
        }

        protected void linkbtnedit2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
        }

        protected void linkbtnedit1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PostJobCompanyInformation.aspx?ID=" + JobID);
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        //protected void BtnSubmit_Click(object sender, ImageClickEventArgs e)
        //{
          
           
        //}

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Session["ctrl"] = Panel1;
            ClientScript.RegisterStartupScript(this.GetType(), "onclick", "<script language=javascript>window.open('Print.aspx','PrintMe','height=300px,width=300px,scrollbars=1,toolbar=yes,resizable=yes');</script>");
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            JobPostingSH JobPostSH = new JobPostingSH();
            JobPostingFA Jobpostfa = new JobPostingFA();
            if (title != null && ExpiryDate != "" )
            {
                DataTable temp = new DataTable();
                step = "Submit";
                JobPostSH.Sponser = true;
                temp = Jobpostfa.GetCompany(JobPostSH, step, JobID, Collection);
                //DigitalAdvisorFA objAdvisePurchUpdate = new DigitalAdvisorFA();
                //objAdvisePurchUpdate.UpdateUserPurchageDetail(UserID, this.PageID);
            string scriptstring = "radalert(''You have <b> Successfully </ b> Job Posting <b>!</b>', 310, 150);";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring, true);
            Response.Redirect("MyDashBoard.aspx");
            }
            else
            {
           Lblmessage.Visible = true;
           Lblmessage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(99);
            }
           
        }
        protected void getJobPreviewPageLanguageInfo()
        {
            try
            {

                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_PostJobInformation");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label11_PostJobCompanyInformation");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label1_PostJobCompanyInformation");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label2_PostJobCompanyInformation");
                Label7.Text = (string)GetGlobalResourceObject("PageResource", "Label9_PostJobInformation");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_JobPreview");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_PostJobCompanyInformation");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_PostJobInformation");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label13_PostJobInformation");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label1_PostJobInformation");
                Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label2_PostJobInformation");
                Label22.Text = (string)GetGlobalResourceObject("PageResource", "Label3_PostJobInformation");
                Label27.Text = (string)GetGlobalResourceObject("PageResource", "Label5_PostJobInformation");
                Label31.Text = (string)GetGlobalResourceObject("PageResource", "Label18_PostJobInformation");
                Label29.Text = (string)GetGlobalResourceObject("PageResource", "Label29_JobPreview");
                Label20.Text = (string)GetGlobalResourceObject("PageResource", "Label24_PostJobInformation");

                Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label18_PostJobInformation");
                Label33.Text = (string)GetGlobalResourceObject("PageResource", "Label33_JobPreview");
                LblAssessment.Text = (string)GetGlobalResourceObject("PageResource", "LblAssessment_JobPreview");
                Label8.Text = (string)GetGlobalResourceObject("PageResource", "Label9_JobPostingProfile");
                Label34.Text = (string)GetGlobalResourceObject("PageResource", "Label28_JobPostingProfile");
                Label36.Text = (string)GetGlobalResourceObject("PageResource", "Label13_JobPostingProfile");
                Label38.Text = (string)GetGlobalResourceObject("PageResource", "Label16_JobPostingProfile");
                Label40.Text = (string)GetGlobalResourceObject("PageResource", "Label21_JobPostingProfile");
                Label42.Text = (string)GetGlobalResourceObject("PageResource", "Label17_JobPostingProfile");
                Label45.Text = (string)GetGlobalResourceObject("PageResource", "Label14_JobPostingProfile");
                Label46.Text = (string)GetGlobalResourceObject("PageResource", "Label29_JobPreview");
                Label48.Text = (string)GetGlobalResourceObject("PageResource", "Label48_JobPreview");

                Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label9_JobPostingOtherInfo");
                Label50.Text = (string)GetGlobalResourceObject("PageResource", "Label11_JobPostingOtherInfo");
                Label52.Text = (string)GetGlobalResourceObject("PageResource", "Label19_JobPostingOtherInfo");
                Label54.Text = (string)GetGlobalResourceObject("PageResource", "Label13_JobPostingOtherInfo");
                Label65.Text = (string)GetGlobalResourceObject("PageResource", "Label5_JobPostingOtherInfo");
                Label63.Text = (string)GetGlobalResourceObject("PageResource", "Label6_JobPostingOtherInfo");
                Label56.Text = (string)GetGlobalResourceObject("PageResource", "Label14_JobPostingOtherInfo");
                Label57.Text = (string)GetGlobalResourceObject("PageResource", "Label7_JobPostingOtherInfo");
                Label59.Text = (string)GetGlobalResourceObject("PageResource", "Label8_JobPostingOtherInfo");
                Label61.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingOtherInfo");
                BtnSubmit.Text = (string)GetGlobalResourceObject("PageResource", "BtnSubmit_JobPreview");
            }
            catch
            {
            }
            //Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_PostJobInformation");

            //Button1.Text = (string)GetGlobalResourceObject("PageResource", "Button1_PostJobInformation");
        }
        //protected void BtnCredit_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("JobPosting.aspx");
        //}
    }
}
