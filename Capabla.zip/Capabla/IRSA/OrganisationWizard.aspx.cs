﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;
namespace IRSA
{
    public partial class OrganisationWizard : System.Web.UI.Page
    {
        string Accountxml = "Irsatooltiporganisation.xml";
        string PhotoDirectoryPath;
        string LogoDirectoryPath;
        //string ResumeDirectoryPath;
        int UserID=1;
        int OrganisationID;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ID"] != null)
           
            {
                OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);
               


            }



            LogoDirectoryPath = ConfigurationSettings.AppSettings["CompanyLogo"];

            if (!IsPostBack)
            {
                FillIndustry();

                XmlCountry();
                RetreiveData();
            }

            GetiRsaToolTipOrgMsg();

            if (OrganisationID != int.MinValue)
            {
                OrgAccountFA objaccFA = new OrgAccountFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.RetrievePriContactData(UserID, OrganisationID, true);
              //  Lblmember.Text = objdt.Rows[0]["FullName"].ToString() + " " + "!";
              //  SessionInfo.FirstName = objdt.Rows[0]["FullName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            // Getdata();

        }
        private void GetiRsaToolTipOrgMsg()
        {
            try
            {
                txthqadd.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, Accountxml);
                txtstocksymbol.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, Accountxml);
                RadEditorgoals.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(10, Accountxml);
                RadEditorCompanyDesc.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(11, Accountxml);
                Txtwebsite.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);
                Ddncompsize.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(8, Accountxml);
                Ddntype.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                txtcity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(23, Accountxml);
                Image2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(21, Accountxml);
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(16, Accountxml);
                RadNumericfounded.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(7, Accountxml);
                txtorgname.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, Accountxml);

            }
            catch { }
        }
        public void RetreiveData()
        {
            OrgAccountFA objorgFA = new OrgAccountFA();
            DataTable objdt = new DataTable();
            objdt = objorgFA.RetrieveOrganisationData(UserID, OrganisationID);
            if (objdt.Rows.Count > 0)
            {
                txtorgname.Text = objdt.Rows[0]["Name"].ToString();
                txthqadd.Text = objdt.Rows[0]["HeadQuarterAddress"].ToString();
                Txtwebsite.Text = objdt.Rows[0]["Website"].ToString();
                txtstocksymbol.Text = objdt.Rows[0]["StockSymbol"].ToString();
                RadNumericfounded.Text = objdt.Rows[0]["Founded"].ToString();
                Ddncompsize.SelectedValue = objdt.Rows[0]["Size"].ToString().Trim();
                //Ddnstatus.SelectedValue = objdt.Rows[0]["Status"].ToString();
                txtcity.Text = objdt.Rows[0]["City"].ToString();
                RadComboCountry.SelectedValue = objdt.Rows[0]["Country"].ToString();
                RadComboIndustry.SelectedValue = objdt.Rows[0]["IndustryID"].ToString();

                Ddntype.SelectedValue = objdt.Rows[0]["Type"].ToString().Trim();
                RadEditorCompanyDesc.Content = objdt.Rows[0]["Description"].ToString();
                RadEditorgoals.Content = objdt.Rows[0]["GoalsAndValues"].ToString();
                txtstocksymbol.Text = objdt.Rows[0]["StockSymbol"].ToString();
                //string file = objdt.Rows[0]["LogoPath"].ToString();
                //if (file != "")
                //{
                //    Image2.Visible = true;
                //    Image2.ImageUrl = LogoDirectoryPath + file;
                //}
                string file = objdt.Rows[0]["LogoPath"].ToString();
                if (file != "")
                {

                    Image2.Visible = true;
                    Image2.ImageUrl = "~/UserData/OrganisationLogos/" + file;

                }
                else
                {
                    Image2.Visible = true;
                    Image2.ImageUrl = "~/UserData/OrganisationLogos/" + "0.png";

                    //Image1.ImageUrl = PhotoDirectoryPath + "DefaultImage.Png";
                }

            }
        }
        public void SaveData(int UserID)
        {

            string str;

            str = DateTime.Today.Year.ToString();
            //if (CurrentWizardStep == "Welcome")
            //{
            //string Professionaltitle;
            //Professionaltitle = Txtprotitle.Text;
            OrgAccountSH objoraccSH = new OrgAccountSH();
            objoraccSH.Name = txtorgname.Text;
            //objoraccSH.HeadQuarterAddress = txthqadd.Text;
            if (txthqadd.Text != "")
            {
                if (Validation.IsValidAddress(txthqadd.Text))
                {
                    objoraccSH.HeadQuarterAddress = UCFirst(txthqadd.Text);

                }
                else
                {
                    Lblerr.Visible = true;
                    Lblerr.Text = "Incorrect Title";
                    goto Last;
                }
            }
            else
            {
                Lblerr.Visible = true;
                Lblerr.Text = "*";
            }
            objoraccSH.City = UCFirst(txtcity.Text);
            objoraccSH.Country = RadComboCountry.SelectedValue;
            objoraccSH.IndustryName = RadComboIndustry.Text;
            objoraccSH.Type = Ddntype.SelectedValue;
            //objoraccSH.Status = Ddnstatus.SelectedValue;
            objoraccSH.Size = Ddncompsize.SelectedValue;
            objoraccSH.Founded = UCFirst(RadNumericfounded.Text);
            if (RadNumericfounded.Text != "")
            {
                if (Convert.ToInt32(RadNumericfounded.Text) <= Convert.ToInt32(str))
                {

                    objoraccSH.Founded = RadNumericfounded.Text;

                }
                else
                {
                    //lblerr1.Visible = true;
                    //lblerr1.Text = "Invalid Year";
                    goto Last;
                }
            }

            //objoraccSH.Website = Txtwebsite.Text;
            if (Txtwebsite.Text != "")
            {
                if (Validation.IsValidInternetURL(Txtwebsite.Text))
                {
                    objoraccSH.Website = (Txtwebsite.Text);

                }
                else
                {
                    Lbler.Visible = true;
                    Lbler.Text = "Incorrect WebSite URL";
                    goto Last;
                }
            }
            else
            {
                Lbler.Visible = true;
                Lbler.Text = "Please Enter Website URL!";
                goto Last;
            }
            objoraccSH.Description = UCFirst(RadEditorCompanyDesc.Text);
            objoraccSH.GoalsAndValues = UCFirst(RadEditorgoals.Text);
            objoraccSH.StockSymbol = (txtstocksymbol.Text).ToUpper();




            string file = FileUpload1.FileName;
            if (file != "")
            {
                FileUpload1.SaveAs(LogoDirectoryPath + file);
                //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                string strLogo = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];
                ResizeImage(LogoDirectoryPath + file, "~/UserData/OrganisationLogos/" + OrganisationID + "." + strLogo, 85, 75);

                //image1.Save(PhotoDirectoryPath + file, System.Drawing.Imaging.ImageFormat.Png);
                //ResizeImage(LogoDirectoryPath + file, LogoDirectoryPath + OrganisationID + ".Png", 104, 78);
                string LogoPath = UserID + "." + strLogo;
                objoraccSH.LogoPath = LogoPath;

            }
            else
            {
                OrgAccountFA objorgFA = new OrgAccountFA();
                DataTable dtlogo = new DataTable();
                dtlogo = objorgFA.RetrieveOrganisationData(UserID, OrganisationID);
                if (dtlogo.Rows.Count > 0)
                {
                    objoraccSH.Photo = dtlogo.Rows[0]["LogoPath"].ToString();
                }
                else
                {
                    objoraccSH.Photo = "0.png";
                }
            }


            OrgAccountFA objaccFA = new OrgAccountFA();
            objaccFA.InsertOrganisationData(objoraccSH, UserID, OrganisationID);

                    //objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep);

                    //Getdata();
        Last: ;
        }
        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(OriginalFile);

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                NewImage.Save(Server.MapPath(NewFile));

            }
            catch
            {
            }
        }
        public void FillIndustry()
        {
            IRSA.Facade.AccountsetupFA Indus = new IRSA.Facade.AccountsetupFA();

            DataTable temp = new DataTable();
            temp = Indus.GetIndustryData();
            RadComboIndustry.DataValueField = "IndustryID";
            RadComboIndustry.DataTextField = "IndustryName";

            RadComboIndustry.DataSource = temp;
            RadComboIndustry.DataBind();

        }

        //protected  void XmlIndustry()
        // {
        //         XPathNavigator nvg4;
        //         XPathDocument docNvg4;
        //         XPathNodeIterator NdIter4;
        //         docNvg4 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Industry.xml"));
        //         nvg4 = docNvg4.CreateNavigator();
        //         string strExp = "/root/English";
        //         NdIter4 = nvg4.Select(strExp);
        //         NdIter4.MoveNext();
        //         RadComboIndustry.LoadXml(NdIter4.Current.InnerXml);

        //     }

        public void XmlCountry()
        {


            XPathNavigator nav1;
            XPathDocument docNav1;
            XPathNodeIterator NodeIter1;
            docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
            nav1 = docNav1.CreateNavigator();
            string strExp = "/root/English";
            NodeIter1 = nav1.Select(strExp);
            NodeIter1.MoveNext();
            RadComboCountry.LoadXml(NodeIter1.Current.InnerXml);






        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SaveData(UserID);
            RetreiveData();

            //txtorgname.Text = "";
            //txthqadd.Text = "";
            //Txtwebsite.Text = "";
            //txtstocksymbol.Text="";
            //RadNumericfounded.Text = "";
            //Ddncompsize.SelectedIndex = 0;
            //Ddnstatus.SelectedIndex = 0;
            //txtcity.Text = "";
            //RadComboCountry.SelectedValue = "";
            //RadComboIndustry.SelectedValue = "";
            //Ddntype.SelectedIndex = 0;
            //RadEditorCompanyDesc.Content = "";
            //RadEditorgoals.Content = "";
            //txtstocksymbol.Text = "";


        }

        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    txtorgname.Text = "";
        //    txthqadd.Text = "";
        //    Txtwebsite.Text = "";
        //    txtstocksymbol.Text = "";
        //    RadNumericfounded.Text = "";
        //    Ddncompsize.SelectedIndex = 0;
        //    //Ddnstatus.SelectedIndex = 0;
        //    txtcity.Text = "";
        //    RadComboCountry.SelectedValue = "";
        //    RadComboIndustry.SelectedValue = "";
        //    Ddntype.SelectedIndex = 0;
        //    RadEditorCompanyDesc.Content = "";
        //    RadEditorgoals.Content = "";
        //    txtstocksymbol.Text = "";
        //}

        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {

                sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);

            }
            catch { }
            return sb.ToString();
        }

        protected void Upload_Click(object sender, EventArgs e)
        {
            AccountsetupSH objaccSH = new AccountsetupSH();
            string file = FileUpload1.FileName;
            if (file != "")
            {
                FileUpload1.SaveAs(LogoDirectoryPath + file);
                //System.Drawing.Image image1 = System.Drawing.Image.FromFile(PhotoDirectoryPath + file);
                string strlogo = file.Split(new string[] { "." }, 2, StringSplitOptions.None)[1];

                //image1.Save(PhotoDirectoryPath + file, System.Drawing.Imaging.ImageFormat.Png);
                ResizeImage(LogoDirectoryPath + file, "~/UserData/OrganisationLogos/" + OrganisationID + "." + strlogo, 85, 75);

                string Logopath = OrganisationID + "." + strlogo;
                OrgAccountFA objorgFA = new OrgAccountFA();

                objorgFA.insertLogo(Logopath, OrganisationID);
                //objaccFA.InsertAccountSetUpData(objaccSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                RetreiveData();
                //Getdata();
            }







        }

        //protected void Update_Click(object sender, EventArgs e)
        //{
        //    SaveData(UserID);
        //}

        protected void ButtonNext_Click(object sender, EventArgs e)
        {
            SaveData(UserID);
            if (Request.QueryString["ID"] != null)
            {
                OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);
                Response.Redirect("OrganisationWizardPrimaryContact.aspx?id=" + OrganisationID);


            }

        }




    }
}


