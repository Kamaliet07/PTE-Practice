﻿using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using Telerik.Web.UI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IRSA
{
    public partial class CustomerSupportPopUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            regexvldtrTxtEMail.ValidationExpression = (@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
        }

        protected void imgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                string MaiAddress = ConfigurationSettings.AppSettings["SenderMailID"]; ;
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowMessegeSent";
                rd.NavigateUrl = "~/MessageSentPopUp.aspx";
                rd.Width = 400;
                rd.Height = 200;
                rd.VisibleStatusbar = false;
                rd.Title = "Thank You";
                rd.VisibleOnPageLoad = true;
                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(MaiAddress);
                MailAddress fromto = new MailAddress(txtEMail.Text);
                MailMessage msg = new MailMessage(fromto, sendto);
                msg.Subject = txtEMail.Text + " wanted to chat with the customer support.";
                msg.Body = txtDetails.Text;
                msg.IsBodyHtml = false;
                msg.Priority = MailPriority.High;
                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                smt.Send(msg);
                txtEMail.Text = "";
                txtDetails.Text = "";
                RadWindowManager1.Windows.Add(rd);
                rd.Visible = true;
                //CustomerSupportPopUp objCSPU = new CustomerSupportPopUp();
                //objCSPU = this;
                //objCSPU.Dispose();
            }
            catch { }
        }
    }
}
