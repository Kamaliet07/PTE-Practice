﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Text;

namespace IRSA
{
    public partial class JobSearchAdvanced : System.Web.UI.Page
    {     string str,str6;
    int UserID;
        JobSearchAdvancedSH objJobSearchAdvancedSH = new JobSearchAdvancedSH();
        JobSearchAdvancedFA objJobSearchAdvancedFA = new JobSearchAdvancedFA();
   
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        string Accountxml = "irsaToolTipSearch.xml";
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
                XmlCountry();
                FillIndustry();
                FillJobFamily();
                
            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

        }
            private void XmlCountry()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                countrybox.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {

            }
        }
            private void GetiRsaToolTipAccMsg()
            {
                try
                {
                    RKeyword.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(14, Accountxml);
                    RCompany.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(6, Accountxml);
                    RCity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);
                    




                }
                catch { }
            }
        public void GetpersonGrid()
        {

            JobSearchFA objJobSearchFA = new JobSearchFA();
            DataTable dt = new DataTable();
            dt = objJobSearchFA.GetJobData(str);
            RadGrid1.DataSource = dt;
            RadGrid1.DataBind();


        }
         public void getmember(string str4)
        {
           try
           {
            DataTable dtCalc = new DataTable();
            DataTable ds = new DataTable();

            if (GetTempsearchCollection == null)
            {
                JobSearchAdvancedFA objJobSearchAdvancedFA = new JobSearchAdvancedFA();

                ds = objJobSearchAdvancedFA.Job(str4, objJobSearchAdvancedSH);
                GetTempsearchCollection = ds;
                dtCalc = ds;
                int count = dtCalc.Rows.Count;
                dtCalc.Merge(GetTempsearchCollection);
                GetTempsearchCollection = dtCalc;
                
            }
            else
            {
                DataRow[] Result = GetTempsearchCollection.Select("Expr1 Like '%" + str4 + "%'");
               
                DataTable dfg = new DataTable();
                dfg.Columns.Add("Title", typeof(string));
                dfg.Columns.Add("Name", typeof(string));
                dfg.Columns.Add("JobCountry", typeof(string));
                dfg.Columns.Add("JobCity", typeof(string));
                dfg.Columns.Add("JobDescription", typeof(string));
                dfg.Columns.Add("JobID", typeof(int));
                dfg.Columns.Add("LocationDetl", typeof(string));


               
                foreach (DataRow dr in Result)
                {
                    DataRow  row;
                    row = dfg.NewRow();
                    row["Title"] = dr[1];
                    row["Name"] = dr[2];
                    row["JobCity"] = dr[3];
                    row["JobDescription"] = dr[5];
                    row["JobCountry"] = dr[4];
                    row["JobID"] = dr[8];
                    if (dr[2].ToString() != "" && dr[3].ToString() != "" && dr[5].ToString() != "")
                    {
                        row["LocationDetl"] = dr[2].ToString() + "," + dr[3].ToString() + "," + dr[5].ToString();
                    }
                    else if (dr[2].ToString() != "" && dr[3].ToString() != "" && dr[5].ToString() == "")
                    {
                        row["LocationDetl"] = dr[2].ToString() + "," + dr[3].ToString();
                    }
                    else if (dr[2].ToString() != "" && dr[3].ToString() == "" && dr[5].ToString() != "")
                    {
                        row["LocationDetl"] = dr[2].ToString() + "," + dr[5].ToString();
                    }
                    else if (dr[2].ToString() != "" && dr[3].ToString() == "" && dr[5].ToString() == "")
                    {
                        row["LocationDetl"] = dr[2].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() != "" && dr[5].ToString() != "")
                    {
                        row["LocationDetl"] = dr[3].ToString() + "," + dr[5].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() == "" && dr[5].ToString() != "")
                    {
                        row["LocationDetl"] = dr[5].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() != "" && dr[5].ToString() == "")
                    {
                        row["LocationDetl"] = dr[3].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() == "" && dr[5].ToString() == "")
                    {
                        row["LocationDetl"] = "";
                    }
                    dfg.Rows.Add(row);
                   
                    
                }
                
                GetTempsearch = dfg;
            }
         }
             catch
                {
                }
            }   
            
        
        public void GetSearchWords(string str)
        {
            
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str4 = words[i];

                getmember(str4);

            }




            if (GetTempsearch == null || GetTempsearch.Rows.Count == 0)
            {
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            }
            else
            {
                RadGrid1.DataSource = GetTempsearch;

                RadGrid1.DataBind();
            }

        }
         public void FillIndustry()
        {
            try
            {
                JobSearchFA objJobSearchFA = new JobSearchFA();

                DataTable temp = new DataTable();
                temp = objJobSearchFA.GetIndustryData();
                Industry.DataTextField = "IndustryName";
                DataRow dr = temp.NewRow();
                dr["IndustryName"] = "Select IndustryName";
                temp.Rows.InsertAt(dr, 0);
                Industry.DataTextField = "IndustryName";
                Industry.DataSource = temp;
                Industry.DataBind();
            }
            catch
            {
            }
        }
         public void FillJobFamily()
         {
             JobSearchAdvancedFA objJobSearchAdvancedFA = new JobSearchAdvancedFA();

             DataTable temp = new DataTable();
             temp = objJobSearchAdvancedFA.GetFamilyData();
             DataRow dr = temp.NewRow();
             dr["JobFamilyName"] = "Select JobFamilyName";
             temp.Rows.InsertAt(dr, 0);
             JobFamilyBox.DataTextField = "JobFamilyName";
             JobFamilyBox.DataSource = temp;
             JobFamilyBox.DataBind();
         }

         protected void button_Click(object sender, EventArgs e)
         {
             GetTempsearchCollection = null;
             GetTempsearch = null;
             if ((RKeyword.Text != "") && (RJobTitle.Text != ""))
             {
                 Job();
             }
             else if ((RKeyword.Text == "") && (RJobTitle.Text != ""))
             {
                 Job();
             }
             else if ((RKeyword.Text != "") && (RJobTitle.Text == ""))
             {
                 string strkey = RKeyword.Text;
                 int ln = strkey.Length;
                 if (ln > 1)
                 {
                     string[] words = strkey.Split(' ', ',');
                     foreach (string word in words)
                     {
                         str6 = str6 + " " + word;
                         str = str6;
                     }

                     GetSearchWords(str);
                 }
                

             }
         }

        protected void countrybox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objJobSearchAdvancedSH.CountryName = countrybox.SelectedItem.Text;
        }

        protected void Industry_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objJobSearchAdvancedSH.IndustryName = Industry.Text;
        }

        protected void JobFamilyBox_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objJobSearchAdvancedSH.JobFamilyName = JobFamilyBox.Text;
        }
        protected void Job()
        {
            string str6, str7, str8, str9, str10, str15, str16, str13, str14, str5, str17, str18
                , str21, str22, strJobType, strExpT, strExpF;
            str6 = RKeyword.Text;
            if (str6 == "")
            {
                str6 = null;
            }
            str9 = " ";
            str7 = RJobTitle.Text;
            if (str7 == "")
            {
                str7 = null;
            }
            str10 = " ";
            objJobSearchAdvancedSH.Title = RJobTitle.Text;
            str15 = RCity.Text;
            if (str15 == "")
            {
                str15 = null;
            }
            str16 = " ";
            objJobSearchAdvancedSH.City = RCity.Text;
            str8 = countrybox.SelectedValue;
            if (str8 == "")
            {
                str8 = null;
            }
            str22 = " ";
            objJobSearchAdvancedSH.CountryName = countrybox.SelectedValue;
            str13 = Industry.SelectedValue;
            if (str13 == "")
            {
                str13 = null;
            }

            str14 = " ";
            objJobSearchAdvancedSH.IndustryName = Industry.SelectedValue;
            str5 = RCompany.Text;
            if (str5 == "")
            {
                str5 = null;
            }
            str21 = " ";
            objJobSearchAdvancedSH.CompanyName = RCompany.Text;
            str17 = JobFamilyBox.SelectedValue;
            if (str17 == "")
            {
                str17 = null;
            }
            objJobSearchAdvancedSH.JobFamilyName = JobFamilyBox.SelectedValue;
            str18 = " ";
            strJobType = RJobType.SelectedValue;
            if (strJobType == "")
            {
                strJobType = null;
            }
            
            strExpF = RExpF.SelectedValue;
            if(strExpF=="")
            {
                strExpF = null;
            }
            strExpT = RExpF.SelectedValue;
            if (strExpT == "")
            {
                strExpT = null;
            }


            objJobSearchAdvancedSH.JobType = RJobType.SelectedValue;
            objJobSearchAdvancedSH.JobFamilyName = JobFamilyBox.SelectedValue;
            objJobSearchAdvancedSH.ExperienceFrom = Convert.ToInt32(RExpF.SelectedValue.ToString());
            objJobSearchAdvancedSH.ExperienceTo = Convert.ToInt32(RExpT.SelectedValue.ToString());


            string ab = str6 + str9 + str7 + str10 + str15 + str16 + str8 + str22 + str13 + str14
             + str5 + str21 + str17 + str18;
            GetSearchWords(ab);
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RadioButtonList1.Text == "Anywhere")
            {
                countrybox.Enabled = false;
                RCity.Enabled = false;
            }
            else
            {
                countrybox.Enabled = true;
                RCity.Enabled = true;
            }
        }

        protected void RadGrid1_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGrid1.CurrentPageIndex = e.NewPageIndex;

            if (GetTempsearch == null)
            {
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            }
            else
            {
                RadGrid1.DataSource = GetTempsearch;
                RadGrid1.DataBind();
            }
        }

        protected void RExpF_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            //objJobSearchAdvancedSH.ExperienceFrom = Convert.ToInt32(RExpF.SelectedValue.ToString());
        }

        protected void RExpT_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            //objJobSearchAdvancedSH.ExperienceTo = RExpT.Text;
        }

        protected void RadComboBox1_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objJobSearchAdvancedSH.JobType = RJobType.Text;
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton btnprev = (LinkButton)sender;
            LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("lnkTitle");
            string JobID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["JobID"]);

            if (UserID != int.MinValue)
            {
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/popUpVwApplyRCJob.aspx?id=" + JobID;
                rd.VisibleOnPageLoad = true;
                rd.Width = 600;
                rd.Height = 500;
                rd.Left = 400;
                rd.Top = 150;
                RadWindowManager12.Windows.Add(rd);

            }
        }
    }
}
