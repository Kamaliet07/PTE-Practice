﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Text;
using System.Resources;
using System.Threading;
using System.Globalization;
namespace IRSA
{
    public partial class JobSearch : System.Web.UI.Page
    {
        JobSearchSH objJobSearchSH = new JobSearchSH();
        JobSearchFA objJobSearchFA = new JobSearchFA();
        string str;
        int UserID;
        string CULINFO;
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }

        public DataTable JobDetails
        {
            get { return (DataTable)ViewState["JobDetails"]; }
            set { ViewState["JobDetails"] = value; }
        }
        string Accountxml = "irsaToolTipSearch.xml";
    
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                XmlCountry();
                FillIndustry();


                str = Request.QueryString.Get("id");
                //if (str == "")
                //{
                //    GetList();
                //}
                //else
                //{
                //    int lng = str.Length;
                //    if (lng <= 1)
                //    {
                //        GetpersonGrid();
                //    }
                //    else
                //    {
                //        GetSearchWords(str);

                //    }
                //}
                if (str != "")
                {
                    int lng = str.Length;
                    if (lng <= 1)
                    {
                        GetpersonGrid();
                    }
                    else
                    {
                        GetSearchWords(str);

                    }

                }
                else
                {
                    //lblcomp.Text = "No matching Organisation Found.Refine your search criteria";
                    lbljob.Visible = true;
                    lbljob.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(97);
                }
            }
            GetiRsaToolTipAccMsg();
            getPageLanguageInfo();
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
               
            }
            else
            {
                Lblmember.Text = "Guest !";
            }
           
            }
        

        private void XmlCountry()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                countrybox1.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {

            }
        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                RtxtTitle.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(7, Accountxml);
                RtxtCity.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, Accountxml);

            }
            catch { 
            }
        }
        public void GetpersonGrid()
        {
            try
            {
                JobSearchFA objJobSearchFA = new JobSearchFA();
                DataTable dt = new DataTable();
                dt = objJobSearchFA.GetJob(str, objJobSearchSH);
                RadGrid1.DataSource = dt;
                RadGrid1.DataBind();
            }
            catch
            {
            }


        }
        //public void GetList()
        //{
        //    try
        //    {

        //        JobSearchFA objJobSearchFA = new JobSearchFA();
        //        DataTable dl = new DataTable();
        //        dl = objJobSearchFA.GetJobList();
        //        this.JobDetails = EvaluateLocationDtl(dl);
        //        RadGrid1.DataSource = this.JobDetails;
        //        RadGrid1.DataBind();
        //    }
        //    catch
        //    {
        //    }


        //}

        private DataTable EvaluateLocationDtl(DataTable dfg)
        {
            try
            {
                dfg.Columns.Add("LocationDetl", typeof(string));
                foreach (DataRow dr in dfg.Rows)
                {
                    if (dr[2].ToString() != "" && dr[3].ToString() != "" && dr[4].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[2].ToString() + "," + dr[3].ToString() + "," + dr[4].ToString();
                    }
                    else if (dr[2].ToString() != "" && dr[3].ToString() != "" && dr[4].ToString() == "")
                    {
                        dr["LocationDetl"] = dr[2].ToString() + "," + dr[3].ToString();
                    }
                    else if (dr[2].ToString() != "" && dr[3].ToString() == "" && dr[4].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[2].ToString() + "," + dr[4].ToString();
                    }
                    else if (dr[2].ToString() != "" && dr[3].ToString() == "" && dr[4].ToString() == "")
                    {
                        dr["LocationDetl"] = dr[2].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() != "" && dr[4].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[3].ToString() + "," + dr[4].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() == "" && dr[4].ToString() != "")
                    {
                        dr["LocationDetl"] = dr[4].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() != "" && dr[4].ToString() == "")
                    {
                        dr["LocationDetl"] = dr[3].ToString();
                    }
                    else if (dr[2].ToString() == "" && dr[3].ToString() == "" && dr[4].ToString() == "")
                    {
                        dr["LocationDetl"] = "";
                    }

                    dfg.AcceptChanges();
                }
            }
            catch
            {
            }
            return dfg;
        }
        public void getmember(string str4)
        {
            try
            {

                DataTable dtCalc = new DataTable();
                DataTable ds = new DataTable();

                if (GetTempsearchCollection == null)
                {
                    JobSearchFA objJobSearchFA = new JobSearchFA();
                    ds = objJobSearchFA.GetJob(str4, objJobSearchSH);
                    this.GetTempsearchCollection = ds;
                    

                }
                else
                {

                    if (GetTempsearchCollection.Rows.Count > 0)
                    {
                        if (GetTempsearchCollection.Rows[0]["details"].ToString() != "")
                        {
                            DataRow[] Result = GetTempsearchCollection.Select("details Like '%" + str4 + "%'");
                           

                            DataTable dfg = new DataTable();
                           
                            dfg.Columns.Add("JobID", typeof(int));
                            dfg.Columns.Add("Title", typeof(string));
                            dfg.Columns.Add("CompanyName", typeof(string));
                            dfg.Columns.Add("JobCity", typeof(string));
                            dfg.Columns.Add("JobCountry", typeof(string));
                            dfg.Columns.Add("JobDescription", typeof(string));
                            
                           
                             foreach (DataRow dr in Result)
                            {
                                DataRow row;
                                row = dfg.NewRow();
                                row["JobID"] = dr[8];
                                row["Title"] = dr[1];
                                row["CompanyName"] = dr[2];
                                row["JobCity"] = dr[3];
                                row["JobCountry"] = dr[4];
                                row["JobDescription"] = dr[5];
                               
                               dfg.Rows.InsertAt(row, 0);


                            }
                            GetTempsearchCollection = dfg;
                        }

                    }
                }
              }
                        catch
                        {
                        }
               }
        
        public void GetSearchWords(string str)
        {
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str4 = words[i];

                getmember(str4);

            }


            if (GetTempsearch == null)
            {
               
                this.JobDetails = EvaluateLocationDtl(this.GetTempsearchCollection);
                RadGrid1.DataSource = this.JobDetails;
                RadGrid1.DataBind();
                
            }
            else if (GetTempsearch != null)
            {
                this.JobDetails = EvaluateLocationDtl(this.GetTempsearchCollection);
                RadGrid1.DataSource = this.JobDetails;
                RadGrid1.DataBind();
               
            }
            else
            {
                this.JobDetails = EvaluateLocationDtl(this.GetTempsearchCollection);
                RadGrid1.DataSource = this.JobDetails;
                RadGrid1.DataBind();
                
            }

        }

        protected void Button_Click(object sender, EventArgs e)
        {
            GetTempsearchCollection = null;
            GetTempsearch = null;
            Job();
        
        }
        
        
        public void FillIndustry()
        {
            try
            {
                JobSearchFA objJobSearchFA = new JobSearchFA();
                DataTable temp = new DataTable();
                temp = objJobSearchFA.GetIndustryData();
                DataRow dr = temp.NewRow();
                dr["IndustryName"] = "Select IndustryName";                
                temp.Rows.InsertAt(dr, 0);               
                Industry.DataTextField = "IndustryName";
                Industry.DataSource = temp;
                Industry.DataBind();
            }
            catch
            {
            }
        }
        protected void Job()
        {
            string str6, str7, str9, str10, str11, str12, str14;
            str11 = RtxtTitle.Text;
            str12 = " ";
            objJobSearchSH.Title = RtxtTitle.Text; ;
            str6 = Industry.SelectedValue;
            str9 = " ";
            objJobSearchSH.IndustryName = Industry.SelectedValue;
            str7 = RtxtCity.Text;
            str10 = " ";
            objJobSearchSH.City = RtxtCity.Text;
            str14 = countrybox1.SelectedValue;
            objJobSearchSH.CountryName = countrybox1.SelectedValue;
            string ab = str11 + str12 + str6 + str9 + str7 + str10 + str14;
            GetSearchWords(ab);
        }


        protected void countrybox1_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objJobSearchSH.CountryName = countrybox1.SelectedItem.Text;
        }

        

        protected void Industry_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            objJobSearchSH.IndustryName = Industry.Text;
        }

       
         protected void RadGrid1_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            //if (str == "" || str== null)
            //{
            //    GetList();
            //}
            if(str!="")
            {
                int lng = str.Length;
                if (lng <= 1)
                {
                    GetpersonGrid();
                }
                else
                {
                    GetSearchWords(str);

                }
            }
            
        }

        protected void LinkButton1_Click1(object sender, EventArgs e)
        {
            
                Response.Redirect("JobSearchAdvanced.aspx");
            
          
        }

        protected void lnkTitle_Click(object sender, EventArgs e)
        {
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton btnprev = (LinkButton)sender;
            LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("lnkTitle");
            string JobID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["JobID"]);

            if (UserID != int.MinValue)
            {
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/popUpVwApplyRCJob.aspx?id=" + JobID;
                rd.VisibleOnPageLoad = true;
                rd.Width = 600;
                rd.Height = 500;
                rd.Left = 400;
                rd.Top = 150;
                RadWindowManager12.Windows.Add(rd);

            }
            else
            {

                lbljob.Visible = true;
                //lbljob.Text = "You must be logged in to view the job";
                lbljob.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(95);
            }
        }
        protected void getPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;

                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_JobSearch");
                LKeywords.Text = (string)GetGlobalResourceObject("PageResource", "Label10_JobPostingProfile");
                LIndustry.Text = (string)GetGlobalResourceObject("PageResource", "LblIndustry_Registration");
                LCountry.Text = (string)GetGlobalResourceObject("PageResource", "Label10_ScreeningSchedule");
                LCity.Text = (string)GetGlobalResourceObject("PageResource", "Label11_ScreeningSchedule");
                Button1.Text = (string)GetGlobalResourceObject("PageResource", "btnFind_ResumeVsSavedJobs");
                RadGrid1.MasterTableView.NoDetailRecordsText = (string)GetGlobalResourceObject("PageResource", "RadGrid1_JobSearch");
            }
            catch
            {
            }

        }

    }
}


        




