﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using System.Globalization;
using System.Resources;
using System.Configuration;
using System.Threading;
using IRSA.Shared;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;

namespace IRSA
{
    public partial class CommunityInformation : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserID = SessionInfo.UserId;
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }    
            if (!IsPostBack)
            {
                FillCategory();
                FillCommunityType();
                FillFunctionalDomain();
            }
           }
            catch
            {
            }
            }


        public void FillCategory()
        {
           try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/CommunityCategory.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                RdCboSearch.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {
            }         

        }

     
        public void FillCommunityType()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/CommunityCategory.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                ddlCommunityType.LoadXml(NodeIter1.Current.InnerXml);
  

            //IRSA.Facade.Community.CommunityFA comm = new IRSA.Facade.Community.CommunityFA();

            //DataTable temp = new DataTable();
            //temp = comm.GetCommunityData();
            //ddlCommunityType.DataValueField = "CatagoryID";
            //ddlCommunityType.DataTextField = "CatagoryName";
            //ddlCommunityType.DataSource = temp;
            //ddlCommunityType.DataBind();
            }
            catch
            {
            }

        }
        public void FillFunctionalDomain()
        {
            try
            {
            IRSA.Facade.Community.CommunityFA comm = new IRSA.Facade.Community.CommunityFA();

            DataTable temp = new DataTable();
            temp = comm.GetData();
            ddlFuctionalDomain.DataValueField = "IndustryID";
            ddlFuctionalDomain.DataTextField = "IndustryName";
            ddlFuctionalDomain.DataSource = temp;
            ddlFuctionalDomain.DataBind();
            }
            catch
            {
            }
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
           try
           {
            SessionInfo.i_CategoryName =RdCboSearch.SelectedItem.Text;
            SessionInfo.i_CommSearch = txtSearch.Text;
            DataTable ojdt = new DataTable();

            IRSA.Facade.Community.CommunityFA comm = new IRSA.Facade.Community.CommunityFA();

            ojdt = comm.GetCommunityDetails(1,"EN",RdCboSearch.SelectedItem.Text,txtSearch.Text);
            foreach (DataRow dr in ojdt.Rows)
            {
                txtShortDescription.Text = ojdt.Rows[0]["ShortDescription"].ToString();
                txtDetailDescription.Text = ojdt.Rows[0]["DetailedDescription"].ToString();
                txtURL.Text = ojdt.Rows[0]["WebsiteUrl"].ToString();
                ddlFuctionalDomain.SelectedItem.Text = ojdt.Rows[0]["FunctionalDomain"].ToString();
                ddlCommunityType.SelectedItem.Text = ojdt.Rows[0]["CommunityType"].ToString();
            }
           }
           catch
           {
           }
        }

        protected void btnCommunityIdentity_Click(object sender, EventArgs e)
        {

        }

        protected void btnCommunityInformation_Click(object sender, EventArgs e)
        {

        }

        protected void btnCommunitySettings_Click(object sender, EventArgs e)
        {

        }

        protected void btnCommunityDirectory_Click(object sender, EventArgs e)
        {

        }

        protected void btnMyCommunity_Click(object sender, EventArgs e)
        {

        }

        protected void btnCreateCommunity_Click(object sender, EventArgs e)
        {

        }

        protected void btnContinue_Click(object sender, EventArgs e)
        {
            try
            {
            SessionInfo.i_CommunityType = ddlCommunityType.SelectedItem.Text;
            SessionInfo.i_FunctionalDomain = ddlFuctionalDomain.SelectedItem.Text;
            SessionInfo.i_ShortDescription = txtShortDescription.Text;
            SessionInfo.i_DetailedDescription = txtDetailDescription.Text;
            SessionInfo.i_WebsiteURL = txtURL.Text;
            Response.Redirect("CommunitySettings.aspx");
            }
            catch
            {
            }
        }


    
    }
}
