﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Collections.Specialized;
using System.Globalization;
using System.Resources;
using System.Configuration;
using Telerik.Web.UI;
using System.Collections;
namespace IRSA
{
    public partial class OrganisationQuestionBank : System.Web.UI.Page
    {
        int OrganisationID;
        public String keyword
        {
            set
            {
                ViewState["keyword"] = value;
            }
            get
            {
                if (ViewState["keyword"] == null)
                {
                    ViewState["keyword"] = "";
                }
                return (ViewState["keyword"].ToString());
            }
        }
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }


        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public DataTable RadGridQuestionBankData
        {
            get { return (DataTable)ViewState["RadGridQuestionBankData"]; }
            set { ViewState["RadGridQuestionBankData"] = value; }
        }
        public int OccupationID
        {
            set
            {
                ViewState["OccupationID"] = value;
            }
            get
            {
                if (ViewState["OccupationID"] == null)
                {
                    ViewState["OccupationID"] = 0;
                }
                return Convert.ToInt32(ViewState["OccupationID"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ID"] != null)
            {
                OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);



            }

            Comboboxbind();

        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    RadGridQuestionBank.DataSource = this.RadGridQuestionBankData;
                    RadGridQuestionBank.DataBind();


                }


                SelectQuestionnaireRadioList();
            }
            catch { }
        }
        public void Comboboxbind()
        {
            try
            {
                SkillQuestionnaireFA objFA = new SkillQuestionnaireFA();
                DataTable temp = new DataTable();
                temp = objFA.BindJobFamilyData();
                ComboJobFamily.DataSource = temp;
                ComboJobFamily.DataBind();
            }
            catch
            {
            }
        }
        public void RadGridQuestionBankoccupationBind(int jobmaillyID)
        {
            try
            {
                SkillQuestionnaireFA objFA = new SkillQuestionnaireFA();
                DataTable temp = new DataTable();
                temp = objFA.BindOccupation(jobmaillyID);
                this.RadGridQuestionBankData = temp;
                TotalCount = this.RadGridQuestionBankData.Rows.Count;
                RadGridQuestionBank.DataSource = temp;
                RadGridQuestionBank.DataBind();
            }
            catch
            {
            }
        }
        protected void ComboJobFamily_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int jobmaillyID = Convert.ToInt32(ComboJobFamily.SelectedValue.ToString());
                OccupationID = jobmaillyID;
                RadGridQuestionBankoccupationBind(jobmaillyID);
            }
            catch { }
        }

 
        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }
        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }

        protected void RadGridQuestionBank_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGridQuestionBank.DataSource = this.RadGridQuestionBankData;
            RadGridQuestionBank.DataBind();
            SelectQuestionnaireRadioList();
        }

        //protected void BtnSave_Click(object sender, EventArgs e)
        //{
        //    OrganisationQuestionaireBankFA fa = new OrganisationQuestionaireBankFA();
        //    if (SelectedParentRecord.Count > 0)
        //    {

        //        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
        //        while (Enumerator.MoveNext())
        //        {
        //            string ONETSOCCodeID = Convert.ToString(Enumerator.Key.ToString());
        //            fa.QuestionStatus(ONETSOCCodeID);

        //        }
        //        SelectedParentRecord = null;



        //    }
        //}
        private void SelectQuestionnaireRadioList()
        {
            try
            {
                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < RadGridQuestionBank.MasterTableView.Items.Count; i++)
                    {
                        string eid = RadGridQuestionBank.MasterTableView.DataKeyValues[i]["ONETSOCCode"].ToString();
                     

                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            CheckBoxList obj1 = (CheckBoxList)RadGridQuestionBank.Items[i].FindControl("ChkBox");

                            obj1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;
                            //lblErrorMsg.Visible = false;
                        }
                        else
                        {
                            


                        }
                    }
                }
                else
                {

                }
            }
            catch { }
        }

        private void ResetCheckBoxSelection(RadGrid radGrid, string templateCol, string checkBoxid)
        {
           
        }
        protected void BtnUpdateSave_Click(object sender, EventArgs e)
        {
            OrganisationQuestionaireBankFA fa = new OrganisationQuestionaireBankFA();
            if (SelectedParentRecord.Count > 0)
            {

                IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                while (Enumerator.MoveNext())
                {
                    string ONETSOCCodeID = Convert.ToString(Enumerator.Key.ToString());
                    fa.QuestionStatus(ONETSOCCodeID);

                }
                SelectedParentRecord = null;

                if (Request.QueryString["ID"] != null)
                {
                    OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);

                    Response.Redirect("OrganisationWizardSecondaryContact.aspx");


                }

            }

        }

        //protected void BtnReset_Click(object sender, EventArgs e)
        //{

        //}

        protected void BtnNext_Click(object sender, EventArgs e)
        {
            OrganisationQuestionaireBankFA fa = new OrganisationQuestionaireBankFA();
            if (SelectedParentRecord.Count > 0)
            {

                IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                while (Enumerator.MoveNext())
                {
                    string ONETSOCCodeID = Convert.ToString(Enumerator.Key.ToString());
                    fa.QuestionStatus(ONETSOCCodeID);

                }
                SelectedParentRecord = null;

                if (Request.QueryString["ID"] != null)
                {
                    OrganisationID = Convert.ToInt32(Request.QueryString["ID"]);

                    Response.Redirect("OrganisationLicense.aspx");


                }

            }

        }

        protected void RadGridQuestionBank_ItemDataBound(object sender, GridItemEventArgs e)
        {
           
        }

        protected void Onchkclick(object sender, EventArgs e)
        {
            StringCollection idCollection = new StringCollection();
            string strID = string.Empty;

            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            CheckBoxList ChkBoxClicik = (CheckBoxList)sender;
            CheckBoxList obj1 = (CheckBoxList)ChkBoxClicik.NamingContainer.FindControl("ChkBox");
            string ONETSOCCodeID = Convert.ToString(RadGridQuestionBank.MasterTableView.DataKeyValues[gr.ItemIndex]["ONETSOCCode"]);
            strID = Convert.ToString(ONETSOCCodeID);
           
           
            if (obj1.SelectedValue != "")
                {
                    if (CRecordCount < TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(strID) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(strID);
                        }
                        CRecordCount++;
                        SaveRecord(strID, obj1.SelectedValue);

                    }
                }

            else
            {
                if (CRecordCount > 0)
                {
                    CRecordCount--;
                    RemoveRecord(strID);
                }
            }

            

            RadGridQuestionBank.DataSource = this.RadGridQuestionBankData;
            RadGridQuestionBank.DataBind();
            SelectQuestionnaireRadioList();
        }
    }
}
