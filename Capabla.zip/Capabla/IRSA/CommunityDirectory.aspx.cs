﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using System.Globalization;
using System.Resources;
using System.Configuration;
using System.Threading;
using IRSA.Shared;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;


namespace IRSA
{
    public partial class CommunityDirectory : System.Web.UI.Page
    {
        int UserID;
        string AddCommunityImage;
        public string FunctionalDomain
        {
            set
            {
                ViewState["FunctionalDomain"] = value;
            }
            get
            {
                if (ViewState["FunctionalDomain"] == null)
                {
                    ViewState["FunctionalDomain"] = string.Empty;
                }
                return ViewState["FunctionalDomain"].ToString();
            }
        }
        public int CommunityID
        {
            set
            {
                ViewState["CommunityID"] = value;
            }
            get
            {
                if (ViewState["CommunityID"] == null)
                {
                    ViewState["CommunityID"] = 0;
                }
                return Convert.ToInt32(ViewState["CommunityID"].ToString());
            }
        }
        public DataTable GetCommunityDetail
        {
            get { return (DataTable)ViewState["GetCommunityDetail"]; }
            set { ViewState["GetCommunityDetail"] = value; }
        }
        string Accountxml = "Community.xml";
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserID = SessionInfo.UserId;
                AddCommunityImage = ConfigurationSettings.AppSettings["AddCommunityImage"];
                if (UserID != int.MinValue)
                {
                    Lblmember.Text = SessionInfo.FirstName + " " + "!";                   
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
                if (!Page.IsPostBack)
                {
                    this.FunctionalDomain = SessionInfo.i_FunctionalDomain;
                    LabelDomainName.Text = SessionInfo.i_FunctionalDomain;
                    btnCommunityDirectory.BackColor = System.Drawing.Color.OrangeRed;
                    FillCategory();
                    if (this.FunctionalDomain != null)
                    {
                        FillCommunityDirectoryData();
                    }
                    GetiRsaToolTipAccMsg();
                }


            }
            catch
            {
            }
        }
        private void FillCommunityDirectoryData()
        {
            IRSA.Facade.Community.CommunityFA objcomm = new IRSA.Facade.Community.CommunityFA();
            this.GetCommunityDetail = objcomm.GetCommunityDirectory(SessionInfo.UserId, "EN", this.FunctionalDomain);
            RebindTablleForImage();            
            RadGridDirectory.DataSource = this.GetCommunityDetail;
            RadGridDirectory.DataBind();

        }

        private void RebindTablleForImage()
        {
            this.GetCommunityDetail.Columns.Add(new DataColumn("NewImagePath", typeof(string)));
            foreach (DataRow dr in  this.GetCommunityDetail.Rows)
            {
              string imagpath = AddCommunityImage + dr["CommunityLogo"].ToString();
              dr["NewImagePath"] = imagpath;
            }
        }

        private void FillCategory()
        {
            try
            {
                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/CommunityCategory.xml"));
                nav1 = docNav1.CreateNavigator();
                string strExp = "/root/English";
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                RdCboSearch.LoadXml(NodeIter1.Current.InnerXml);
            }
            catch
            {
            }  
        }

        protected void ImgBtnAdvance_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                ImageButton chk = (ImageButton)sender;
                ImageButton obj = (ImageButton)chk.NamingContainer.FindControl("ImgBtnAdvance");
                this.CommunityID = Convert.ToInt32(RadGridDirectory.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
                Response.Redirect("CommunityDetail.aspx?ID=" + this.CommunityID);
            }

            catch
            { 
            
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton chk = (LinkButton)sender;
                LinkButton obj = (LinkButton)chk.NamingContainer.FindControl("LinkButton1");
                this.CommunityID = Convert.ToInt32(RadGridDirectory.MasterTableView.DataKeyValues[gr.ItemIndex]["CommunityID"].ToString());
                Response.Redirect("CommunityDetail.aspx?ID=" + this.CommunityID);
            }

            catch
            { 
            
            }
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                string str6 = string.Empty;
                string combofield = RdCboSearch.Text;
                string str = rdtxtSearch.Text;
                int ln = str.Length;
                if (ln > 1)
                {
                    string[] words = str.Split(' ', ',');
                    foreach (string word in words)
                    {
                        str6 = str6 + " " + word;
                        str = str6;
                    }
                }
                if (ln != 0 && combofield != "Select")
                {
                    IRSA.Facade.Community.CommunityFA objcomm = new IRSA.Facade.Community.CommunityFA();
                    this.GetCommunityDetail = objcomm.GetSearchCommunity(str, combofield);
                    BindSearchGris();
                }

                else
                {
                    Lblshow.Text = "Text Field required";

                }
            }
            catch
            { 
            
            }

        }

        private void BindSearchGris()
        {
            RadGridDirectory.DataSource = EmptyUserSavedData();
            RadGridDirectory.DataBind();
            RadGridDirectory.DataSource = this.GetCommunityDetail;
            RadGridDirectory.DataBind();
        }


        private static DataTable EmptyUserSavedData()
        {
            DataTable objDT = new DataTable();
            objDT.Columns.Add(new DataColumn("CommunityID", typeof(int)));
            objDT.Columns.Add(new DataColumn("CommunityLogo", typeof(string)));
            objDT.Columns.Add(new DataColumn("CommunityName", typeof(string)));
            objDT.Columns.Add(new DataColumn("ShortDescription", typeof(string)));
            return objDT;

        }

        protected void RadGridDirectory_OnPageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            RadGridDirectory.DataSource = this.GetCommunityDetail;
            RadGridDirectory.DataBind();
        }

        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                rdtxtSearch.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(8, Accountxml);
                RdCboSearch.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);

            }
            catch { }
        }
    
    }
}
