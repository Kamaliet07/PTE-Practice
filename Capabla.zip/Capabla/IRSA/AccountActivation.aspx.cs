﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class AccountActivation : System.Web.UI.Page
    {
        string UserID;
        string AppName;
        protected void Page_Load(object sender, EventArgs e)
        {

            UserID = Request.QueryString.Get("param1");
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Form.DefaultButton = BtnSubmit.UniqueID;
            Lblapp.Text = AppName;
            if (!IsPostBack)
            {
                LbCaptcha.Text = randompassword();
                GetUserInformation(UserID); 

            }
            
        }
        public void GetUserInformation(string UserID)
        {
            IRSA.Facade.AccountActivationFA UserInfo = new IRSA.Facade.AccountActivationFA();
            DataTable temp = new DataTable();
            temp = UserInfo.RetrieveUserID(UserID);
            if (temp.Rows.Count > 0)
            {
                txtusername.Text = temp.Rows[0]["EmailID"].ToString();
                if (Convert.ToBoolean(temp.Rows[0]["Active"].ToString()) == true)
                {
                    BtnSubmit.Enabled = false;
                    lblmsg.Visible = true;
                    lblmsg.Text = ErrorMessage.GetiRsaErrorMessage(80) + AppName + ErrorMessage.GetiRsaErrorMessage(81) + ErrorMessage.GetiRsaErrorMessage(82) + AppName;
                    hypelogin.Visible = true;
                }
                else
                {
                    lblmsg.Visible = false;
                    BtnSubmit.Enabled = true;
                    hypelogin.Visible = false;
                }
            }
            
        }
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {

            RegistrationSH objRegistrationSH = new RegistrationSH();
            string userentercode = Txtcapcode.Text;
            ValidateUserCode(userentercode);
            objRegistrationSH.CapchaCode = Txtcapcode.Text;
           
        }
        private void ValidateUserCode(string userEnteredCode)
        {
            if (LbCaptcha.Text == userEnteredCode)
            {
                IRSA.Facade.AccountActivationFA active = new IRSA.Facade.AccountActivationFA();
                active.Getactive(UserID);
                LblError.Visible = false;
                hypelogin.Visible = true;
                lblmsg.Visible = true;
                lblmsg.Text = ErrorMessage.GetiRsaErrorMessage(84);
                BtnSubmit.Enabled = false;
                Txtcapcode.Text = "";
            }
            else
            {
                // clear the session and generate a new code 
               
                LblError.Visible = true;
                LblError.Text = ErrorMessage.GetiRsaErrorMessage(85);
                hypelogin.Visible = false;
                lblmsg.Visible = false;
                BtnSubmit.Enabled = true;
                LbCaptcha.Text = randompassword();
                Txtcapcode.Text = "";
            }
        }

       

        public static string randompassword()
        {
            string passwordString;
            string allowedChars = "";

            allowedChars = "0,1,2,3,4,5,6,7,8,9";


            char[] sep = { ',' };
            string[] arr = allowedChars.Split(sep);

            passwordString = "";

            string temp = "";

            Random rand = new Random();
            for (int i = 0; i < 6; i++)
            {
                temp = arr[rand.Next(0, arr.Length)];
                passwordString += temp;
            }

            return passwordString;
        }

        protected void ImageButton_Click(object sender, ImageClickEventArgs e)
        {
            LbCaptcha.Text = randompassword();
        }

    }
}
