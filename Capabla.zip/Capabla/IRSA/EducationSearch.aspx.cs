﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Text.RegularExpressions;
using Telerik.Web.UI;
//using System.Web.UI.HtmlControls;

namespace IRSA
{
    public partial class EducationSearch : System.Web.UI.Page
    {
        int UserID;
        string str, str2;
        
        public DataTable GetTempsearchCollection
        {
            get { return (DataTable)ViewState["GetTempsearchCollection"]; }
            set { ViewState["GetTempsearchCollection"] = value; }
        }
        public DataTable GetTempsearch
        {
            get { return (DataTable)ViewState["GetTempsearch"]; }
            set { ViewState["GetTempsearch"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
                str = Request.QueryString.Get("id");
                if (str == "")
                {

                    GetEducationList();
                }
                else
                {
                    int lng = str.Length;
                    if (lng <= 1)
                    {
                        GetEducation();
                    }
                    else
                    {
                        GetSearchWords(str);

                    }
                }
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                   
                }
                else
                {
                    Lblmember.Text = "Guest !";
                }
            }


        }
        protected void GetEducation()
        {
            GetTempsearchCollection = null;
            int ln = str.Length;
            if (ln > 1)
            {
                char[] ch = { ' ', ',' };
                int j = ch.Count();

                String[] words = str.Split(ch);
                for (int i = 0; i < words.Length; i++)
                {
                    str2 = str2 + " " + words[i];

                }
                GetSearchWords(str2);
            }

        }
        public void GetSearchWords(string str2)
        {
            string pattern = @"\S+";
            Regex re = new Regex(pattern);

            MatchCollection matches = re.Matches(str2);
            string[] words = new string[matches.Count];
            for (int i = 0; i < matches.Count; i++)
            {
                words[i] = matches[i].Value;
                string str6 = words[i];

                SearchEducation(str6);
            }
            RadGrid1.DataSource = GetTempsearchCollection;
            RadGrid1.DataBind();

        }
        public void SearchEducation(string str6)
        {
            try
            {
                PersonSearchFA objPerson = new PersonSearchFA();
                DataTable dtCalc = new DataTable();
                DataTable ds = new DataTable();
                ds = objPerson.GetEducationSearch(str6);

                if (GetTempsearchCollection == null)
                {


                    GetTempsearchCollection = ds;
                }
                else
                {
                    dtCalc = ds;
                    dtCalc.Merge(GetTempsearchCollection);
                    GetTempsearchCollection = dtCalc;
                }

            }

            catch
            {
            }
        }
        public void GetEducationList()
        {
            PersonSearchFA objPerson = new PersonSearchFA();
            DataTable dt = new DataTable();
            dt = objPerson.GetEducationList();

            RadGrid1.DataSource = dt;
            GetTempsearch = dt;
            RadGrid1.DataBind();

        }

        protected void RadGrid1_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            if (GetTempsearchCollection == null)
            {
                RadGrid1.DataSource = GetTempsearch;
                RadGrid1.DataBind();
            }


            else
            {
                RadGrid1.DataSource = GetTempsearchCollection;
                RadGrid1.DataBind();
            } 

          
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            lbleduc.Visible = false;
            GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
            LinkButton btnprev = (LinkButton)sender;
            LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("LinkButton1");
            string EventID = Convert.ToString(RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["EventID"]);

            if (UserID != int.MinValue)
            {
                RadWindow rd = new RadWindow();
                rd.ID = "RadWindowhelp";
                rd.NavigateUrl = "~/PersonProfile.aspx" + EventID;
                rd.VisibleOnPageLoad = true;
                rd.Width = 600;
                rd.Height = 500;
                rd.Left = 400;
                rd.Top = 150;
                RadWindowManagerE.Windows.Add(rd);
            }
            else
            {

                lbleduc.Visible = true;
                lbleduc.Text = "You must be logged in to view the details of training";
            }
        }

    }
}
