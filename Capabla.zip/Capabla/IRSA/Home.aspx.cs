﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using IRSA.Common.GlobalFunction;
using System.Globalization;
using System.Resources;
using System.Threading;
using IRSA.Facade;


namespace IRSA
{
    public partial class Home : System.Web.UI.Page
    {
        int UserID;
        string CULINFO;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            }
            else
            {
                Lblmember.Text = "Guest !";
            }
            getHomewPageLanguageInfo();
            //WebPartManager1.DisplayMode = WebPartManager.DesignDisplayMode;
            
            
        }


        //protected void Page_LoadComplete(object sender, EventArgs e)
        //{
        //    if (WebPartManager1.WebParts.Count == 0)
        //    {

        //        if (Session["NewAddedControl"] != null)
        //        {
        //            DataTable controldt = new DataTable();
        //            controldt = Session["NewAddedControl"] as DataTable;
        //            setwebpartonpage(controldt);
        //            Session["NewAddedControl"] = null;
        //        }

        //    }

        //}
        private void ResetPersonalization()
        {
            // put the web parts back to their initial state
            WebPartManagerHome.Personalization.ResetPersonalizationState();
        }
        private void setwebpartonpage(DataTable controldt)
        {
            //string zonepath = string.Empty;
            foreach (DataRow contdr in controldt.Rows)
            {
                string contr = contdr["ControlName"].ToString().Trim();
                Control control = LoadControl("~/UserControl/" + contr);
                control.ID = contr;
                WebPart myWebPart = WebPartManagerHome.CreateWebPart(control);

                WebPartManagerHome.AddWebPart(myWebPart, WebPartZone1, 0);

            }

        }
        protected void getHomewPageLanguageInfo()
        {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            LblWelcome.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
            LinkbtnUseragree_Home.Text = (string)GetGlobalResourceObject("PageResource", "LinkbtnUseragree_Login");
            LblPrivPolicy_Home.Text = (string)GetGlobalResourceObject("PageResource", "LblPrivPolicy_Login");
            LblCopyRight_Home.Text = (string)GetGlobalResourceObject("PageResource", "LblCopyrghtPolicy_Login");
            LblCopyrghtL2_Home.Text = (string)GetGlobalResourceObject("PageResource", "LblCopyrghtL2_Home");
            LblCopyrghtL3_Home.Text = (string)GetGlobalResourceObject("PageResource", "LblCopyrghtL3_Home");
            lnkcontact.Text = (string)GetGlobalResourceObject("PageResource", "lnkcontact");
            WebPartZone3.WebParts[0].Title = (string)GetGlobalResourceObject("PageResource", "WebPartZone3_Home");
            WebPartZone1.WebParts[0].Title = (string)GetGlobalResourceObject("PageResource", "WebPartZone1_Home");
            WebPartZone2.WebParts[0].Title = (string)GetGlobalResourceObject("PageResource", "WebPartZone2_Home");
            WebPartZone10.WebParts[0].Title = (string)GetGlobalResourceObject("PageResource", "WebPartZone10_Home");
        }
       

    }
}