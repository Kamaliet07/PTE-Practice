﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;


namespace IRSA
{
    public partial class CommunityDomains : System.Web.UI.Page
    {
        int UserID;
        string IndustryName;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            }
            else
            {
                Lblmember.Text = "Guest !";
            }
        }

        protected void ImgBtnAdvance_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Advanced Manufacturing";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Advanced Manufacturing";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImgBtnAero_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Aerospace";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Aerospace";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImgBtnid_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Automotive";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Automotive";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Biotechnology";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Biotechnology";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Construction";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Construction";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Business Management and Administration";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton6_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Business Management and Administration";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Education";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton7_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Education";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Energy";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton8_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Energy";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Financial Services";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton9_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Financial Services";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Geospatial Technology";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton10_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Geospatial Technology";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Art & Humanities";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton11_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Art & Humanities";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Retail";
            Response.Redirect("CommunityDirectory.aspx");
        }

        protected void LinkButton12_Click(object sender, EventArgs e)
        {
            SessionInfo.i_FunctionalDomain = "Retail";
            Response.Redirect("CommunityDirectory.aspx");
        }

        
    }
}
