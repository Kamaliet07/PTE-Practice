﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using System.Data;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class CareerLadderDetailsConstruction : System.Web.UI.Page
    {
        int UserID;
        string tabName;
        string CLDetailID = "8"; 
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            tabName = Request.QueryString.Get("id").ToString();
            ViewDetails(tabName);
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }    
        }

        public void ViewDetails(string tabName)
        {
            string Onsetcode = null;


            if (tabName == "Construction Foreman")
            {
                Onsetcode = "47-1011.00";
            }
            if (tabName == "Tile & Marble Setter")
            {
                Onsetcode = "47-2044.00";
            }
            if (tabName == "Bricklayer")
            {
                Onsetcode = "47-2021.00";
            }
            if (tabName == "Stonemason")
            {
                Onsetcode = "47-2022.00";
            }
            if (tabName == "Tapers")
            {
                Onsetcode = "47-2082.00";
            }
            if (tabName == "Glaziers")
            {
                Onsetcode = "47-2121.00";
            }
            if (tabName == "Construction Laborers")
            {
                Onsetcode = "47-2061.00";
            }
            if (tabName == "Helper/Finisher")
            {
                Onsetcode = "47-3011.00";
            }

            bindGridViewDetail(Onsetcode);

        }
        public void bindGridViewDetail(string Onsetcode)
        {
            CarrerLadderFA objLadderFA = new CarrerLadderFA();
            DataTable dtgridDetailTask = new DataTable();
            DataTable dtgridDetailKnowlwdge = new DataTable();
            DataTable dtgridDetailAbility = new DataTable();
            DataTable dtgridDetailSkills = new DataTable();
            DataTable dtgridDetailWorkActivities = new DataTable();

            dtgridDetailTask = objLadderFA.GetDetailCLTask(Onsetcode,0);
            dtgridDetailKnowlwdge = objLadderFA.GetDetailCLKnowlwdge(Onsetcode,1);
            dtgridDetailAbility = objLadderFA.GetDetailCLAbility(Onsetcode,2);
            dtgridDetailSkills = objLadderFA.GetDetailCLSkills(Onsetcode,3);
            dtgridDetailWorkActivities = objLadderFA.GetDetailCLWorkActivities(Onsetcode,4);

            radgridCLTasks.DataSource = dtgridDetailTask;
            radgridCLTasks.DataBind();
            radgridKnowledge.DataSource = dtgridDetailKnowlwdge;
            radgridKnowledge.DataBind();
            radgridSkills.DataSource = dtgridDetailSkills;
            radgridSkills.DataBind();
            radgridAbilities.DataSource = dtgridDetailAbility;
            radgridAbilities.DataBind();
            radgridWorkActivities.DataSource = dtgridDetailWorkActivities;
            radgridWorkActivities.DataBind();
        }
        protected void radgridCLTasks_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }

        protected void LnkBtnBackToCLInfo_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderConstructionInfo.aspx?id=" + CLDetailID);
        }

        protected void radgridTools_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }

        protected void radgridKnowledge_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }

        protected void radgridSkills_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }

        protected void radgridAbilities_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }

        protected void radgridWorkActivities_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }
    }
}
