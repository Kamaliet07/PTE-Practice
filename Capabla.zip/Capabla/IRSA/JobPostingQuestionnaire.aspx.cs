﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using Telerik.Web.UI;
using System.Collections;
using IRSA.Shared;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Resources;
using IRSA.BussinessLogic;
using System.Configuration;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class JobPostingQuestionnaire : System.Web.UI.Page
    {
        int UserID;
        int JobID;
        string step = "";
        int QuesCount;
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }
        public int RadioRecordCount
        {
            set
            {
                ViewState["RadioRecordCount"] = value;
            }
            get
            {
                if (ViewState["RadioRecordCount"] == null)
                {
                    ViewState["RadioRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["RadioRecordCount"].ToString());
            }
        }

        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public string stroccuption
        {
            set
            {
                ViewState["stroccuption"] = value;
            }
            get
            {
                if (ViewState["stroccuption"] == null)
                {
                    ViewState["stroccuption"] = "";
                }
                return ViewState["stroccuption"].ToString();
            }
        }

      
        public Hashtable SelectedRadioParentRecord
        {
            set
            {
                ViewState["SelectedRadioParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedRadioParentRecord"] == null)
                {
                    SelectedRadioParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedRadioParentRecord"];
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }    
            string Job = Request.QueryString.Get("ID");
            if (Job != "")
            {
                JobID = Convert.ToInt32(Job);
                //JobID = 5;
            }
        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    GetJobQuestion();


                }


               // SelectCheckedBox();
                SelectRadioButton();
            }
            catch
            {
            }
        }
        protected void GetJobQuestion()
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    GetSavedData();
                }

                DataTable dtJobQus = new DataTable();
                JobPostingFA ObjJoPostingFA = new JobPostingFA();
                dtJobQus = ObjJoPostingFA.GetJobQuestionnaireData(JobID);
                TotalCount = dtJobQus.Rows.Count;
                Grid_JobQuestionnaire.DataSource = dtJobQus;
                Grid_JobQuestionnaire.DataBind();
            }
            catch
            {
            }

        }

       
        private void SelectRadioButton()
        {
            try
            {

                if (SelectedRadioParentRecord.Count > 0)
                {
                    for (int i = 0; i < Grid_JobQuestionnaire.MasterTableView.Items.Count; i++)
                    {
                        string eid = Grid_JobQuestionnaire.MasterTableView.DataKeyValues[i]["ElementID"].ToString();



                        if (SelectedRadioParentRecord.ContainsKey(eid))
                        {
                            RadioButtonList objrb1 = (RadioButtonList)Grid_JobQuestionnaire.Items[i].FindControl("rb1_list");
                            objrb1.Items.FindByValue(SelectedRadioParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch
            {
            }
        }

       
        private void GetSavedData()
        {
            try
            {
                JobPostingFA objJobposingFa = new JobPostingFA();
                DataTable Getdt = new DataTable();
                Getdt = objJobposingFa.GetSubmitJobQuestionsStatus(JobID);
                QuesCount = Getdt.Rows.Count;

                if (Getdt.Rows.Count > 0)
                {
                    for (int i = 0; i < Getdt.Rows.Count; i++)
                    {
                        string ElementID = Getdt.Rows[i]["ElementID"].ToString();
                        string DataValue = Getdt.Rows[i]["DataValue"].ToString();
                        if (DataValue != "")
                        {
                            RadioRecordCount++;
                            SaveRadioButtonRecord(ElementID, DataValue);
                        }
                    }
                }

            }
            catch
            {
            }

        }
        protected void rb1_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");

                eid = Grid_JobQuestionnaire.MasterTableView.DataKeyValues[gr.ItemIndex]["ElementID"].ToString();
                if (objrb2.SelectedValue != "")
                {
                    if (RadioRecordCount <= TotalCount)
                    {
                        if (SelectedRadioParentRecord.ContainsKey(eid) == true)
                        {
                            RadioRecordCount--;
                            RemoveRadioButtonRecord(eid);

                        }
                        RadioRecordCount++;
                        SaveRadioButtonRecord(eid, objrb2.SelectedValue);

                    }
                }
                else
                {
                    if (RadioRecordCount > 0)
                    {
                        RadioRecordCount--;
                        RemoveRadioButtonRecord(eid);

                    }
                }
                GetJobQuestion();
                SelectRadioButton();

            }

            catch
            {
            }

        }

        protected void Grid_JobQuestionnaire_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                Grid_JobQuestionnaire.CurrentPageIndex = e.NewPageIndex;
                GetJobQuestion();
                //SelectCheckedBox();
                SelectRadioButton();
            }
            catch
            {
            }

        }
       
        private void SaveRadioButtonRecord(string id, string value)
        {
            if (!SelectedRadioParentRecord.ContainsKey(id))
            {
                SelectedRadioParentRecord.Add(id, value);
            }

        }

        private void RemoveRadioButtonRecord(string id)
        {
            if (SelectedRadioParentRecord.Count > 0)
            {
                if (SelectedRadioParentRecord.ContainsKey(id))
                {
                    SelectedRadioParentRecord.Remove(id);
                }
            }

        }
       

        protected void Button2_Click(object sender, EventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }
        protected void SaveData()
        {
            try
            {
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();


                if (SelectedRadioParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedRadioParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        JobPostingFA objJobFA = new JobPostingFA();
                        objskill.ElementID = Enumerator.Key.ToString();
                        objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objJobFA.InsertJobSkillQues(objskill, JobID);

                    }
                }
            }
            catch
            {
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
        }

        protected void CompanyInfo_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("PostJobCompanyInformation.aspx?ID=" + JobID);
        }

        protected void jobInfo_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
        }

        protected void JobProfile_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
        }

        protected void Jobskills_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
        }

        protected void OtherInfo_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        protected void Toolsandtechnology_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingDescribetoolsandtech.aspx?ID=" + JobID);
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            SaveData();
        }

       
    }
}
