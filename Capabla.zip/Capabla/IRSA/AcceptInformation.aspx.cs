﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


namespace IRSA
{
    public partial class AcceptInformation : System.Web.UI.Page
    {
        public int InvitedByUserID
        {
            set
            {
                ViewState["InvitedByUserID"] = value;
            }
            get
            {
                if (ViewState["InvitedByUserID"] == null)
                {
                    ViewState["InvitedByUserID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["InvitedByUserID"].ToString());
            }
        }
        public int InvitedToUserID
        {
            set
            {
                ViewState["InvitedToUserID"] = value;
            }
            get
            {
                if (ViewState["InvitedToUserID"] == null)
                {
                    ViewState["InvitedToUserID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["InvitedToUserID"].ToString());
            }
        }
        public DataTable GetInviteUserDetail
        {
            get { return (DataTable)ViewState["GetInviteUserDetail"]; }
            set { ViewState["GetInviteUserDetail"] = value; }
        }

        public DataTable InviteByUserDetail
        {
            get { return (DataTable)ViewState["InviteByUserDetail"]; }
            set { ViewState["InviteByUserDetail"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {

                    this.InvitedToUserID = Convert.ToInt32(Request.QueryString["param1"]);
                    this.InvitedByUserID = Convert.ToInt32(Request.QueryString["param2"]);
                    if (this.InvitedToUserID != int.MinValue && this.InvitedByUserID != int.MinValue)
                    {

                        this.GetInviteUserDetail = GetInvitedUserInfo();
                        this.InviteByUserDetail = GetStatusOfInvitedByUser();
                        BindInvitationInfornation();
                    }
                
                }

            }

            catch
            { 
            
            
            }

        }

        private void BindInvitationInfornation()
        {
            //LabelMemberDet.Text = this.InviteByUserDetail.Rows[0]["ProfessionalExperinceandGoals"].ToString();

            LblInvitedUser.Text = this.InviteByUserDetail.Rows[0]["UserName"].ToString();

            LblInvitedDate.Text = this.InviteByUserDetail.Rows[0]["InvitationDate"].ToString();
            
            //LblEmail.Text = this.InviteByUserDetail.Rows[0]["EmailID"].ToString();
        }

        private DataTable GetStatusOfInvitedByUser()
        {
            IRSA.Facade.Community.CommunityFA ObjMydetail = new IRSA.Facade.Community.CommunityFA();
            return ObjMydetail.GetStatusOFInvitedByUser(this.InvitedByUserID, this.InvitedToUserID);
        }

        private DataTable GetInvitedUserInfo()
        {
            IRSA.Facade.Community.CommunityFA ObjMyInviteUser = new IRSA.Facade.Community.CommunityFA();
            return ObjMyInviteUser.GetInvitedUserDetail(this.InvitedToUserID);
        }

        

        private DataTable UpdateInvitedByUserAccount()
        {
            
            IRSA.Facade.Community.CommunityFA ObjMyInviteUser = new IRSA.Facade.Community.CommunityFA();
            return ObjMyInviteUser.UpdateInvitedUserAcceptance(this.InvitedByUserID, this.InvitedToUserID);
            
            

        }

        protected void BtnAccept_Click1(object sender, EventArgs e)
        {
            try
            {
                DataTable obj = new DataTable();
                obj = UpdateInvitedByUserAccount();
                Response.Redirect("Login.aspx");
            }
            catch
            {

            }

        }
        }
    }

