﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Globalization;
using System.Resources;
using System.Threading;
using IRSA.Facade;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class MyDashBoard : System.Web.UI.Page
    {
        int UserID;
        string CULINFO;
        string cu;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                cu = SessionInfo.CultureID;
                UserID = SessionInfo.UserId;
                getHomewPageLanguageInfo();
                if (!Page.IsPostBack)
                {
                    // set the display mode to "Design" to allow drag and drop
                    WebPartDisplayMode mode = WebPartManager1.SupportedDisplayModes["Design"];
                    if (mode != null)
                    {
                        WebPartManager1.DisplayMode = mode;
                    }

                    if (UserID != int.MinValue)
                    {
                        AccountsetupFA objaccFA = new AccountsetupFA();
                        DataTable objdt = new DataTable();
                        objdt = objaccFA.GetaccountData(UserID);
                        Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                        SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                    }


                }
                if (UserID != int.MinValue)
                {

                    Lblmember.Text = SessionInfo.FirstName + " " + "!";

                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }

            catch
            { 
            
            }
        }

        
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {

                if (lbIsPostBack.Text == "true")
                {
                    lbIsPostBack.Text = "false";
                    WebPartManager manager = WebPartManager.GetCurrentWebPartManager(this);
                    if (manager.WebParts.Count == 0)
                    {
                        DataTable newcontroldt = new DataTable();
                        newcontroldt = GetUserControlData();
                        setwebpartonEmpatyPage(newcontroldt);

                    }
                    
                    if (Session["NewAddedControl"] != null)
                    {
                        DataTable controldt = new DataTable();
                        controldt = Session["NewAddedControl"] as DataTable;
                        setwebpartonpage(controldt);
                        //Session["NewAddedControl"] = null;
                    }
                }
                else
                {
                    //this.Load += new System.EventHandler(this.Page_Load);
                    if (WebPartManager1.WebParts.Count == 0)
                    {
                        DataTable newcontroldt = new DataTable();
                        newcontroldt = GetUserControlData();
                        setwebpartonEmpatyPage(newcontroldt);

                    }
                    DataTable newcontroldtsess = new DataTable();
                    if (Session["NewAddedControl"] != null)
                    {
                        newcontroldtsess = Session["NewAddedControl"] as DataTable;
                        setwebpartonpage(newcontroldtsess);
                        Session["NewAddedControl"] = null;
                    }

                }
            }

            catch
            { 
            
            }
                
                        
        }

       private DataTable GetUserControlData()
           {
            
                DataTable dt = new DataTable();
                MyDashBoardFA objmydashboard = new MyDashBoardFA();
                dt = objmydashboard.GetDefaultWebPArt();
                return dt;
                       
           }

       private void setwebpartonEmpatyPage(DataTable newcontroldt)
       {
           DynamicWebParts dynamicWebParts = new DynamicWebParts(this);
           dynamicWebParts.Manager = WebPartManager1;

           foreach (DataRow drRow in newcontroldt.Rows)
           {
               string Precontr = drRow["ControlName"].ToString().Trim();
               string controlTitle = drRow["ControlTitle"].ToString().Trim();
               
               string controlpath = "UserControl/" + Precontr;
               
               if (WebPartZone1.WebParts.Count == 0)
               {
                   dynamicWebParts.AddWebPartToZone("WebPartZone1", controlpath, controlTitle);
                   
               }
               else
               {
                   if (WebPartZone2.WebParts.Count == 0)
                   {
                       dynamicWebParts.AddWebPartToZone("WebPartZone2", controlpath, controlTitle);
                   }
                   else
                   {
                       if (WebPartZone3.WebParts.Count == 0)
                       {
                           dynamicWebParts.AddWebPartToZone("WebPartZone3", controlpath, controlTitle);
                       }
                       else
                       {
                           dynamicWebParts.AddWebPartToZone("WebPartZone1", controlpath, controlTitle);
                       
                       }

                   }

               }


           }
           

       }
        
        

        private void setwebpartonpage(DataTable controldt)
        {
            try
            {
                //string zonepath = string.Empty;
                foreach (DataRow contdr in controldt.Rows)
                {
                    string contr = contdr["ControlName"].ToString().Trim();
                    string contrTitle = contdr["ControlTitle"].ToString().Trim();
                    
                    string controlpath = "UserControl/" + contr;
                    DynamicWebParts dynamicWebParts = new DynamicWebParts(this);
                    dynamicWebParts.Manager = WebPartManager1;
                    
                    dynamicWebParts.AddWebPartToZone("WebPartZone1", controlpath, contrTitle);
                   
                   
                }
                this.btnEvent.Click += new System.EventHandler(this.btnEvent_Click);
            }

            catch
            { 
            
            }

        }


        protected void ImageButEmport_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("AddWebPart.aspx");
        }
        protected void getHomewPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
            }
            catch
            {

            }
        }

        protected void btnEvent_Click(object sender, EventArgs e)
        {

        }
    }
}
