﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using Telerik.Web.UI;
using System.Collections;
using IRSA.Shared;
using System.Threading;
using System.Globalization;
using System.Resources;
using System.Configuration;
using System.IO;
using IRSA.BussinessLogic;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class JobPostingDescribetoolsandtech : System.Web.UI.Page
    {
        int UserID;
        string Tabtext;
        int JobID;
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }
        public int CRecordCount1
        {
            set
            {
                ViewState["CRecordCount1"] = value;
            }
            get
            {
                if (ViewState["CRecordCount1"] == null)
                {
                    ViewState["CRecordCount1"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount1"].ToString());
            }
        }

        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }

        public int CRecordCountRadioGrid
        {
            set
            {
                ViewState["CRecordCountRadioGrid"] = value;
            }
            get
            {
                if (ViewState["CRecordCountRadioGrid"] == null)
                {
                    ViewState["CRecordCountRadioGrid"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCountRadioGrid"].ToString());
            }
        }

        public int TotalCountRadioGrid
        {
            set
            {
                ViewState["TotalCountRadioGrid"] = value;
            }
            get
            {
                if (ViewState["TotalCountRadioGrid"] == null)
                {
                    ViewState["TotalCountRadioGrid"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCountRadioGrid"].ToString());
            }
        }
        public int TotalCount1
        {
            set
            {
                ViewState["TotalCount1"] = value;
            }
            get
            {
                if (ViewState["TotalCount1"] == null)
                {
                    ViewState["TotalCount1"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount1"].ToString());
            }
        }
        public string stroccuption
        {
            set
            {
                ViewState["stroccuption"] = value;
            }
            get
            {
                if (ViewState["stroccuption"] == null)
                {
                    ViewState["stroccuption"] = "";
                }
                return ViewState["stroccuption"].ToString();
            }
        }

        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }

        public Hashtable SelectedParentRecordRadio
        {
            set
            {
                ViewState["SelectedParentRecordRadio"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecordRadio"] == null)
                {
                    SelectedParentRecordRadio = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecordRadio"];
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              
            }
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            string Job = Request.QueryString.Get("ID");
            if (Job != "")
            {
                JobID = Convert.ToInt32(Job);

            }

        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    Selectjobstoolsandtech();
                    

                }


                SelectCheckedBox();
                SelectCheckedBoxsecond();
                SelectQuestionnaireRadioList();
            }
            catch
            {
            }
        }
        protected void RadTabStrip_TabClick(object sender, Telerik.Web.UI.RadTabStripEventArgs e)
        {
          Tabtext= RadTabStrip.SelectedTab.Text;
          Selectjobstoolsandtech();
          SelectCheckedBoxsecond();
         
        }
        protected void Selectjobstoolsandtech()
        {
            try
            {
                DataTable dttool = new DataTable();
                JobPostingFA Jobpostfa = new JobPostingFA();

                if (Tabtext == "Tools")
                {
                    dttool = Jobpostfa.selectJobToolsAndTech(JobID, Tabtext);
                    TotalCount = dttool.Rows.Count;
                    RadGrid1.DataSource = dttool;
                    RadGrid1.DataBind();
                }
                else
                    if (Tabtext == "Technology")
                    {
                        dttool = Jobpostfa.selectJobToolsAndTech(JobID, Tabtext);
                        TotalCount1 = dttool.Rows.Count;
                        RadGrid2.DataSource = dttool;
                        RadGrid2.DataBind();
                    }
                    else
                    {
                        Tabtext = "Tools";
                        dttool = Jobpostfa.selectJobToolsAndTech(JobID, Tabtext);
                        TotalCount = dttool.Rows.Count;
                        RadGrid1.DataSource = dttool;
                        RadGrid1.DataBind();
                    }
            }
            catch
            {
            }
        }

        protected void RadGrid1_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                Tabtext = RadTabStrip.SelectedTab.Text;
                RadGrid1.CurrentPageIndex = e.NewPageIndex;
                Selectjobstoolsandtech();
                SelectCheckedBox();
            }
            catch
            {
            }
        }

        protected void RadGrid2_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                Tabtext = RadTabStrip.SelectedTab.Text;
                RadGrid2.CurrentPageIndex = e.NewPageIndex;
                Selectjobstoolsandtech();
                SelectCheckedBoxsecond();

            }
            catch
            {
            }
        }

        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }
        private void SelectCheckedBox()
        {
            try
            {
                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < RadGrid1.MasterTableView.Items.Count; i++)
                    {
                        string eid = RadGrid1.MasterTableView.DataKeyValues[i]["T2Example"].ToString(); if (SelectedParentRecord.ContainsKey(eid))
                        {
                            CheckBoxList obj1 = (CheckBoxList)RadGrid1.Items[i].FindControl("CheckBoxList1");
                            obj1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch
            {
            }
        }
        private void SelectCheckedBoxsecond()
        {
            try
            {
                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < RadGrid2.MasterTableView.Items.Count; i++)
                    {
                        string eid = RadGrid2.MasterTableView.DataKeyValues[i]["T2Example"].ToString();
                        //SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                        //DataTable temp = new DataTable();
                        //temp = objskillFA.GetWorkStyleData();
                        //string eid = temp.Rows[j - 1]["ElementID"].ToString();


                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            CheckBoxList obj1 = (CheckBoxList)RadGrid2.Items[i].FindControl("CheckBoxList1");
                            obj1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch
            { }
        }

        protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                CheckBoxList Chbox = (CheckBoxList)sender;
                CheckBoxList objch2 = (CheckBoxList)Chbox.NamingContainer.FindControl("CheckBoxList1");
                eid = RadGrid1.MasterTableView.DataKeyValues[gr.ItemIndex]["T2Example"].ToString();
                if (objch2.SelectedValue != "")
                {
                    if (CRecordCount < TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(eid);

                        }
                        CRecordCount++;
                        SaveRecord(eid, objch2.SelectedValue);

                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCount--;
                        RemoveRecord(eid);

                    }
                }
                Selectjobstoolsandtech();
                SelectCheckedBox();

            }

            catch
            {
            }

        }

        protected void CheckBoxList1_SelectedIndexChanged1(object sender, EventArgs e)
        {
            try
            {
            string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                CheckBoxList Chbox = (CheckBoxList)sender;
                CheckBoxList objch2 = (CheckBoxList)Chbox.NamingContainer.FindControl("CheckBoxList1");
                eid = RadGrid2.MasterTableView.DataKeyValues[gr.ItemIndex]["T2Example"].ToString();
                if (objch2.SelectedValue != "")
                {
                    if (CRecordCount1 <= TotalCount1)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount1--;
                            RemoveRecord(eid);

                        }
                        CRecordCount1++;
                        SaveRecord(eid, objch2.SelectedValue);

                    }
                }
                else
                {
                    if (CRecordCount1 > 0)
                    {
                        CRecordCount1--;
                        RemoveRecord(eid);

                    }
                }
                Selectjobstoolsandtech();
                SelectCheckedBoxsecond();

            }

            catch
            {
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            savedata();
            Response.Redirect("JobPostingPreview.aspx?ID=" + JobID);
        }
        protected void savedata()
        {
            try
            {
                JobPostingSH objJobPostingSH = new JobPostingSH();
                if (SelectedParentRecordRadio.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecordRadio.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        JobPostingFA objJobFA = new JobPostingFA();
                        string DescribeValue = Enumerator.Key.ToString();
                        objJobPostingSH.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objJobFA.InsertJobToolsandtech(objJobPostingSH, DescribeValue, JobID);

                    }
                }

            }

            catch
            { }
        }
        protected void SavetoolAndtec()
        {
            try
            {
                JobPostingSH objJobPostingSH = new JobPostingSH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        JobPostingFA objJobFA = new JobPostingFA();
                        string DescribeValue = Enumerator.Key.ToString();
                        objJobPostingSH.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objJobFA.InsertJobToolsandtech(objJobPostingSH, DescribeValue, JobID);

                    }
                }

            }

            catch
            { }
        }
        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            savedata();
            Response.Redirect("PostJobCompanyInformation.aspx?ID=" + JobID);
        }

        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            savedata();
            Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
        }

        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            savedata();
            Response.Redirect("JobPostingProfile.aspx?ID=" + JobID);
        }

        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            savedata();
            Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            savedata();
            Response.Redirect("JobPostingQuestionnaire.aspx?ID=" + JobID);
        }

        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            savedata();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            savedata();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
        }
        protected void Grid_Questionnairebind()
        {
            try
            {
                JobPostingFA Jobpostfa = new JobPostingFA();
                DataTable dttools = new DataTable();
                dttools = Jobpostfa.GetJobToolandtechQuestionnaireData(JobID);
                TotalCountRadioGrid = dttools.Rows.Count;
                Grid_Questionnaire.DataSource = dttools;
                Grid_Questionnaire.DataBind();
            }
            catch
            {
            }
    }
        protected void rb1_list_selectedindexchanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);

                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");
                eid = Grid_Questionnaire.MasterTableView.DataKeyValues[gr.ItemIndex]["T2Example"].ToString();

                if (objrb2.SelectedValue != "")
                {
                    if (CRecordCountRadioGrid <= TotalCountRadioGrid)
                    {
                        if (SelectedParentRecordRadio.ContainsKey(eid) == true)
                        {
                            CRecordCountRadioGrid--;
                            RemoveRecordRadio(eid);
                        }
                        CRecordCountRadioGrid++;
                        SaveRecordRadio(eid, objrb2.SelectedValue);
                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCountRadioGrid--;
                        RemoveRecordRadio(eid);
                    }
                }
                SelectQuestionnaireRadioList();
                Grid_Questionnairebind();
            }
            catch { }
        }
        private void SelectQuestionnaireRadioList()
        {
            try
            {
                if (SelectedParentRecordRadio.Count > 0)
                {
                    for (int i = 0; i < Grid_Questionnaire.MasterTableView.Items.Count; i++)
                    {
                        string eid = Grid_Questionnaire.MasterTableView.DataKeyValues[i]["T2Example"].ToString();


                        if (SelectedParentRecordRadio.ContainsKey(eid))
                        {
                            RadioButtonList obj1 = (RadioButtonList)Grid_Questionnaire.Items[i].FindControl("rb1_list");
                            obj1.Items.FindByValue(SelectedParentRecordRadio[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch { }
        }
        protected void Grid_Questionnaire_pageindexchanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                Grid_Questionnaire.CurrentPageIndex = e.NewPageIndex;

                PanelToolAndTech.Visible = true;
                Grid_Questionnairebind();
                SelectQuestionnaireRadioList();
              
            }
            catch
            {
            }
        }

        protected void Btnget_Click(object sender, EventArgs e)
        {
            SavetoolAndtec();
            PanelToolAndTech.Visible = true;
            Grid_Questionnairebind();
        }
        private void SaveRecordRadio(string id, string value)
        {
            if (!SelectedParentRecordRadio.ContainsKey(id))
            {
                SelectedParentRecordRadio.Add(id, value);
            }

        }

        private void RemoveRecordRadio(string id)
        {
            if (SelectedParentRecordRadio.Count > 0)
            {
                if (SelectedParentRecordRadio.ContainsKey(id))
                {
                    SelectedParentRecordRadio.Remove(id);
                }
            }

        }

        protected void Btnupdate_Click(object sender, EventArgs e)
        {
            savedata();
        }

       
    }
}
