﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Collections.Specialized;
using System.Globalization;
using System.Resources;
using System.Configuration;
using Telerik.Web.UI;
using System.Collections;
using System.Management;
using System.Security;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Text;



namespace IRSA
{
    public partial class OrganisationLicense : System.Web.UI.Page
    {
        string CULINFO;
        public String keyword
        {
            set
            {
                ViewState["keyword"] = value;
            }
            get
            {
                if (ViewState["keyword"] == null)
                {
                    ViewState["keyword"] = string.Empty ;
                }
                return (ViewState["keyword"].ToString());
            }
        }
        [System.Runtime.InteropServices.DllImport("KERNEL32.DLL", EntryPoint = "RtlZeroMemory")]
        public static extern bool ZeroMemory(IntPtr Destination, int Length);

        protected void Page_Load(object sender, EventArgs e)
        {
            BindComboIndustryData();
            GetMacAddress();
            //GetCheckBoxName();

        }
        public void BindComboIndustryData()
        {
            OrganisationLicenseFA objFA = new OrganisationLicenseFA();
            DataTable temp = new DataTable();
            temp = objFA.BindComboIndustryData();
            ComboIndustry.DataSource = temp;
            ComboIndustry.DataBind();

        }
        string eng;
        string dut;
        string fre;
        string spn;
        string users;
        string mac;
        DateTime from;
        DateTime to;

        public void GetCheckBoxName()
        {
            CULINFO = "en-GB";
            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            from = Convert.ToDateTime(RadDateTimePickerFrom.SelectedDate.Value.ToString());
            to = Convert.ToDateTime(RadDateTimePickerTo.SelectedDate.Value.ToString());
            users = txtusers.Text;
            if(CheckboxEn.Checked==true)
            {
            eng = CheckboxEn.Text;
            }
            else{}
            if(CheckboxDu.Checked==true)
            {
            dut = CheckboxDu.Text;
            }
            else{}
            if(CheckboxFr.Checked==true)
            {
            fre = CheckboxFr.Text;
            }
            else{}
            if(CheckboxSp.Checked==true)
            {
            spn = CheckboxSp.Text;
            }
            else{}
            CreateErrorLog(eng,dut,fre,spn,mac,users,from,to);
        }



        public  string GetMacAddress()
        {
                 
                ManagementClass mc = new ManagementClass("Win32_NetworkAdapter");
                foreach (ManagementObject mo in mc.GetInstances())
                {
                    string macAddr = mo["MACAddress"] as string;
                    if (macAddr != null && macAddr.Trim() != "")
                        lblmacvalue.Text = macAddr;
                    mac = lblmacvalue.Text;
                    
                }
                return "";
            }

      
       

        
            

            /**************************************************************************************************
            METHOD NAME : CreateErrorLog
            PARAMETERS  : Ex
            RETURN TYPE : Returns true i.e Log is created
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
            **************************************************************************************************/
       
            private static bool CreateErrorLog(string eng,string dut,string fre,string spn,string mac,string users,DateTime from,DateTime to)
            {
                string sErrorDirectoryPath, sErrorFileName, sErrorCompletePath; //sErrorLogFilePath;
                try
                {
                    sErrorDirectoryPath = ConfigurationSettings.AppSettings["TelerikLogDirectoryPath"];
                    sErrorFileName = ConfigurationSettings.AppSettings["TelerikLogFilePath"];
                    sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
                    if (GetExitandMakeNewDirectory(sErrorDirectoryPath))
                    {
                        if (GetExitandMakeNewFile(sErrorCompletePath, eng, dut, fre, spn, mac, users,from, to))
                        {

                        }
                    }
                }
                finally
                {
                    sErrorDirectoryPath = null;
                    sErrorFileName = null;
                    sErrorCompletePath = null;
                    //sErrorLogFilePath = null;
                }
                return true;
            }

          

            /**************************************************************************************************
             METHOD NAME : GetExitandMakeNewDirectory
             PARAMETERS  : DirectoryPath
             RETURN TYPE : Returns true i.e Directory is created or get a directory if exits
             CREATE DATE : 23-APRIL-2009
             MODIFY DATE :  
            **************************************************************************************************/
            private static bool GetExitandMakeNewDirectory(string DirectoryPath)
            {
                DirectoryInfo objDir;
                try
                {
                    objDir = new DirectoryInfo(DirectoryPath);
                    if (!objDir.Exists)
                    {
                        objDir.Create();
                        objDir.SetAccessControl(new System.Security.AccessControl.DirectorySecurity(DirectoryPath, System.Security.AccessControl.AccessControlSections.All));
                    }

                    objDir = null;
                }
                finally
                {
                    objDir = null;
                }
                return true;
            }

            /**************************************************************************************************
             METHOD NAME : GetExitandMakeNewFile
             PARAMETERS  : FilePath, Ex
             RETURN TYPE : Returns true i.e file is created or get a File if exits
             CREATE DATE : 23-APRIL-2009
             MODIFY DATE :  
            **************************************************************************************************/

            private static bool GetExitandMakeNewFile(string FilePath, string eng, string dut, string fre, string spn, string mac, string users, DateTime from, DateTime to)
            {
                FileInfo objFile;
                try
                {
                    objFile = new FileInfo(FilePath);
                    if (objFile.Exists)
                    {
                        MakeErrorLog(ref objFile, eng, dut, fre, spn, mac, users, from, to);
                    }
                    else
                    {
                        MakeErrorLog(FilePath, eng, dut, fre, spn, mac, users,from, to);
                    }

                    objFile.Refresh();
                    objFile = null;
                }
                finally
                {
                    objFile = null;
                }
                return true;
            }

            /**************************************************************************************************
             METHOD NAME : MakeErrorLog
             PARAMETERS  : FilePath, Ex
             RETURN TYPE : Returns true i.e file is created and file is wrriten
             CREATE DATE : 23-APRIL-2009
             MODIFY DATE :  
            **************************************************************************************************/
            private static bool MakeErrorLog(string FilePath, string eng, string dut, string fre, string spn, string mac, string users, DateTime from, DateTime to)
            {
                StreamWriter strmLogFile;
                try
                {
                    strmLogFile = new StreamWriter(FilePath, true);
                   // strmLogFile.WriteLine(DateTime.Now.ToString());
                    strmLogFile.WriteLine("Language = " + eng + dut + fre + spn);
                    strmLogFile.WriteLine("Number of Users = " + users);
                    strmLogFile.WriteLine("Mac Address = " + mac);
                    strmLogFile.WriteLine("Tecnical Exam = " + "No Exams");
                    strmLogFile.WriteLine("Date From = " + to);
                    strmLogFile.WriteLine("Date To = " + from);
                    strmLogFile.Close();
                }
                finally
                {
                    strmLogFile = null;
                }
                return true;
            }

            /**************************************************************************************************
            METHOD NAME : MakeErrorLog
            PARAMETERS  : ref File, Ex
            RETURN TYPE : Returns true i.e file is created and file is wrriten
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
            **************************************************************************************************/
            private static bool MakeErrorLog(ref FileInfo File, string eng, string dut, string fre, string spn, string mac, string users, DateTime from, DateTime to)
            {
                StreamWriter strmLogFile;
                try
                {
                    strmLogFile = File.CreateText();
                   // strmLogFile.WriteLine(DateTime.Now.ToLongDateString());
                    strmLogFile.WriteLine("Language = " + eng +  dut +  fre +  spn);
                    strmLogFile.WriteLine("Number of Users = " + users);
                    strmLogFile.WriteLine("Mac Address = " + mac);
                    strmLogFile.WriteLine("Tecnical Exam = " + "No Exams");
                    strmLogFile.WriteLine("Date From = " + to);
                    strmLogFile.WriteLine("Date To = " + from);
                    strmLogFile.Close();
                }
                finally
                {
                    strmLogFile = null;
                }
              
                return true;
            }
          
            public void DeleteFile()
            {
               string sErrorDirectoryPath = ConfigurationSettings.AppSettings["TelerikLogDirectoryPath"];
               string sErrorFileName = ConfigurationSettings.AppSettings["TelerikLogFilePath"];
               string sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
               FileInfo fiPath = new FileInfo(sErrorCompletePath);
               if (fiPath.Exists)
                        {
                            //Delete the file from sever
                            File.Delete(sErrorCompletePath);
                        }
                            
            }
            //protected void BtnDecrypt_Click(object sender, EventArgs e)
            //{
            //    string sErrorDirectoryPath = ConfigurationSettings.AppSettings["LogDirectoryPath"];
            //    string sErrorFileName = ConfigurationSettings.AppSettings["LogFilePath"];
            //    string sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
            //    // Must be 64 bits, 8 bytes.
            //    // Distribute this key to the user who will decrypt this file.
            //    string sSecretKey;
            //    OrganisationLicenseFA fa = new OrganisationLicenseFA();
                
            //    DataTable dt=new DataTable();
            //    dt=fa.GetData();
               
            //    string key =dt.Rows[0]["LicenseKey"].ToString();
            //    // Get the Key for the file to Encrypt.
            //    sSecretKey = key;
                
            //    // For additional security Pin the key.
            //    GCHandle gch = GCHandle.Alloc(sSecretKey, GCHandleType.Pinned);

            //    // Encrypt the file.        
            //    //EncryptFile(sErrorCompletePath,
            //    //   sErrorDirectoryPath + "Encrypted.txt",
            //    //   sSecretKey);

            //    //// Decrypt the file.
            //    DecryptFile(sErrorCompletePath ,
            //       @"c:\Decrypted.txt" ,
            //       sSecretKey);

            //    // Remove the Key from memory. 
            //    ZeroMemory(gch.AddrOfPinnedObject(), sSecretKey.Length * 2);
            //    gch.Free();
            //    ReadDecryptedFile();
                
            //}
            protected void BtnNext_Click(object sender, EventArgs e)
            {
                GetCheckBoxName();
               string sErrorDirectoryPath = ConfigurationSettings.AppSettings["TelerikLogDirectoryPath"];
               string sErrorFileName = ConfigurationSettings.AppSettings["TelerikLogFilePath"];
               string sErrorCompletePath = sErrorDirectoryPath + sErrorFileName;
                // Must be 64 bits, 8 bytes.
                // Distribute this key to the user who will decrypt this file.
                string sSecretKey;

                // Get the Key for the file to Encrypt.
                sSecretKey = GenerateKey();
                this.keyword = sSecretKey;
                OrganisationLicenseFA fa = new OrganisationLicenseFA();
                fa.InsertLicenseKey(sSecretKey);
                // For additional security Pin the key.
               // GCHandle gch = GCHandle.Alloc(sSecretKey, GCHandleType.Pinned);

                // Encrypt the file.        
                EncryptFile(sErrorCompletePath ,
                   sErrorDirectoryPath + "TelerikLic.txt",
                   sSecretKey);
                //DeleteFile();

                //// Decrypt the file.
                //DecryptFile(@"C:\Encrypted.txt",
                //   @"C:\Decrypted.txt",
                //   sSecretKey);

                // Remove the Key from memory. 
               // ZeroMemory(gch.AddrOfPinnedObject(), sSecretKey.Length * 2);
                //gch.Free();
            }
        // ________________________________________Encryption and Decryption__________________________________ // 

            //[System.Runtime.InteropServices.DllImport("KERNEL32.DLL", EntryPoint = "RtlZeroMemory")]
            //public static extern bool ZeroMemory(IntPtr Destination, int Length);

            // Function to Generate a 64 bits Key.
            public static string GenerateKey()
            {
                // Create an instance of Symetric Algorithm. Key and IV is generated automatically.
                DESCryptoServiceProvider desCrypto = (DESCryptoServiceProvider)DESCryptoServiceProvider.Create();

                // Use the Automatically generated key for Encryption. 
                return ASCIIEncoding.ASCII.GetString(desCrypto.Key);
            }

           public static void EncryptFile(string sInputFilename,
               string sOutputFilename,
               string sKey)

            {
                FileStream fsInput = new FileStream(sInputFilename,
                   FileMode.Open,
                   FileAccess.Read);

                FileStream fsEncrypted = new FileStream(sOutputFilename,
                   FileMode.Create,
                   FileAccess.Write);
                DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
                DES.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
                DES.IV = ASCIIEncoding.ASCII.GetBytes(sKey);
                ICryptoTransform desencrypt = DES.CreateEncryptor();
                CryptoStream cryptostream = new CryptoStream(fsEncrypted,
                   desencrypt,
                   CryptoStreamMode.Write);

                byte[] bytearrayinput = new byte[fsInput.Length];
                fsInput.Read(bytearrayinput, 0, bytearrayinput.Length);
                cryptostream.Write(bytearrayinput, 0, bytearrayinput.Length);
                cryptostream.Close();
                fsInput.Flush();
                fsInput.Close();
                fsEncrypted.Close();
            }

       

          //public  void DecryptFile(string sInputFilename,
          //    string sOutputFilename,
          //    string sKey)
          // {
          //     try
          //     {
          //         DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
          //         //A 64 bit key and IV is required for this provider.
          //         //Set secret key For DES algorithm.
          //         DES.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
          //         //Set initialization vector.
          //         DES.IV = ASCIIEncoding.ASCII.GetBytes(sKey);

          //         //Create a file stream to read the encrypted file back.
          //         FileStream fsread = new FileStream(@"c:\ErrorLogEncrypted.txt",
          //            FileMode.Open,
          //            FileAccess.Read);
          //         //Create a DES decryptor from the DES instance.
          //         ICryptoTransform desdecrypt = DES.CreateDecryptor();
          //         //Create crypto stream set to read and do a 
          //         //DES decryption transform on incoming bytes.
          //         CryptoStream cryptostreamDecr = new CryptoStream(fsread,
          //            desdecrypt,
          //            CryptoStreamMode.Read);
          //         //Print the contents of the decrypted file.
          //         StreamWriter fsDecrypted = new StreamWriter(sOutputFilename);
                  
          //        fsDecrypted.Write(new StreamReader(cryptostreamDecr).ReadToEnd());

          //        fsDecrypted.Flush();
          //         fsDecrypted.Close();



          //         StreamReader srd = new StreamReader(sOutputFilename);
                    
          //         while (!srd.EndOfStream)
          //         {
          //             string str = srd.ReadLine();
          //             string str1 = srd.ReadLine();
          //             string str2 = srd.ReadLine();
          //             string str3 = srd.ReadLine();
          //             string str4 = srd.ReadLine();
          //             string str5 = srd.ReadLine();
          //             if (str1.Contains("Users") || str2.Contains("Mac Address") || str5.Contains("DateTo"))
          //             {     //The moment we find the hello,we stop the readiing of the file and inform the user about it.       Console.WriteLine(Found hello at:");       
          //                // Console.WriteLine(str);

          //                 string Availability = str1;
          //                 string[] arAvailability = new string[2];
          //                 char[] splitter = { '-' };
          //                 arAvailability = Availability.Split(splitter);
          //                 string Availability1 = arAvailability[1];
          //                 lbluserscount.Text = Availability1;

          //                 string Availability111 = str2;
          //                 string[] arAvailability111 = new string[2];
          //                 char[] splitter1 = { '-' };
          //                 arAvailability111 = Availability111.Split(splitter1);
          //                 string Availability11 = arAvailability111[1];
          //                 lbldate.Text = Availability11;

          //                 string Availability1111 = str5;
          //                 string[] arAvailability1111 = new string[2];
          //                 char[] splitter11 = { '-' };
          //                 arAvailability1111 = Availability1111.Split(splitter11);
          //                 string Availability112 = arAvailability1111[1];
          //                 lblmacc.Text = Availability112;
          //                  break;
          //             }

          //         } srd.Close(); 

                
          
                   
          //     }
                  
          //     catch { }
          // }

          //public void ReadDecryptedFile()
          //{
              //StreamReader srd = File.OpenText(@"C:\Decrypted.txt");
              //   while(!srd.EndOfStream) { string str=srd.ReadLine();
              //   string str1 = srd.ReadLine();
              //   string str2 = srd.ReadLine();

              //   if (str.Contains("Users") || str1.Contains("DateTo") || str2.Contains("Mac Address"))
              //       {     //The moment we find the hello,we stop the readiing of the file and inform the user about it.       Console.WriteLine(Found hello at:");       
              //            Console.WriteLine(str);
              //            lbluserscount.Text = str;
              //            lbldate.Text = str1;
              //            lblmacc.Text = str2;
              //       break;    
              //       }

              //   } srd.Close(); 
             //}

        }
       

    }


