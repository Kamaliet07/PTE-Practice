﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Collections.Specialized;

using System.Xml.XPath;


namespace IRSA
{
    
   
    public partial class JobPostingProfile : System.Web.UI.Page
    {
        int JobID;
        string step = "";
        int UserID;
        string CULINFO;
        string JobType;
        string JobPostingxml = "TooltripJobposting.xml";
        string strExpression;
        string CultureID;
        public string Collection
        {
            set
            {
                ViewState["Collection"] = value;
            }
            get
            {
                if (ViewState["Collection"] == null)
                {
                    ViewState["Collection"] = "";
                }
                return ViewState["Collection"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            CultureID = "EN";
            string Job = Request.QueryString.Get("ID");
            if (Job != null)
            {
                JobID = Convert.ToInt32(Job);

               

            }
            if (!IsPostBack)
            {
                Comboboxbind();
                XmlEducation();
                GetSourceDataBind();
                RaddateAvailabilityafrom.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                RaddateAvailabilityto.SelectedDate = Convert.ToDateTime(System.DateTime.Today.ToString());
                GetJobProfiles();
                
               
                
            }
          GettooltipMessage();
          getJobProfilePageLanguageInfo();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }    
           
        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            SaveData();
                Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
            
        }
        public bool ValidateData()
        {
            if (DdAge.SelectedValue != "")
            {
                if (RadComboAgeTo.SelectedValue != "")
                {
                    if (Convert.ToInt32(DdAge.SelectedValue.Trim()) >= Convert.ToInt32(RadComboAgeTo.SelectedValue.Trim()))
                    {
                        lblerrormessageage.Visible = true;
                        lblerrormessageage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(45);
                        return false;
                       
                    }
                    else
                    {
                        lblerrormessageage.Visible = false;
                        lblerrormessageage.Text = " ";
                        return true;
                    }
                }
                else
                {
                    lblerrormessageage.Visible = false;
                    lblerrormessageage.Text = " ";
                    return true;
                }
            }
            else
            {
                lblerrormessageage.Visible = false;
                lblerrormessageage.Text = " ";
                return true;
            }




        }
        public bool ValidateDate()
        {


            if (RaddateAvailabilityto.SelectedDate.Value < RaddateAvailabilityafrom.SelectedDate.Value || RaddateAvailabilityafrom.IsEmpty == true || RaddateAvailabilityafrom.IsEmpty == true)
                    {
                       
                        LblErrrmassage.Visible = true;
                        LblErrrmassage.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(11);
                        return false;
                    }
                    else
                    {
                        LblErrrmassage.Visible = false;
                        LblErrrmassage.Text = "";
                        return true;
                       
                    }
                
               




        }
        public void Comboboxbind()
        {
            try
            {
                JobPostingFA Jobpostfa = new JobPostingFA();
                JobPostingSH JobPostSH = new JobPostingSH();
                DataTable temp = new DataTable();
                temp = Jobpostfa.GetJobFamilyData();
                DdRoleJobFamily.DataSource = temp;
                DdRoleJobFamily.DataBind();
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {

            SaveData();
                Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);
            
            }
  protected void SaveData()
       {
    try
    {
      if (ValidateData() && ValidateDate())
            
            {
                JobPostingSH JobPostSH = new JobPostingSH();
                JobPostingFA Jobpostfa = new JobPostingFA();

                DataTable temp = new DataTable();
                step = "JobProfile";



                
                JobPostSH.Education = RadComboeducation.SelectedValue;
                JobPostSH.CurrentJobFamily = DdRoleJobFamily.Text;
                JobPostSH.CurrentJobRoleType = RadDdRoleJobtype.Text;
                if (RadioBtndl.SelectedValue != "")
                {
                    JobPostSH.DrivingLicence = Convert.ToBoolean(Convert.ToInt32(RadioBtndl.SelectedValue));
                }

                CULINFO = "en-GB";
                 
                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                
                string PostoingStart =RaddateAvailabilityafrom.SelectedDate.Value.ToString("dd/MMM/yyyy");
                
                
          //string JobPostingStartdate = PostoingStart.Replace("0:00:00", "");
                JobPostSH.AvailabilityFrom = PostoingStart;
                string jobpostingEnd = RaddateAvailabilityto.SelectedDate.Value.ToString("dd/MMM/yyyy");
                //string PostingJodEndDate = jobpostingEnd.Replace("0:00:00", "");
                JobPostSH.AvailabilityTo = jobpostingEnd;
                JobPostSH.Distance = DdDistance.SelectedValue;
                if (DdAge.SelectedValue != "" && RadComboAgeTo.SelectedValue != "")
                {
                    JobPostSH.AgeFrom = Convert.ToInt32(DdAge.SelectedValue);
                    JobPostSH.AgeTo = Convert.ToInt32(RadComboAgeTo.SelectedValue);
                }
                JobPostSH.Gender = RadComboGender.SelectedValue;
                JobPostSH.Keyword = TxtKeyword.Text;
                temp = Jobpostfa.GetCompany(JobPostSH, step, JobID, Collection);
                 LblMessage.Visible=true;
                LblMessage.Text=IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(50);
            }
         else
          {
          LblMessage.Visible=true;
          LblMessage.Text=IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(43);
         }
            }
     catch (System.Exception ex)
     {
         ErrorLog.Logging(ex, true);
         Response.Redirect("Login.aspx");
     }
        }
        protected void GetJobProfiles()
        {
            try
            {
                DataTable dt = new DataTable();
                JobPostingFA ObjJobPostingFA = new JobPostingFA();
                dt = ObjJobPostingFA.SelectJobProfile(JobID);
                if (dt.Rows.Count > 0)
                {
                    JobType = dt.Rows[0]["JobType"].ToString();
                    RadComboeducation.SelectedValue = dt.Rows[0]["Education"].ToString();
                    DdAge.SelectedValue = dt.Rows[0]["AgeFrom"].ToString();
                    RadComboAgeTo.SelectedValue = dt.Rows[0]["AgeTo"].ToString();
                    DdRoleJobFamily.SelectedValue = dt.Rows[0]["JobFamilyName"].ToString();

                   // RadDdRoleJobtype.SelectedValue = dt.Rows[0]["Title"].ToString();
                    RadioBtndl.SelectedValue = dt.Rows[0]["DrivingLicense"].ToString();
                    DdDistance.SelectedValue = dt.Rows[0]["Distance"].ToString();
                    RadComboGender.SelectedValue = dt.Rows[0]["Gender"].ToString();
                    RaddateAvailabilityafrom.SelectedDate = Convert.ToDateTime(dt.Rows[0]["AvailabiltyFrom"].ToString());
                    RaddateAvailabilityto.SelectedDate = Convert.ToDateTime(dt.Rows[0]["AvailabiltyTo"].ToString());
                    TxtKeyword.Text = dt.Rows[0]["KeyWord"].ToString();

                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }

        }

        protected void DdRoleJobFamily_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetSourceDataBind();
        }
        protected void GetSourceDataBind()
        {
            try
            {
                Collection = "";
                JobPostingFA Jobpostfa = new JobPostingFA();
                DataTable temp = new DataTable();
                string JobFamily = DdRoleJobFamily.SelectedItem.Text;
                temp = Jobpostfa.GetSourceData(JobFamily);
                RadDdRoleJobtype.DataSource = temp;
                RadDdRoleJobtype.DataBind();
            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }

        //protected void RadDdRoleJobtype_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        //{
        //    try
        //    {
        //    JobPostingFA Jobpostfa = new JobPostingFA();
        //    DataTable temp = new DataTable();
        //    string ONETSOCCodeData = RadDdRoleJobtype.Text;
        //    temp = Jobpostfa.GetSourceDataID(ONETSOCCodeData);
        //    if (temp.Rows.Count>0)
        //    {
        //        string ONETSOCCodeID = temp.Rows[0]["ONETSOCCode"].ToString();
        //    }
        //}


        //protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        string eid;
        //        RadComboBoxItem gr = (RadComboBoxItem)(((Control)sender).NamingContainer);
        //        CheckBoxList Chbox = (CheckBoxList)sender;
        //        CheckBoxList objch2 = (CheckBoxList)Chbox.NamingContainer.FindControl("CheckBoxList1");

        //        eid = Convert.ToString(Chbox.Text);
        //    }
        //    catch
        //    {
        //    }
        //}
        private void XmlEducation()
        {
            try
            {


                XPathNavigator navdegree;
                XPathDocument docNavdegree;
                XPathNodeIterator NodeIterdegree;
                docNavdegree = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Educationlevel.xml"));
                if (CultureID == "EN")
                {
                    strExpression = "/root/English";
                }
                else if (CultureID == "NL")
                {
                    strExpression = "/root/Dutch";
                }
                navdegree = docNavdegree.CreateNavigator();
                //string strExp = "/root/English";
                NodeIterdegree = navdegree.Select(strExpression);
                NodeIterdegree.MoveNext();
                RadComboeducation.LoadXml(NodeIterdegree.Current.InnerXml);


            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
             try
            {
               
                JobPostingFA Jobpostfa = new JobPostingFA();

                DataTable temp = new DataTable();
                //StringCollection idCollection = new StringCollection();
                string strID = string.Empty;
                string eid;
                // RadComboBoxItem gr = (RadComboBoxItem)(((Control)sender).NamingContainer);
                CheckBox Chbox = (CheckBox)sender;
                CheckBox objch2 = (CheckBox)Chbox.NamingContainer.FindControl("CheckBox1");

                eid = Convert.ToString(Chbox.Text);

                temp = Jobpostfa.GetSourceDataID(eid);
                if (temp.Rows.Count>0)
                {
                    strID = temp.Rows[0]["ONETSOCCode"].ToString();
                    if (Collection != "")
                    {
                        Collection = Collection + "," + strID;
                    }
                    else
                    {
                        Collection = strID;
                    }
                }
            }
             catch (System.Exception ex)
             {
                 ErrorLog.Logging(ex, true);
                 Response.Redirect("Login.aspx");
             }

        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("PostJobCompanyInformation.aspx?ID=" + JobID); 
                
            
        }

        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("PostJobInformation.aspx?ID=" + JobID);
           
        }

        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
           
            Response.Redirect("JobPostingDescribeSkills.aspx?ID=" + JobID);  
               
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {

            SaveData();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID);
            
        }

        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingOtherInfo.aspx?ID=" + JobID); 
               
        }

        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            SaveData();
            Response.Redirect("JobPostingDescribetoolsandtech.aspx?ID=" + JobID);  
            
        }
        private void GettooltipMessage()
        {
            try
            {
                RadioBtndl.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(16, JobPostingxml);
                BtnEduhelp.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(17, JobPostingxml);
                RadComboAgeTo.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(18, JobPostingxml);
                RadComboGender.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(19, JobPostingxml);
                DdDistance.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(20, JobPostingxml);
                ImgJobfamily.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, JobPostingxml);
                ImgDate.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(21, JobPostingxml);
                ImgJobOccupation.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(30, JobPostingxml);
                TxtKeyword.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(29, JobPostingxml);

            }
            catch (System.Exception ex)
            {
                ErrorLog.Logging(ex, true);
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {

                SaveData();
           
            
        }
        protected void getJobProfilePageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                Label25.Text = (string)GetGlobalResourceObject("PageResource", "LblWelcome");
                Label3.Text = (string)GetGlobalResourceObject("PageResource", "Label3_JobPostingProfile");
                Label4.Text = (string)GetGlobalResourceObject("PageResource", "Label4_JobPostingProfile");
                //Label5.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingProfile");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_JobPostingProfile");
                Label24.Text = (string)GetGlobalResourceObject("PageResource", "Label24_JobPostingProfile");
                Label12.Text = (string)GetGlobalResourceObject("PageResource", "Label12_JobPostingProfile");
                Label9.Text = (string)GetGlobalResourceObject("PageResource", "Label9_JobPostingProfile");
                Label11.Text = (string)GetGlobalResourceObject("PageResource", "Label11_JobPostingProfile");
                Label15.Text = (string)GetGlobalResourceObject("PageResource", "Label15_JobPostingProfile");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_JobPostingProfile");
                Label2.Text = (string)GetGlobalResourceObject("PageResource", "Label2_JobPostingProfile");
                Label14.Text = (string)GetGlobalResourceObject("PageResource", "Label14_JobPostingProfile");
                Label16.Text = (string)GetGlobalResourceObject("PageResource", "Label16_JobPostingProfile");
                Label17.Text = (string)GetGlobalResourceObject("PageResource", "Label17_JobPostingProfile");
                Label10.Text = (string)GetGlobalResourceObject("PageResource", "Label10_JobPostingProfile");
                Lblexp.Text = (string)GetGlobalResourceObject("PageResource", "Label4_PostJobInformation");
                Label20.Text = (string)GetGlobalResourceObject("PageResource", "Label20_JobPostingProfile");
                Label21.Text = (string)GetGlobalResourceObject("PageResource", "Label21_JobPostingProfile");
                Label18.Text = (string)GetGlobalResourceObject("PageResource", "Label18_JobPostingProfile");
                Label28.Text = (string)GetGlobalResourceObject("PageResource", "Label28_JobPostingProfile");
                Label13.Text = (string)GetGlobalResourceObject("PageResource", "Label13_JobPostingProfile");
                Label22.Text = (string)GetGlobalResourceObject("PageResource", "Label22_JobPostingProfile");
                btnupdate.Text = (string)GetGlobalResourceObject("PageResource", "btnupdate_JobPostingProfile");
                Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_JobPostingProfile");
                RadioBtndl.Items[0].Text = (string)GetGlobalResourceObject("PageResource", "RadioBtndl1_Jobprofile");
                RadioBtndl.Items[1].Text = (string)GetGlobalResourceObject("PageResource", "RadioBtndl2_Jobprofile");
                Button1.Text = (string)GetGlobalResourceObject("PageResource", "Button1_JobPostingProfile");
            }
            catch
            {
            }
        }
       
    }
}
