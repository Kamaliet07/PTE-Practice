﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.IO;

namespace IRSA
{
    public partial class AssessmentCentre : System.Web.UI.Page
    {
        int UserID;
        string ReportPath;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            ReportPath = ConfigurationSettings.AppSettings["ReportDirectoryPath"];
            ImageButton1.Enabled = false;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
            }
            else
            {
                Lblmember.Text = "Guest !";
            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
           
        }

        protected void Link1_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "SkillAssessment.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "_360DegreeAssessment.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            try
            {

                string filePath = ReportPath + "WorkActivityAssessment.pdf";
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    Response.ClearContent();
                    Response.AddHeader("content-disposition", "attachment;filename=" + file.Name);
                    Response.ContentType = "application/vnd.pdf";
                    Response.Flush();
                    Response.TransmitFile(file.FullName);
                    Response.End();
                }

            }
            catch { }
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (UserID != int.MinValue)
            {
                Response.Redirect("AssessmentInfo.aspx");
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}
