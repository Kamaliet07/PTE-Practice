﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;
using System.Globalization;
using Telerik.Web.UI;
using System.IO;
using IRSA.Facade;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class EventPopUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetData();  
        }
        public void GetData()
        {
             string Event = Request.QueryString.Get("id");
            int EventID = Convert.ToInt32(Event);
            DataTable dtEvent = new DataTable();
            EventNewFA objUserDocumentsEventList = new EventNewFA();
            dtEvent = objUserDocumentsEventList.GetUSerDocumentsEventList1(EventID);
            if (dtEvent.Rows.Count > 0)
            {
                Lbl2.Text = dtEvent.Rows[0]["EventDescription"].ToString();
                lbl1.Text = dtEvent.Rows[0]["EventDate"].ToString();
            
            }
        
        }
    }
}
