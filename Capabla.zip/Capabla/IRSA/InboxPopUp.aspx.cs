﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;
using System.Globalization;
using Telerik.Web.UI;
using System.IO;
using IRSA.Facade;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
namespace IRSA
{
    public partial class InboxPopUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetData();
        }
        public void GetData()
        {
            string Inbox = Request.QueryString.Get("id");
            int InboxID = Convert.ToInt32(Inbox);
            DataTable dtInboxPopUp = new DataTable();
            UserInboxFA objfa = new UserInboxFA();
            dtInboxPopUp = objfa.InboxPopUp(InboxID);
            if (dtInboxPopUp.Rows.Count > 0)
            {
                RadEditorRecievedMail.Content = dtInboxPopUp.Rows[0]["Description"].ToString();
                lblsendername.Text = dtInboxPopUp.Rows[0]["SenderName"].ToString();
                lblsubject.Text = dtInboxPopUp.Rows[0]["Subject"].ToString();
               

            }
           

        }
    }
}
