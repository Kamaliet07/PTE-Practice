﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using System.Data;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class CareerLadderManufacturingInfo : System.Web.UI.Page
    {
        int UserID;
        string strTabName;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack == true)
            {

                int str = Convert.ToInt32(Request.QueryString.Get("id").ToString());
                if (str != 11)
                {
                    if (str == 0)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView1.Selected = true;
                    }
                    if (str == 1)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView2.Selected = true;
                    }
                    if (str == 2)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView3.Selected = true;
                    }
                    if (str == 3)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView4.Selected = true;
                    }
                    if (str == 4)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView5.Selected = true;
                    }
                    if (str == 5)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView6.Selected = true;
                    }
                    if (str == 6)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView7.Selected = true;
                    }
                    if (str == 7)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView8.Selected = true;
                    }
                    if (str == 8)
                    {
                        radTabCLIT.SelectedIndex = str;
                        RadPageView9.Selected = true;
                    }                    
                }

                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void btnback_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderManufacturing.aspx");
        }

        protected void lnkbtnDetail_Click(object sender, EventArgs e)
        {
            strTabName = radTabCLIT.SelectedTab.Text;            
            Response.Redirect("CareerladderDetails.aspx?id=" + strTabName);
        }

        protected void radTabCLIT_TabClick(object sender, Telerik.Web.UI.RadTabStripEventArgs e)
        {
            strTabName = radTabCLIT.SelectedTab.Text;
        }

        protected void LnkBtnBackToCl_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderManufacturingInfo.aspx");
        }


    }
}

