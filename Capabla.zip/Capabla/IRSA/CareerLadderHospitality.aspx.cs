﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Data;

namespace IRSA
{
    public partial class CareerLadderHospitality : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember1.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void lnkBtnGeneralManager(object sender, EventArgs e)
        {
            int i = 0;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }

        protected void lnkBtnTrainingManager(object sender, EventArgs e)
        {
            int i = 1;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }

        protected void lnkBtnFrontOfficeManager(object sender, EventArgs e)
        {
            int i = 2;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }

        protected void lnkBtnSalesManager(object sender, EventArgs e)
        {
            int i = 3;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }

        protected void lnkBtnDepartmentTrainer(object sender, EventArgs e)
        {
            int i = 4;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }
         
        protected void lnkBtnFrontDeskSupervisor(object sender, EventArgs e)
        {
            int i = 5;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }

        protected void lnkBtnFrontDeskRepresentative(object sender, EventArgs e)
        {
            int i = 6;
            Response.Redirect("CareerLadderHospitalityInfo.aspx?id=" + i);
        }

        


        protected void ImgbtnItmngrConsul_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void ImageButton16_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void lnkbtnCLITBAck_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderIntroduction.aspx");
        }

    }
}
