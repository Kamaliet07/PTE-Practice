﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class AccountPresentCmy : System.Web.UI.Page
    {
        
        int UserID;
        string Accountxml = "irsatooltipaccount.xml";
        string CurrentWizardStep = "Present Company";
        string AppName;
        string CULINFO;
        string CultureID1;
        string strExp;
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountPrescmyPageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            Page.Form.DefaultButton = Update.UniqueID;
            UserID =  SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
            if (!this.IsPostBack)
            {
                string str = Request.QueryString.Get("id");

                int id = Convert.ToInt32(str);
                if (str != null)
                {

                    str = Request.QueryString.Get("id");

                }
                Filloccupation();
                //FillIndustry();

                XmlCountry();




                Getdata();

            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["DisplayName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }

            }
            else
            {
                Response.Redirect("Login.aspx");
            }


        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                Image5.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(52, Accountxml);
                Txtdesignationprecmy.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(49, Accountxml);
                Txtpresentcmy.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(48, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(47, Accountxml);
                Image2.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(51, Accountxml);
                Image3.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(9, Accountxml);
                Txtdescriptionprecmy.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(50, Accountxml);
          

            }
            catch { }
        }
        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                    {
                        RadCombooccupationprecmy.Text = objdt.Rows[0]["Title"].ToString();
                        Txtpresentcmy.Text = objdt.Rows[0]["Company"].ToString();
                        Txtdesignationprecmy.Text = objdt.Rows[0]["Designation"].ToString();
                        Txtdescriptionprecmy.Text = objdt.Rows[0]["Description"].ToString();
                        CULINFO = "en-GB";
                        CultureInfo objCI = new CultureInfo(CULINFO);
                        Thread.CurrentThread.CurrentCulture = objCI;
                        Thread.CurrentThread.CurrentUICulture = objCI;

                        RadDateworkinfromprecmy.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["WorkingFrom"].ToString());
                   
                        RadCombocountryprecmy.SelectedValue = objdt.Rows[0]["Country"].ToString();
                        Txtpostalcodeprecmy.Text = objdt.Rows[0]["PostalCode"].ToString();
                    }


                
            }
            catch { }
        }
        public void Filloccupation()
        {
            try
            {
                IRSA.Facade.AccountsetupFA occ = new IRSA.Facade.AccountsetupFA();

                DataTable temp = new DataTable();
                temp = occ.GetoccupationData();
                RadCombooccupationprecmy.DataTextField = "Title";

                RadCombooccupationprecmy.DataSource = temp;
                RadCombooccupationprecmy.DataBind();
            }
            catch
            {
            }
        }
        private void XmlCountry()
        {
            try
            {


                XPathNavigator nav1;
                XPathDocument docNav1;
                XPathNodeIterator NodeIter1;
                docNav1 = new XPathDocument(HttpContext.Current.Server.MapPath("~/xml/Country.xml"));
                nav1 = docNav1.CreateNavigator();
                if (CultureID1 == "EN")
                {
                    strExp = "/root/English";
                }
                else if (CultureID1 == "NL")
                {
                    strExp = "/root/Dutch";
                }
                NodeIter1 = nav1.Select(strExp);
                NodeIter1.MoveNext();
                //RadCombocountry.LoadXml(NodeIter1.Current.InnerXml);
                RadCombocountryprecmy.LoadXml(NodeIter1.Current.InnerXml);




            }
            catch
            {

            }

        }
        DateTime dateTo;
        DateTime dateFrom;
        public void savedata()
        {
            CULINFO = "en-GB";
            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
           
            if (RadDateworkinfromprecmy.SelectedDate!= null)
            {
              dateFrom = RadDateworkinfromprecmy.SelectedDate.Value;
            }
            DateTime dateToday = System.DateTime.Today.Date;

            try
            {
                AccountsetupSH objaccpreSH = new AccountsetupSH();
                objaccpreSH.Occupation = RadCombooccupationprecmy.SelectedValue;
                objaccpreSH.Company = UCFirst(Txtpresentcmy.Text);
                objaccpreSH.Designation = UCFirst(Txtdesignationprecmy.Text);
                objaccpreSH.Description = UCFirst(Txtdescriptionprecmy.Text);
                if (RadDateworkinfromprecmy.SelectedDate != null)
                {
                    objaccpreSH.WorkingFrom = RadDateworkinfromprecmy.SelectedDate.Value.ToString("dd/MMM/yyyy");
                    
                    if ((dateFrom > dateToday))
                    {

                        lblDateErrorS.Visible = true;
                        Lbldatamodified.Visible = false;
                        RadDateworkinfromprecmy.Focus();
                        goto Last;
                    }
                    else
                    {
                        Lbldatamodified.Visible = false;
                        lblDateErrorS.Visible = false;

                    }

                }                //objaccpreSH.WorkingTo = RadDateworkintoprecmy.SelectedDate.Value.ToString("dd/MMM/yyyy");
               
                
                objaccpreSH.Countryprecmy = RadCombocountryprecmy.SelectedValue;

                objaccpreSH.PostalCode = Txtpostalcodeprecmy.Text;
                #region Profile Progressbar
                // string path = "~/App_Themes/Site/images/";
                int i = 0;
                if (Txtpresentcmy.Text != "")
                {
                    i++;
                }
                if (Txtdesignationprecmy.Text != "")
                {
                    i++;
                }
                if (Txtdescriptionprecmy.Text != "")
                {
                    i++;
                }
                if (Txtpostalcodeprecmy.Text != "")
                {
                    i++;
                }
                if (RadCombooccupationprecmy.SelectedIndex != 0)
                {
                    i++;
                }
                if (RadCombocountryprecmy.SelectedIndex != 0)
                {
                    i++;
                }
                


                int PresentCompany = i * 100 / 6;
                int Experience = 0, AccountWelcome = 0, Acadimic = 0, PastCompany = 0, Projects = 0;
                AccountsetupFA objaccFA = new AccountsetupFA();
                if (RadCombooccupationprecmy.SelectedValue != "")
                {
                    objaccFA.InsertAccountSetUpData(objaccpreSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                }
                else
                {
                    goto Last;
                }
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                Getdata();
                #endregion

            Last: ; 
            }
            catch { }
        }
       

       

        protected void Next_Click(object sender, EventArgs e)
        {
            savedata();
            Response.Redirect("AccountPastCompany.aspx");
        }

        
        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {
                if (strName.Length > 0)
                {
                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);
                }
            }
            catch { }
            return sb.ToString();
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            savedata();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
           
            try
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {
                    RadCombooccupationprecmy.Text = objdt.Rows[0]["Title"].ToString();
                    Txtpresentcmy.Text = objdt.Rows[0]["Company"].ToString();
                    Txtdesignationprecmy.Text = objdt.Rows[0]["Designation"].ToString();
                    Txtdescriptionprecmy.Text = objdt.Rows[0]["Description"].ToString();

                    RadDateworkinfromprecmy.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["WorkingFrom"].ToString());
                    //RadDateworkintoprecmy.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["WorkingTo"].ToString());
                    //RadDateworkintoprecmy.SelectedDate = System.DateTime.Today.Date;
                    RadCombocountryprecmy.SelectedValue = objdt.Rows[0]["Country"].ToString();
                    Txtpostalcodeprecmy.Text = objdt.Rows[0]["PostalCode"].ToString();
                }
                else
                {
                    RadCombooccupationprecmy.Text ="----Select Industry----";
                    Txtpresentcmy.Text ="";
                    Txtdesignationprecmy.Text = "";
                    Txtdescriptionprecmy.Text = "";

                    RadDateworkinfromprecmy.SelectedDate = null;
                    //RadDateworkintoprecmy.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["WorkingTo"].ToString());
                    //RadDateworkintoprecmy.SelectedDate = System.DateTime.Today.Date;
                    RadCombocountryprecmy.Text = "----Select Country----";
                    Txtpostalcodeprecmy.Text = "";
                }
            }
            catch { }


        }

        protected void Btnnext_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("AccountPastCompany.aspx");
        }

        protected void btnprevios_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountAcademics.aspx");  
        }

       
        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void getAccountPrescmyPageLanguageInfo()
        {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountPrescmy");
            btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountPrescmy");
            btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountPrescmy");
            Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountPrescmy");
            Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountPrescmy");
            Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccountPrescmy");
            Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccountPrescmy");
            Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccountPrescmy");
            Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccountPrescmy");
            Button7.Text = (string)GetGlobalResourceObject("PageResource", "Button7_AccountPrescmy");
            Button8.Text = (string)GetGlobalResourceObject("PageResource", "Button8_AccountPrescmy");
            Label45.Text = (string)GetGlobalResourceObject("PageResource", "Label45_AccountPresentCmy");
            Label46.Text = (string)GetGlobalResourceObject("PageResource", "Label46_AccountPresentCmy");
            Label48.Text = (string)GetGlobalResourceObject("PageResource", "Label48_AccountPresentCmy");
            Label49.Text = (string)GetGlobalResourceObject("PageResource", "Label49_AccountPresentCmy");
            Label50.Text = (string)GetGlobalResourceObject("PageResource", "Label50_AccountPresentCmy");
            Label51.Text = (string)GetGlobalResourceObject("PageResource", "Label51_AccountPresentCmy");
            Label53.Text = (string)GetGlobalResourceObject("PageResource", "Label53_AccountPresentCmy");
            Label54.Text = (string)GetGlobalResourceObject("PageResource", "Label54_AccountPresentCmy");
            btnprevios.Text = (string)GetGlobalResourceObject("PageResource", "btnprevios_AccountPrescmy");
            Update.Text = (string)GetGlobalResourceObject("PageResource", "Update_AccountPresentCmy");
            Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountPresentCmy");
            Btnnext.Text = (string)GetGlobalResourceObject("PageResource", "Btnnext_AccountPrescmy");
            //RegularExpressionValidator9.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator9_AccountPrescmy");
            RegularExpressionValidator4.ErrorMessage = (string)GetGlobalResourceObject("PageResource", "RegularExpressionValidator4_AccountPrescmy");
            Label25.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
        }

       

        
            
    }
}
