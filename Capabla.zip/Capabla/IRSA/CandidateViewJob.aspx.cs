﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using System.Data;
using IRSA.Common.GlobalFunction;
using Telerik.Web.UI;

namespace IRSA
{
    public partial class CandidateViewJob : System.Web.UI.Page
    {
        string agentName;
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            agentName = Request.QueryString.Get("id").ToString();
            if(!IsPostBack)
            {
            gridViewJobs();  //Search jobs for candidate 
            }
        }

       void gridViewJobs()
        {
        MyJobAgentFA viewJobFA = new MyJobAgentFA();
        DataTable dtViewJobs = new DataTable();
        dtViewJobs = viewJobFA.candidateViewJobs(agentName, UserID);//Search jobs for candidate using Job Agent
        dtViewJobs.Columns.Add(new DataColumn("SkillJobID", typeof(string)));
        for (int i = dtViewJobs.Rows.Count-1; i >= 0;i-- )
        {
            dtViewJobs.Rows[i]["SkillJobID"] = "redirectTo(" + (dtViewJobs.Rows[i]["JobID"]).ToString() + ")";
        }
        rdCandidateViewJob.DataSource = dtViewJobs;
        rdCandidateViewJob.DataBind();    
        }
        
     

       protected void imgApplyNow_Click(object sender, ImageClickEventArgs e)
       {
           //lnkBtnAlertmsgAssessment.Visible = false;
           lblMsgJob.Visible = false;
           int jobID=0;
           GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
           ImageButton lnkBtnApply = (ImageButton)rdCandidateViewJob.Items[gr.ItemIndex].FindControl("imgApplyNow");
           LinkButton lnkAssessment = (LinkButton)rdCandidateViewJob.Items[gr.ItemIndex].FindControl("lnkBtnAlertmsgAssessment");
           LinkButton lnkTools = (LinkButton)rdCandidateViewJob.Items[gr.ItemIndex].FindControl("lnkBtnTools");
           jobID = Convert.ToInt32(rdCandidateViewJob.MasterTableView.DataKeyValues[gr.ItemIndex]["JobID"]);
           MyJobAgentFA getAppliedJob =new MyJobAgentFA();
           DataTable dtjob = getAppliedJob.getAppliedJob(jobID,UserID);
           if (dtjob.Rows.Count > 0)
           {
               lblMsgJob.Visible = true;
               lblMsgJob.Text = "You have already Applied";
           }
           else
           {
               MyJobAgentFA getStatusFA = new MyJobAgentFA();
               DataTable dtStatus = getStatusFA.getStatus(UserID, jobID);
               DataTable dtStatusTools = getStatusFA.getStatusTools(UserID, jobID);
               if (dtStatus.Rows.Count > 0 || dtStatusTools.Rows.Count > 0)
               {
                   if (dtStatus.Rows.Count > 0 && dtStatusTools.Rows.Count > 0)
                   {
                       if (dtStatus.Rows[0]["Status"].ToString().Trim() == "Submit" && dtStatusTools.Rows[0]["Status"].ToString().Trim() == "Submit")
                       {
                           lnkAssessment.Visible = false;
                           lnkTools.Visible = false;
                           MyJobAgentFA applyJob = new MyJobAgentFA();
                           applyJob.candidateApplyJob(UserID, jobID);
                           //lnkBtnApply.Enabled = false;
                           //lnkBtnApply.Enabled = false;
                           lblMsgJob.Visible = true;
                           lblMsgJob.Text = "You have successfully applied";
                       }
                       else
                       {

                           if (dtStatusTools.Rows[0]["Status"].ToString().Trim() == "Save")
                           {
                               lnkTools.Visible = true;
                               lblMsgJob.Visible = true;
                               lblMsgJob.Text = "Your Assessment is Pending";
                           }

                           if (dtStatus.Rows[0]["Status"].ToString().Trim() == "Save")
                           {
                               lnkAssessment.Visible = true;
                               lblMsgJob.Visible = true;
                               lblMsgJob.Text = "Your Assessment is Pending";
                           }
                       }
                   }

                   else if (dtStatus.Rows.Count > 0 && dtStatusTools.Rows.Count == 0)
                   {
                       if (dtStatus.Rows[0]["Status"].ToString().Trim() == "Save" || dtStatus.Rows[0]["Status"].ToString().Trim() == "")
                       {
                           lnkAssessment.Visible = true;
                           lblMsgJob.Visible = true;
                           lblMsgJob.Text = "Your Assessment is Pending";
                       }
                       else
                       {
                           lnkAssessment.Visible = false;
                           lnkTools.Visible = false;
                           MyJobAgentFA applyJob = new MyJobAgentFA();
                           applyJob.candidateApplyJob(UserID, jobID);
                           //lnkBtnApply.Enabled = false;
                           //lnkBtnApply.Enabled = false;
                           lblMsgJob.Visible = true;
                           lblMsgJob.Text = "You have successfully applied";
                       }
                   }
                   else if (dtStatus.Rows.Count == 0 && dtStatusTools.Rows.Count > 0)
                   {
                       if (dtStatusTools.Rows[0]["Status"].ToString().Trim() == "Save")
                       {
                           lnkTools.Visible = true;
                           lblMsgJob.Visible = true;
                           lblMsgJob.Text = "Your Assessment is Pending";
                       }
                       else
                       {
                           lnkAssessment.Visible = false;
                           lnkTools.Visible = false;
                           MyJobAgentFA applyJob = new MyJobAgentFA();
                           applyJob.candidateApplyJob(UserID, jobID);
                           //lnkBtnApply.Enabled = false;
                           //lnkBtnApply.Enabled = false;
                           lblMsgJob.Visible = true;
                           lblMsgJob.Text = "You have successfully applied";
                       }
                   }

               }
               else
               {

                   MyJobAgentFA applyJob = new MyJobAgentFA();
                   applyJob.candidateApplyJob(UserID, jobID);//To insert Applied job of Candidate
                   //lnkBtnApply.Enabled = false;
                   lblMsgJob.Visible = true;
                   lblMsgJob.Text = "You have successfully applied";
               }
           }
       }
           
       

       protected void rdCandidateViewJob_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
       {
           MyJobAgentFA viewJobFA = new MyJobAgentFA();
           DataTable dtViewJobs = new DataTable();
           dtViewJobs = viewJobFA.candidateViewJobs(agentName, UserID);//Search jobs for candidate using Job Agent
           rdCandidateViewJob.DataSource = dtViewJobs;
           rdCandidateViewJob.DataBind();    
       }

      

    }
}
