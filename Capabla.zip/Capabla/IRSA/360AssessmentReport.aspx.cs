﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;
using IRSA.BussinessLogic;
using iTextSharp.text.pdf;
using System.Configuration;
using System.IO;
using IRSA.Facade;
using Telerik.Web.UI;
using ChartDirector;
using Telerik.Reporting;
using System.Reflection;
using System.ComponentModel;

using ReportLibrary;

namespace IRSA
{
    public partial class _60AssessmentReport : System.Web.UI.Page
    {
        string reportName;
        int UserID;
        string ChartsFilePath;
        int AttemptID;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                AttemptID = SessionInfo.AttemptID;
                ChartsFilePath = ConfigurationSettings.AppSettings["ChartsFilePath"];
                UserID = SessionInfo.UserId;
                get360Assementradar();
                foreach (Type t in ReportExplorer.GetReports())
                {
                    DescriptionAttribute description =
                        TypeDescriptor.GetAttributes(t)[typeof(DescriptionAttribute)] as DescriptionAttribute;

                    object[] values = new object[]
                {
                   reportName = t.AssemblyQualifiedName
                };
                    reportName = Server.UrlDecode(reportName);
                    Type reportType = Type.GetType(reportName);
                    if (reportType.Name == "_360DegreeAssessment")
                    {
                        IReportDocument report = (IReportDocument)Activator.CreateInstance(reportType);
                        this.ReportViewer1.Report = report;
                        this.Page.Title = "360 Degree Assessment Report";
                    }

                }

            }
            catch
            { }
        }
        public void get360Assementradar()
        {
            try
            {
                int[] colors = { 0xb8bc9c, 0xa0bdc4, 0x999966, 0x333366, 0xc3c3e6 };

                double[] data = new double[5];
                double[] data1 = new double[5];
                double[] data2 = new double[5];
                double[] data3 = new double[5];
                double[] data4 = new double[5];
                double[] fixeddata = { 3.5, 3.5, 3.5, 3.5, 3.5 };
                double[] fixeddata1 = { 4.25, 4.25, 4.25, 4.25, 4.25 };
                // The labels for the chart
                string[] labels = new string[5];
                DataTable dtrpt = new DataTable();
                dtrpt = ReportBL.Get360AssessmentReportData(UserID, "",AttemptID);
                if (dtrpt.Rows.Count > 0)
                {
                    for (int i = 0; i < dtrpt.Rows.Count; i++)
                    {
                        data[i] = Convert.ToDouble(dtrpt.Rows[i]["Percentage"].ToString());


                        labels[i] = dtrpt.Rows[i]["SkillName"].ToString();
                    }
                }
                dtrpt = ReportBL.Get360AssessmentReportData(UserID, "B", AttemptID);
                if (dtrpt.Rows.Count > 0)
                {
                    for (int i = 0; i < dtrpt.Rows.Count; i++)
                    {
                        data1[i] = Convert.ToDouble(dtrpt.Rows[i]["Percentage"].ToString());



                    }
                }
                dtrpt = ReportBL.Get360AssessmentReportData(UserID, "C", AttemptID);
                if (dtrpt.Rows.Count > 0)
                {
                    for (int i = 0; i < dtrpt.Rows.Count; i++)
                    {
                        data2[i] = Convert.ToDouble(dtrpt.Rows[i]["Percentage"].ToString());



                    }
                }
                dtrpt = ReportBL.Get360AssessmentReportData(UserID, "F", AttemptID);
                if (dtrpt.Rows.Count > 0)
                {
                    for (int i = 0; i < dtrpt.Rows.Count; i++)
                    {
                        data3[i] = Convert.ToDouble(dtrpt.Rows[i]["Percentage"].ToString());



                    }
                }
                for (int i = 0; i < 5; i++)
                {
                    data4[i] = ((data1[i] + data2[i] + data3[i]) / 3);



                }

                // Create a PolarChart object of size 450 x 350 pixels
                PolarChart c = new PolarChart(820, 500, ChartDirector.Chart.silverColor(), 0x000000, 1);

                // Set center of plot area at (225, 185) with radius 150 pixels
                c.setPlotArea(400, 250, 200, 0xffcccc);
                PolarLineLayer pl = new PolarLineLayer();
                LegendBox b = c.addLegend(400, 480, false, "Arial Bold", 10);

                b.setAlignment(ChartDirector.Chart.BottomCenter);
                b.setBackground(ChartDirector.Chart.silverColor(), ChartDirector.Chart.Transparent, 1);
                // Add an area layer to the polar chart
                //c.addAreaLayer(data, unchecked((int)0x90008000), "Gaurav");
                c.addAreaLayer(fixeddata1, 0xa0bce0, "Favoural Zone(3.5 to 4.25)");
                c.addAreaLayer(fixeddata, 0xffcccc);
                pl = c.addLineLayer(data, 0x008000, "Self[S]");
                //pl.setDataSymbol(Chart.DiamondSymbol, 12);
                pl.setDataSymbol(ChartDirector.Chart.CircleSymbol, 12);
                pl.setLineWidth(2);
                pl.setDataLabelFormat("S");
                pl.setDataLabelStyle("Arial Bold", 10, 0x008000);

                //c.addAreaLayer(data1, unchecked((int)0x900088ff), "Boss");
                pl = c.addLineLayer(data4, 0x800000, "All Observers(combined scores of Boss, Colleague and Friend)[A]");
                pl.setDataSymbol(ChartDirector.Chart.CircleSymbol, 12);
                pl.setLineWidth(2);
                pl.setDataLabelFormat("A");
                pl.setDataLabelStyle("Arial Bold", 10, 0x800000);

                //c.addAreaLayer(data2, unchecked((int)0x90cc6666), "Collegue");
                //pl = c.addLineLayer(data2, 0x0000ff, "Colleague");
                //pl.setDataSymbol(Chart.DiamondSymbol, 12);
                //pl.setLineWidth(2);
                ////c.addAreaLayer(data3, unchecked((int)0x906666cc), "Friend");
                //pl = c.addLineLayer(data3, 0x800000, "Friend");
                //pl.setDataSymbol(Chart.DiamondSymbol, 12);
                //pl.setLineWidth(2);


                // Set the labels to the angular axis as spokes
                c.angularAxis().setLabels(labels);
                c.radialAxis().setLinearScale(0, 6, 1);
                // Output the chart
                WebChartViewer1.Image = c.makeWebImage(ChartDirector.Chart.PNG);

                //include tool tip for the chart
                WebChartViewer1.ImageMap = c.getHTMLImageMap("", "",
                    "title='{label}: score = {value}'");
                string filename = c.makeTmpFile(ChartsFilePath);
                string filesave;
                string filee = ChartsFilePath + filename;
                filesave = ChartsFilePath + UserID + "360Degree" + ".png";
                ResizeImage(filee, filesave, 760, 500);
            }
            catch
            {

            }
        }
        public void ResizeImage(string OriginalFile, string NewFile, int NewWidth, int MaxHeight)
        {
            try
            {
                System.Drawing.Image FullsizeImage = System.Drawing.Image.FromFile(OriginalFile);

                // Prevent using images internal thumbnail
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                FullsizeImage.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);


                System.Drawing.Image NewImage = FullsizeImage.GetThumbnailImage(NewWidth, MaxHeight, null, IntPtr.Zero);

                // Clear handle to original file so that we can overwrite it if necessary
                FullsizeImage.Dispose();

                // Save resized picture
                NewImage.Save(NewFile);
            }
            catch
            {
            }
        }
       
    }
}
