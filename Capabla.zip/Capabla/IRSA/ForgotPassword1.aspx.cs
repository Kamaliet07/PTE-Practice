﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using System.Configuration;
using IRSA.Common.GlobalFunction;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using System.Xml;
using System.Net.Mail;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Globalization;
using System.Resources;
using System.Threading;


namespace IRSA
{
    public partial class ForgotPassword1 : System.Web.UI.Page
    {   
        
       static string passwordString;
       public string cultureid;
       public string Cultinfo;
       string senderID;
       string CULINFO;
       string forgotmailxml = "Forgotpassword.xml";
        protected void Page_Load(object sender, EventArgs e)
       {
           cultureid = SessionInfo.CultureID;
           senderID = ConfigurationSettings.AppSettings["SenderMailID"];
           getPageLanguageInfo();
            //LoginLanguageInfo();
        }

                                                                          
        public static string randompassword()
        {
        
        string allowedChars = "";
        allowedChars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";
        allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";
        allowedChars += "1,2,3,4,5,6,7,8,9,0,!,";

        char[] sep = { ',' };
        string[] arr = allowedChars.Split(sep);

        passwordString = "";

        string temp = "";

        Random rand = new Random();
        for (int i = 0; i < 6 ; i++)
        {
            temp = arr[rand.Next(0, arr.Length)];
            passwordString += temp;
        }
            return passwordString;
        }


        public static bool ValidateServerCertificate(Object sender, X509Certificate certificate, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
       
        public void SendMail()
        {
            try
            {
                
                StringBuilder bodyMsg = new StringBuilder();
                MailAddress sendto = new MailAddress(RadTextBox2.Text);
                MailAddress fromto = new MailAddress(senderID);
                MailMessage msg = new MailMessage(fromto, sendto);
                MailDefinition mailmsg = new MailDefinition();
                mailmsg.BodyFileName = "";
                mailmsg.IsBodyHtml = true;
                msg.IsBodyHtml = true;
                string htmlmail;
                bodyMsg.Append(ToolTipMessages.GetiRsaToolTipModuleWiseMessage(1, forgotmailxml));
                
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append(ToolTipMessages.GetiRsaToolTipModuleWiseMessage(2, forgotmailxml));
                bodyMsg.AppendFormat(RadTextBox2.Text);
                bodyMsg.Append("<br />");
                bodyMsg.Append(ToolTipMessages.GetiRsaToolTipModuleWiseMessage(3, forgotmailxml));
                bodyMsg.AppendFormat(passwordString);
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append(ToolTipMessages.GetiRsaToolTipModuleWiseMessage(4, forgotmailxml));
                bodyMsg.Append("<br />");
                bodyMsg.Append("<br />");
                bodyMsg.Append(ToolTipMessages.GetiRsaToolTipModuleWiseMessage(5, forgotmailxml));
                if (cultureid == "EN")
                {
                    msg.Subject = "Forgot Password information";

                    msg.Body = bodyMsg.ToString();
                }
                else if (cultureid == "NL")
                {
                    msg.Subject = "Wachtwoord Wachtwoord informatie";

                    msg.Body = bodyMsg.ToString();

                }


                msg.Priority = MailPriority.High;

                SmtpClient smt = new SmtpClient();
                smt.EnableSsl = true;
                System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };

                smt.Send(msg);

                //msg.Subject = "ForgotPassword information";
                //msg.Body = "User Name :" + RadTextBox2.Text + "\n Password :" + passwordString + "\n Congratulation! This is Your new Password.After you login,explore the various tools & information to grow your career and get involved!.Your Participation Drives capabala.com.Thank You for your interest in capabala capabala values your privacy at no time has capabala made your email address available to any other capabala user without your permission @2009,Powered By capabala";
                //msg.Priority = MailPriority.High;
                //SmtpClient smt = new SmtpClient();
                //smt.EnableSsl = true;
                //smt.Send(msg);
                
                }
               
            
            
            catch
            {
            }
        }


        protected void Button3_Click(object sender, EventArgs e)
        {
            ForgotPasswordSH objForgotPasswordSH = new ForgotPasswordSH();
            if ((RadTextBox2.Text == null)||(RadTextBox2.Text == ""))
            {
                Lblshow.Visible = true;
                Lblshow.Text = "EmailID is either Blank or not in correct Format";
            }
            else 
            {
                if (Validation.IsValidEmailAddress(RadTextBox2.Text))
                {
                    objForgotPasswordSH.UserName = RadTextBox2.Text;
                    ForgotPasswordFA objForgotPasswordFA = new ForgotPasswordFA();
                    string pwd = randompassword();
                    string newpassword = Encryption.HashPwd(pwd);
                    objForgotPasswordSH.Password = newpassword;
                    DataTable ds = new DataTable();
                    ds = objForgotPasswordFA.GetData(objForgotPasswordSH);
                    int count = ds.Rows.Count;
                    if (count > 0)
                    {
                        SendMail();
                        RadTextBox2.Enabled = false;
                        Lblshow.Visible = true;
                        Lblshow.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(100);
                    }
                    else
                    {
                        Lblshow.Visible = true;
                        Lblshow.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(101);
                    }
                
                }
                
                else
                {
                    Lblshow.Visible = true;
                    Lblshow.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(75);
                }
            }

           
        }
        protected void getPageLanguageInfo()
        {
            try
            {
                string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

                if (cultureid == "EN")
                {
                    CULINFO = "en-GB";

                }
                else
                {
                    CULINFO = "nl-NL";
                }

                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                lblForgetPassword.Text = (string)GetGlobalResourceObject("PageResource", "lblForgetPassword_ForgetPassword");
                LblUsernameFP.Text = (string)GetGlobalResourceObject("PageResource", "LblEmail_Registration");
                Label1.Text = (string)GetGlobalResourceObject("PageResource", "Label1_ForgetPassword");
                Button3.Text = (string)GetGlobalResourceObject("PageResource", "btnSubmit_Questionnaire");
                Button4.Text = (string)GetGlobalResourceObject("PageResource", "Btncancel_AccSetting");
                
            }

            catch
            {
            }
        }
       
    }
        
    }







