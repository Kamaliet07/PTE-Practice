﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Shared;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Net.Mail;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Threading;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Configuration;
using IRSA.Exception;
using Telerik.Web.UI;


namespace IRSA
{
    public partial class AccountPastCompany : System.Web.UI.Page
    {
        int UserID;
        string Accountxml = "irsatooltipaccount.xml";
        string CurrentWizardStep = "Past Company";
        DateTime dateTo;
        DateTime dateFrom;
        string AppName;
        string CULINFO;
        string CultureID1;
        string strExp;
        public string Company
        {
            set
            {
                ViewState["Company"] = value;
            }
            get
            {
                if (ViewState["Company"] == null)
                {
                    ViewState["Company"] = "";
                }
                return ViewState["Company"].ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            getAccountPastcmyPageLanguageInfo();
            AppName = ConfigurationSettings.AppSettings["Applicationname"];
            Page.Title = AppName + "– My Account, Create Profile," + AppName + " " + "Resume";
            Page.Form.DefaultButton = Update.UniqueID;
            UserID = SessionInfo.UserId;
            CultureID1 = SessionInfo.CultureID;
            if (!this.IsPostBack)
            {
                Disablepastcmy();
                string str = Request.QueryString.Get("id");

                int id = Convert.ToInt32(str);
                if (str != null)
                {

                    str = Request.QueryString.Get("id");

                }
                Lbldatamodified.Visible = false;
                Getdata();
            }
            GetiRsaToolTipAccMsg();
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                if (objdt.Rows[0]["DisplayName"].ToString() != "")
                {
                    Lblmember.Text = objdt.Rows[0]["DisplayName"].ToString() + " " + "!";
                    SessionInfo.DisplayName = objdt.Rows[0]["DisplayName"].ToString();
                }
                else
                {
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
                }

            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
        private void GetiRsaToolTipAccMsg()
        {
            try
            {
                Txtdescription.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(57, Accountxml);
                Txtcmymail.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(56, Accountxml);
                Txtdesignation.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(49, Accountxml);
                Image1.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(55, Accountxml);
                TxtPastCmy.ToolTip = ToolTipMessages.GetiRsaToolTipModuleWiseMessage(54, Accountxml);



            }
            catch { }
        }
        public void Getdata()
        {
            try
            {

                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {


                    RadGridPstCmy.DataSource = objdt;
                    RadGridPstCmy.DataBind();
                    panel2.Visible = true;
                    RadGridPstCmy.Visible = true;

                }
                else
                {
                    panel2.Visible = false;
                    RadGridPstCmy.Visible = false;
                }




            }
            catch { }
        }
        public void getgriddata()
        {
            AccountsetupFA objaccFA = new AccountsetupFA();
            DataTable objdt = new DataTable();
            objdt = objaccFA.GetPastcmygrdData(UserID, this.Company);
            if (objdt.Rows.Count > 0)
            {
                TxtPastCmy.Text = objdt.Rows[0]["Company"].ToString();
                Txtdesignation.Text = objdt.Rows[0]["Designation"].ToString();
                CULINFO = "en-GB";
                CultureInfo objCI = new CultureInfo(CULINFO);
                Thread.CurrentThread.CurrentCulture = objCI;
                Thread.CurrentThread.CurrentUICulture = objCI;
                if (objdt.Rows[0]["WorkingFrom"].ToString() != "")
                {
                    RadDateworkinfrm.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["WorkingFrom"].ToString());
                }
                if (objdt.Rows[0]["WorkingTo"].ToString() != "")
                {
                    RadDateworkinto.SelectedDate = Convert.ToDateTime(objdt.Rows[0]["WorkingTo"].ToString());
                }
                Txtdescription.Text = objdt.Rows[0]["Description"].ToString();
                Txtcmymail.Text = objdt.Rows[0]["CompanyURL"].ToString();


                DataTable objsdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {
                    RadGridPstCmy.DataSource = objdt;
                    RadGridPstCmy.DataBind();
                    panel2.Visible = true;
                    RadGridPstCmy.Visible = true;
                }
            }
        }
        protected void Btnmorepstcmy_Click(object sender, EventArgs e)
        {
            try
            {
                this.Company = "";
                Enablepastcmy();
                Lbldatamodified.Visible = false;
            }
            catch { }


        }
        protected void btncmyupdate_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btncmyupdate");
                this.Company = Convert.ToString(RadGridPstCmy.MasterTableView.DataKeyValues[gr.ItemIndex]["Company"]);
                Enablepastcmy();
                getgriddata();


            }
            catch
            {
            }

        }

        protected void RadGridPstCmy_pageindexchanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            RadGridPstCmy.CurrentPageIndex = e.NewPageIndex;
            Getdata();
        }

        public void savedata()
        {
            CULINFO = "en-GB";
            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;

            if (RadDateworkinto.SelectedDate != null)
            {
                dateTo = RadDateworkinto.SelectedDate.Value;
            }
            if (RadDateworkinfrm.SelectedDate != null)
            {
                dateFrom = RadDateworkinfrm.SelectedDate.Value;
            }
            DateTime dateToday = System.DateTime.Today.Date;
            try
            {
                AccountsetupSH objaccpastSH = new AccountsetupSH();
                if (TxtPastCmy.Text != "")
                {

                    objaccpastSH.Designation = UCFirst(Txtdesignation.Text);
                    if ((RadDateworkinfrm.SelectedDate != null) && (RadDateworkinto.SelectedDate != null))
                    {
                        objaccpastSH.WorkingFrom = RadDateworkinfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                        objaccpastSH.WorkingTo = RadDateworkinto.SelectedDate.Value.ToString("dd/MMM/yyyy");
                        if ((dateFrom > dateToday))
                        {

                            lblDateErrorS.Visible = true;
                            RadDateworkinfrm.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        else
                        {
                            lblDateErrorS.Visible = false;
                            Lbldatamodified.Visible = false;
                        }
                        if (dateTo > dateToday)
                        {
                            lblDateErrorS.Visible = true;
                            RadDateworkinto.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        else
                        {
                            Lbldatamodified.Visible = false;
                            lblDateErrorS.Visible = false;
                        }
                        if ((dateFrom > dateTo))
                        {

                            lblDateErrorS.Visible = true;
                            RadDateworkinfrm.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        else
                        {
                            lblDateErrorS.Visible = false;
                            Lbldatamodified.Visible = false;
                        }
                    }
                    else if (RadDateworkinfrm.SelectedDate != null)
                    {
                        objaccpastSH.WorkingFrom = RadDateworkinfrm.SelectedDate.Value.ToString("dd/MMM/yyyy");
                        objaccpastSH.WorkingTo = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        if ((dateFrom > dateToday))
                        {

                            lblDateErrorS.Visible = true;
                            RadDateworkinfrm.Focus();
                            Lbldatamodified.Visible = false;
                            goto Last;
                        }
                        else
                        {
                            lblDateErrorS.Visible = false;
                            Lbldatamodified.Visible = false;
                        }
                    }
                    objaccpastSH.pastcompnyname = UCFirst(TxtPastCmy.Text);
                    objaccpastSH.CompanyURL = Txtcmymail.Text;
                    //objaccpastSH.CompanyEmail = TxtCompanyEmail.Text;
                    objaccpastSH.Description = UCFirst(Txtdescription.Text);

                    #region Profile Progressbar
                    //string path = "~/App_Themes/Site/images/";
                    int i = 0;
                    if (TxtPastCmy.Text != "")
                    {
                        i++;
                    }
                    if (Txtdesignation.Text != "")
                    {
                        i++;
                    }
                    if (Txtcmymail.Text != "")
                    {
                        i++;
                    }
                    if (Txtdescription.Text != "")
                    {
                        i++;
                    }
                    //if (RadDateworkinfrm.SelectedDate != Convert.ToDateTime(""))
                    //{
                    //    i++;
                    //}
                    //if (RadDateworkinto.SelectedDate != Convert.ToDateTime(""))
                    //{
                    //    i++;
                    //}
                    int PastCompany = i * 100 / 4;
                    int Experience = 0, AccountWelcome = 0, Acadimic = 0, PresentCompany = 0, Projects = 0;
                    #endregion

                    AccountsetupFA objaccpastFA = new AccountsetupFA();
                    objaccpastFA.InsertAccountSetUpData(objaccpastSH, UserID, CurrentWizardStep, AccountWelcome, Experience, PresentCompany, PastCompany, Acadimic, Projects);
                    Lbldatamodified.Visible = true;
                    Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(62);
                    Disablepastcmy();
                    Getdata();


                }
            Last: ;
            }
            catch { }
        }




        protected void Next_Click(object sender, EventArgs e)
        {
            savedata();
            Response.Redirect("AccountExperience.aspx");
        }



        protected void btncmydelete_Click(object sender, EventArgs e)
        {
            try
            {
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);
                LinkButton btnprev = (LinkButton)sender;
                LinkButton obj = (LinkButton)btnprev.NamingContainer.FindControl("btncmyupdate");
                string Company = Convert.ToString(RadGridPstCmy.MasterTableView.DataKeyValues[gr.ItemIndex]["Company"]);

                // string UserID = Convert.ToString(RadGridAcademics.MasterTableView.DataKeyValues[gr.ItemIndex]["UserID"]);
                AccountsetupFA objaccFA = new AccountsetupFA();
                objaccFA.deletecmyGridData(UserID, Company);
                
                Lbldatamodified.Visible = true;
                Lbldatamodified.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(63);

                DataTable objdt = new DataTable();
                objdt = objaccFA.GetAccountSetUpData(UserID, CurrentWizardStep);
                if (objdt.Rows.Count > 0)
                {
                    RadGridPstCmy.DataSource = objdt;
                    RadGridPstCmy.DataBind();
                    Disablepastcmy();
                }
                else
                {
                    RadGridPstCmy.Visible = false;
                    Disablepastcmy();
                }
            }
            catch { }
        }
        private string UCFirst(string strName)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(strName);
            try
            {
                if (strName.Length > 0)
                {
                    sb = sb.Replace(sb[0], Char.ToUpper(sb[0]), 0, 1);
                }
            }
            catch { }
            return sb.ToString();
        }

        protected void Update_Click(object sender, EventArgs e)
        {
            savedata();
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.Company != "")
                {
                    Enablepastcmy();
                    getgriddata();
                }
                else
                {
                    Disablepastcmy();
                }

            }
            catch { }

        }
        public void Enablepastcmy()
        {
            TxtPastCmy.Text = "";
            Txtdesignation.Text = "";
            RadDateworkinfrm.SelectedDate = null;
            RadDateworkinto.SelectedDate = null;
            Txtdescription.Text = "";
            Txtcmymail.Text = "";
            //Txtsplpassingyear.Text = "";
            TxtPastCmy.ReadOnly = false;
            Txtdesignation.ReadOnly = false;
            RadDateworkinfrm.Enabled = true;
            RadDateworkinto.Enabled = true;
            Txtdescription.ReadOnly = false;
            Txtcmymail.ReadOnly = false;

        }
        public void Disablepastcmy()
        {
            TxtPastCmy.Text = "";
            Txtdesignation.Text = "";
            RadDateworkinfrm.SelectedDate = null;
            RadDateworkinto.SelectedDate = null;
            Txtdescription.Text = "";
            Txtcmymail.Text = "";
            //Txtsplpassingyear.Text = "";
            TxtPastCmy.ReadOnly = true;
            Txtdesignation.ReadOnly = true;
            RadDateworkinfrm.Enabled = false;
            RadDateworkinto.Enabled = false;
            Txtdescription.ReadOnly = true;
            Txtcmymail.ReadOnly = true;
        }

        protected void Btnprv_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountPresentCmy.aspx");
        }

        protected void Btnnxt_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccountExperience.aspx");
        }

        protected void btnResume_Click(object sender, EventArgs e)
        {
            try
            {
                string Url = "PdfIRSAResume.aspx";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script language='javascript' type='text/javascript'>");
                sb.Append("window.open('" + Url + "', 'PopUp',");
                sb.Append("'top=100, left=0, width=1000, height=600, menubar=no,toolbar=no,status,resizable=yes,addressbar=no');<");
                sb.Append("/script>");

                Type t = this.GetType();

                if (!ClientScript.IsClientScriptBlockRegistered(t, "PopupScript"))
                    ClientScript.RegisterClientScriptBlock(t, "PopupScript", sb.ToString());
            }
            catch { }
        }

        protected void getAccountPastcmyPageLanguageInfo()
        {
            string cultureid = IRSA.Common.GlobalFunction.SessionInfo.CultureID;

            if (cultureid == "EN")
            {
                CULINFO = "en-GB";

            }
            else
            {
                CULINFO = "nl-NL";
            }

            CultureInfo objCI = new CultureInfo(CULINFO);
            Thread.CurrentThread.CurrentCulture = objCI;
            Thread.CurrentThread.CurrentUICulture = objCI;
            btnEdit.Text = (string)GetGlobalResourceObject("PageResource", "btnEdit_AccountPast");
            btnView.Text = (string)GetGlobalResourceObject("PageResource", "btnView_AccountPast");
            btnResume.Text = (string)GetGlobalResourceObject("PageResource", "btnResume_AccountPast");
            Label73.Text = (string)GetGlobalResourceObject("PageResource", "Label73_AccountPast");
            Button2.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountPast");
            Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button3_AccountPast");
            Button4.Text = (string)GetGlobalResourceObject("PageResource", "Button4_AccountPast");
            Button5.Text = (string)GetGlobalResourceObject("PageResource", "Button5_AccountPast");
            Button6.Text = (string)GetGlobalResourceObject("PageResource", "Button6_AccountPast");
            Button7.Text = (string)GetGlobalResourceObject("PageResource", "Button7_AccountPast");
            Button8.Text = (string)GetGlobalResourceObject("PageResource", "Button8_AccountPast");
            //Button3.Text = (string)GetGlobalResourceObject("PageResource", "Button2_AccountPast");
            Label35.Text = (string)GetGlobalResourceObject("PageResource", "Label35_AccountPastCompany");
            Label36.Text = (string)GetGlobalResourceObject("PageResource", "Label36_AccountPastCompany");
            Label39.Text = (string)GetGlobalResourceObject("PageResource", "Label39_AccountPastCompany");
            Label38.Text = (string)GetGlobalResourceObject("PageResource", "Label38_AccountPastCompany");
            Label40.Text = (string)GetGlobalResourceObject("PageResource", "Label40_AccountPastCompany");
            Label41.Text = (string)GetGlobalResourceObject("PageResource", "Label41_AccountPastCompany");
            Label42.Text = (string)GetGlobalResourceObject("PageResource", "Label42_AccountPastCompany");
            Update.Text = (string)GetGlobalResourceObject("PageResource", "Update_AccountPastCompany");
            Reset.Text = (string)GetGlobalResourceObject("PageResource", "Reset_AccountPastCompany");
            Btnprv.Text = (string)GetGlobalResourceObject("PageResource", "Btnprv_AccountPast");
            Btnnxt.Text = (string)GetGlobalResourceObject("PageResource", "Btnnxt_AccountPast");
            ImageButton2.Text = (string)GetGlobalResourceObject("PageResource", "ImageButton3_AccountAcademics");
            RadGridPstCmy.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdcompany_accpstcmy");
            RadGridPstCmy.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdDesignation_accpstcmy");
            RadGridPstCmy.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdWorkingFrom_accpstcmy");
            RadGridPstCmy.Columns[0].HeaderText = (string)GetGlobalResourceObject("PageResource", "grdWorkingTo_accpstcmy");
            RadGridPstCmy.PagerStyle.NextPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire2");
            RadGridPstCmy.PagerStyle.PrevPageText = (string)GetGlobalResourceObject("PageResource", "Grid_Questionnaire3");
            RadGridPstCmy.PagerStyle.PagerTextFormat = (string)GetGlobalResourceObject("PageResource", "grid_pagetext");
            Label25.Text = (string)GetGlobalResourceObject("PageResource", "Lblmember_accountsetup");
        }
    }
    }

