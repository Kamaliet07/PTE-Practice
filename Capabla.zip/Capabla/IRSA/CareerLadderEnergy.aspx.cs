﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Common.GlobalFunction;
using IRSA.Facade;
using System.Data;

namespace IRSA
{
    public partial class CareerLadderEnergy : System.Web.UI.Page
    {
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void lnkBtnPetroleumEngineer(object sender, EventArgs e)
        {
            int i = 0;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnRigManager(object sender, EventArgs e)
        {
            int i = 1;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnDrillingForeman(object sender, EventArgs e)
        {
            int i = 2;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnDriller(object sender, EventArgs e)
        {
            int i = 3;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnPetroleumPumpSystemsOperator(object sender, EventArgs e)
        {
            int i = 4;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnDerrick(object sender, EventArgs e)
        {
            int i = 5;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnRoustabout(object sender, EventArgs e)
        {
            int i = 6;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }

        protected void lnkBtnExtractionWorkers(object sender, EventArgs e)
        {
            int i = 7;
            Response.Redirect("CareerLadderEnergyInfo.aspx?id=" + i);
        }



        protected void ImgbtnItmngrConsul_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void ImageButton16_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void lnkbtnCLITBAck_Click(object sender, EventArgs e)
        {
            Response.Redirect("CareerLadderIntroduction.aspx");
        }

    }
}
