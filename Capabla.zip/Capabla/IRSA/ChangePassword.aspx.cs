﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Web.Security;

namespace IRSA
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        int UserID;
        string oldpwd;
        string OldPwd;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID=SessionInfo.UserId;
            
        }
       
        protected void Button3_Click(object sender, EventArgs e)
        {
           
           
            ChangePasswordSH Objchgpwdsh = new ChangePasswordSH();
            if (Txnpwd.Text != "")
            {
                Objchgpwdsh.Password = Txnpwd.Text;
            }
            else 
            {
                lblconfirm.Visible = true;
                lblconfirm.Text = ErrorMessage.GetiRsaErrorMessage(54);
                goto Last;
            }

            if (txnnewpwd.Text != "")
            {
                Objchgpwdsh.NewPassword = Txnpwd.Text;
            }
            else
            {
                lblconfirm.Visible = true;
                lblconfirm.Text = ErrorMessage.GetiRsaErrorMessage(55);
                goto Last;
            }
            if (txnconfirmpwd.Text != "")
            {
                Objchgpwdsh.ConfirmPassword = Txnpwd.Text;
            }
            else
            {
                lblconfirm.Visible = true;
                lblconfirm.Text = ErrorMessage.GetiRsaErrorMessage(56);
                goto Last;
            }
            //Objchgpwdsh.Password = Txnpwd.Text;
            //Objchgpwdsh.NewPassword = txnnewpwd.Text;
            //Objchgpwdsh.ConfirmPassword = txnconfirmpwd.Text;

            Encryption.HashPwd(Txnpwd.Text);
            string password = Encryption.HashPwd(Txnpwd.Text);
            ChangePasswordFA objchgpwd = new ChangePasswordFA();
            DataTable objroledt = new DataTable();
            objroledt = objchgpwd.GetPassword(password);
            if (objroledt.Rows.Count > 0)
            {
                for (int i = 0; i < objroledt.Rows.Count; i++)
                {
                    if (objroledt.Rows[i]["UserID"].ToString() != "")
                    {
                        oldpwd = objroledt.Rows[i]["UserID"].ToString();
                        if (oldpwd == UserID.ToString())
                        {
                            OldPwd = oldpwd;
                        }
                        
                    }
                }
            }
            if (OldPwd == UserID.ToString())
            {
                if ((Objchgpwdsh.NewPassword == Objchgpwdsh.ConfirmPassword))
                {
                    string newpwd = Encryption.HashPwd(txnconfirmpwd.Text);
                    ChangePasswordFA objchgpwdup = new ChangePasswordFA();
                    DataTable objupdatedt = new DataTable();
                    objchgpwdup.UpdatePassword(UserID, newpwd);
                    lblconfirm.Visible = true;
                    lblconfirm.Text = ErrorMessage.GetiRsaErrorMessage(57);
                    Txnpwd.Text = "";
                    txnnewpwd.Text = "";
                    txnconfirmpwd.Text = "";
                }
                else
                {
                    lblconfirm.Text = ErrorMessage.GetiRsaErrorMessage(58);
                    Txnpwd.Text = "";
                    txnnewpwd.Text = "";
                    txnconfirmpwd.Text = "";
                }
            }
            else
            {
                lblconfirm.Visible = true;
                lblconfirm.Text = ErrorMessage.GetiRsaErrorMessage(59);
                Txnpwd.Text = "";
                txnnewpwd.Text = "";
                txnconfirmpwd.Text = "";
            }
          Last:; 
            
        }
    }
}
