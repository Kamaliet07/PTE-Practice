﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Collections;
using IRSA.BussinessLogic;


namespace IRSA
{
    public partial class Assessment360forUser : System.Web.UI.Page
    {
        int UserID;
        string questemplate;
        string Name;
        string WhoIs;
        int IndustryID;
        string OccupationID;
      
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }
        public string Status
        {
            set
            {
                ViewState["Status"] = value;
            }
            get
            {
                if (ViewState["Status"] == null)
                {
                    ViewState["Status"] ="";
                }
                return ViewState["Status"].ToString();
            }
        }

        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public int quescount
        {
            set
            {
                ViewState["quescount"] = value;
            }
            get
            {
                if (ViewState["quescount"] == null)
                {
                    ViewState["quescount"] = 0;
                }
                return Convert.ToInt32(ViewState["quescount"].ToString());
            }
        }
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public int AttemptID
        {
            set
            {
                ViewState["AttemptID"] = value;
            }
            get
            {
                if (ViewState["AttemptID"] == null)
                {
                    ViewState["AttemptID"] = 0;
                }
                return Convert.ToInt32(ViewState["AttemptID"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if ((Request.QueryString["param1"] != null && Request.QueryString["param2"] != null) && Request.QueryString["param3"] != null && Request.QueryString["param4"] != null && Request.QueryString["param5"] != null)
                {
                    UserID = Convert.ToInt32(Request.QueryString["param1"]);
                    WhoIs = Request.QueryString["param3"];
                    IndustryID = Convert.ToInt32(Request.QueryString["param4"]);
                    OccupationID = Request.QueryString["param5"];
                   
                }
                //UserID = 9;// Convert.ToInt32(Request.QueryString["param1"]);
                //WhoIs = "F";// Request.QueryString["param3"];
                //IndustryID = 8;// Convert.ToInt32(Request.QueryString["param4"]);
                //OccupationID = "47-3015.00";//Request.QueryString["param5"];
                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    //Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                    Name = objdt.Rows[0]["FirstName"].ToString() + " " + objdt.Rows[0]["LastName"].ToString();
                }
                GetUserAttemptIDfromsubmissonList();
                Assessment360FA objAssessmentFA = new Assessment360FA();
                DataTable dtattemptid = new DataTable();
                Assessment360SH objAssessment = new Assessment360SH();
                DataTable dtinvitestatus = new DataTable();
                objAssessment.WhoIs = WhoIs;
                objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                dtattemptid = objAssessmentFA.Get360UserAttemptIDforInvitie(UserID,objAssessment);
                if (dtattemptid.Rows.Count > 0)
                {
                    objAssessment.AttemptID = Convert.ToInt32(dtattemptid.Rows[0]["AttemptID"].ToString());
                }
                dtinvitestatus = objAssessmentFA.GetInvitationStatus(objAssessment, UserID);
                if (dtinvitestatus.Rows.Count > 0)
                {
                    Status = dtinvitestatus.Rows[0]["InvitationStatus"].ToString().Trim();
                    if (dtinvitestatus.Rows[0]["InvitationStatus"].ToString().Trim() == "Submit")
                    {
                        Panel3.Visible = true;
                        Panel2.Visible = false;
                        Panel1.Visible = false;
                        Lblthanks.Text = "Thanks For your support to do the 360 Degree Assessment of Mr. &nbsp;" + Name;

                    }
                    else
                    {
                        Panel2.Visible = true;
                        Panel3.Visible = false;
                        Panel1.Visible = true;
                        LblDesc.Text = "This is a assessment Invitation from iRSA.com" + "This invitation is sent by&nbsp;" + Name + "You have to select appropriate level for question and Assess to&nbsp;" + Name;

                    }
                }
                else
                {
                    LblDesc.Text = "This is a assessment Invitation from iRSA.com" + "This invitation is sent by&nbsp;" + Name + "You have to select appropriate level for question and Assess to&nbsp;" + Name;

                }

            }
            catch
            {
            }
        }


        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {

                    
                    if (OccupationID != "")
                    {
                        BindAssessmentGrid(OccupationID);
                    }
                }


                SelectRadioButton();
            }
            catch
            {
            }
        }
        public void BindAssessmentGrid(string OccupationID)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    GetSavedData();
                }
                Assessment360FA AssessFA = new Assessment360FA();
                DataTable temp = new DataTable();
                temp = AssessFA.Get360AssessmentDataForInvitie(OccupationID);
                TotalCount = temp.Rows.Count;
                if (TotalCount > 0)
                {
                    if (Status == "Submit")
                    {
                        Panel1.Visible = false;
                    }
                    else
                    {
                        Panel1.Visible = true;
                        Panel2.Visible = true;
                        AssessmentGrid.DataSource = temp;
                        AssessmentGrid.DataBind();
                    }
                }
                if (quescount == TotalCount)
                {
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = false;
                  
                }
                else
                {
                    btnSave.Enabled = true;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = true;
                    
                }
                if (TotalCount == SelectedParentRecord.Count)
                {
                    if (quescount == TotalCount)
                    {

                        btnSubmit.Enabled = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                       
                    }
                    else
                    {
                        btnSubmit.Enabled = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                       
                    }
                }
                else
                {
                    btnSubmit.Enabled = false;
                    btnSave.Enabled = true;
                    btnReset.Enabled = true;
                   
                }
            }
            catch { }
        }
        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }

        private void DeleteAllRecord()
        {
            if (SelectedParentRecord.Count > 0)
            {

                SelectedParentRecord.Clear();
                CRecordCount = 0;
            }

        }
        private void SelectRadioButton()
        {
            try
            {

                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < AssessmentGrid.MasterTableView.Items.Count; i++)
                    {
                        string eid = AssessmentGrid.MasterTableView.DataKeyValues[i]["ElementID"].ToString();



                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            RadioButtonList objrb1 = (RadioButtonList)AssessmentGrid.Items[i].FindControl("rb1_list");
                            objrb1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;

                        }
                        else
                        {




                        }
                    }
                }
                else
                {

                }
            }
            catch
            {
            }
        }
        protected void rb1_list_selectedindexchanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);

                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");
                eid = AssessmentGrid.MasterTableView.DataKeyValues[gr.ItemIndex]["ElementID"].ToString();

                if (objrb2.SelectedValue != "")
                {
                    if (CRecordCount < TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(eid);
                        }
                        CRecordCount++;
                        SaveRecord(eid, objrb2.SelectedValue);
                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCount--;
                        RemoveRecord(eid);
                    }
                }

                SelectRadioButton();
                BindAssessmentGrid(OccupationID);
            }
            catch { }
        }

        protected void AssessmentGrid_PageIndexChanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                BindAssessmentGrid(OccupationID);
            }
            catch { }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Assessment360SH objAssessment = new Assessment360SH();
            Assessment360FA objAssessmentFA = new Assessment360FA();
            SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
            SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
            try
            {
                
                    if (SelectedParentRecord.Count > 0)
                    {

                        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                        while (Enumerator.MoveNext())
                        {
                            objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                            objAssessment.ElementID = Enumerator.Key.ToString();
                            objAssessment.ScaleID = "LV";
                            objAssessment.DataValue = (Convert.ToInt32(Enumerator.Value));
                            objAssessment.IndustryID = IndustryID;
                            objAssessment.OccupationID = OccupationID;
                            objAssessment.InvitationStatus = "Save";
                            objAssessment.SubmitStatus = "Accepted";
                            objAssessment.DateofAcceptingInvitation = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            objAssessment.WhoIs = WhoIs;
                            objAssessment.AttemptID = AttemptID;
                            objAssessmentFA.Insert360Assessment(objAssessment, UserID);

                        }
                        objAssessmentFA.Insert360AssessmentInviteStatus(objAssessment, UserID);
                    }

                    LblMsg.Visible = true;
                    LblMsg.Text = "Your Answers saved successfully.";

                SelectRadioButton();
                //BindAssessmentGrid(JobOccupation);
            }
            catch
            {
            }

        }
        private void GetSavedData()
        {
            try
            {
                string questemplate = "360 Degree Assessment";
                Assessment360FA objassessmentFA = new Assessment360FA();
                Assessment360SH objAssessment = new Assessment360SH();
                objAssessment.WhoIs = WhoIs;
                objAssessment.AttemptID = AttemptID;
                DataTable Getdt = new DataTable();
                Getdt = objassessmentFA.Get360AssessmentSubmitQuestions(questemplate, objAssessment, UserID);
                quescount = Getdt.Rows.Count;
                if (Getdt.Rows.Count > 0)
                {
                    for (int i = 0; i < Getdt.Rows.Count; i++)
                    {
                        string ElementID = Getdt.Rows[i]["ElementID"].ToString();
                        string DataValue = Getdt.Rows[i]["Datavalue"].ToString();
                        CRecordCount++;
                        SaveRecord(ElementID, DataValue);

                    }
                }

            }
            catch
            { }

        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                Assessment360FA objAssessmentFA = new Assessment360FA();
                DataTable temp = new DataTable();

                Assessment360SH objAssessment = new Assessment360SH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                        objAssessment.ElementID = Enumerator.Key.ToString();
                        objAssessment.ScaleID = "LV";
                        objAssessment.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objAssessment.IndustryID = IndustryID;
                        objAssessment.OccupationID = OccupationID;
                        objAssessment.WhoIs = WhoIs;
                        objAssessment.InvitationStatus = "Pending";
                        objAssessment.SubmitStatus = "Accepted";
                        objAssessment.AttemptID = AttemptID;
                        objAssessment.DateofAcceptingInvitation = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        objAssessmentFA.Delete360AssessmentSubmitQuestions(objAssessment, UserID);
                    }
                }
                DeleteAllRecord();
                LblMsg.Visible = true;
                LblMsg.Text = "Your Answers Reset successfully.";
                BindAssessmentGrid(OccupationID);
             
            }
            catch
            {
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Assessment360SH objAssessment = new Assessment360SH();
            Assessment360FA objAssessmentFA = new Assessment360FA();
            SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
            SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
            try
            {
                if (TotalCount == SelectedParentRecord.Count)
                {

                    if (SelectedParentRecord.Count > 0)
                    {

                        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                        while (Enumerator.MoveNext())
                        {
                            objAssessment.QuestionnaireTemplate = "360 Degree Assessment";
                            objAssessment.ElementID = Enumerator.Key.ToString();
                            objAssessment.ScaleID = "LV";
                            objAssessment.DataValue = (Convert.ToInt32(Enumerator.Value));
                            objAssessment.IndustryID = IndustryID;
                            objAssessment.OccupationID = OccupationID;
                            objAssessment.DateofAcceptingInvitation = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            objAssessment.AttemptID = AttemptID;
                            objAssessment.InvitationStatus = "Submit";
                            objAssessment.SubmitStatus = "Accepted";
                            objAssessment.WhoIs = WhoIs;
                            objAssessmentFA.Insert360Assessment(objAssessment, UserID);

                        }
                        objAssessmentFA.Insert360AssessmentInviteStatus(objAssessment, UserID);
                    }
                    //string scriptstring = "radalert('You have submitted Your all questions.<br/>Now You can invite to others to Assess Yourself', 310, 150);";
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "radalert", scriptstring, true);
                    LblMsg.Visible = false;
                    Panel3.Visible = true;
                    Lblthanks.Text = "Thanks For your support to do the 360 Degree Assessment of Mr. &nbsp;" + Name;
                    Panel1.Visible = false;
                    Panel2.Visible = false;
                    SelectRadioButton();
                }
            }
            catch { }
        }

        public void GetUserAttemptIDfromsubmissonList()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable dtattempt = new DataTable();
                dtattempt = objskillFA.GetUserAttemptIDfromsubmissonList(UserID, "360 Degree Assessment");
                if (dtattempt.Rows.Count > 0)
                {
                    AttemptID = Convert.ToInt32(dtattempt.Rows[0]["AttemptID"].ToString());
                }
            }
            catch { }
        }

    }
}
