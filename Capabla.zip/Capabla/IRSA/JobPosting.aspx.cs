﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using Telerik.Web.UI;
using IRSA.Shared;
using IRSA.Facade;
using System.Data;
using IRSA.Common.Validation;
using IRSA.Common.GlobalFunction;
using IRSA.Exception;
using System.Globalization;
using System.Resources;
using System.Threading;
using System.Web.Security;

namespace IRSA
{
    public partial class JobPostingLogin : System.Web.UI.Page
    {
        public string UserName
        {
            set
            {
                ViewState["UserName"] = value;
            }
            get
            {
                if (ViewState["UserName"] == null)
                {
                    ViewState["UserName"] = string.Empty;
                }
                return ViewState["UserName"].ToString();
            }
        }

        public int ProductID
        {
            set
            {
                ViewState["ProductID"] = value;
            }
            get
            {
                if (ViewState["ProductID"] == null)
                {
                    ViewState["ProductID"] = int.MinValue.ToString();
                }
                return Convert.ToInt32(ViewState["ProductID"].ToString());
            }
        }
        int UserID;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            if (!IsPostBack)
            {
                //if (Request.Cookies["myCookie"] != null)
                //{
                //    HttpCookie cookie = Request.Cookies.Get("myCookie");
                //    String UserName = cookie.Values["username"];
                //    CheckBox rm = (CheckBox)ChkBox.FindControl("RememberMe");

                //}
                
                //Session.Abandon();
                //Session.Clear();
                //Session.RemoveAll();
                //LoginLanguageInfo();
            }
            if (UserID != int.MinValue)
            {
                Panelbuy.Visible = true;
                PanelLogon.Visible = false;

                Panel1.Visible = false;
                Lblmember.Text = SessionInfo.Username + " " + "!";
                
            }
            else
            {
                PanelLogon.Visible = true;
                Panel1.Visible = true;
                Panelbuy.Visible = false;
                Lblmember.Text = "Guest" + " " + "!";

            }
            lblMesg.Visible = false;
            lblError.Visible = false;
        }

        protected void imgbtnEnter_Click(object sender, ImageClickEventArgs e)
        {
            string email;
            
            LoginSH objsh = new LoginSH();
            email = txtbUserName.Text;
            if (Validation.IsValidEmailAddress(email))
            {
                objsh.UserID = email;
                UserName = email;
                objsh.Password = txtbPassword.Text;

            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "Enter vaild E-mail Address!";
            }
            if (txtbUserName.Text == null || txtbPassword.Text==null)
            {
                lblError.Visible = true;
                lblError.Text = "Enter vaild E-mail address or Password!";

            }
            objsh.EmailID = txtbUserName.Text;
            LoginFA objFA = new LoginFA();
            Encryption.HashPwd(txtbPassword.Text);
            string password = Encryption.HashPwd(txtbPassword.Text);
            objsh.Password = password;
            if (Encryption.verifyPwd(txtbPassword.Text, objsh.Password) && objsh.EmailID == txtbUserName.Text)
            {
                objFA.GetValidateRec(objsh);

                int y = Convert.ToInt32(SessionInfo.UserId);

                if (y > 0)
               // if(objFA.GetValidateRec(objsh)==true)
                {
                    string Who = SessionInfo.RoleID;
                    //MembershipUser search = Membership.GetUser(this.TxtLoginname.Text);
                    //if (search == null)
                    //{
                    //    MembershipCreateStatus status;
                    //    search = Membership.CreateUser(this.TxtLoginname.Text, Textpassword.Text, this.TxtLoginname.Text, "What does 1+1 equal?", "2", true, out status);
                    //}
                    //FormsAuthentication.RedirectFromLoginPage(search.UserName, false);
                    if (Who == "RC" || Who == "OR")
                    {
                        Response.Redirect("PostJobCompanyInformation.aspx");
                    }
                    else
                    {
                        lblError.Visible = true;
                        lblError.Text = "You are not a Recruite/Organisation!";
                    }

                }
                else
                {
                    lblMesg.Visible = true;
                    lblMesg.Text = "*Invalid user";
                    lblError.Visible = true;
                    lblError.Text = "Enter vaild E-mail address or Password!";
                }
            }



        }
        private void InsertUserPurchageRecord()
        {
            if (this.UserName != string.Empty && SessionInfo.UserId != int.MinValue)
            {
                int productid = 102;
                DigitalAdvisorFA objbuydet = new DigitalAdvisorFA();
                objbuydet.InserUserPurchageIntery(this.UserName, productid, SessionInfo.UserId);

            }
        }
        protected void lnkbtnForgotPwd_Click(object sender, EventArgs e)
        {
            RadWindow rd = new RadWindow();
            rd.ID = "RadWindowhelp";
            rd.NavigateUrl = "~/ForgotPassword1.aspx";
            rd.VisibleOnPageLoad = true;
            rd.Width = 330;
            rd.Height = 250;
            rd.Left = 400;
            rd.Top = 320;
            RadWindowManager1.Windows.Add(rd);
        }

        protected void imgbtnRegister_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }

        

        
    }

}
        