﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Threading;
using System.Globalization;
using Telerik.Web.UI;
using System.IO;
using IRSA.Facade;
using IRSA.Shared;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class EmailSendingInterface : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetComboBoxData();
        }
        public DataTable GetComboBoxData()
        {
            EmailSendingInterfaceFA fa = new EmailSendingInterfaceFA();
            fa.GetComboBoxData();
            DataTable dt = new DataTable();
            dt = fa.GetComboBoxData();
            RadComboBoxUSerEmailID.DataSource = dt;
            RadComboBoxUSerEmailID.DataBind();
            return dt;
        }
        public void InsertData()
        {
           
             
           EmailSendingInterfaceSH obj = new EmailSendingInterfaceSH();
        
           obj.RecieverName =RadComboBoxUSerEmailID.Text;
           obj.Subject =txtsubject.Text;
           obj.Description = RadEditor1.Text;
           obj.Status = "Pending";
           EmailSendingInterfaceFA fa = new EmailSendingInterfaceFA();
           fa.InsertData(obj);

        
        }

     

        protected void Cancel_Click(object sender, EventArgs e)
        {
            if  (txtsubject.Text=="")
            {
                //lblcombomsg.Visible = true;
                lblsubjectmsg.Visible = true;
            }
            else
            {
                //lblcombomsg.Visible = false;
                lblsubjectmsg.Visible = false;
                InsertData();
                lblsavemsg.Visible = true;
            }           
        }

        protected void Ok_Click(object sender, EventArgs e)
        {

        }
    }
}
