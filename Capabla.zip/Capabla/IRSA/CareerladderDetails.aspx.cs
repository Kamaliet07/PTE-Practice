﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using System.Data;
using IRSA.Common.GlobalFunction;
namespace IRSA
{
    public partial class CareerladderDetails : System.Web.UI.Page
    {
        int UserID;
        string tabName;
        string CLDetailID="5" ; 
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = SessionInfo.UserId;
            tabName = Request.QueryString.Get("id").ToString();
            ViewDetails(tabName);
            if (UserID != int.MinValue)
            {
                AccountsetupFA objaccFA = new AccountsetupFA();
                DataTable objdt = new DataTable();
                objdt = objaccFA.GetaccountData(UserID);
                Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                SessionInfo.FirstName = objdt.Rows[0]["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }    


        }

        protected void radgridCLTasks_PageIndexChanged(object source, Telerik.Web.UI.GridPageChangedEventArgs e)
        {
            radgridCLTasks.CurrentPageIndex = e.NewPageIndex;
            ViewDetails(tabName);
        }

        public void ViewDetails(string tabName)
        {
            string Onsetcode = null;


            if (tabName == "IT Manager")
            {
                Onsetcode = "11-3021.00";
            }
            if (tabName == "IT Consultant")
            {
                Onsetcode = "15-1051.00";
            }
            if (tabName == "Network and Computer Systems Administrator")
            {
                Onsetcode = "15-1071.00";
            }
            if (tabName == "Computer Security Specialist")
            {
                Onsetcode = "115-1071.01";
            }
            if (tabName == "Database Administrator")
            {
                Onsetcode = "15-1061.00";
            }
            if (tabName == "Network Systems and Data Communications Analyst")
            {
                Onsetcode = "15-1081.00";
            }
            if (tabName == "Computer Programmer")
            {
                Onsetcode = "15-1021.00";
            }
            if (tabName == "Computer Support Specialist")
            {
                Onsetcode = "15-1041.00";
            }

            bindGridViewDetail(Onsetcode);
            
        }

        public void bindGridViewDetail(string Onsetcode)
        {
            CarrerLadderFA objLadderFA = new CarrerLadderFA();
            DataTable dtgridDetailTask = new DataTable();
            DataTable dtgridDetailKnowlwdge = new DataTable();
            DataTable dtgridDetailAbility = new DataTable();
            DataTable dtgridDetailSkills = new DataTable();
            DataTable dtgridDetailWorkActivities = new DataTable();

            dtgridDetailTask = objLadderFA.GetDetailCLTask(Onsetcode);
            dtgridDetailKnowlwdge = objLadderFA.GetDetailCLKnowlwdge(Onsetcode);
            dtgridDetailAbility = objLadderFA.GetDetailCLAbility(Onsetcode);
            dtgridDetailSkills = objLadderFA.GetDetailCLSkills(Onsetcode);
            dtgridDetailWorkActivities = objLadderFA.GetDetailCLWorkActivities(Onsetcode);

            radgridCLTasks.DataSource = dtgridDetailTask;
            radgridCLTasks.DataBind();
            radgridKnowledge.DataSource = dtgridDetailKnowlwdge;
            radgridKnowledge.DataBind();
            radgridSkills.DataSource = dtgridDetailSkills;
            radgridSkills.DataBind();
            radgridAbilities.DataSource = dtgridDetailAbility;
            radgridAbilities.DataBind();
            radgridWorkActivities.DataSource = dtgridDetailWorkActivities;
            radgridWorkActivities.DataBind();
        }


        protected void LnkBtnBackToCLInfo_Click(object sender, EventArgs e)
        {
              
            Response.Redirect("CareerLadderITInfo.aspx?id="+CLDetailID);
        }

       

        //protected void lnkbtnBack_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("CareerLadderITInfo.aspx");
        //}
    }
}
