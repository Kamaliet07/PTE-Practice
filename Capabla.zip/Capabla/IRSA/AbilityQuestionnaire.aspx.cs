﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IRSA.Facade;
using Telerik.Web.UI;
using System.Collections;
using IRSA.Shared;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Resources;
using IRSA.BussinessLogic;
using System.Configuration;
using IRSA.Common.GlobalFunction;

namespace IRSA
{
    public partial class AbilityQuestionnaire : System.Web.UI.Page
    {
        string Reportpath;
        string directorypath;
        public string cultureid = "EN";
        int UserID;
        public string Cultinfo;
        int quescount;
        string EID;
        string questemplate;
        string quesName;
        public int CRecordCount
        {
            set
            {
                ViewState["CRecordCount"] = value;
            }
            get
            {
                if (ViewState["CRecordCount"] == null)
                {
                    ViewState["CRecordCount"] = 0;
                }
                return Convert.ToInt32(ViewState["CRecordCount"].ToString());
            }
        }


        public int TotalCount
        {
            set
            {
                ViewState["TotalCount"] = value;
            }
            get
            {
                if (ViewState["TotalCount"] == null)
                {
                    ViewState["TotalCount"] = 0;
                }
                return Convert.ToInt32(ViewState["TotalCount"].ToString());
            }
        }
        public int coquestioncount
        {
            set
            {
                ViewState["coquestioncount"] = value;
            }
            get
            {
                if (ViewState["coquestioncount"] == null)
                {
                    ViewState["coquestioncount"] = 0;
                }
                return Convert.ToInt32(ViewState["coquestioncount"].ToString());
            }
        }
        public Hashtable SelectedParentRecord
        {
            set
            {
                ViewState["SelectedParentRecord"] = value;
            }
            get
            {
                if (ViewState["SelectedParentRecord"] == null)
                {
                    SelectedParentRecord = new Hashtable();
                }
                return (Hashtable)ViewState["SelectedParentRecord"];
            }
        }
        public int AttemptID
        {
            set
            {
                ViewState["AttemptID"] = value;
            }
            get
            {
                if (ViewState["AttemptID"] == null)
                {
                    ViewState["AttemptID"] = 0;
                }
                return Convert.ToInt32(ViewState["AttemptID"].ToString());
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                IRSA.Common.GlobalFunction.SessionInfo.CultureID = "EN";
                //UserID = 3;
                UserID = SessionInfo.UserId;

                if (UserID != int.MinValue)
                {
                    AccountsetupFA objaccFA = new AccountsetupFA();
                    DataTable objdt = new DataTable();
                    objdt = objaccFA.GetaccountData(UserID);
                    Lblmember.Text = objdt.Rows[0]["FirstName"].ToString() + " " + "!";
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }

               
                quesName = Request.QueryString.Get("id").ToString();
               
                questemplate = quesName + " " + Lblques.Text;
                if (questemplate == "Ability Questionnaire")
                {
                    Lbl.Text = "Ability Assessment";
                    btnability.BackColor = System.Drawing.Color.OrangeRed;
                    btnSkill.BackColor = System.Drawing.Color.Maroon;
                    btnKnowledge.BackColor = System.Drawing.Color.Maroon;
                   
                    EID = "1.A.[1-9].[a-z].[1-9]";
                }
                
              
                LblquestionnaireName.Text = quesName;
                Lblqu.Text = quesName;
                LblMsg.Visible = false;
                GetUserAttemptIDfromsubmissonList();
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable Getdt = new DataTable();
                Getdt = objskillFA.GetSubmitStatus(questemplate,AttemptID);
                quescount = Getdt.Rows.Count;
            }
            catch { }
        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    Grid_Questionnairebind();
                    

                }


                SelectQuestionnaireRadioList();
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable Getdt = new DataTable();
                Getdt = objskillFA.GetSubmitStatus(questemplate,AttemptID);
                quescount = Getdt.Rows.Count;
                if (quescount == TotalCount)
                {
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = false;
                   
                    BtnworkcontexReport.Enabled = true;
                }
                else
                {
                    btnSave.Enabled = true;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = true;
                 
                    BtnworkcontexReport.Enabled = false;
                }
                if (TotalCount == SelectedParentRecord.Count)
                {
                    if (quescount == TotalCount)
                    {

                        btnSubmit.Enabled = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                       
                        BtnworkcontexReport.Enabled = true;
                    }
                    else
                    {
                        btnSubmit.Enabled = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                      
                        BtnworkcontexReport.Enabled = false;
                    }
                }
                else
                {
                    btnSubmit.Enabled = false;
                    btnSave.Enabled = true;
                    btnReset.Enabled = true;
                   
                    BtnworkcontexReport.Enabled = false;
                }


            }
            catch
            {
            }
        }
        public void Grid_Questionnairebind()
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    GetSavedData();
                }

                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable temp = new DataTable();

                temp = objskillFA.GetSkillQuestionnaireData(EID);
                TotalCount = temp.Rows.Count;
                Grid_Questionnaire.DataSource = temp;
                Grid_Questionnaire.DataBind();
                if (quescount == TotalCount)
                {
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = false;
                  
                    BtnworkcontexReport.Enabled = true;
                }
                else
                {
                    btnSave.Enabled = true;
                    btnSubmit.Enabled = false;
                    btnReset.Enabled = true;
                   
                    BtnworkcontexReport.Enabled = false;
                }
                if (TotalCount == SelectedParentRecord.Count)
                {
                    if (quescount == TotalCount)
                    {

                        btnSubmit.Enabled = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                      
                        BtnworkcontexReport.Enabled = true;
                    }
                    else
                    {
                        btnSubmit.Enabled = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                      
                        BtnworkcontexReport.Enabled = false;
                    }
                }
                else
                {
                    btnSubmit.Enabled = false;
                    btnSave.Enabled = true;
                    btnReset.Enabled = true;
                   
                    BtnworkcontexReport.Enabled = false;
                }
            }
            catch { }
        }




        protected void rb1_list_selectedindexchanged(object sender, EventArgs e)
        {
            try
            {
                string eid;
                GridDataItem gr = (GridDataItem)(((Control)sender).NamingContainer);

                RadioButtonList rb1 = (RadioButtonList)sender;

                RadioButtonList objrb2 = (RadioButtonList)rb1.NamingContainer.FindControl("rb1_list");
                eid = Grid_Questionnaire.MasterTableView.DataKeyValues[gr.ItemIndex]["ElementID"].ToString();
                
                if (objrb2.SelectedValue != "")
                {
                    if (CRecordCount < TotalCount)
                    {
                        if (SelectedParentRecord.ContainsKey(eid) == true)
                        {
                            CRecordCount--;
                            RemoveRecord(eid);
                        }
                        CRecordCount++;
                        SaveRecord(eid, objrb2.SelectedValue);
                    }
                }
                else
                {
                    if (CRecordCount > 0)
                    {
                        CRecordCount--;
                        RemoveRecord(eid);
                    }
                }

                SelectQuestionnaireRadioList();
                Grid_Questionnairebind();
            }
            catch { }
        }

        protected void Grid_Questionnaire_pageindexchanged(object source, GridPageChangedEventArgs e)
        {
            try
            {
                Grid_Questionnaire.CurrentPageIndex = e.NewPageIndex;
                int i = e.NewPageIndex + 1;
                int j = i - 1;


                Grid_Questionnairebind();
                SelectQuestionnaireRadioList();
            }
            catch
            { }
        }

        private void SaveRecord(string id, string value)
        {
            if (!SelectedParentRecord.ContainsKey(id))
            {
                SelectedParentRecord.Add(id, value);
            }

        }

        private void RemoveRecord(string id)
        {
            if (SelectedParentRecord.Count > 0)
            {
                if (SelectedParentRecord.ContainsKey(id))
                {
                    SelectedParentRecord.Remove(id);
                }
            }

        }

        private void DeleteAllRecord()
        {
            if (SelectedParentRecord.Count > 0)
            {

                SelectedParentRecord.Clear();
                CRecordCount = 0;
            }

        }
        private void SelectQuestionnaireRadioList()
        {
            try
            {
                if (SelectedParentRecord.Count > 0)
                {
                    for (int i = 0; i < Grid_Questionnaire.MasterTableView.Items.Count; i++)
                    {
                        string eid = Grid_Questionnaire.MasterTableView.DataKeyValues[i]["ElementID"].ToString();
                        Label lblErrorMsg = (Label)Grid_Questionnaire.Items[i].FindControl("lblErrorMsg");

                        if (SelectedParentRecord.ContainsKey(eid))
                        {
                            RadioButtonList obj1 = (RadioButtonList)Grid_Questionnaire.Items[i].FindControl("rb1_list");
                            obj1.Items.FindByValue(SelectedParentRecord[eid].ToString()).Selected = true;
                            //lblErrorMsg.Visible = false;
                        }
                        else
                        {

                            //lblErrorMsg.Visible = true;
                            //lblErrorMsg.Text ="Please select it."; 


                        }
                    }
                }
                else
                {

                }
            }
            catch { }
        }





        protected void btnSubmit_click(object sender, EventArgs e)
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                //DataTable temp = new DataTable();
                //temp = objskillFA.GetSkillQuestionnaireData(EID);
                string scaleid = "LV";//temp.Rows[0]["ScaleID"].ToString();
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                if (TotalCount == SelectedParentRecord.Count)
                {

                    if (SelectedParentRecord.Count > 0)
                    {

                        IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                        while (Enumerator.MoveNext())
                        {
                            objskill.QuestionnaireTemplate = questemplate;
                            objskill.ElementID = Enumerator.Key.ToString();
                            objskill.ScaleID = scaleid;
                            objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                            objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                            objskill.Status = "Submit";
                            objskill.AttemptID = AttemptID;
                            objskillFA.InsertskillQues(objskill);

                        }
                        objskillFA.InsertQuesSubmissionList(objskill);
                    }


                  
                    
                    LblMsg.Visible = true;
                    LblMsg.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(1);// "Answer Submitted Successfylly";
                    btnReset.Enabled = false;
                    btnSave.Enabled = false;
                    btnSubmit.Enabled = false;
                  
                    BtnworkcontexReport.Enabled = true;
                }
                

                SelectQuestionnaireRadioList();
                Grid_Questionnairebind();
            }
            catch { }
        }

        private void GetSavedData()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable Getdt = new DataTable();
                Getdt = objskillFA.GetSubmitStatus(questemplate,AttemptID);
                quescount = Getdt.Rows.Count;
                if (Getdt.Rows.Count > 0)
                {
                    for (int i = 0; i < Getdt.Rows.Count; i++)
                    {
                        string ElementID = Getdt.Rows[i]["ElementID"].ToString();
                        string DataValue = Getdt.Rows[i]["DataValue"].ToString();
                        CRecordCount++;
                        SaveRecord(ElementID, DataValue);

                    }
                }

            }
            catch
            { }

        }

       
        protected void btnReset_click(object sender, EventArgs e)
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                //DataTable temp = new DataTable();
                //temp = objskillFA.GetSkillQuestionnaireData(EID);
                string scaleid = "LV";//temp.Rows[0]["ScaleID"].ToString();
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        objskill.QuestionnaireTemplate = questemplate;
                        objskill.ElementID = Enumerator.Key.ToString();
                        objskill.ScaleID = scaleid;
                        objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        objskill.AttemptID = AttemptID;
                        objskillFA.DeleteskillQues(objskill);
                    }
                }

            
                DeleteAllRecord();
                LblMsg.Visible = true;
                LblMsg.Text = "Your Answers are Reset Successfully.";
                Grid_Questionnairebind();
                BtnworkcontexReport.Enabled = false;
              
            }
            catch { }
        }


       

        protected void btnSave_click(object sender, EventArgs e)
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                //DataTable temp = new DataTable();
                //temp = objskillFA.GetSkillQuestionnaireData(EID);
                string scaleid = "LV";//temp.Rows[0]["ScaleID"].ToString();
                SkillQuestionnaireSH objskill = new SkillQuestionnaireSH();
                if (SelectedParentRecord.Count > 0)
                {

                    IDictionaryEnumerator Enumerator = SelectedParentRecord.GetEnumerator();
                    while (Enumerator.MoveNext())
                    {
                        objskill.QuestionnaireTemplate = questemplate;
                        objskill.ElementID = Enumerator.Key.ToString();
                        objskill.ScaleID = scaleid;
                        objskill.DataValue = (Convert.ToInt32(Enumerator.Value));
                        objskill.DateofSubmit = System.DateTime.Now.ToString("dd/MMM/yyyy");
                        objskill.Status = "Save";
                        objskill.AttemptID = AttemptID;
                        objskillFA.InsertskillQues(objskill);

                    }
                    objskillFA.InsertQuesSubmissionList(objskill);
                }
                LblMsg.Visible = true;
                LblMsg.Text = IRSA.Common.GlobalFunction.ErrorMessage.GetiRsaErrorMessage(2);// "Answers Saved Successfylly";
                SelectQuestionnaireRadioList();
                Grid_Questionnairebind();
            }
            catch { }
        }
       
       
        public void GetUserAttemptIDfromsubmissonList()
        {
            try
            {
                SkillQuestionnaireFA objskillFA = new SkillQuestionnaireFA();
                DataTable dtattempt = new DataTable();
                dtattempt = objskillFA.GetUserAttemptIDfromsubmissonList(UserID, questemplate);
                if (dtattempt.Rows.Count > 0)
                {
                    AttemptID = Convert.ToInt32(dtattempt.Rows[0]["AttemptID"].ToString());
                }
            }
            catch { }
        }
    }
}
