﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using IRSA.DALInterface;


namespace IRSA.DataAccess
{
    public class OledbDataAccess :DataAccessInterface, IDisposable 
    {
        private string _connectionString;
            private bool _isDisposed = false;

       public string ConnectionString
       {
           get
           {
               return _connectionString;
           }
           set
           {
               _connectionString = value;
           }
       }

           
       public OledbDataAccess()
       {
              
       }
            
            #region IDisposable Members

            public void Dispose()
            {
                /*************************************************************************************
                 Pass true in dispose method to clean managed resources too and say GC to skip finalize 
                 in next line.
                **************************************************************************************/
                Dispose(true);
                /*************************************************************************************
                If dispose is called already then say GC to skip finalize on this instance.
                *************************************************************************************/
                GC.SuppressFinalize(this);
            }
            protected virtual void Dispose(bool disposedStatus)
            {
                if (!_isDisposed)
                {
                    _isDisposed = true;
                    /* Released unmanaged Resources */
                    if (disposedStatus)
                    {
                        /* Released managed Resources */
                    }
                }
            }


            #endregion


            #region OledbDataAccess Members
            /**************************************************************************************************
            METHOD NAME : GetConnection
            PARAMETERS  : None
            RETURN TYPE : Returns Object of OleDbConnection Class
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
            **************************************************************************************************/
            public IDbConnection GetConnection()
            {
                OleDbConnection iConnection = new OleDbConnection(); 
                iConnection.ConnectionString = ConnectionString;
                return iConnection;
            }

           /**************************************************************************************************
                METHOD NAME : CloseConnection
                PARAMETERS  : None
                RETURN TYPE : Closes The Open Connection and Returns True
                CREATE DATE : 23-APRIL-2009
                MODIFY DATE :   
           **************************************************************************************************/
          public bool CloseConnection(ref IDbConnection connection)
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
                return true;
            }

          /**************************************************************************************************
          METHOD NAME : ExecuteNonQuery
          PARAMETERS  : CommandText,CommandType,IDataParameter Array and ref ErrorMessage
          RETURN TYPE : Returns No.Of Rows Affected
          CREATE DATE : 23-APRIL-2009
          MODIFY DATE :
          **************************************************************************************************/
          public int ExecuteNonQuery(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                OleDbConnection iConnection;
                OleDbCommand iCommand;
                int iReturnialue = 0;
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                iCommand = new OleDbCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = iConnection;
                    iCommand.CommandType = type;
                    iCommand.Parameters.AddRange(parameter);
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iReturnialue = iCommand.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iConnection.Close();
                    iConnection.Dispose();
                    iCommand.Dispose();
                }

                return iReturnialue;
            }

          /**************************************************************************************************
          METHOD NAME : ExecuteNonQuery
          PARAMETERS  : CommandText,CommandType and ref ErrorMessage
          RETURN TYPE : Returns No.Of Rows Affected
          CREATE DATE : 23-APRIL-2009
          MODIFY DATE : 
          **************************************************************************************************/
           public int ExecuteNonQuery(string commandText, CommandType type, ref string errorMessage)
            {
                OleDbConnection iConnection;
                OleDbCommand  iCommand;
                int iReturnialue = 0;
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                iCommand = new OleDbCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iCommand.CommandType = type;
                    iReturnialue = iCommand.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iConnection.Close();
                    iConnection.Dispose();
                    iCommand.Dispose();
                }
                return iReturnialue;
            }

           /**************************************************************************************************
           METHOD NAME : ExecuteNonQuery
           PARAMETERS  : IDbCommand and ref ErrorMessage
           RETURN TYPE : Returns No.Of Rows Affected
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE :
           **************************************************************************************************/

           public int ExecuteNonQuery(IDbCommand command, ref string errorMessage)
            {
                OleDbConnection iConnection;
                int iReturnialue = 0;
                iConnection = new OleDbConnection(); 
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    command.Connection = iConnection;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iReturnialue = command.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iConnection.Close();
                    iConnection.Dispose();
                    command.Dispose();
                }

                return iReturnialue;
            }

           /**************************************************************************************************
           METHOD NAME : ExecuteReader
           PARAMETERS  : CommandText,CommandType,IDataParameter Array, ref ErrorMessage and ref Connection Object
           RETURN TYPE : Returns Data Reader RecordSet
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE : 
           **************************************************************************************************/

           public IDataReader ExecuteReader(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage, ref IDbConnection connection)
            {
                OleDbDataReader iObjDataReader;
                OleDbCommand iCommand;
                iCommand = new OleDbCommand(); 
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = (OleDbConnection)connection;
                    iCommand.Connection.ConnectionString = ConnectionString;
                    iCommand.CommandType = type;
                    iCommand.Parameters.AddRange(parameter);
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    iObjDataReader = (OleDbDataReader)iCommand.ExecuteReader();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iCommand.Dispose();
                }

                return iObjDataReader;
            }

           /**************************************************************************************************
           METHOD NAME : ExecuteReader
           PARAMETERS  : CommandText,CommandType,ref ErrorMessage and ref Connection Object
           RETURN TYPE : Returns Data Reader RecordSet
           CREATE DATE : 23-APRIL-2009
           MODIFY DATE : 
           **************************************************************************************************/
           
           public IDataReader ExecuteReader(string commandText, CommandType type, ref string errorMessage, ref IDbConnection connection)
            {
               OleDbDataReader iObjDataReader;
                OleDbCommand iCommand;
                iCommand = new OleDbCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = (OleDbConnection)connection;
                    iCommand.Connection.ConnectionString = ConnectionString;
                    iCommand.CommandType = type;
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    iObjDataReader = iCommand.ExecuteReader();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iCommand.Dispose();
                }

                return iObjDataReader;
            }

           /**************************************************************************************************
              METHOD NAME : ExecuteReader
              PARAMETERS  : IDbCommand,ref ErrorMessage and ref Connection Object
              RETURN TYPE : Returns Data Reader RecordSet
              CREATE DATE : 23-APRIL-2009
              MODIFY DATE :
           **************************************************************************************************/
           public IDataReader ExecuteReader(IDbCommand command, ref string errorMessage, ref IDbConnection connection)
            {
               OleDbDataReader iObjDataReader;
                try
                {
                    command.Connection = connection;
                    command.Connection.ConnectionString = ConnectionString;
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    iObjDataReader = (OleDbDataReader)command.ExecuteReader();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    command.Dispose();
                }

                return iObjDataReader;
            }

           /**************************************************************************************************
            METHOD NAME : ExecuteScalar
            PARAMETERS  : CommandText,CommandType,IDataParameter Array and ref ErrorMessage
            RETURN TYPE : Returns ialue of First Column of the First Row
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
           **************************************************************************************************/

           public object ExecuteScalar(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                Object iScalarReturnialue;
                OleDbConnection iConnection;
                OleDbCommand iCommand;
                iCommand = new OleDbCommand();
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = iConnection;
                    iCommand.CommandType = type;
                    iCommand.Parameters.AddRange(parameter);
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iScalarReturnialue = iCommand.ExecuteScalar();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    
                    iConnection.Close();
                    iCommand.Dispose();
                    iConnection.Dispose();
                   
                }

                return iScalarReturnialue;
            }

           /**************************************************************************************************
            METHOD NAME : ExecuteScalar
            PARAMETERS  : CommandText,CommandType and ref ErrorMessage
            RETURN TYPE : Returns ialue of First Column of the First Row
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :
            **************************************************************************************************/


           public object ExecuteScalar(string commandText, CommandType type, ref string errorMessage)
            {
                Object iScalarReturnialue;
                OleDbConnection iConnection;
                OleDbCommand iCommand;
                iCommand = new OleDbCommand();
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = iConnection;
                    iCommand.CommandType = type;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iScalarReturnialue = iCommand.ExecuteScalar();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                   
                    iConnection.Close();
                    iCommand.Dispose();
                    iConnection.Dispose();
                   
                }

                return iScalarReturnialue;
            }

           /**************************************************************************************************
               METHOD NAME : ExecuteScalar
               PARAMETERS  : IDbCommand and ref ErrorMessage
               RETURN TYPE : Returns ialue of First Column of the First Row
               CREATE DATE : 23-APRIL-2009
               MODIFY DATE : 
           **************************************************************************************************/

           public object ExecuteScalar(IDbCommand command, ref string errorMessage)
            {
                Object iScalarReturnialue;
                OleDbConnection iConnection;
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    command.Connection = iConnection;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iScalarReturnialue = command.ExecuteScalar();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    
                    iConnection.Close();
                    command.Dispose();
                    iConnection.Dispose();
                   
                }

                return iScalarReturnialue;
            }

           /**************************************************************************************************
               METHOD NAME : GetDataSet
               PARAMETERS  : CommandText,CommandType,IDataParameter Array and ref ErrorMessage
               RETURN TYPE : Returns DataSet Object
               CREATE DATE : 23-APRIL-2009
               MODIFY DATE : 
           **************************************************************************************************/
           public DataSet GetDataSet(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                DataSet iObjDataSet;
                OleDbConnection iConnection;
                OleDbDataAdapter iDataAdapter;
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                iDataAdapter = new OleDbDataAdapter(new OleDbCommand());
                try
                {
                    iDataAdapter.SelectCommand.Connection = iConnection;
                    iDataAdapter.SelectCommand.CommandType = type;
                    iDataAdapter.SelectCommand.CommandText = commandText;
                    iDataAdapter.SelectCommand.Parameters.AddRange(parameter);
                    iObjDataSet = new DataSet();
                    iDataAdapter.Fill(iObjDataSet);
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                   
                    iDataAdapter.Dispose();
                    iConnection.Dispose();
                    
                }

                return iObjDataSet;
            }

           /**************************************************************************************************
              METHOD NAME : GetDataSet
              PARAMETERS  : CommandText,CommandType and ref ErrorMessage
              RETURN TYPE : Returns DataSet Object
              CREATE DATE : 23-APRIL-2009
              MODIFY DATE : 
          **************************************************************************************************/

           public DataSet GetDataSet(string commandText, CommandType type, ref string errorMessage)
            {
                DataSet iObjDataSet;
                OleDbConnection iConnection;
                OleDbDataAdapter iDataAdapter;
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                iDataAdapter = new OleDbDataAdapter(new OleDbCommand());
                try
                {
                    iDataAdapter.SelectCommand.Connection = iConnection;
                    iDataAdapter.SelectCommand.CommandType = type;
                    iDataAdapter.SelectCommand.CommandText = commandText;
                    iObjDataSet = new DataSet();
                    iDataAdapter.Fill(iObjDataSet);
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    
                    iDataAdapter.Dispose();
                    iConnection.Dispose();
                    
                }

                return iObjDataSet;
            }

           /**************************************************************************************************
              METHOD NAME : GetDataSet
              PARAMETERS  : IDbCommand and ref ErrorMessage
              RETURN TYPE : Returns DataSet Object
              CREATE DATE : 23-APRIL-2009
              MODIFY DATE : 
           **************************************************************************************************/

           public DataSet GetDataSet(IDbCommand command, ref string errorMessage)
            {
                DataSet iObjDataSet;
                OleDbConnection iConnection;
                OleDbDataAdapter iDataAdapter;
                iConnection = new OleDbConnection();
                iConnection.ConnectionString = ConnectionString;
                iDataAdapter = new OleDbDataAdapter((OleDbCommand)command);
                try
                {
                    iDataAdapter.SelectCommand.Connection = iConnection;
                    iObjDataSet = new DataSet();
                    iDataAdapter.Fill(iObjDataSet);
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iDataAdapter.Dispose();
                    iConnection.Dispose();
                }

                return iObjDataSet;
            }

           /**************************************************************************************************
               METHOD NAME : GetDataSet
               PARAMETERS  : XmlFilePath and ref ErrorMessage
               RETURN TYPE : Read XML File and Returns Corresponding DataSet Object
               CREATE DATE : 23-APRIL-2009
               MODIFY DATE : 
              
           **************************************************************************************************/

           public DataSet GetDataSet(string xmlFilePath, ref string errorMessage)
            {
                DataSet iObjDataSet;
                iObjDataSet = new DataSet();
                try
                {
                    iObjDataSet.ReadXml(xmlFilePath);
                }
                catch (System.Security.SecurityException Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                catch (System.Security.XmlSyntaxException Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                catch (System.Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                return iObjDataSet;
            }

           /**************************************************************************************************
               METHOD NAME : GetDataTable
               PARAMETERS  : CommandText,CommandType,IDataParameter Array and ref ErrorMessage
               RETURN TYPE : Returns First DataTable from a DataSet
               CREATE DATE : 23-APRIL-2009
               MODIFY DATE : 
          **************************************************************************************************/

           public DataTable GetDataTable(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                DataSet iObjDataSet = new DataSet();
                iObjDataSet = GetDataSet(commandText, type, parameter, ref errorMessage);
                return iObjDataSet.Tables[0];
            }

           /**************************************************************************************************
              METHOD NAME : GetDataTable
              PARAMETERS  : CommandText,CommandType and ref ErrorMessage
              RETURN TYPE : Returns First DataTable from a DataSet
              CREATE DATE : 23-APRIL-2009
              MODIFY DATE : 
           **************************************************************************************************/

           public DataTable GetDataTable(string commandText, CommandType type, ref string errorMessage)
            {
                DataSet iObjDataSet = new DataSet();
                iObjDataSet = GetDataSet(commandText, type, ref errorMessage);
                return iObjDataSet.Tables[0];
            }

           /**************************************************************************************************
              METHOD NAME : GetDataTable
              PARAMETERS  : IDbCommand and ref ErrorMessage
              RETURN TYPE : Returns First DataTable from a DataSet
              CREATE DATE : 23-APRIL-2009
              MODIFY DATE :  
              **************************************************************************************************/
           public DataTable GetDataTable(IDbCommand command, ref string errorMessage)
            {
                DataSet iObjDataSet = new DataSet();
                iObjDataSet = GetDataSet(command, ref errorMessage);
                return iObjDataSet.Tables[0];
            }

           

            #endregion


    }
}
