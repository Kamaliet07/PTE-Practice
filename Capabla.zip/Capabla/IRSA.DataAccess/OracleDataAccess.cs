﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;
using IRSA.DALInterface;


namespace IRSA.DataAccess
{
    public class OracleDataAccess : DataAccessInterface, IDisposable 
    {
            private string _connectionString;
            private bool _isDisposed = false;

            public string ConnectionString
            {
                get
                {
                    return _connectionString;
                }
                set
                {
                    _connectionString = value;
                }
            }


            public OracleDataAccess()
            {
            }

            #region OracleDataAccess Members

           /**************************************************************************************************
            METHOD NAME : ExecuteNonQuery
            PARAMETERS  : CommandText,CommandType,OracleParameter Array and ref ErrorMessage
            RETURN TYPE : Returns No.Of Rows Affected
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :
            **************************************************************************************************/

            public int ExecuteNonQuery(string commandText, CommandType type, OracleParameter[] OracleParam, ref string errorMessage)
            {
                OracleConnection iConnection;
                OracleCommand iCommand;
                int iReturnialue = 0;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                iCommand = new OracleCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = iConnection;
                    iCommand.CommandType = type;
                    iCommand.Parameters.AddRange(OracleParam);
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iReturnialue = iCommand.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iConnection.Close();
                   
                    iConnection.Dispose();
                    iCommand.Dispose();
                   
                }

                return iReturnialue;
            }

            /**************************************************************************************************
            METHOD NAME : ExecuteNonQuery
            PARAMETERS  : CommandText,CommandType and ref ErrorMessage
            RETURN TYPE : Returns No.Of Rows Affected
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/

            public int ExecuteNonQuery(string commandText, CommandType type, ref string errorMessage)
            {
                OracleConnection iConnection;
                OracleCommand iCommand;
                int iReturnialue = 0;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                iCommand = new OracleCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iCommand.CommandType = type;
                    iConnection.Open();
                    iReturnialue = iCommand.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iConnection.Close();
                    
                    iConnection.Dispose();
                    iCommand.Dispose();
                   
                }

                return iReturnialue;
            }

            /**************************************************************************************************
            METHOD NAME : ExecuteNonQuery
            PARAMETERS  : OracleCommand and ref ErrorMessage
            RETURN TYPE : Returns No.Of Rows Affected
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :
            **************************************************************************************************/


            public int ExecuteNonQuery(OracleCommand command, ref string errorMessage)
            {
                OracleConnection iConnection;
                OracleCommand iCommand;
                int iReturnialue = 0;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                iCommand = command;
                try
                {
                    iCommand.Connection = iConnection;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iReturnialue = iCommand.ExecuteNonQuery();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    iConnection.Close();
                    
                    iConnection.Dispose();
                    iCommand.Dispose();
                   
                }

                return iReturnialue;
            }


            /**************************************************************************************************
            METHOD NAME : ExecuteReader
            PARAMETERS  : CommandText,CommandType,OracleParameter Array, ref ErrorMessage and ref Connection Object
            RETURN TYPE : Returns Data Reader RecordSet
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/


            public System.Data.OracleClient.OracleDataReader ExecuteReader(string commandText, CommandType type, OracleParameter[] OracleParam, ref string errorMessage, ref System.Data.OracleClient.OracleConnection connection)
            {
                OracleDataReader iObjDataReader;
                OracleCommand iCommand;
                iCommand = new OracleCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = connection;
                    iCommand.CommandType = type;
                    iCommand.Parameters.AddRange(OracleParam);
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    iObjDataReader = iCommand.ExecuteReader();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                   
                    iCommand.Dispose();
                    
                }

                return iObjDataReader;
            }

            /**************************************************************************************************
             METHOD NAME : ExecuteReader
             PARAMETERS  : CommandText,CommandType,ref ErrorMessage and ref Connection Object
             RETURN TYPE : Returns Data Reader RecordSet
             CREATE DATE : 23-APRIL-2009
             MODIFY DATE : 
             **************************************************************************************************/


            public System.Data.OracleClient.OracleDataReader ExecuteReader(string commandText, CommandType type, ref string errorMessage, ref OracleConnection connection)
            {
                OracleDataReader iObjDataReader;
                OracleCommand iCommand;
                iCommand = new OracleCommand();
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = connection;
                    iCommand.CommandType = type;
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    iObjDataReader = iCommand.ExecuteReader();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                   
                    iCommand.Dispose();
                 
                }

                return iObjDataReader;
            }


            /**************************************************************************************************
            METHOD NAME : ExecuteReader
            PARAMETERS  : OracleCommand,ref ErrorMessage and ref Connection Object
            RETURN TYPE : Returns Data Reader RecordSet
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :
            **************************************************************************************************/


            public System.Data.OracleClient.OracleDataReader ExecuteReader(OracleCommand command, ref string errorMessage, ref OracleConnection connection)
            {
                OracleDataReader iObjDataReader;
                OracleCommand iCommand;
                iCommand = command;
                try
                {
                    iCommand.Connection = connection;
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    iObjDataReader = iCommand.ExecuteReader();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    
                    iCommand.Dispose();
                  
                }

                return iObjDataReader;
            }

            /**************************************************************************************************
            METHOD NAME : ExecuteScalar
            PARAMETERS  : CommandText,CommandType,OracleParameter Array and ref ErrorMessage
            RETURN TYPE : Returns ialue of First Column of the First Row
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/


            public object ExecuteScalar(string commandText, CommandType type, OracleParameter[] OracleParam, ref string errorMessage)
            {
                Object iScalarReturnialue;
                OracleConnection iConnection;
                OracleCommand iCommand;
                iCommand = new OracleCommand();
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = iConnection;
                    iCommand.CommandType = type;
                    iCommand.Parameters.AddRange(OracleParam);
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iScalarReturnialue = iCommand.ExecuteScalar();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    
                    iConnection.Close();
                    iCommand.Dispose();
                    iConnection.Dispose();
                    
                }

                return iScalarReturnialue;
            }

            /**************************************************************************************************
            METHOD NAME : ExecuteScalar
            PARAMETERS  : CommandText,CommandType and ref ErrorMessage
            RETURN TYPE : Returns ialue of First Column of the First Row
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :
            **************************************************************************************************/


            public object ExecuteScalar(string commandText, CommandType type, ref string errorMessage)
            {
                Object iScalarReturnialue;
                OracleConnection iConnection;
                OracleCommand iCommand;
                iCommand = new OracleCommand();
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    iCommand.CommandText = commandText;
                    iCommand.Connection = iConnection;
                    iCommand.CommandType = type;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iScalarReturnialue = iCommand.ExecuteScalar();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                    
                    iConnection.Close();
                    iCommand.Dispose();
                    iConnection.Dispose();
                  
                }

                return iScalarReturnialue;
            }

            /**************************************************************************************************
            METHOD NAME : ExecuteScalar
            PARAMETERS  : OracleCommand and ref ErrorMessage
            RETURN TYPE : Returns ialue of First Column of the First Row
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/



            public object ExecuteScalar(OracleCommand command, ref string errorMessage)
            {
                Object iScalarReturnialue;
                OracleConnection iConnection;
                OracleCommand iCommand;
                iCommand = command;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                try
                {
                    iCommand.Connection = iConnection;
                    if (iConnection.State != ConnectionState.Open)
                    {
                        iConnection.Open();
                    }
                    iScalarReturnialue = iCommand.ExecuteScalar();
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                  
                    iConnection.Close();
                    iCommand.Dispose();
                    iConnection.Dispose();
                   
                }

                return iScalarReturnialue;
            }

            /**************************************************************************************************
            METHOD NAME : GetDataSet
            PARAMETERS  : CommandText,CommandType,OracleParameter Array and ref ErrorMessage
            RETURN TYPE : Returns DataSet Object
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/



            public System.Data.DataSet GetDataSet(string commandText, CommandType type,OracleParameter[] OracleParam, ref string errorMessage)
            {
                DataSet iObjDataSet;
                OracleConnection iConnection;
                OracleDataAdapter iDataAdapter;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                iDataAdapter = new OracleDataAdapter(new OracleCommand());
                try
                {
                    iDataAdapter.SelectCommand.Connection = iConnection;
                    iDataAdapter.SelectCommand.CommandType = type;
                    iDataAdapter.SelectCommand.CommandText = commandText;
                    iDataAdapter.SelectCommand.Parameters.AddRange(OracleParam);
                    iObjDataSet = new DataSet();
                    iDataAdapter.Fill(iObjDataSet);
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                   
                    iDataAdapter.Dispose();
                    iConnection.Dispose();
                   
                }

                return iObjDataSet;
            }

           /**************************************************************************************************
            METHOD NAME : GetDataSet
            PARAMETERS  : CommandText,CommandType and ref ErrorMessage
            RETURN TYPE : Returns DataSet Object
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/




            public System.Data.DataSet GetDataSet(string commandText, CommandType type, ref string errorMessage)
            {
                DataSet iObjDataSet;
                OracleConnection iConnection;
                OracleDataAdapter iDataAdapter;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                iDataAdapter = new OracleDataAdapter(new OracleCommand());
                try
                {
                    iDataAdapter.SelectCommand.Connection = iConnection;
                    iDataAdapter.SelectCommand.CommandType = type;
                    iDataAdapter.SelectCommand.CommandText = commandText;
                    iObjDataSet = new DataSet();
                    iDataAdapter.Fill(iObjDataSet);
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                  
                    iDataAdapter.Dispose();
                    iConnection.Dispose();
                   
                }

                return iObjDataSet;
            }


            /**************************************************************************************************
            METHOD NAME : GetDataSet
            PARAMETERS  : OracleCommand and ref ErrorMessage
            RETURN TYPE : Returns DataSet Object
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/





            public System.Data.DataSet GetDataSet(OracleCommand command, ref string errorMessage)
            {
                DataSet iObjDataSet;
                OracleConnection iConnection;
                OracleDataAdapter iDataAdapter;
                iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                iDataAdapter = new OracleDataAdapter(command);
                try
                {
                    iDataAdapter.SelectCommand.Connection = iConnection;
                    iObjDataSet = new DataSet();
                    iDataAdapter.Fill(iObjDataSet);
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                finally
                {
                   
                    iDataAdapter.Dispose();
                    iConnection.Dispose();
                  
                }

                return iObjDataSet;
            }


            /**************************************************************************************************
            METHOD NAME : GetDataSet
            PARAMETERS  : XmlFilePath and ref ErrorMessage
            RETURN TYPE : Read XML File and Returns Corresponding DataSet Object
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/




            public DataSet GetDataSet(string xmlFilePath, ref string errorMessage)
            {
                DataSet iObjDataSet;
                iObjDataSet = new DataSet();
                try
                {
                    iObjDataSet.ReadXml(xmlFilePath);
                }
                catch (System.Security.SecurityException Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                catch (System.Security.XmlSyntaxException Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                catch (System.Exception Ex)
                {
                    errorMessage = Ex.Message;
                    throw Ex;
                }
                return iObjDataSet;
            }

            /**************************************************************************************************
            METHOD NAME : GetDataTable
            PARAMETERS  : CommandText,CommandType,OracleParameter Array and ref ErrorMessage
            RETURN TYPE : Returns First DataTable from a DataSet
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/




            public System.Data.DataTable GetDataTable(string commandText, CommandType type, OracleParameter[] OracleParam, ref string errorMessage)
            {
                DataSet iObjDataSet = new DataSet();
                iObjDataSet = GetDataSet(commandText, type, OracleParam, ref errorMessage);
                return iObjDataSet.Tables[0];
            }

            /**************************************************************************************************
            METHOD NAME : GetDataTable
            PARAMETERS  : CommandText,CommandType and ref ErrorMessage
            RETURN TYPE : Returns First DataTable from a DataSet
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE : 
            **************************************************************************************************/



            public System.Data.DataTable GetDataTable(string commandText, CommandType type, ref string errorMessage)
            {
                DataSet iObjDataSet = new DataSet();
                iObjDataSet = GetDataSet(commandText, type, ref errorMessage);
                return iObjDataSet.Tables[0];
            }

            /**************************************************************************************************
            METHOD NAME : GetDataTable
            PARAMETERS  : OracleCommand and ref ErrorMessage
            RETURN TYPE : Returns First DataTable from a DataSet
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
            **************************************************************************************************/

            public System.Data.DataTable GetDataTable(OracleCommand command, ref string errorMessage)
            {
                DataSet iObjDataSet = new DataSet();
                iObjDataSet = GetDataSet(command, ref errorMessage);
                return iObjDataSet.Tables[0];
            }

            /**************************************************************************************************
            METHOD NAME : GetConnection
            PARAMETERS  : None
            RETURN TYPE : Returns Object of OracleConnection Class
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :  
            **************************************************************************************************/

            public OracleConnection GetConnection()
            {
                OracleConnection iConnection = new OracleConnection();
                iConnection.ConnectionString = ConnectionString;
                return iConnection;
            }

            /**************************************************************************************************
            METHOD NAME : CloseConnection
            PARAMETERS  : None
            RETURN TYPE : Closes The Open Connection and Returns True
            CREATE DATE : 23-APRIL-2009
            MODIFY DATE :   
            **************************************************************************************************/


            public bool CloseConnection(ref OracleConnection connection)
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
                return true;
            }

            #endregion

            #region IDisposable Members

            public void Dispose()
            {
               /*************************************************************************************
                Pass true in dispose method to clean managed resources too and say GC to skip finalize 
                in next line.
               **************************************************************************************/
                Dispose(true);
                /*************************************************************************************
                If dispose is called already then say GC to skip finalize on this instance.
                *************************************************************************************/
                GC.SuppressFinalize(this);
            }
            protected virtual void Dispose(bool disposedStatus)
            {
                if (!_isDisposed)
                {
                    _isDisposed = true;

                    /* Released unmanaged Resources */

                    if (disposedStatus)
                    {
                        /* Released managed Resources */
                    }
                }
            }


            #endregion





            #region DataAccessInterface Members

            IDbConnection DataAccessInterface.GetConnection()
            {
                throw new NotImplementedException();
            }

            public bool CloseConnection(ref IDbConnection connection)
            {
                throw new NotImplementedException();
            }

            public int ExecuteNonQuery(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public int ExecuteNonQuery(IDbCommand command, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public IDataReader ExecuteReader(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage, ref IDbConnection connection)
            {
                throw new NotImplementedException();
            }

            public IDataReader ExecuteReader(string commandText, CommandType type, ref string errorMessage, ref IDbConnection connection)
            {
                throw new NotImplementedException();
            }

            public IDataReader ExecuteReader(IDbCommand command, ref string errorMessage, ref IDbConnection connection)
            {
                throw new NotImplementedException();
            }

            public object ExecuteScalar(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public object ExecuteScalar(IDbCommand command, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public DataSet GetDataSet(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public DataSet GetDataSet(IDbCommand command, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public DataTable GetDataTable(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            public DataTable GetDataTable(IDbCommand command, ref string errorMessage)
            {
                throw new NotImplementedException();
            }

            #endregion
    }
}
