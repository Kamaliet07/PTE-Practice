﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TDRP.Utility
{
    public class AppConstant
    {
        public const string StatusSubmitted = "Submitted";
        public const string StatusApproved = "Approved";
        public const string StatusRejected = "Rejected";
        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string Employee = "Employee";
        public const string usp_GetEmployees = "usp_GetEmployees";
    }
}
