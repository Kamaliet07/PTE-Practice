﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class CarouselController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public CarouselController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult CarouselImages()
        {
            List<CarouselSlider> sliderimages = new List<CarouselSlider>();
            sliderimages = _unitOfWork.carouselRepository.GetAll().ToList();
            return View(sliderimages);
        }

        /// <summary>
        /// Method to get all Carousel Images
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAllCarousels()
        {
            return Json(new { data = _unitOfWork.carouselRepository.GetAll()});
        }

        [HttpPost]
        public async Task<IActionResult> UploadSliderImage()
        {
            var files = HttpContext.Request.Form.Files;

            if (files.Count > 0)
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\carousels", files[0].FileName);

                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await files[0].CopyToAsync(stream);
                }

                CarouselSlider crobj = new CarouselSlider
                {
                    Name = files[0].FileName,
                    FileSize = (int)files[0].Length / 1000,
                    FilePath = path,
                    Active = true,
                    CreatedDate = DateTime.Now
                };

                _unitOfWork.carouselRepository.Add(crobj);
                _unitOfWork.Save();
            }
            else
            {
                TempDataMessage(TDRPResource.msg, TDRPResource.msgError, TDRPResource.imgNotFound);
            }
            
            return RedirectToAction("CarouselImages");
        }

        /// <summary>
        /// Method to delete the Carousel
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        public IActionResult DeleteCarousel(int id)
        {
            var objExpDb = _unitOfWork.carouselRepository.GetFirstOrDefault(x => x.CarId.Equals(id));
            if (objExpDb == null)
            {
                return Json(new { success = false, message = "Error while deleting." });
            }

            _unitOfWork.carouselRepository.Remove(objExpDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful." });
        }

        /// <summary>
        ///  Method to popup error message
        /// </summary>
        /// <param name="key"></param>
        /// <param name="alert"></param>
        /// <param name="value"></param>
        public void TempDataMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }
        }
    }
}