﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ProfileController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        /// Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        public ProfileController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        /// <summary>
        /// Index method To Load profile
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> MyProfile()
        {
            ApplicationUser user = await _userService.GetUserAsync(User);
            return View(user);
        }

        /// <summary>
        /// Method to update about me details
        /// </summary>
        /// <param name="profileId">profile id</param>
        /// <param name="headlines">profile headlines</param>
        /// <param name="proffDetails">breif details</param>
        /// <param name="workLocation">Work Location</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<PartialViewResult> UpdateAboutMe(int profileId, string headlines, string proffDetails, string workLocation)
        {
            ApplicationUser user = await _userService.GetUserAsync(User);
            UserProfileDetails objUserProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(user.Id));
            if (objUserProfile == null)
            {
                objUserProfile = new UserProfileDetails();
            }
            objUserProfile.UserId = user.Id;
            objUserProfile.Headlines = headlines;
            objUserProfile.DetailDescription = proffDetails;
            objUserProfile.Worklocation = workLocation;

            if (ModelState.IsValid)
            {
                if (profileId == 0)
                {
                    _unitOfWork.userprofile.Add(objUserProfile);
                }
                else
                {
                    _unitOfWork.userprofile.Update(objUserProfile);
                }
                _unitOfWork.Save();
            }
            return PartialView("AboutMe", objUserProfile);
        }

        /// <summary>
        /// Method to get employee experience
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetEmpExperience()
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            return Json(new { data = _unitOfWork.expRepository.GetAll(x => x.UserId.Equals(userId)) });
        }

        /// <summary>
        /// Method to Get the team list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetTeamList()
        {
            var teams = _unitOfWork.teamRepository.GetAll();
            return Json(teams);
        }

        /// <summary>
        /// Methos to get Autocomplete Job Roles
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetJobRoles(string search)
        {
            List<JobRoles> allsearch = _unitOfWork.jobRolesRepository.GetAll(x => x.JobRole.Contains(search)).Select(
                x => new JobRoles
                {
                    JobRoleId = x.JobRoleId,
                    JobRole = x.JobRole
                }).ToList();

            return Json(allsearch);
        }

        /// <summary>
        /// Methos to get Autocomplete Skills
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetSkills(string search)
        {
            List<Skills> allsearch = _unitOfWork.skillRepository.GetAll(x => x.Skill.Contains(search)).Select(
                x => new Skills
                {
                    SkillId = x.SkillId,
                    Skill = x.Skill
                }).ToList();

            return Json(allsearch);
        }

        /// <summary>
        /// Method to get employee Skills
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetEmployeeSkills()
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            return Json(new { data = _unitOfWork.userSkillsRepository.GetAll(x => x.UserId.Equals(userId)) });
        }

        /// <summary>
        /// Method to save Experience details
        /// </summary>
        /// <param name="expDetails"></param>
        /// <returns></returns>
        [HttpPost]
        public PartialViewResult SaveEmployeeSkills(string values)
        {
            UserSkills userSkill = null;
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            if (!string.IsNullOrEmpty(values))
            {
                // Parse and desearilize the JSON object
                JArray array = JArray.Parse(values);
                foreach (JToken jToken in array)
                {
                    userSkill = new UserSkills();
                    JToken[] innerArray = jToken.ToArray();
                    userSkill.Skill = innerArray[0].First.ToString();
                    userSkill.UserId = userId;
                    userSkill.CreatedDate = DateTime.Now;
                    userSkill.Active = true;
                    _unitOfWork.userSkillsRepository.Add(userSkill);
                    _unitOfWork.Save();
                }
            }
            return PartialView("EmployeeSkills");
        }

        /// <summary>
        /// Method to save Experience details
        /// </summary>
        /// <param name="expDetails"></param>
        /// <returns></returns>
        [HttpPost]
        public PartialViewResult SaveExperienceDetails(string expDetails)
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            UserExperience userExp = new UserExperience();
            userExp.UserId = userId;
            userExp.ExpDetails = expDetails;
            userExp.CreatedDate = DateTime.Now;
            userExp.Active = true;
            if (!string.IsNullOrEmpty(expDetails))
            {
                _unitOfWork.expRepository.Add(userExp);
                _unitOfWork.Save();
            }
            return PartialView("MyExperience");
        }

        /// <summary>
        /// Method to Update the user experience.
        /// </summary>
        /// <param name="userExp">User Experience Model</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateExperience(UserExperience userExp)
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            if (ModelState.IsValid)
            {
                if (userExp.ExpId == 0)
                {
                    userExp.UserId = userId;
                    userExp.CreatedDate = DateTime.Now;
                    userExp.Active = true;
                    _unitOfWork.expRepository.Add(userExp);
                }
                else
                {
                    _unitOfWork.expRepository.Update(userExp);
                }
                _unitOfWork.Save();
                return RedirectToAction(nameof(MyProfile));
            }
            return PartialView("MyExperience", userExp);
        }

        /// <summary>
        /// Method to update basic details
        /// </summary>
        /// <param name="profileId">Profile Id</param>
        /// <param name="fistName">User Firs Name</param>
        /// <param name="lastName">User Last Name</param>
        /// <param name="phoneNumber">phone Number</param>
        /// <param name="hireDate">Hire Date</param>
        /// <param name="teamId">Team Assigned</param>
        /// <param name="jobRolesId">Job Role Assigned</param>
        /// <param name="gender">Gender</param>
        /// <param name="dob">Date Of Birth</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult UpdateBasicDetails(int profileId, string fistName, string lastName, string phoneNumber,
            DateTime hireDate, int teamId, int jobRolesId, string gender, DateTime dob)
        {
            var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            UserProfileDetails objUserProfile = _unitOfWork.userprofile.GetFirstOrDefault(x => x.UserId.Equals(userId));
            if (objUserProfile == null)
            {
                objUserProfile = new UserProfileDetails();
            }
            objUserProfile.FirstName = fistName;
            objUserProfile.LastName = lastName;
            objUserProfile.PhoneNumber = phoneNumber;
            objUserProfile.HireDate = hireDate;
            objUserProfile.TeamId = teamId;
            objUserProfile.JobRoleId = jobRolesId;
            objUserProfile.Gender = gender[0].ToString();
            objUserProfile.DOB = dob;

            if (profileId == 0)
            {
                _unitOfWork.userprofile.Add(objUserProfile);
            }
            else
            {
                _unitOfWork.userprofile.Update(objUserProfile);
            }
            _unitOfWork.Save();

            return PartialView("BasicDetails", objUserProfile);
        }

        /// <summary>
        /// Method to Delete the user Experience
        /// </summary>
        /// <param name="id">Experience Id</param>
        /// <returns></returns>
        [HttpDelete]
        public IActionResult DeleteExperience(int id)
        {
            var objExpDb = _unitOfWork.expRepository.GetFirstOrDefault(x => x.ExpId.Equals(id));
            if (objExpDb == null)
            {
                return Json(new { success = false, message = "Error while deleting." });
            }

            _unitOfWork.expRepository.Remove(objExpDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful." });
        }

        /// <summary>
        /// Method to delete the Employee Skills
        /// </summary>
        /// <param name="id">User Skill Id</param>
        /// <returns></returns>
        [HttpDelete]
        public IActionResult DeleteEmployeeSkill(int id)
        {
            var objFromDb = _unitOfWork.userSkillsRepository.GetFirstOrDefault(x => x.SysId.Equals(id));
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting." });
            }

            _unitOfWork.userSkillsRepository.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Delete successful." });
        }

        public ActionResult GetWorkDetails()
        {
            // to do : Update to include the data for the view
            return PartialView("EmployeeWorkDetail");
        }
    }
}