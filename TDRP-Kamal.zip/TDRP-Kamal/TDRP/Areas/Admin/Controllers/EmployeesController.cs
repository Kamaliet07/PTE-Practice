﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;
using TDRP.DataModel;
using TDRP.Utility;

namespace TDRP.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class EmployeesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        /// Constructor To Initialize Dependency
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="userService"></param>
        public EmployeesController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        /// <summary>
        /// Action Method To Load Employee List View
        /// </summary>
        /// <returns></returns>
        public IActionResult EmployeesList()
        {
            List<EmployeesList> objEmpList = _unitOfWork.spCall
                .ReturnList<EmployeesList>(AppConstant.usp_GetEmployees, null).Result.ToList();
            return View(objEmpList);
        }

        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            return Json(new { data = _unitOfWork.spCall.ReturnList<EmployeesList>(AppConstant.usp_GetEmployees, null).Result });
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteEmployee(string id)
        {
            ApplicationUser objFromDb = await _userService.FindByIdAsync(id);
            if (objFromDb == null)
            {
                return Json(new
                {
                    success = false,
                    message = "Error While Deleting."

                });
            }

            await _userService.DeleteAsync(objFromDb);
            _unitOfWork.Save();

            return Json(new
            {
                success = true,
                message = "Delete Successful."

            });
        }
    }
}