﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.RepositoryUnit;
using TDRP.DataAccessLayer.Data;

namespace TDRP.Areas.Employee.Controllers
{
    [Authorize]
    [Area("Employee")]
    public class ProfileController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUserRepository _userService;

        /// <summary>
        /// Initialize constructor and dependencies
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="userService"></param>
        public ProfileController(IUnitOfWork unitOfWork, IUserRepository userService)
        {
            _unitOfWork = unitOfWork;
            _userService = userService;
        }

        /// <summary>
        /// Method to get user profile details
        /// </summary>
        /// <param name="id">user id</param>
        /// <returns></returns>
        public async Task<IActionResult> UserProfile(string id)
        {
            ApplicationUser user = await _userService.FindByIdAsync(id);
            return View(user);
        }

    }
}