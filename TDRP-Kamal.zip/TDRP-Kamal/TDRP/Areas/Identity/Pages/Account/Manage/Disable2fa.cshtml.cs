﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using TDRP.BusinessLayer.Interface;

namespace TDRP.Areas.Identity.Pages.Account.Manage
{
    public class Disable2faModel : PageModel
    {
        private readonly IUserRepository userRepository;
        private readonly ILogger<Disable2faModel> _logger;

        public Disable2faModel(
            IUserRepository userRepository,
            ILogger<Disable2faModel> logger)
        {
            this.userRepository = userRepository;
            _logger = logger;
        }

        [TempData]
        public string StatusMessage { get; set; }

        public async Task<IActionResult> OnGet()
        {
            var user = await userRepository.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{userRepository.GetUserId(User)}'.");
            }

            if (!await userRepository.GetTwoFactorEnabledAsync(user))
            {
                throw new InvalidOperationException($"Cannot disable 2FA for user with ID '{userRepository.GetUserId(User)}' as it's not currently enabled.");
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await userRepository.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{userRepository.GetUserId(User)}'.");
            }

            var disable2faResult = await userRepository.SetTwoFactorEnabledAsync(user, false);
            if (!disable2faResult.Succeeded)
            {
                throw new InvalidOperationException($"Unexpected error occurred disabling 2FA for user with ID '{userRepository.GetUserId(User)}'.");
            }

            _logger.LogInformation("User with ID '{UserId}' has disabled 2fa.", userRepository.GetUserId(User));
            StatusMessage = "2fa has been disabled. You can reenable 2fa when you setup an authenticator app";
            return RedirectToPage("./TwoFactorAuthentication");
        }
    }
}