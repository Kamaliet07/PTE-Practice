﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using TDRP.BusinessLayer.Interface;

namespace TDRP.Areas.Identity.Pages.Account.Manage
{
    public class ResetAuthenticatorModel : PageModel
    {
        private readonly IUserRepository userRepository;
        ILogger<ResetAuthenticatorModel> _logger;

        public ResetAuthenticatorModel(
           IUserRepository userRepository,
            ILogger<ResetAuthenticatorModel> logger)
        {
            this.userRepository = userRepository;
            _logger = logger;
        }

        [TempData]
        public string StatusMessage { get; set; }

        public async Task<IActionResult> OnGet()
        {
            var user = await userRepository.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{userRepository.GetUserId(User)}'.");
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await userRepository.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{userRepository.GetUserId(User)}'.");
            }

            await userRepository.SetTwoFactorEnabledAsync(user, false);
            await userRepository.ResetAuthenticatorKeyAsync(user);
            _logger.LogInformation("User with ID '{UserId}' has reset their authentication app key.", user.Id);

            await userRepository.RefreshSignInAsync(user);
            StatusMessage = "Your authenticator app key has been reset, you will need to configure your authenticator app using the new key.";

            return RedirectToPage("./EnableAuthenticator");
        }
    }
}