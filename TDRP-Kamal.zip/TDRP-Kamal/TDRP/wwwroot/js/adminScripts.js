﻿//Carousels Methods - Java Script Method For All Carousels Activities
var dataTableCarousel;

$(document).ready(function () {
    loadCarouselDetails();
});

function loadCarouselDetails() {

    dataTableExp = $('#tblCarousel').DataTable({
        "ajax": {
            "url": "/admin/carousel/GetAllCarousels",
            "type": "GET",
            "datatype": "json"
        },
        "columns": [
            { "data": "name", "width": "20%" },
            { "data": "fileSize", "width": "10%" },
            { "data": "filePath", "width": "30%" },
            {
                "data": "filePath",
                "render": function (data) {
                    return `<div class="text-center">                                
                               <img src="@Url.Content(${data})" alt="" width="80" height="60" class="img-thumbnail"/>
                            </div>
                            `;
                }, "width": "30%"
            },
            {
                "data": "carId",
                "render": function (data) {
                    return `<div class="text-center">                                
                                <a onclick= DeleteCarousel("/Admin/carousel/DeleteCarousel/${data}") class='btn btn-box-tool' style='cursor:pointer;'>
                                    <i class='fa fa-trash-o'></i> </a>	
                            </div>
                            `;
                }, "width": "10%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

$("#addCarousel").click(function () {
    $("#carouselTable").hide();
    $("#UpdateCarouselPanel").show();
});

$("#btnCancel").click(function () {
    $("#carouselTable").show();
    $("#UpdateCarouselPanel").hide();
});

function DeleteCarousel(url) {
    swal({
        title: "Are you sure you want to delete?",
        text: "You will not be able to restore the content!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        closeOnconfirm: true
    }, function () {
        $.ajax({
            type: 'DELETE',
            url: url,
            success: function (data) {
                if (data.success) {
                    dataTableExp.ajax.reload();
                }
                else {
                    toastr.error(data.message);
                }
            }
        });
    });
}

//Employees List - Java Script Method For All Employees List Activities

$(function () {
    $('#tblEmployees').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    })
})

function DeactivateUser(id) {
    swal({
            title: "Are you sure you want to deactivate user?",
            text: "Your can re-activate from activation module!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, de-activate!",
            closeOnconfirm: true
        },
        function () {
            swal("Deleted!", "Your imaginary file has been deleted.", "success");
        });
}

