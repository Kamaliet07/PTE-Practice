﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TDRP.DataModel
{
    public class UserProfileDetails
    {
        [Key]
        public int ProfileId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        [StringLength(20, ErrorMessage = "length can't be more than 20.")]
        public string FirstName { get; set; }

        [StringLength(25, ErrorMessage = "length can't be more than 25.")]
        public string LastName { get; set; }

        [DataType(DataType.PhoneNumber)]
        [StringLength(20, ErrorMessage = "length can't be more than 20.")]
        public string PhoneNumber { get; set; }
        
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        public DateTime? HireDate { get; set; }

        public int? TeamId { get; set; }
        [ForeignKey("TeamId")]
        public Teams Teams { get; set; }

        public int? JobRoleId { get; set; }
        [ForeignKey("JobRoleId")]
        public JobRoles JobRoles { get; set; }

        public string Gender { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? DOB { get; set; }

        [StringLength(10, ErrorMessage = "length can't be more than 10.")]
        public string Nationality { get; set; }

        [StringLength(35, ErrorMessage = "length can't be more than 35.")]
        public string Worklocation { get; set; }

        [StringLength(150, ErrorMessage = "length can't be more than 150.")]
        public string Headlines { get; set; }

        [StringLength(350, ErrorMessage = "length can't be more than 350.")]
        public string DetailDescription { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }
    

    public class UserProfileImage
    {
        [Key]
        public int SysId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        [Required]
        [StringLength(15, ErrorMessage = "length can't be more than 15.")]
        public string Name { get; set; }

        public byte[] Picture { get; set; }

        public bool Active { get; set; }
    }

    public class UserAddress
    {
        [Key]
        public int AddressId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "length can't be more than 50.")]
        public string AddressLine1 { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "length can't be more than 50.")]
        public string AddressLine2 { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "length can't be more than 50.")]
        public string City { get; set; }
        public int? StateProvinceId { get; set; }
        [ForeignKey("StateProvinceId")]
        public StateTerritory StateTerritory { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "length can't be more than 10.")]
        public string PostalCode { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }

    }

    public class UserExperience
    {
        [Key]
        public int ExpId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        [Required]
        [StringLength(250, ErrorMessage = "length can't be more than 250.")]
        [Display(Name = "Experience Details")]
        public string ExpDetails { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class UserSkills
    {
        [Key]
        public int SysId { get; set; }

        [StringLength(450)]
        public string UserId { get; set; }

        public string Skill { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class MySkills
    {
    public List<string> values { get; set; }

    }

public class Supervisor
    {
        [Key]
        public string SupervisorId { get; set; }
        public string SupervisorName { get; set; }
        public string SupervisorEmail { get; set; }
    }

  
}
