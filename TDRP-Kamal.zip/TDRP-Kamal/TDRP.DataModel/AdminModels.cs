﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TDRP.DataModel
{
    public class CarouselSlider
    {
        [Key]
        public int CarId { get; set; }
        public string Name { get; set; }
        public int? FileSize { get; set; }

        [DataType(DataType.ImageUrl)]
        public string FilePath { get; set; }
        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class EmployeesList
    {
        public string UserId { get; set; }

        [Display(Name = "Name")]
        public string UserName { get; set; }
        public string Email { get; set; }
        public byte[] Picture { get; set; }
        public string Team { get; set; }
        public string SupervisorName { get; set; }
        public string JobRole { get; set; }
        public bool Active { get; set; }
    }
}
