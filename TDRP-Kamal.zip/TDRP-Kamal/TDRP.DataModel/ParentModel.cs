﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TDRP.DataModel
{
    public class ContractTypes
    {
        [Key]
        public int ContractId { get; set; }

        [StringLength(50, ErrorMessage = "Name length can't be more than 50.")]
        public string ContractType { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class JobRoles
    {
        [Key]
        public int JobRoleId { get; set; }

        [StringLength(150, ErrorMessage = "Name length can't be more than 150.")]
        public string JobRole { get; set; }

        [StringLength(450, ErrorMessage = "Name length can't be more than 450.")]
        public string JobRoleDescription { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class Qualifications
    {
        [Key]
        public int QualificationId { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Name length can't be more than 50.")]
        public string Qualification { get; set; }
        
        [StringLength(250, ErrorMessage = "Name length can't be more than 250.")]
        public string Description { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class Skills
    {
        [Key]
        public int SkillId { get; set; }

        [Required]
        [StringLength(150, ErrorMessage = "Name length can't be more than 150.")]
        public string Skill { get; set; }

        [StringLength(250, ErrorMessage = "Name length can't be more than 250.")]
        public string SkillDescription { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class StateTerritory
    {
        [Key]
        public int StateProvinceId { get; set; }

        [Required]
        [StringLength(3, ErrorMessage = "Name length can't be more than 3.")]
        public string StateCode { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Name length can't be more than 50.")]
        public string StateName { get; set; }

        [Required]
        public int CountryRegionCode { get; set; }

        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class Teams
    {
        [Key]
        public int TeamId { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "Name length can't be more than 50.")]
        public string TeamName { get; set; }

        [StringLength(250, ErrorMessage = "Name length can't be more than 250.")]
        public string TeamDetails { get; set; }

        [Required]
        [StringLength(450)]
        public string SupervisorName { get; set; }
      
        public bool Active { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }
    }

    public class Projects
    {
        [Key]
        public int ProjectId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "Name length cannot exceed 100 characters.")]
        public string ProjectName { get; set; }

        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        public int CreateId { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }

        public int? UpdateId { get; set; }
    }

    public class AssignedWork
    {
        [Key]
        public int AssignedWorkId { get; set; }

        [Required]
        public int ProjectId { get; set; }

        [Required]
        public int UserId { get; set; }

        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? CreatedDate { get; set; }

        public int CreateId { get; set; }

        [DataType(DataType.Date)]
        public DateTime? UpdatedDate { get; set; }

        public int? UpdateId { get; set; }
    }
}
