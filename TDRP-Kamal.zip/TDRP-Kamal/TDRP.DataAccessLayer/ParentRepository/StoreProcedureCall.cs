﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Microsoft.EntityFrameworkCore;
using TDRP.DataAccessLayer.Data;

namespace TDRP.DataAccessLayer.ParentRepository
{
    public class StoreProcedureCall : IStoreProcedureCall
    {
        private readonly ApplicationDbContext dbContext;
        private static string connectionString = "";

        public StoreProcedureCall(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
            connectionString = dbContext.Database.GetDbConnection().ConnectionString;
        }

        public async Task<T> ExecuteReturnScaler<T>(string storeprocedure, DynamicParameters parm = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    return (T)Convert.ChangeType(connection.ExecuteScalarAsync<T>(storeprocedure, parm, commandType: System.Data.CommandType.StoredProcedure), typeof(T));
                }
            }
            catch (Exception ex)
            {
                //do logging
                throw ex;
            }
        }

        public void ExecuteWithoutReturn(string storeprocedure, DynamicParameters parm = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    connection.Execute(storeprocedure, parm, commandType: System.Data.CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                //do logging
                throw ex;
            }
        }

        public async Task<IEnumerable<T>> ReturnList<T>(string storeprocedure, DynamicParameters parm = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    return await connection.QueryAsync<T>(storeprocedure, parm, commandType: System.Data.CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                //do logging
                throw ex;
            }
        }

        public async Task<T> QueryFirstOrDefault<T>(string storeprocedure, DynamicParameters parm = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var result = await connection.QueryFirstOrDefault(storeprocedure, parm, commandType: System.Data.CommandType.StoredProcedure);
                    return (T)Convert.ChangeType(result, typeof(T));
                }
            }
            catch (Exception ex)
            {
                //do logging
                throw ex;
            }
        }

        public async Task<T> QueryAsync<T>(string storeprocedure, DynamicParameters parm = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var result = await connection.QueryAsync(storeprocedure, parm, commandType: System.Data.CommandType.StoredProcedure);
                    return (T)Convert.ChangeType(result, typeof(T));
                }
            }
            catch (Exception ex)
            {
                //do logging
                throw ex;
            }
        }

        public void Dispose()
        {
            dbContext.Dispose();
        }
    }
}
