﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TDRP.DataAccessLayer.Migrations
{
    public partial class updatingmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SupervisorId",
                table: "Teams",
                newName: "SupervisorName");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SupervisorName",
                table: "Teams",
                newName: "SupervisorId");
        }
    }
}
