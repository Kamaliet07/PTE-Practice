﻿using System;
using System.Collections.Generic;
using System.Text;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.ParentRepository;

namespace TDRP.BusinessLayer.RepositoryUnit
{
    public interface IUnitOfWork : IDisposable
    {
        IStoreProcedureCall spCall { get; }

        IUserProfileRepository userprofile { get; }

        IExperienceRepository expRepository { get; }

        ITeamRepository teamRepository { get; }

        IJobRolesRepository jobRolesRepository { get; }

        ISkillRepository skillRepository { get; }

        IUserSkillsRepository userSkillsRepository { get; }

        ICarouselRepository carouselRepository { get; }

        void Save();
    }
}
