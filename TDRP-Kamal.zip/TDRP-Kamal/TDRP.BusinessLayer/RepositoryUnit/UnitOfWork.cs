﻿using TDRP.BusinessLayer.Interface;
using TDRP.BusinessLayer.Repository;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;

namespace TDRP.BusinessLayer.RepositoryUnit
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _dbcontext;
        public IStoreProcedureCall spCall { get; private set; }

        public IUserProfileRepository userprofile { get; private set; }

        public IExperienceRepository expRepository { get; private set; }

        public ITeamRepository teamRepository { get; private set; }

        public IJobRolesRepository jobRolesRepository { get; private set; }

        public ISkillRepository skillRepository { get; private set; }

        public IUserSkillsRepository userSkillsRepository { get; private set; }

        public ICarouselRepository carouselRepository { get; private set; }

        public IUserRepository userRepository { get; private set; }

        public UnitOfWork(ApplicationDbContext dbcontext)
        {
            _dbcontext = dbcontext;
            spCall = new StoreProcedureCall(_dbcontext);
            userprofile = new UserProfileRepository(_dbcontext);
            expRepository = new ExperienceRepository(_dbcontext);
            teamRepository = new TeamRepository(_dbcontext);
            jobRolesRepository = new JobRolesRepository(_dbcontext);
            skillRepository = new SkillRepository(_dbcontext);
            userSkillsRepository = new UserSkillsRepository(_dbcontext);
            carouselRepository = new CarouselRepository(_dbcontext);
        }

        public void Save()
        {
            _dbcontext.SaveChanges();
        }

        public void Dispose()
        {
            _dbcontext.Dispose();
        }
    }
}
