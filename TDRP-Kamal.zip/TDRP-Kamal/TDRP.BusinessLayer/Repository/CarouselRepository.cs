﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class CarouselRepository : Repository<CarouselSlider>, ICarouselRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public CarouselRepository(ApplicationDbContext db) : base(db)
        {
            _dbContext = db;
        }

        public IEnumerable<SelectListItem> GetCarouselList()
        {
            return _dbContext.CarouselSlider.Select(i => new SelectListItem()
            {
                Text = i.FilePath,
                Value = i.CarId.ToString(),
                Selected = i.Active
            });
        }

        public void Update(CarouselSlider carouselSlider)
        {
            var objFromDb = _dbContext.CarouselSlider.FirstOrDefault(s => s.CarId == carouselSlider.CarId);
            objFromDb.FilePath = carouselSlider.FilePath;
            _dbContext.SaveChanges();
        }
    }
}
