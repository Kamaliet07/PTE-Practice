﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class UserSkillsRepository : Repository<UserSkills>, IUserSkillsRepository
    {
        private readonly ApplicationDbContext _db;

        public UserSkillsRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetUserSkillsList()
        {
            return _db.UserSkills.Select(i => new SelectListItem()
            {
                Text = i.Skill,
                Value = i.SysId.ToString()
            });
        }
    }
}
