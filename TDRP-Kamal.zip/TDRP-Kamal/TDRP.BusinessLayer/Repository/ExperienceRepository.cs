﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using TDRP.BusinessLayer.Interface;
using TDRP.DataAccessLayer.Data;
using TDRP.DataAccessLayer.ParentRepository;
using TDRP.DataModel;

namespace TDRP.BusinessLayer.Repository
{
    public class ExperienceRepository : Repository<UserExperience>, IExperienceRepository
    {
        private readonly ApplicationDbContext _db;

        public ExperienceRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }
        public IEnumerable<SelectListItem> GetExperienceListForDropDown()
        {
            return _db.UserExperience.Select(i => new SelectListItem()
                {
                  Text = i.ExpDetails,
                  Value = i.ExpId.ToString()
                });
        }

        public void Update(UserExperience userExperience)
        {
            var objFromDb = _db.UserExperience.FirstOrDefault(s => s.ExpId == userExperience.ExpId);
            objFromDb.ExpDetails = userExperience.ExpDetails;
            _db.SaveChanges();
        }
    }
}
