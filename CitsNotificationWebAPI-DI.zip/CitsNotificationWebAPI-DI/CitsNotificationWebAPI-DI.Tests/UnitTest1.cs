﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CitsNotificationWebAPI_DI.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
