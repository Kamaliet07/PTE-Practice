﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CitsNotification.DataAccess;

namespace CitsNotification.BusinessLogic
{
    public interface ICitsNotificationContext
    {
        Task<List<GetAllCustomer_Result>> GetCustomerList();
    }
}
