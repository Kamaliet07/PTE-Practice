﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CitsNotification.DataAccess;

namespace CitsNotification.BusinessLogic
{
    public class CitsNotificationContext : ICitsNotificationContext, IDisposable
    {
        private MGASubscriptionDBEntities db = new MGASubscriptionDBEntities();

        public async Task<List<GetAllCustomer_Result>> GetCustomerList()
        {
            return await Task.Run(() => this.db.GetAllCustomer().ToList());
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (db != null)
                {
                    db.Dispose();
                    db = null;
                }
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
