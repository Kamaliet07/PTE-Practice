﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CitsNotificationWebAPI_DI.App_Start
{
    public static class AutoMapperConfig
    {
        /// <summary>
        /// Following method automatically map stored procedures fields with model properties.
        /// </summary>
        public static void CreateMappings()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.CreateMissingTypeMaps = true;
                cfg.CreateMap<usp_GetExtractType_Result, ExtractTypeModel>().ReverseMap();
                cfg.CreateMap<usp_GetAllSubscriptionNotificationFeed_Result, GetSubscriptionNotificationModel>().ReverseMap();
                cfg.CreateMap<usp_GetSubscriptionNotificationForMGA_Result, GetSubscriptionNotificationModel>().ReverseMap();
                cfg.CreateMap<usp_GetNotificationForEditDelete_Result, SubscriptionNotificationModel>().ReverseMap();
                cfg.CreateMap<usp_GetSearchedMGAList_Result, SearchedMGAList>().ReverseMap();
                cfg.CreateMap<usp_GetSearchedMGAListSorted_Result, SearchedMGAList>().ReverseMap();
                cfg.CreateMap<usp_GetMGAExtractViewDetails_Result, MGAExtractDetails>().ReverseMap();
                cfg.CreateMap<usp_GetNotificationType_Result, NotificationTypeModel>().ReverseMap();
                cfg.CreateMap<usp_GetMGACodeList_Result, MGACodeListModel>().ReverseMap();
                cfg.CreateMap<usp_GetMGAExtractDetailForEdit_Result, MGAExtractDetails>().ReverseMap();
            });
            Mapper.AssertConfigurationIsValid();
        }

    }
}