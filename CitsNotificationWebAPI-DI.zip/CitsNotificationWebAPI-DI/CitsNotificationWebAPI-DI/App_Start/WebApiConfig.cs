﻿using CitsNotification.BusinessLogic;
using CitsNotificationWebAPI_DI.ExceptionHandling;
using CitsNotificationWebAPI_DI.Resolver;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;

namespace CitsNotificationWebAPI_DI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            var container = new UnityContainer();
            container.RegisterType<ICitsNotificationContext, CitsNotificationContext>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);

            //config.Filters.Add(new ElmahExceptionLogger());

            // There can be multiple exception loggers. (By default, no exception loggers are registered.)
            // config.Services.Add(typeof(IExceptionLogger), new ElmahExceptionLogger());
            // There must be exactly one exception handler. (There is a default one that may be replaced.)
            // To make this sample easier to run in a browser, replace the default exception handler with one that sends
            // back text/plain content for all errors.
            config.Services.Replace(typeof(IExceptionHandler), new ApplicationExceptionHandler());

            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
               name: "ActionApi",
               routeTemplate: "api/{controller}/{action}/{id}",
               defaults: new { controller = "MGASubscription", action = "GetExtractType", id = RouteParameter.Optional });

            // config.Routes.MapHttpRoute(
            //    name: "DefaultApi",
            //    routeTemplate: "api/{controller}/{id}",
            //    defaults: new { id = RouteParameter.Optional }
            // ) ;
            config.Formatters.Remove(config.Formatters.XmlFormatter);
            config.Formatters.JsonFormatter.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
        }

    }
}

