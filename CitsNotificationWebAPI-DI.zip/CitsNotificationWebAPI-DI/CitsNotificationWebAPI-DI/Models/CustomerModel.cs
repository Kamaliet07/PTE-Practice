﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CitsNotificationWebAPI_DI.Models
{
    public class CustomerModel
    {
        public int CustID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
    }
}