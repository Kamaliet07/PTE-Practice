﻿using CitsNotification.BusinessLogic;
using CitsNotificationWebAPI_DI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using AutoMapper;

namespace CitsNotificationWebAPI_DI.Controllers
{
    public class CustomerNotificationController : ApiController
    {
        private ICitsNotificationContext context;

        public CustomerNotificationController(ICitsNotificationContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// Method To Fetch Entire List of Data for MGA Subscription
        /// </summary>
        /// <returns>List of Return Type</returns>
        [HttpGet]
        public async Task<IList<CustomerModel>> GetAllSubscriptionFeed()
        {
            // Create the List of Model To Return
            var retVal = new List<CustomerModel>();

            // Execute the Context to fetch Data
            var contextResult = await this.context.GetCustomerList();

            // Map the return Value
            Mapper.Map(contextResult, retVal);

            return retVal;
        }        
    }
}
