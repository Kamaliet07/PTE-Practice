﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace CitsNotificationWebAPI_DI.ExceptionHandling
{
    public class ApplicationExceptionResult : IHttpActionResult
    {
        public ApplicationExceptionResult(System.Exception exception, HttpRequestMessage request)
        {
            this.Exception = exception;
            this.Request = request;
        }

        public System.Exception Exception { get; set; }

        public HttpRequestMessage Request { get; set; }

        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            HttpStatusCode httpStatusCode = HttpStatusCode.InternalServerError;
            HttpError httpError;
            if (this.Exception is BusinessException)
            {
                BusinessException businessException = (BusinessException)this.Exception;
                int errorCode = businessException.ErrorCode;
                httpStatusCode = ExceptionHttpStatusCodeMapper.GetHttpStatusCode(errorCode);

                // if no Exception.Data  or only ErrorLogID in Exception.Data
                if (this.Exception.Data.Count == 0 ||
                    (this.Exception.Data.Contains(KeyConstants.ErrorLogID) && this.Exception.Data.Count == 1))
                {
                    // custom error with message and error code
                    httpError = new HttpError(businessException.Message) { { KeyConstants.ErrorCode, errorCode } };
                }
                else
                {
                    // Assume collection of errors in ExceptionData so create a ModelState and add errors to it
                    ModelStateDictionary modelState = this.GetModelStateFromExceptionData(this.Exception.Data);
                    httpError = new HttpError(modelState, false);

                    // Overwrite the generic message "The request is invalid"
                    httpError["Message"] = businessException.Message;

                    // Add the error code
                    httpError.Add(KeyConstants.ErrorCode, errorCode);
                }
            }
            else
            {
                System.Exception userFriendlyException = new System.Exception();
                httpError = new HttpError(userFriendlyException, false);
            }

            // Add the ErrorLogID from the Exception.Data to the httpError
            if (this.Exception.Data.Contains(KeyConstants.ErrorLogID))
            {
                string errorLogID = this.Exception.Data[KeyConstants.ErrorLogID].ToString();
                httpError.Add(KeyConstants.ErrorLogID, errorLogID);
            }

            HttpResponseMessage response = this.Request.CreateErrorResponse(httpStatusCode, httpError);
            response.RequestMessage = this.Request;
            return Task.FromResult(response);
        }

        private ModelStateDictionary GetModelStateFromExceptionData(IDictionary exceptionData)
        {
            ModelStateDictionary retVal = new ModelStateDictionary();
            foreach (string key in exceptionData.Keys)
            {
                if (key != KeyConstants.ErrorLogID)
                {
                    retVal.AddModelError(key, exceptionData[key].ToString());
                }
            }

            return retVal;
        }

    }
}