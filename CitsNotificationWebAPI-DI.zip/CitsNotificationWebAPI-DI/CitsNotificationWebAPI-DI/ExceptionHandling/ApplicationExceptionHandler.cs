﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ExceptionHandling;

namespace CitsNotificationWebAPI_DI.ExceptionHandling
{
    public class ApplicationExceptionHandler : ExceptionHandler
    {
        public override void Handle(ExceptionHandlerContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }

            context.Result = new ApplicationExceptionResult(context.Exception, context.Request);

        }
    }
}