﻿CREATE TABLE [dbo].[Teams] (
    [TeamId]         INT            IDENTITY (1, 1) NOT NULL,
    [TeamName]       NVARCHAR (50)  NOT NULL,
    [TeamDetails]    NVARCHAR (250) NULL,
    [SupervisorName] NVARCHAR (450) NOT NULL,
    [Active]         BIT            NOT NULL,
    [CreatedDate]    DATETIME2 (7)  NULL,
    [UpdatedDate]    DATETIME2 (7)  NULL,
    [CreateId]       INT            NULL,
    [UpdateId]       INT            NULL,
    CONSTRAINT [PK_Teams] PRIMARY KEY CLUSTERED ([TeamId] ASC)
);

