﻿CREATE TABLE [dbo].[UserSkills] (
    [SysId]       INT            IDENTITY (1, 1) NOT NULL,
    [UserId]      NVARCHAR (450) NULL,
    [Skill]       NVARCHAR (MAX) NULL,
    [Active]      BIT            NOT NULL,
    [CreatedDate] DATETIME2 (7)  NULL,
    [UpdatedDate] DATETIME2 (7)  NULL,
    CONSTRAINT [PK_UserSkills] PRIMARY KEY CLUSTERED ([SysId] ASC)
);

