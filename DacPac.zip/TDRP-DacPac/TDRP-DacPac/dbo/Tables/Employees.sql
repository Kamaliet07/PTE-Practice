﻿CREATE TABLE [dbo].[Employees] (
    [EmpSysId]         INT             IDENTITY (1, 1) NOT NULL,
    [EmployeeNumber]   INT             NOT NULL,
    [SupervisorNumber] INT             NULL,
    [EmploymentType]   NVARCHAR (MAX)  NULL,
    [FTE]              DECIMAL (18, 2) NULL,
    [Active]           BIT             NOT NULL,
    [StartDate]        DATETIME2 (7)   NULL,
    [EndDate]          DATETIME2 (7)   NULL,
    [CreateId]         INT             NOT NULL,
    [CreateDate]       DATETIME2 (7)   NOT NULL,
    [UpdateId]         INT             NULL,
    [UpdateDate]       DATETIME2 (7)   NULL,
    [FirstName]        NVARCHAR (50)   NOT NULL,
    [JobRoleId]        INT             NULL,
    [LastName]         NVARCHAR (50)   NOT NULL,
    [TeamId]           INT             NOT NULL,
    [Title]            NVARCHAR (50)   NULL,
    [IsSupervisor]     BIT             NOT NULL,
    CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED ([EmpSysId] ASC),
    CONSTRAINT [FK_Employees_JobRoles_JobRoleId] FOREIGN KEY ([JobRoleId]) REFERENCES [dbo].[JobRoles] ([JobRoleId]),
    CONSTRAINT [FK_Employees_Teams_TeamId] FOREIGN KEY ([TeamId]) REFERENCES [dbo].[Teams] ([TeamId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_Employees_JobRoleId]
    ON [dbo].[Employees]([JobRoleId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Employees_TeamId]
    ON [dbo].[Employees]([TeamId] ASC);

