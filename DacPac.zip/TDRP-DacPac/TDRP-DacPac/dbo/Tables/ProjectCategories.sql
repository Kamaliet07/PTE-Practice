﻿CREATE TABLE [dbo].[ProjectCategories] (
    [CategoryId] INT           IDENTITY (1, 1) NOT NULL,
    [Name]       NVARCHAR (50) NOT NULL,
    [CreateId]   INT           NOT NULL,
    [CreateDate] DATE          NOT NULL,
    [UpdateId]   INT           NULL,
    [UpdateTime] DATE          NULL,
    CONSTRAINT [PK_ProjectCategories] PRIMARY KEY CLUSTERED ([CategoryId] ASC)
);

