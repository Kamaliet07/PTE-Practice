﻿CREATE TABLE [dbo].[JobRoles] (
    [JobRoleId]          INT            IDENTITY (1, 1) NOT NULL,
    [JobRole]            NVARCHAR (150) NULL,
    [JobRoleDescription] NVARCHAR (450) NULL,
    [Active]             BIT            NOT NULL,
    [CreatedDate]        DATETIME2 (7)  NULL,
    [UpdatedDate]        DATETIME2 (7)  NULL,
    CONSTRAINT [PK_JobRoles] PRIMARY KEY CLUSTERED ([JobRoleId] ASC)
);

