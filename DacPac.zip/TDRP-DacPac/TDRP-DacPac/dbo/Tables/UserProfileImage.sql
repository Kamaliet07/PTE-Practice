﻿CREATE TABLE [dbo].[UserProfileImage] (
    [SysId]   INT             IDENTITY (1, 1) NOT NULL,
    [UserId]  NVARCHAR (450)  NULL,
    [Name]    NVARCHAR (15)   NOT NULL,
    [Picture] VARBINARY (MAX) NULL,
    [Active]  BIT             NOT NULL,
    CONSTRAINT [PK_UserProfileImage] PRIMARY KEY CLUSTERED ([SysId] ASC)
);

