﻿CREATE TABLE [dbo].[Projects] (
    [ProjectId]          INT             IDENTITY (1, 1) NOT NULL,
    [ProjectName]        NVARCHAR (100)  NOT NULL,
    [StartDate]          DATETIME2 (7)   NULL,
    [EndDate]            DATETIME2 (7)   NULL,
    [CreatedDate]        DATETIME2 (7)   NULL,
    [CreateId]           INT             NOT NULL,
    [UpdatedDate]        DATETIME2 (7)   NULL,
    [UpdateId]           INT             NULL,
    [Category]           NVARCHAR (50)   NULL,
    [ProjectDescription] NVARCHAR (2000) NULL,
    [EstimatedBudget]    DECIMAL (18, 2) NULL,
    [TotalExpenditure]   DECIMAL (18, 2) NULL,
    [TeamId]             INT             NULL,
    CONSTRAINT [PK_Projects] PRIMARY KEY CLUSTERED ([ProjectId] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IX_Projects_TeamId]
    ON [dbo].[Projects]([TeamId] ASC);

