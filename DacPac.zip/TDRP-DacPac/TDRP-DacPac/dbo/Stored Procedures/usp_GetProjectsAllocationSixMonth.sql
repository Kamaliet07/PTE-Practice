﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 04-MARCH-2020
-- Description:	Retrieves the list of project allocation for next six month
--				
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetProjectsAllocationSixMonth] 
	-- Add the parameters for the stored procedure here	
	@EmployeeNo int
	
AS
BEGIN	
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	-- Declare the variable used in store procedure
	DECLARE 
	@loopCounter int = 0,
	@monthId int,
	@WorkingDays int,
	@AllocatedDays int,
	@CurrentDate Date,
	@HoliDays int,
	@MonthName CHAR(12),
	@Year int

	-- Declare the table variable
	DECLARE @Allocation_table TABLE (
    MonthName CHAR(12) NOT NULL,
    WorkingDays INT NOT NULL,
    AllocatedDays INT NOT NULL,
	Year INT NOT NULL
    );
	-- Validate input paremeter
	IF (@EmployeeNo IS NOT NULL)
	 BEGIN
	 --- Select Current Month Id
	   SELECT @monthId = mn.MonthId FROM dbo.Months as mn WHERE mn.MonthName = (Select DATENAME(mm,GETDATE()))
	   SET @Year = YEAR(GETDATE());

       WHILE ( @loopCounter <= 5)
         BEGIN    
	        SELECT @MonthName = mt.MonthName FROM dbo.Months AS mt  WHERE mt.MonthId = @monthId
            SELECT @CurrentDate  =  dbo.GetMonthFirstDate(@MonthName, @Year)
			SELECT @HoliDays = mn.Holidays FROM dbo.Months mn WHERE mn.MonthName = @MonthName
	        -- Get the total working days in the month
			SELECT @WorkingDays = (SELECT DAY(EOMONTH(@CurrentDate))) - (SELECT dbo.GetWeekendDaysCount(@CurrentDate)) -@HoliDays
			-- Not used Join because if project not assigned for any month then it will return null instead of 0		 
			SELECT @AllocatedDays = COALESCE(SUM(aw.AllocatedDays),0) FROM dbo.ProjectAllocation AS aw WHERE aw.EmployeeNumber = @EmployeeNo AND  aw.MonthId = @monthId AND aw.Year = @Year
			
			INSERT INTO @Allocation_table
			SELECT   @MonthName AS MonthName, @WorkingDays AS WorkingDays, @AllocatedDays, @Year

			-- Increment loop counter and monthId.  If monthId is greater than 12 set it back to 1 for forecasts
			-- where 6 months could overlap to the next year. 
			SET @monthId = @monthId + 1;
			SET @loopCounter = @loopCounter + 1;

			IF @monthId > 13
			BEGIN 
				SET @monthId = 2;
				SET @Year = @Year + 1;
			END
         END

		 -- Return Value
        SELECT * FROM @Allocation_table
	  END	
	   
	END TRY
	
	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	      
	        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
