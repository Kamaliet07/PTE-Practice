﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 05-MARCH-2020
-- Description:	Retrieves the list of all projects assigned to resource
--				
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAllocationDetails] 
	-- Add the parameters for the stored procedure here	
	@EmployeeNo int,
	@ProjectId int,
	@Month char(12),
	@Year int
AS
BEGIN	
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
       DECLARE @monthId int;
       SELECT @monthId = mn.MonthId FROM dbo.Months as mn WHERE mn.MonthName = @Month

	   SELECT aw.AllocatedDays, aw.WorkingDays
       FROM  dbo.ProjectAllocation AS aw 
	   WHERE  aw.EmployeeNumber = @EmployeeNo AND  aw.MonthId = @monthId AND aw.ProjectId = @ProjectId
	   AND	 aw.Year = @Year;
	   
	END TRY
	
	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	      
	        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
