﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 28-Jul-2020
-- Description:	Gets assigned employees for the month.
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAllocatedEmployeesMonth]
	-- Add the parameters for the stored procedure here
	@ProjectId INT,
	@Year INT,
	@Month VARCHAR(20)
AS
BEGIN
	BEGIN TRY
		DECLARE
		@MonthId INT

		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		SELECT @MonthId = m.MonthId FROM Months AS m WHERE m.MonthName = @Month;

		SELECT  pa.ProjectId,
				p.ProjectName,
				pa.EmployeeNumber,
				e.FirstName + ' ' + e.LastName AS EmployeeName,
				pa.TeamId,
				t.TeamName,
				pa.AllocatedDays,
				pa.MonthId,
				pa.Year
		FROM	ProjectAllocation AS pa
		INNER JOIN Employees AS e ON e.EmployeeNumber = pa.EmployeeNumber
		INNER JOIN Teams AS t ON t.TeamId = pa.TeamId
		INNER JOIN Projects AS p ON p.ProjectId = pa.ProjectId
		WHERE	pa.Year = @Year
		AND		pa.ProjectId = @ProjectId
		AND		pa.MonthId = @MonthId
		AND		e.EndDate IS NULL;
	END TRY
	BEGIN CATCH
		-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
		DECLARE   @errorMessage     VARCHAR    (500)
				, @errorNumber      VARCHAR    (Max)
				, @errorSeverioty   VARCHAR    (1000)
				, @errorState       VARCHAR    (1000)
				, @errorLine        VARCHAR    (500)
				, @errorProcedure   VARCHAR    (500)
		-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
		SELECT   @errorNumber     = ERROR_NUMBER()
				,@errorSeverioty  = ERROR_SEVERITY()
				,@errorState      = ERROR_STATE()
				,@errorLine       = ERROR_LINE()
				,@errorProcedure  = ERROR_PROCEDURE()	      
	        
		SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
		RAISERROR
			(
				 @errorMessage
				,@errorSeverioty
				,@errorState
				,@errorLine
				,@errorProcedure
				,@errorNumber
			)
	END CATCH
END