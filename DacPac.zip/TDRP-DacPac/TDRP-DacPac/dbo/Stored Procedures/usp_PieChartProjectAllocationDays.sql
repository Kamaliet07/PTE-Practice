﻿-- ====================================================
-- Author:		Stewart Dunn
-- Create date: 05-May-2020
-- Description:	Get all of the allocated days for each
--				project in a month for the user's team.
-- ====================================================
CREATE PROCEDURE [dbo].[usp_PieChartProjectAllocationDays]
	-- Add the parameters for the stored procedure here
	@TeamId INT,
	@MonthId INT,
	@Year INT
AS
BEGIN
	BEGIN TRY
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Select the total sum of allocated days for each project in a month.
		SELECT	 SUM(pa.AllocatedDays) AS AllocatedDays,
				 pa.MonthId,
				 pa.TeamId,
				 prj.ProjectName
		FROM	 ProjectAllocation AS pa
		INNER JOIN Projects AS prj ON prj.ProjectId = pa.ProjectId
		WHERE	 pa.MonthId = @MonthId
		AND		 pa.Year = @Year
		AND		 pa.TeamId = @TeamId
		GROUP BY pa.MonthId,
				 pa.TeamId,
				 prj.ProjectName;
			 	   
	END TRY
	
	BEGIN CATCH
		-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
		DECLARE   @errorMessage     VARCHAR    (500)
				, @errorNumber      VARCHAR    (Max)
				, @errorSeverioty   VARCHAR    (1000)
				, @errorState       VARCHAR    (1000)
				, @errorLine        VARCHAR    (500)
				, @errorProcedure   VARCHAR    (500)
		-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
		SELECT   @errorNumber     = ERROR_NUMBER()
				,@errorSeverioty  = ERROR_SEVERITY()
				,@errorState      = ERROR_STATE()
				,@errorLine       = ERROR_LINE()
				,@errorProcedure  = ERROR_PROCEDURE()	      
	        
		SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
		RAISERROR
			(
				 @errorMessage
				,@errorSeverioty
				,@errorState
				,@errorLine
				,@errorProcedure
				,@errorNumber
			)
	END CATCH
END
