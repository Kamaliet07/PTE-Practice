﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 28-JAN-2020
-- Description:	Retrives Employees that are not 
-- assigned to a project.
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetUnassignedEmployees]
	-- Add the parameters for the stored procedure here
	@ProjectId int
AS
BEGIN
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	SELECT	e.EmployeeNumber
		   ,e.FirstName + ' ' + e.LastName AS EmployeeName
		   ,e.FTE
		   ,t.TeamName
		   ,j.JobRole
		   ,(SELECT emp.FirstName + ' ' + emp.LastName
		     FROM	Employees AS emp
			 WHERE	e.SupervisorNumber = emp.EmployeeNumber) AS SupervisorName
	FROM	Employees AS e
	LEFT JOIN Teams AS t ON t.TeamId = e.TeamId
	LEFT JOIN JobRoles AS j ON j.JobRoleId = e.JobRoleId
	WHERE	NOT EXISTS(SELECT * 
					   FROM AssignedWork AS a 
					   WHERE a.ProjectId = @ProjectId
					   AND	 a.EmployeeNumber = e.EmployeeNumber
					   AND	 a.EndDate IS NULL)
	AND	     e.EmployeeNumber IS NOT NULL
	and		 e.EndDate IS NULL
	AND		 e.Active = 1;
	
	END TRY

	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	        
		        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END