﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 07-May-2020
-- Description:	Retrieves total Days available and assigned
--				days to projects for the bar chart
--				on the main dashboard of the app.
-- =============================================
CREATE PROCEDURE [dbo].[usp_AreaChartDataAllocation] 
	-- Add the parameters for the stored procedure here
	@TeamId  INT,
	@MonthId INT
AS
BEGIN
	BEGIN TRY
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE
		@loopCounter INT = 0,
		@WorkingDays int,
		@AllocatedDays int,
		@CurrentDate Date,
		@Holidays int,
		@MonthName CHAR(12),
		@HoursInMonth decimal,
		@FteDays int,
		@Year int = YEAR(GETDATE())

		DECLARE @AllocationTable TABLE(
		MonthName CHAR(12) NOT NULL,
		AllocatedDays INT NOT NULL,
		WorkingDays INT NOT NULL,
		DaysInMonth INT NOT NULL,
		Year INT NOT NULL
		);

		WHILE(@loopCounter <= 5)
			BEGIN
				SELECT @MonthName = mt.MonthName FROM dbo.Months AS mt  WHERE mt.MonthId = @MonthId
				SELECT @CurrentDate  =  dbo.GetMonthFirstDate(@MonthName, @Year)
				SELECT @Holidays = mn.Holidays FROM dbo.Months mn WHERE mn.MonthName = @MonthName
				-- Get the total working days in the month
				SELECT @WorkingDays = (SELECT DAY(EOMONTH(@CurrentDate))) - (SELECT dbo.GetWeekendDaysCount(@CurrentDate));
				SELECT @WorkingDays = @WorkingDays - @Holidays;
				-- Get the total available hours for the month.
				SELECT @HoursInMonth = @WorkingDays * 7;
			    -- Calculate the number of days the employee is available to work in the month based on their weekly FTE.
				SELECT @FteDays = CEILING((((SELECT SUM(e.FTE) FROM Employees AS e WHERE e.TeamId = @TeamId AND e.Active = 1) / 35) * @HoursInMonth) / 7);
				
				-- SELECT Allocated Hours on Projects and Total Hours using the Team ID and Month
				SELECT	@AllocatedDays = ISNULL(SUM(pa.AllocatedDays), 0)
				FROM	ProjectAllocation AS pa
				WHERE	pa.TeamId = @TeamId
				AND		pa.AllocatedDays IS NOT NULL
				AND		pa.MonthId = @MonthId
				AND		pa.Year = @Year;

				INSERT INTO @AllocationTable
				SELECT   @MonthName AS MonthName, @AllocatedDays, @FteDays, @WorkingDays, @Year

				-- Loop Increment
				SET @loopCounter = @loopCounter + 1;
				SET @MonthId = @MonthId + 1;

				-- If the month Id is greater than December reset the month to January and increase the year by 1.
				IF @monthId > 13
				BEGIN 
					SET @monthId = 2;
					SET @Year = @Year + 1;
				END
			END

			SELECT * FROM @AllocationTable;
    END TRY	

	BEGIN CATCH
		-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
		DECLARE   @errorMessage     VARCHAR    (500)
				, @errorNumber      VARCHAR    (Max)
				, @errorSeverioty   VARCHAR    (1000)
				, @errorState       VARCHAR    (1000)
				, @errorLine        VARCHAR    (500)
				, @errorProcedure   VARCHAR    (500)
		-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
		SELECT   @errorNumber     = ERROR_NUMBER()
				,@errorSeverioty  = ERROR_SEVERITY()
				,@errorState      = ERROR_STATE()
				,@errorLine       = ERROR_LINE()
				,@errorProcedure  = ERROR_PROCEDURE()	        
		        
		SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
		RAISERROR
			(
				 @errorMessage
				,@errorSeverioty
				,@errorState
				,@errorLine
				,@errorProcedure
				,@errorNumber
			)
	END CATCH
END
