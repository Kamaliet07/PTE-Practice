﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 23-Jul-2020
-- Description:	Retrieve all assigned employees 
--				by Project ID.
-- Changes:
-- Altered main query to accept Unnamed Resources.
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAssignedEmployees]
	-- Add the parameters for the stored procedure here
	@ProjectId INT
AS
BEGIN
	BEGIN TRY
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		SELECT  aw.AssignedWorkId,
				ISNULL((SELECT e.EmployeeNumber
						FROM   Employees AS e
						WHERE  aw.EmployeeNumber = e.EmployeeNumber), 0) AS EmployeeNumber,
				ISNULL((SELECT e.FirstName + ' ' + e.LastName
						FROM   Employees AS e
						WHERE  aw.EmployeeNumber = e.EmployeeNumber), 'Unnamed Resource') AS EmployeeName,
				aw.TeamId,
				t.TeamName,
				aw.UnnamedResource
		FROM    AssignedWork AS aw
		INNER JOIN Teams AS t ON t.TeamId = aw.TeamId
		WHERE	aw.ProjectId = @ProjectId
		AND		aw.EndDate IS NULL;
	END TRY
	BEGIN CATCH 
		-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
		DECLARE   @errorMessage     VARCHAR    (500)
				, @errorNumber      VARCHAR    (Max)
				, @errorSeverioty   VARCHAR    (1000)
				, @errorState       VARCHAR    (1000)
				, @errorLine        VARCHAR    (500)
				, @errorProcedure   VARCHAR    (500)
		-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
		SELECT   @errorNumber     = ERROR_NUMBER()
				,@errorSeverioty  = ERROR_SEVERITY()
				,@errorState      = ERROR_STATE()
				,@errorLine       = ERROR_LINE()
				,@errorProcedure  = ERROR_PROCEDURE()	        
		        
		SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
		RAISERROR
		(
				@errorMessage
			,@errorSeverioty
			,@errorState
			,@errorLine
			,@errorProcedure
			,@errorNumber
		)
	END CATCH 
END
