﻿-- =============================================
-- Author:		Stewart Dunn
-- Create date: 02-MARCH-2020
-- Description:	Retrieves the list of all projects assigned to resource
--				
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetAssignedProjects] 
	-- Add the parameters for the stored procedure here	
	@EmployeeNo int,
	@ProjectId int = null,
	@Month char(12)	= null,
	@Year int
AS
BEGIN	
	BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @monthId int;
	-- Get the current month
	IF (@Month IS NULL)
	 BEGIN
	 --- Select Current Month Id
	   SELECT @monthId = mn.MonthId FROM dbo.Months as mn WHERE mn.MonthName = (Select DATENAME(mm,GETDATE()))

	   SELECT  prj.ProjectId, prj.ProjectName, aw.ProjAllocationId, aw.AllocatedDays, mn.MonthName, aw.WorkingDays
         FROM  dbo.ProjectAllocation AS aw INNER JOIN
            dbo.Projects AS prj ON aw.ProjectId = prj.ProjectId INNER JOIN 
			dbo.Months AS mn on mn.MonthId = aw.MonthId
	     WHERE  aw.EmployeeNumber = @EmployeeNo
	       AND    aw.MonthId = @monthId
		   AND	  aw.Year = @Year
	  END

	ELSE
	  BEGIN
	   SELECT @monthId = mn.MonthId FROM dbo.Months as mn WHERE mn.MonthName = @Month

	   SELECT  prj.ProjectId, prj.ProjectName, aw.ProjAllocationId, aw.AllocatedDays, mn.MonthName, aw.WorkingDays
         FROM  dbo.ProjectAllocation AS aw INNER JOIN
            dbo.Projects AS prj ON aw.ProjectId = prj.ProjectId INNER JOIN 
			dbo.Months AS mn on mn.MonthId = aw.MonthId
	     WHERE  aw.EmployeeNumber = @EmployeeNo
	       AND    aw.MonthId = @monthId
		   AND	  aw.Year = @Year
	   END
	   
	END TRY
	
	BEGIN CATCH
	-- DECLARATION OF LOCAL VARIABLE FOR LOGGING
	DECLARE   @errorMessage     VARCHAR    (500)
	        , @errorNumber      VARCHAR    (Max)
	        , @errorSeverioty   VARCHAR    (1000)
	        , @errorState       VARCHAR    (1000)
	        , @errorLine        VARCHAR    (500)
	        , @errorProcedure   VARCHAR    (500)
	-- ASSIGN VARIABLE TO ERROR HANDLING FUNCTION THAT CAPTURE THE INFORMATION FOR RAISE ERROR
	
	SELECT   @errorNumber     = ERROR_NUMBER()
	        ,@errorSeverioty  = ERROR_SEVERITY()
	        ,@errorState      = ERROR_STATE()
	        ,@errorLine       = ERROR_LINE()
	        ,@errorProcedure  = ERROR_PROCEDURE()	      
	        
	SET @errorMessage         = 'Error %s, Level %s, State %s, Procedure %s, Line %s, Message: '+ ERROR_MESSAGE();
	
	RAISERROR
	    (
	         @errorMessage
	        ,@errorSeverioty
	        ,@errorState
	        ,@errorLine
	        ,@errorProcedure
	        ,@errorNumber
	    )
	END CATCH
END
