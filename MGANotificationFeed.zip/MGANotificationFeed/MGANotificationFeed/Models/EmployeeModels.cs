﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MGANotificationFeed.Models
{
    public class EmployeeModels
    {
        public string FName { get; set; }

        public string MName { get; set; }

        public string LName { get; set; }

        public string EmailId { get; set; }

        public string Country { get; set; }

        public string State { get; set; }
    }
}