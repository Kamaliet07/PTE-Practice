﻿using MGANotification.BAL;
using MGANotificationFeed.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace MGANotificationFeed.Controllers
{
    public class MGANotificationController : ApiController
    {
        
        public async Task<IEnumerable<EmployeeModels>> GetMGANotificationAsync()
        {
            try
            {
                var returnValue = new List<EmployeeModels>();
                using (MGANotificationBL mgsBL = new MGANotificationBL())
                {


                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }

    }
}
