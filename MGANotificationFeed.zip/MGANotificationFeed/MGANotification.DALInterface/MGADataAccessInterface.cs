﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MGANotification.DALInterface
{
   public interface MGADataAccessInterface
    {
        IDbConnection GetConnection();
        bool CloseConnection(ref IDbConnection connection);
        int ExecuteNonQuery(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage);
        int ExecuteNonQuery(string commandText, CommandType type, ref string errorMessage);
        int ExecuteNonQuery(IDbCommand command, ref string errorMessage);
        IDataReader ExecuteReader(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage, ref IDbConnection connection);
        IDataReader ExecuteReader(string commandText, CommandType type, ref string errorMessage, ref IDbConnection connection);
        IDataReader ExecuteReader(IDbCommand command, ref string errorMessage, ref IDbConnection connection);
        Object ExecuteScalar(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage);
        Object ExecuteScalar(string commandText, CommandType type, ref string errorMessage);
        Object ExecuteScalar(IDbCommand command, ref string errorMessage);
        DataSet GetDataSet(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage);
        DataSet GetDataSet(string commandText, CommandType type, ref string errorMessage);
        DataSet GetDataSet(IDbCommand command, ref string errorMessage);
        DataSet GetDataSet(string xmlFilePath, ref string errorMessage);
        DataTable GetDataTable(string commandText, CommandType type, IDataParameter[] parameter, ref string errorMessage);
        DataTable GetDataTable(string commandText, CommandType type, ref string errorMessage);
        DataTable GetDataTable(IDbCommand command, ref string errorMessage);
        string ConnectionString
        {
            get;
            set;
        }
    }
}
