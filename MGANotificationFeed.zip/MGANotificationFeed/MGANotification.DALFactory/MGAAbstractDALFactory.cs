﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MGANotification.DALFactory
{
   public abstract class MGAAbstractDALFactory
    {
        //public static MGAAbstractDALFactory CreateDBObject(string databaseType)
        //{
        //    return new SqlFactory();
        //}
        abstract public IDbConnection CreateConnection(string connectionString);
        abstract public IDbCommand CreateCommand(string commandText);
        abstract public IDbCommand CreateCommand();
        abstract public IDataAdapter CreateAdapter(string commandText);
        abstract public IDataAdapter CreateAdapter();
        abstract public IDataParameter CreateParameter();
        abstract public IDataParameter CreateParameter(string name, Object value);
        abstract public IDataParameter CreateParameter(string name, DbType type);
        abstract public IDataParameter CreateParameter(string name, DbType type, int size);
        abstract public Object GetParameterValue(Object parameter);
        abstract public string ConnectionString
        {
            get;
        }
    }
}
