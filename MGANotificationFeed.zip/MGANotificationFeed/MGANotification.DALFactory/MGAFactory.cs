﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MGANotification.DALInterface;

namespace MGANotification.DALFactory
{
   public class MGAFactory
    {
        private string _DBType;

        public string DBType
        {
            get
            {
                return _DBType;
            }
            set
            {
                value = _DBType;
            }
        }

        public MGAFactory(string DataBaseType)
        {
            this._DBType = DataBaseType;
        }

        /**************************************************************************************************
         METHOD NAME : GetDBProvider
         PARAMETERS  : None
         RETURN TYPE : Returns type of database method's Access 
         CREATE DATE : 23-APRIL-2009
         MODIFY DATE :  
        **************************************************************************************************/
        public MGADataAccessInterface GetDBProvider()
        {
            return new MGANotification.DataAccess.MGADataAccess();
        }
    }
}
